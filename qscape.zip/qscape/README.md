# Q-SCAPE — Quest Simulation & Collision Analysis Platform Environment

Q-SCAPE tests how autonomous vehicles (**AVs**) avoid collisions. Two or more AVs drive a saved route one behind
the other. Each AV brakes only on what its own simulated sensors report: camera, LiDAR, radar and, if switched on,
V2V messages. Climates such as fog, rain, snow and night change what the sensors can detect. The test window shows
every AV's sensors, detections, time to collision (TTC), braking and collisions. For each collision it also shows
why it happened (climate, detected too late, range or speed) and how to avoid it. Results and full replays are kept
in **Reports**.

## What is in it
- **Sign-in**: the first start creates the administrator account. The administrator adds and approves the other
  users. Each user sees their own sites and the sites an administrator shares with them.
- **Sites from the map**: Sites menu (top left) → *New site from the map*. Search for a place and draw its outline.
  Its surroundings (buildings, roads, trees, terrain) are downloaded from OpenStreetMap.
- **2D map** (Leaflet) and **3D view** (three.js, `assets/web/yard3d.html`): climates, an optional satellite
  ground, and LiDAR and camera views.
- **AVs**: drag the AV icon onto the map. An AV can drive a saved route or a path you draw.
- **Obstacles, traffic and scenarios**: cars, outer trucks, pedestrians, vans, buses and trucks with trailers.
  They can be static or move along a path. Scenarios are saved sets of obstacles, including traffic on every road.
- **Routes**: from a source to a destination along the roads, or drawn point by point.
- **Collision Testing** (top bar): pick the route, the AVs (speed, gap, sensors), loops, a plan for each loop
  (climate, speeds, stop & go) and V2V. Start the test. The ⓘ button explains how each sensor, the braking and the
  collision reasons work. **Sensors** (top bar) switches between simulated and real-world sensor processing.
- **Reports**: each test's results. The ▶ icon replays a saved test (play / pause, speed, seek, jump to each
  collision).
- **Publish to hardware** (optional): during a test, each AV's live state can be sent as an MQTT message
  (`hw_publish.py`) to drive model vehicles, e.g. `hardware/esp32_l298n_car`. `tools/mqtt_hw_monitor.py` and
  `tools/mqtt_hw_simulator.py` help with testing.

## Run on Windows
```
cd qscape
py -3.12 -m venv .venv            (Python 3.10 – 3.12)
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python main.py
```

## Run on Ubuntu (22.04 / 24.04)
```
cd qscape
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
./run_ubuntu.sh                   (or: .venv/bin/python main.py)
```
If the window does not open, install Qt's system libraries:
`sudo apt install libxkbcommon-x11-0 libxcb-cursor0 libnss3 libxcomposite1 libxdamage1 libxrandr2 libxtst6`.

## Quick start with the demo site (Technopark)
1. Start the app and create the administrator account.
2. Top bar → **Collision Testing**. Choose a route (e.g. *Quest_Main_Entrance*), 2 AVs and a climate, then
   **Start**. Answer *Yes* to "Save this test for replay?".
3. When the test ends, open it in **Reports** → ▶ to replay it.

## Folders
| Path | What |
|---|---|
| `main.py` | start: sign-in, site, main window |
| `shipyard.py` | the main window (`MapWindow`): map, 3D, AVs, obstacles, routes, scenarios, collision tests |
| `collision_panel.py`, `collision_replay.py`, `collision_info.py`, `collision_tech.py` | test window and set-up, replay, the "how it works" window |
| `follow_test.py`, `real_sensors.py`, `real_camera.py`, `sensor_mode.py`, `v2v.py` | sensor models, braking, V2V |
| `sensor_slides*.py`, `sensor_graphics.py`, `tech_graphics.py`, `follow_panel.py` | pictures and widgets of the info / test windows |
| `yard_from_map.py`, `osm_surroundings.py`, `terrain.py`, `real_world.py`, `road_router.py`, `config_loader.py`, `yard_manager.py` | sites from the map, surroundings, roads |
| `scenarios.py`, `hw_publish.py`, `auth.py`, `site_config.py`, `crash_guard.py`, `log_filter.py`, `screen_utils.py`, `window_tray.py` | scenarios, hardware publishing, users, paths / settings, robustness |
| `config/` | app settings, climates, obstacle types, the AV body (vehicle_dimensions.json); `users.json` is made at the first start |
| `sites/<site>/` | `cc_config/` (map parameter file), `data/avs.json`, `obstacles.json`, `scenarios.json`, `osm_surroundings.json`, `routes/*.txt`, `collision_setups.json`, `reports/collision_tests/` |
| `tests/av_runs.py` | functional test: `python tests/av_runs.py nov2v` (1 collision expected), `v2v` (0 collisions, 1 "V2V prevented"), `replay` (opens the newest replay) |
| `tools/check_py310.py` | finds code that Python 3.10 cannot parse (needs Python 3.12 to run) |

Errors in Qt callbacks are written to `logs/app_errors.log` (the app keeps running).
