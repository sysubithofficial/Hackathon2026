#!/usr/bin/env bash
# Starts Q-SCAPE on Ubuntu from its own .venv (made once -- see README.md):
#   python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
cd "$(dirname "$0")"
export PYTHONNOUSERSITE=1                        # (~/.local packages: not used)
if [ ! -f .venv/bin/activate ]; then
  echo "No .venv here -- run once:  python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi
. .venv/bin/activate
if [ "$(id -u)" = 0 ]; then
  export QTWEBENGINE_DISABLE_SANDBOX=1           # (Qt WebEngine runs as root only without its sandbox)
fi
exec python main.py "$@"
