"""The EASY technical pictures (info window → View → Technical overview), registered as "easy_<deck>".

The questions an evaluator asks about every sensor, answered with pictures and very little text, always in the same
order (the coloured band at the top shows where you are):
  1 REAL WORLD   how the real sensor works (animated)
  2 OUR APP      how our simulation does it: 3 - 4 boxes, a message travelling through them
  3 DETECTION    one worked example with real numbers (from the models themselves)
  4 REAL ↔ APP   each real-world feature: ✓ SAME · ≈ SIMPLIFIED · ✕ NOT MODELLED in our app
  5 LIMITS       what is not in our app (✕) and why the results still hold (✓)
V2V has two real-world steps (the radio link; around obstacles + the standards).
"""
import math
import random

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QFont, QPainterPath, QPen, QPolygonF

import follow_test as ft
import sensor_slides as S
import sensor_slides_tech as TT
import v2v
from sensor_graphics import AMBER, COL, GREEN, MUTED, OTHER, OURS, RED, TXT, _arrow, _c, _fog, _mark, _road, _text, \
    _vehicle, draw_icon

H = 340
HL = "#FDE68A"
KEY_C = "#C4B5FD"             # 'what the numbers mean' under each calculation
REAL_C = "#7DD3FC"            # the real world
APP_C = GREEN                 # our app
BADGE = {"same": (GREEN, "✓ SAME"), "approx": (AMBER, "≈ SIMPLIFIED"), "no": (RED, "✕ NOT MODELLED")}
TAGS5 = ("REAL WORLD", "OUR APP", "DETECTION", "REAL ↔ APP", "LIMITS")


def _al(col, a):
    return _c(col, max(0.0, min(1.0, a))).name(QColor.HexArgb)


# ------------------------------------------------------------------ common parts
def _band(p, tags, k):
    """The progress band: the 4 - 6 questions, the current one highlighted."""
    n = len(tags)
    w = 788.0 / n
    for i, t in enumerate(tags):
        r = QRectF(6 + i * w + 2, 4, w - 4, 24)
        cur, done = i + 1 == k, i + 1 < k
        col = HL if cur else GREEN if done else "#475569"
        p.setPen(QPen(_c(col), 1.8 if cur else 1)); p.setBrush(_c(col, 0.2 if cur else 0.05))
        p.drawRoundedRect(r, 12, 12)
        _text(p, r.center().x(), r.top() + 17, f"{i + 1}  {t}", col, 11, True, Qt.AlignCenter, w - 6)


def _callouts(p, items, x=470, y=56, w=320, col=REAL_C, dy=None):
    """Numbered points that appear one after the other (the real-world pictures)."""
    dy = dy or (215.0 / max(1, len(items)))
    for i, t in enumerate(items):
        al = S._appear(i + 1, 0.55)
        bad = t.startswith("✕")
        c = RED if bad else col
        yy = y + i * dy
        p.setPen(Qt.NoPen); p.setBrush(_c(c, al)); p.drawEllipse(QPointF(x + 12, yy + 10), 12, 12)
        _text(p, x + 12, yy + 15, "!" if bad else str(i + 1), _al("#0B1220", al), 12, True, Qt.AlignCenter, 24)
        _text(p, x + 32, yy + 14, t.lstrip("✕ "), _al(TXT, al), 13, True, w=w - 32)


def _icon(p, kind, c, s, col):
    """A simple icon of size s centred at c."""
    x, y = c.x(), c.y()
    p.save()
    pen = QPen(_c(col), 2.2); pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    if kind in ("camera", "LiDAR", "radar", "V2V"):
        draw_icon(p, kind, QRectF(x - s / 2, y - s / 2, s, s), col, 2.4)
    elif kind == "list":                                   # the scene's object list
        for i in range(4):
            yy = y - s * 0.33 + i * s * 0.22
            p.drawEllipse(QPointF(x - s * 0.36, yy), 2.5, 2.5)
            p.drawLine(QPointF(x - s * 0.22, yy), QPointF(x + s * 0.4, yy))
    elif kind == "code":                                   # Python logic
        f = QFont("Consolas"); f.setPixelSize(int(s * 0.55)); f.setBold(True); p.setFont(f)
        p.drawText(QRectF(x - s / 2, y - s / 2, s, s), Qt.AlignCenter, "{ }")
    elif kind == "check":
        _mark(p, x, y, True, s * 0.38)
    elif kind == "cube":                                   # the 3D page
        a = s * 0.32
        top = QPolygonF([QPointF(x, y - a), QPointF(x + a, y - a / 2), QPointF(x, y), QPointF(x - a, y - a / 2)])
        p.drawPolygon(top)
        p.drawLine(QPointF(x - a, y - a / 2), QPointF(x - a, y + a / 2)); p.drawLine(QPointF(x + a, y - a / 2),
                                                                                     QPointF(x + a, y + a / 2))
        p.drawLine(QPointF(x, y), QPointF(x, y + a)); p.drawLine(QPointF(x - a, y + a / 2), QPointF(x, y + a))
        p.drawLine(QPointF(x, y + a), QPointF(x + a, y + a / 2))
    elif kind == "points":                                 # a point cloud
        rnd = random.Random(4)
        p.setPen(Qt.NoPen); p.setBrush(_c(col))
        for _ in range(26):
            p.drawEllipse(QPointF(x + rnd.uniform(-s * 0.42, s * 0.42), y + rnd.uniform(-s * 0.32, s * 0.32)), 2, 2)
    elif kind == "image":                                  # a picture
        p.drawRoundedRect(QRectF(x - s * 0.45, y - s * 0.33, s * 0.9, s * 0.66), 4, 4)
        p.drawPolyline(QPolygonF([QPointF(x - s * 0.4, y + s * 0.25), QPointF(x - s * 0.1, y - s * 0.08),
                                  QPointF(x + s * 0.08, y + s * 0.12), QPointF(x + s * 0.2, y),
                                  QPointF(x + s * 0.4, y + s * 0.25)]))
        p.drawEllipse(QPointF(x + s * 0.22, y - s * 0.17), 3, 3)
    elif kind == "tower":                                  # a mobile-network mast
        p.drawLine(QPointF(x, y - s * 0.3), QPointF(x - s * 0.22, y + s * 0.42))
        p.drawLine(QPointF(x, y - s * 0.3), QPointF(x + s * 0.22, y + s * 0.42))
        p.drawLine(QPointF(x - s * 0.12, y + s * 0.1), QPointF(x + s * 0.12, y + s * 0.1))
        for rr in (0.16, 0.3):
            p.drawArc(QRectF(x - rr * s, y - s * 0.3 - rr * s, 2 * rr * s, 2 * rr * s), 30 * 16, 120 * 16)
    elif kind == "cloud":
        path = QPainterPath()
        for dx, dy, r in ((-0.2, 0.05, 0.18), (0.0, -0.08, 0.22), (0.22, 0.05, 0.17)):
            path.addEllipse(QPointF(x + dx * s, y + dy * s), r * s, r * s)
        p.setBrush(_c(col, 0.15)); p.drawPath(path.simplified())
    elif kind == "truck":
        _vehicle(p, QRectF(x - s * 0.45, y - s * 0.18, s * 0.9, s * 0.36), col, "")
    elif kind == "brake":                                  # an octagon
        pts = [QPointF(x + s * 0.4 * math.cos(math.radians(22.5 + 45 * k)),
                       y + s * 0.4 * math.sin(math.radians(22.5 + 45 * k))) for k in range(8)]
        p.setBrush(_c(RED, 0.8)); p.setPen(QPen(_c("#FFFFFF"), 1.5)); p.drawPolygon(QPolygonF(pts))
        f = QFont(); f.setPixelSize(int(s * 0.2)); f.setBold(True); p.setFont(f); p.setPen(_c("#FFFFFF"))
        p.drawText(QRectF(x - s / 2, y - s / 2, s, s), Qt.AlignCenter, "STOP")
    elif kind == "merge":                                  # several into one
        for dy in (-0.3, 0.0, 0.3):
            p.drawLine(QPointF(x - s * 0.42, y + dy * s), QPointF(x, y))
        _arrow(p, QPointF(x, y), QPointF(x + s * 0.42, y), col, 2.4, 8)
    elif kind == "filter":                                 # a funnel
        p.drawPolygon(QPolygonF([QPointF(x - s * 0.4, y - s * 0.3), QPointF(x + s * 0.4, y - s * 0.3),
                                 QPointF(x + s * 0.08, y + s * 0.05), QPointF(x + s * 0.08, y + s * 0.35),
                                 QPointF(x - s * 0.08, y + s * 0.28), QPointF(x - s * 0.08, y + s * 0.05)]))
    elif kind == "inbox":
        S._packet(p, c, c, 0, col)
    elif kind == "gauge":                                  # a calculation / a meter
        p.drawArc(QRectF(x - s * 0.4, y - s * 0.3, s * 0.8, s * 0.8), 0, 180 * 16)
        a = math.radians(150 - 120 * S.ph(2.0))
        p.drawLine(QPointF(x, y + s * 0.1), QPointF(x + s * 0.32 * math.cos(a), y + s * 0.1 - s * 0.32 * math.sin(a)))
    elif kind == "dice":                                   # a random draw
        p.drawRoundedRect(QRectF(x - s * 0.3, y - s * 0.3, s * 0.6, s * 0.6), 6, 6)
        p.setPen(Qt.NoPen); p.setBrush(_c(col))
        for dx, dy in ((-0.15, -0.15), (0.15, 0.15), (0, 0), (0.15, -0.15), (-0.15, 0.15)):
            p.drawEllipse(QPointF(x + dx * s, y + dy * s), 2.6, 2.6)
    elif kind == "clock":
        p.drawEllipse(QPointF(x, y), s * 0.34, s * 0.34)
        a = S.T * 3
        p.drawLine(QPointF(x, y), QPointF(x + s * 0.24 * math.sin(a), y - s * 0.24 * math.cos(a)))
        p.drawLine(QPointF(x, y), QPointF(x, y - s * 0.16))
    p.restore()


def _pipe(p, items, note=""):
    """OUR APP: the steps as big boxes (icon · title · a few words), a message travelling through them."""
    n = len(items)
    gap = 34.0
    bw = min(176.0, (784.0 - (n - 1) * gap) / n)
    x0 = (800 - (n * bw + (n - 1) * gap)) / 2
    y, bh = 50.0, 190.0
    per = 1.3
    act = int((S.T / per) % n) if S.T > 0.4 * n else -1
    for i, (icon, title, sub) in enumerate(items):
        r = QRectF(x0 + i * (bw + gap), y, bw, bh)
        al = S._appear(i, 0.25)
        on = i == act
        col = HL if on else APP_C
        p.setPen(QPen(_c(col, al), 2.4 if on else 1.3)); p.setBrush(_c(col, (0.16 if on else 0.05) * al))
        p.drawRoundedRect(r, 12, 12)
        p.setPen(Qt.NoPen); p.setBrush(_c(col, al)); p.drawEllipse(QPointF(r.left() + 16, r.top() + 16), 11, 11)
        _text(p, r.left() + 16, r.top() + 21, str(i + 1), _al("#0B1220", al), 12, True, Qt.AlignCenter, 22)
        _icon(p, icon, QPointF(r.center().x(), r.top() + 52), 50, _al(col, al))
        _text(p, r.center().x(), r.top() + 108, title, _al("#F1F5F9", al), 14, True, Qt.AlignCenter, bw - 10)
        _text(p, r.center().x(), r.top() + 146, sub, _al(MUTED if not on else TXT, al), 12, False, Qt.AlignCenter,
              bw - 12)
        if i < n - 1:
            a, b = QPointF(r.right() + 3, r.center().y()), QPointF(r.right() + gap - 3, r.center().y())
            _arrow(p, a, b, _al(MUTED, al), 2.2, 9)
            if on:
                S._packet(p, a, b, ((S.T % per) / per) * 1.4, HL)
    if note:
        r = QRectF(20, 262, 760, 56)
        al = S._appear(n + 1, 0.3)
        p.setPen(QPen(_c(HL, 0.6 * al), 1.2)); p.setBrush(_c(HL, 0.08 * al)); p.drawRoundedRect(r, 9, 9)
        _text(p, 400, r.top() + 22, note, _al(HL, al), 13, True, Qt.AlignCenter, 740)


def _ladder(p, rows, result, x=410, w=380, ok=True):
    """DETECTION: the calculation, one line after the other, then the result (a big pill).
    rows = [(what is computed, the formula with numbers, what the numbers mean)]."""
    y = 44
    for i, row in enumerate(rows):
        lab, f = row[0], row[1]
        key = row[2] if len(row) > 2 else ""
        al = S._appear(i, 0.6)
        p.setPen(Qt.NoPen); p.setBrush(_c(HL, al)); p.drawEllipse(QPointF(x + 6, y + 8), 4, 4)
        _text(p, x + 18, y + 12, lab, _al(MUTED, al), 11, True, w=w - 18)
        _text(p, x + 18, y + 32, f, _al(TXT, al), 15, True, w=w - 18)
        if key:
            _text(p, x + 18, y + 49, key, _al(KEY_C, al), 10, False, w=w - 18)
        y += 64 if key else 48
    al = S._appear(len(rows), 0.6)
    col = GREEN if ok else RED
    r = QRectF(x, max(y + 2, H - 52), w, 40)
    p.setPen(QPen(_c(col, al), 2)); p.setBrush(_c(col, 0.18 * al)); p.drawRoundedRect(r, 20, 20)
    _text(p, r.center().x(), r.top() + 26, result, _al(col, al), 16, True, Qt.AlignCenter, w - 10)
    if al > 0.9:
        S._pulse(p, r, col)


def _match(p, rows):
    """REAL ↔ APP: per real-world feature, what our app does, and a badge (same / simplified / not modelled)."""
    cols = ((10, 120, "WHAT", MUTED), (136, 262, "REAL WORLD", REAL_C), (404, 262, "OUR APP", APP_C),
            (672, 120, "", MUTED))
    for x, w, t, c in cols:
        _text(p, x + 4, 48, t, c, 11, True, w=w)
    rh = min(42.0, (H - 60.0) / max(1, len(rows)))
    y = 54.0
    for i, (what, real, ours, kind) in enumerate(rows):
        al = S._appear(i, 0.35)
        bc, bt = BADGE[kind]
        p.setPen(Qt.NoPen); p.setBrush(_c("#111827" if i % 2 else "#0F172A", al)); p.drawRoundedRect(
            QRectF(6, y, 788, rh - 3), 6, 6)
        mid = y + (rh - 3) / 2

        def put(x, t, col, size, bold, w, per_line):
            lines = 2 if len(t) > per_line else 1
            _text(p, x, mid - lines * (size + 2) / 2 + size, t, _al(col, al), size, bold, w=w)
        put(14, what, "#F1F5F9", 12, True, 120, 18)
        put(140, real, REAL_C, 11, False, 258, 42)
        put(408, ours, TXT, 11, False, 258, 42)
        r = QRectF(676, y + (rh - 3) / 2 - 11, 112, 22)
        p.setPen(QPen(_c(bc, al), 1.2)); p.setBrush(_c(bc, 0.2 * al)); p.drawRoundedRect(r, 11, 11)
        _text(p, r.center().x(), r.top() + 16, bt, _al(bc, al), 10, True, Qt.AlignCenter, 110)
        y += rh


def _limits(p, cons, pros, note=""):
    """LIMITS: ✕ what our app leaves out (left), ✓ why the results still hold (right)."""
    n = max(len(cons), len(pros))
    bh = min(H - 94.0 if note else H - 48.0, 40 + 50.0 * n)
    for x, title, items, ok, c in ((10, "✕  NOT IN OUR APP (LIMITS)", cons, False, RED),
                                   (408, "✓  WHY THE RESULTS STILL HOLD", pros, True, GREEN)):
        r = QRectF(x, 40, 382, bh)
        p.setPen(QPen(_c(c, 0.6), 1.2)); p.setBrush(_c(c, 0.05)); p.drawRoundedRect(r, 10, 10)
        _text(p, x + 12, 60, title, c, 12, True, w=360)
        dy = min(46.0, (r.height() - 34) / max(1, len(items)))
        for i, t in enumerate(items):
            al = S._appear(i + (0 if not ok else len(cons)), 0.35)
            yy = 72 + i * dy
            p.setOpacity(al)
            _mark(p, x + 22, yy + 12, ok, 10)
            p.setOpacity(1.0)
            _text(p, x + 40, yy + 17, t, _al(TXT, al), 12, True, w=334)
    if note:
        al = S._appear(len(cons) + len(pros), 0.35)
        r = QRectF(10, 40 + bh + 8, 780, 38)
        p.setPen(QPen(_c(HL, 0.6 * al), 1.2)); p.setBrush(_c(HL, 0.08 * al)); p.drawRoundedRect(r, 9, 9)
        _text(p, 400, r.top() + 24, note, _al(HL, al), 12, True, Qt.AlignCenter, 760)


def _make(tags, steps):
    """steps = [(caption, draw(p))] -> a DECKS entry with the progress band on every step."""
    def draw(p, s):
        _band(p, tags, s)
        cap, fn = steps[s - 1]
        if cap.startswith("Real world:"):            # (the real-world pictures: drawn for 290 px -- centred)
            p.save(); p.translate(0, (H - 290) / 2)
            try:
                fn(p)
            finally:
                p.restore()
        else:
            fn(p)
    return (H, [c for c, _f in steps], draw)


def _gap_scene(p, gap_txt, obj="truck", fog=False, rng=None, y=175, x1=330):
    """The left half of a DETECTION step: our truck, the object ahead, the gap (and the sensor's range)."""
    _road(p, y - 40, y + 40, 0, 390, lanes=1)
    if fog:
        _fog(p, QRectF(150, y - 40, 240, 80), 30, seed=5, a=0.2)
    _vehicle(p, QRectF(14, y - 14, 80, 28), OURS, "our truck")
    _vehicle(p, QRectF(x1 - 20, y - 16, 90 if obj == "truck" else 50, 32), OTHER, obj)
    TT._dim(p, 94, x1 - 20, y + 60, gap_txt)
    if rng is not None:
        x = 94 + rng * min(1.0, S.ph(3.0) * 1.5)
        p.setPen(QPen(_c(HL), 2.2, Qt.DashLine)); p.drawLine(QPointF(x, y - 50), QPointF(x, y + 44))
        _text(p, x, y - 56, "range", HL, 11, True, Qt.AlignCenter, 80)


# ------------------------------------------------------------------ CAMERA
def _cam_real(p):
    _road(p, 200, 270, 0, 450, lanes=2)
    _vehicle(p, QRectF(20, 240, 90, 26), OURS, "")
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"])); p.drawEllipse(QPointF(112, 253), 5, 5)
    _vehicle(p, QRectF(330, 238, 100, 30), OTHER, "")
    for k in range(5):                                     # light travelling to the lens
        f = S.ph(1.4, k * 0.28)
        p.setBrush(_c(HL, 1 - f)); p.drawEllipse(QPointF(330 - f * 214, 253 + (k - 2) * 4 * (1 - f)), 3, 3)
    r = QRectF(120, 46, 290, 150)                          # the picture the camera takes
    p.setPen(QPen(_c(COL["camera"]), 1.6)); p.setBrush(_c("#0F172A")); p.drawRoundedRect(r, 6, 6)
    p.setPen(Qt.NoPen); p.setBrush(_c("#1E293B"))
    p.drawPolygon(QPolygonF([QPointF(r.left() + 30, r.bottom() - 4), QPointF(r.center().x() - 12, r.top() + 60),
                             QPointF(r.center().x() + 12, r.top() + 60), QPointF(r.right() - 30, r.bottom() - 4)]))
    tb = QRectF(r.center().x() - 26, r.top() + 72, 52, 36)
    p.setBrush(_c(OTHER)); p.drawRoundedRect(tb, 3, 3)
    al = S._appear(2, 0.6)
    if al > 0:
        p.setPen(QPen(_c(GREEN, al), 2.2)); p.setBrush(Qt.NoBrush); p.drawRect(tb.adjusted(-5, -5, 5, 5))
        _text(p, tb.center().x(), tb.top() - 12, "truck 92 %", _al(GREEN, al), 11, True, Qt.AlignCenter, 120)
    _text(p, r.center().x(), r.bottom() - 6, "the picture (pixels)", MUTED, 10, False, Qt.AlignCenter, 200)
    _callouts(p, ["Lens + chip: light → a picture (pixels)", "AI finds objects in the picture: a box + its type",
                  "Distance: estimated from where / how big it is", "✕ Fog, night, glare: it sees less"], x=440, w=350)


CAM_REAL = ("Real world: a camera takes pictures; AI finds the objects in them", _cam_real)


def _cam_app(p):
    _pipe(p, [("list", "Scene", "every object's position (the app knows them)"),
              ("camera", "Camera model", "inside the 90° view?\ncloser than its range?"),
              ("gauge", "Fog / night / hidden", "range shrinks · hidden behind another = not seen"),
              ("check", "Seen", "distance + type + confidence → fusion")],
          "No picture is processed: the camera's LIMITS (view, range, weather, hiding) are applied to the true "
          "positions")


def _cam_calc(p):
    x1 = 94 + TT._CGAP * 3.6 + 20
    _gap_scene(p, f"gap {TT._CGAP:.2f} m (bumper to bumper)", fog=True, rng=TT._CRNG * 3.6, x1=x1)
    # where the 40 and the 0.8 come from: centre of our truck → centre of the truck ahead
    c0, c1 = QPointF(54, 175), QPointF(x1 + 25, 166)
    p.setPen(QPen(_c(KEY_C), 1.6, Qt.DashLine)); p.drawLine(c0, QPointF(c1.x(), c0.y()))
    p.drawLine(QPointF(c1.x(), c0.y()), c1)
    for pt in (c0, c1):
        p.setPen(Qt.NoPen); p.setBrush(_c(KEY_C)); p.drawEllipse(pt, 3.5, 3.5)
    mx = (c0.x() + c1.x()) / 2 - 20
    _text(p, mx, 78, "40 m ahead (centre to centre)", KEY_C, 11, True, Qt.AlignCenter, 260)
    _arrow(p, QPointF(mx, 84), QPointF(mx, 171), KEY_C, 1.2, 6)
    _text(p, c1.x() + 60, 150, "0.8 m to\nthe left", KEY_C, 11, True, w=70)
    _arrow(p, QPointF(c1.x() + 58, 156), QPointF(c1.x() + 4, 170), KEY_C, 1.2, 6)
    _ladder(p, [("1  In the view? (90° wide = ±45°)", "atan(0.8 / 40) = 1.1°  ✓",
                 "0.8 m = how far left of our centre line · 40 m = how far ahead"),
                ("2  Range in fog", f"½ × 120 = {TT._CRNG:.0f} m",
                 "120 m = the fog's visibility · the camera sees ½ of it"),
                ("3  Gap to it (bumper to bumper)", f"40 − 3.5 − 8.25 = {TT._CGAP:.2f} m  ✓",
                 "3.5 = ½ our length (7 m) · 8.25 = ½ its length (16.5 m)"),
                ("4  How sure (confidence)", f"1 − 0.75 × {TT._CGAP:.1f}/{TT._CRNG:.0f} = {TT._CCONF:.2f}",
                 "farther (gap ÷ range) = less sure · ≥ 0.5 → its type")],
            f"SEEN · truck · {TT._CGAP:.1f} m")


def _cam_match(p):
    _match(p, [("View", "lens, ~90° wide", "angle check: within ±45°", "same"),
               ("Range", "contrast fades with distance", "range = ½ visibility (max 80 m)", "approx"),
               ("Fog / night", "picture grey / dark", "range shorter (night × 0.45)", "approx"),
               ("Hidden", "blocked in the picture", "≥ 70 % covered by a nearer one", "same"),
               ("Type", "AI guesses from pixels", "known type + confidence", "approx"),
               ("Distance", "estimated (± 5–10 %)", "exact from positions", "approx"),
               ("Glare / dirt", "sun, rain drops, dirt", "—", "no")])


def _cam_limits(p):
    _limits(p, ["No pixels / no AI: no false or missed boxes", "Glare, dirty lens, shadows: not simulated",
                "Distance is exact (a real camera estimates)"],
            ["The camera's real limits ARE applied: view, range, fog, night, hiding",
             "Fast and repeatable: every truck, 10× a second", "Real-world set-up: a real picture is analysed"],
            "Want pixels? Set-up → Real-world: the 3D view's picture is processed")


# ------------------------------------------------------------------ CAMERA (real-world set-up)
def _camr_app(p):
    _pipe(p, [("image", "3D picture", "the 3D view renders the camera's picture"),
              ("code", "Find the road", "road colour learned from the strip in front"),
              ("filter", "Scan columns", "bottom → up: where the road ends = an object's foot"),
              ("check", "Distance + track", "from that row; 2 of 3 pictures → fusion")],
          "Here pixels ARE processed (numpy) — no positions are given to the camera")


def _camr_calc(p):
    o = QPointF(60, 120)
    p.setPen(QPen(_c(MUTED), 1.4)); p.drawLine(QPointF(30, 230), QPointF(390, 230))
    p.setPen(QPen(_c(COL["camera"]), 2)); p.drawLine(QPointF(o.x(), 230), o)
    p.setBrush(_c(COL["camera"])); p.drawEllipse(o, 6, 6)
    _text(p, 18, 180, "2.4 m", COL["camera"], 11, True, w=40)
    p.setPen(QPen(_c(MUTED), 1, Qt.DashLine)); p.drawLine(o, QPointF(390, 120))
    _text(p, 330, 112, "horizon", MUTED, 10, w=60)
    f = min(1.0, S.ph(3.0) * 1.5)
    p.setPen(QPen(_c(HL), 2)); p.drawLine(o, QPointF(o.x() + (340 - o.x()) * f, 120 + (230 - 120) * f))
    p.setPen(Qt.NoPen); p.setBrush(_c(OTHER)); p.drawRect(QRectF(340, 170, 40, 60))
    _text(p, 150, 250, "foot of the object = where the road ends", MUTED, 10, True, Qt.AlignCenter, 260)
    _ladder(p, [("1  Row of the foot below the horizon", "angle = 9.2°",
                 "pixel rows below the horizon ÷ lens focal length (fy)"),
                ("2  Distance (flat ground)", "2.4 ÷ tan 9.2° = 14.8 m", "2.4 m = the camera's height above the road"),
                ("3  Width of the columns", "2.5 m → 'truck'", "the object's columns span 2.5 m → truck-sized"),
                ("4  Seen in 2 of the last 3 pictures", "→ track C3 confirmed",
                 "C3 = camera track no. 3 (the same object in several pictures)")], "SEEN · C3 · 14.8 m")


def _camr_match(p):
    _match(p, [("Picture", "camera chip, noise, blur", "rendered 3D picture (clean)", "approx"),
               ("Finding objects", "trained AI (e.g. YOLO)", "road-colour scan (classic)", "approx"),
               ("Distance", "height + angle (mono)", "same formula: h ÷ tan(angle)", "same"),
               ("Tracking", "confirm over frames", "2 of 3 pictures", "same"),
               ("Fog / night", "picture fades", "the 3D fog / light fade it", "same"),
               ("Hills / slopes", "flat-road error", "yard is flat", "no")])


def _camr_limits(p):
    _limits(p, ["Rendered picture is cleaner than a real one", "No trained AI: types from width only",
                "Assumes flat ground"],
            ["Uses only pixels — nothing is given for free", "Fails like a real camera in fog / at night",
             "Same distance formula as real mono cameras"])


# ------------------------------------------------------------------ LiDAR
def _lid_real(p):
    s = QPointF(110, 160)
    _road(p, 120, 200, 0, 450, lanes=1)
    _vehicle(p, QRectF(20, 146, 100, 28), OURS, "")
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"])); p.drawEllipse(s, 6, 6)
    ob = QRectF(300, 132, 120, 56)
    p.setPen(QPen(_c("#64748B"), 1.4)); p.setBrush(_c(OTHER, 0.6)); p.drawRect(ob)
    a = S.T * 2.2                                            # the spinning beam
    p.setPen(QPen(_c(COL["LiDAR"], 0.5), 1.4))
    p.drawLine(s, QPointF(s.x() + 300 * math.cos(a), s.y() + 300 * math.sin(a) * 0.45))
    f = S.ph(1.6)                                            # one pulse out and back
    px = s.x() + (ob.left() - s.x()) * (f * 2 if f < 0.5 else 2 - f * 2)
    p.setPen(Qt.NoPen); p.setBrush(_c(HL if f < 0.5 else GREEN)); p.drawEllipse(QPointF(px, s.y()), 5, 5)
    _text(p, 200, 112, "out" if f < 0.5 else "back", HL if f < 0.5 else GREEN, 11, True, Qt.AlignCenter, 60)
    n = int(min(1.0, S.T / 3.0) * 24)                        # the points build up on its face
    rnd = random.Random(3)
    for i in range(24):
        yy = ob.top() + rnd.uniform(2, ob.height() - 2)
        if i < n:
            p.setBrush(_c(HL)); p.drawEllipse(QPointF(ob.left() + rnd.uniform(-1, 2), yy), 2.6, 2.6)
    _text(p, 230, 240, "t = 82 ns  →  d = c × t ÷ 2 = 12.3 m", HL, 13, True, Qt.AlignCenter, 420)
    _callouts(p, ["Laser pulses, ~1 million a second, spinning", "Time for the echo → distance (d = c·t/2)",
                  "→ a 3D 'point cloud'; software groups points into objects", "✕ Fog / snow scatter the light"],
              x=450, w=340)


LID_REAL = ("Real world: laser pulses + their echo time → 3D points", _lid_real)


def _lid_app(p):
    _pipe(p, [("code", "Python asks", "4× a second: 'scan now' (positions as JSON)"),
              ("cube", "3D page traces rays", "every laser ray of the pattern (three.js)"),
              ("points", "Points per object", "fog removes rays by a chance (physics)"),
              ("check", "≥ 4 points = seen", "distance = nearest point → fusion")],
          "Real geometry: each laser ray is traced in the 3D yard — like the real sensor, minus the light physics")


def _lid_calc(p):
    _gap_scene(p, "12.3 m (nearest point)", x1=94 + 12.3 * 12 + 20)
    n = int(min(1.0, S.T / 2.0) * 20)
    rnd = random.Random(6)
    p.setPen(Qt.NoPen); p.setBrush(_c(HL))
    for i in range(20):
        yy = 161 + rnd.uniform(0, 28)
        if i < n:
            p.drawEllipse(QPointF(94 + 12.3 * 12 + rnd.uniform(-1, 2), yy), 2.4, 2.4)
    _ladder(p, [("1  Rays that hit the truck ahead", "60 points", "laser rays of the pattern ending on its back"),
                ("2  Enough? (min. 4 points)", "60 ≥ 4  ✓", "4 = config/lidar.json · fewer could be noise"),
                ("3  Gap = its nearest point", "12.3 m", "from our front bumper to its nearest point"),
                ("4  Whiteout fog, 12 m: rays surviving", f"e^(−2·{TT._EXT_W:g}·12) = "
                                                          f"{math.exp(-2 * TT._EXT_W * 12):.1%}",
                 f"{TT._EXT_W:g}/m = how thick the fog is · 2 = there and back")],
            "SEEN · 60 points · 12.3 m")


def _lid_match(p):
    _match(p, [("Laser rays", "pulses in a fixed pattern", "the same pattern, ray-traced", "same"),
               ("Distance", "echo time (d = c·t/2)", "hit distance + small noise", "approx"),
               ("Fog / snow", "light scattered", "a ray lost by chance e^(−2·ext·d)", "approx"),
               ("What it hit", "unknown → clustering", "known (sim); clustering in real set-up", "approx"),
               ("Dark / wet paint", "weaker echoes", "—", "no"),
               ("Rate", "10–20 scans a second", "~4 scans a second", "approx")])


def _lid_limits(p):
    _limits(p, ["No light physics: colour, wetness, reflection", "Knows which object a ray hit (sim set-up)",
                "Fewer scans a second than a real LiDAR"],
            ["Ray geometry is real: hiding, size, angle all correct", "Fog loss uses the physics formula",
             "Real-world set-up: only raw points, clustered like real software"])


def _lidr_app(p):
    _pipe(p, [("points", "Raw points", "no names: just (forward, left, height)"),
              ("filter", "Clean", "remove ground, buildings, fog specks"),
              ("merge", "Group (cluster)", "touching 0.6 m cells = one object"),
              ("check", "Nearest in lane", "its nearest point; tracked → fusion")],
          "Exactly the steps of real LiDAR software — nothing is known about the objects")


def _lidr_calc(p):
    rnd = random.Random(8)
    p.setPen(QPen(_c("#1F2937"), 1))
    for k in range(9):
        p.drawLine(QPointF(40 + k * 40, 50), QPointF(40 + k * 40, 270))
    p.setPen(Qt.NoPen)
    for cx, cy, n, c in ((220, 120, 30, GREEN), (300, 220, 6, AMBER), (120, 240, 3, MUTED)):
        for _ in range(n):
            p.setBrush(_c(c)); p.drawEllipse(QPointF(cx + rnd.uniform(-22, 22), cy + rnd.uniform(-16, 16)), 2.4, 2.4)
    _text(p, 220, 92, "L4: 30 points", GREEN, 11, True, Qt.AlignCenter, 120)
    _text(p, 300, 196, "pole (beside)", AMBER, 10, True, Qt.AlignCenter, 120)
    _ladder(p, [("1  Neighbouring cells with points", "→ 3 groups", "the ground is cut into 0.6 m cells; touching = one"),
                ("2  At least 5 points?", "L4: 30 ✓ · specks: 3 ✕", "fewer than 5 = fog / rain specks"),
                ("3  Inside our lane (½ width + 0.3 m)?", "L4 ✓ · pole ✕", "0.3 m = a safety margin beside our body"),
                ("4  Gap = nearest point − ½ length", "12.3 m",
                 "points are measured from our centre → minus ½ our length")], "SEEN · L4 · 12.3 m")


def _lidr_match(p):
    _match(p, [("Points", "raw cloud from the sensor", "raw cloud from the 3D yard", "same"),
               ("Ground / fog", "filtered by software", "same kind of filters", "same"),
               ("Grouping", "clustering (DBSCAN, grids)", "0.6 m grid clustering", "same"),
               ("Object type", "AI on the cloud", "size only", "approx"),
               ("Light physics", "reflectivity, wet roads", "—", "no")])


def _lidr_limits(p):
    _limits(p, ["Simple clustering, no AI types", "No reflectivity / wet-road effects"],
            ["Works from raw points only — like the real software", "Hiding, fog loss and size come from geometry"])


# ------------------------------------------------------------------ RADAR
def _rad_real(p):
    o = QPointF(110, 160)
    _road(p, 120, 200, 0, 450, lanes=1)
    _fog(p, QRectF(150, 110, 300, 100), 30, seed=4, a=0.18)
    _vehicle(p, QRectF(20, 146, 90, 28), OURS, "")
    _vehicle(p, QRectF(320, 144, 110, 32), OTHER, "")
    p.save(); p.setClipRect(QRectF(110, 60, 210, 200))
    S._rings(p, o, COL["radar"], 220, n=3, period=1.6, a0=-25, span=50, width=2.4)
    p.restore()
    p.save(); p.setClipRect(QRectF(110, 60, 210, 200))
    S._rings(p, QPointF(320, 160), GREEN, 210, n=2, period=1.6, a0=155, span=50, width=1.8)
    p.restore()
    _text(p, 215, 236, "waves pass through the fog", COL["radar"], 11, True, Qt.AlignCenter, 260)
    _text(p, 215, 100, "echo (green)", GREEN, 11, True, Qt.AlignCenter, 200)
    _callouts(p, ["Radio waves out (77 GHz)", "Echo delay → distance", "Echo pitch shift (Doppler) → speed, at once",
                  "Works in fog / rain; sees no shape"], x=450, w=340)


RAD_REAL = ("Real world: radio waves bounce back — distance and speed at once", _rad_real)


def _rad_app(p):
    _pipe(p, [("list", "Objects in the beam", "inside the 60° view (scene positions)"),
              ("gauge", "Echo strength", "radar equation: size, distance, rain"),
              ("dice", "Seen this scan?", "chance from the strength + a random draw"),
              ("check", "Confirmed", "2 of 3 scans → distance (noise) + speed")],
          "The radar equation decides how likely each echo is detected — so weak / far targets flicker, as in reality")


def _rad_calc(p):
    _gap_scene(p, "60 m", x1=94 + 60 * 3.6 + 20)
    _ladder(p, [("1  Echo strength, truck at 60 m", f"40·log10(120/60) → {TT._RM:+.1f} dB",
                 "120 m = where a truck is just seen (0 dB) · 40·log = echo ∝ 1/r⁴"),
                ("2  Chance this scan", f"{TT._RM:+.1f} dB → {TT._RPD:.1%}", "S-curve: stronger echo → surer"),
                ("3  Heavy rain costs", f"−{TT._RRAIN:.1f} dB", "rain absorbs the waves, 60 m there and back (ITU)"),
                ("4  Speed (Doppler)", "5.6 − 11.1 = −5.6 m/s (closing)",
                 "5.6 m/s = its speed (20 km/h) · 11.1 = ours (40 km/h)")], "SEEN · 60 m · closing 5.6 m/s")


def _rad_match(p):
    _match(p, [("Waves", "77 GHz radio, through fog", "not drawn; fog costs nothing", "approx"),
               ("Echo strength", "radar equation (1/r⁴)", "the same equation + size table", "same"),
               ("Detect or not", "threshold on noise (CFAR)", "chance curve + random draw", "approx"),
               ("Rain", "absorbs, clutter", "ITU rain loss (dB/km)", "same"),
               ("Speed", "Doppler shift", "relative speed + noise", "approx"),
               ("Ghosts", "reflections, interference", "—", "no")])


def _rad_limits(p):
    _limits(p, ["No wave reflections → no ghost targets", "No interference between radars",
                "Shape / angle not measured"],
            ["Uses the textbook radar equation", "Real behaviour: weak targets flicker, rain reduces range",
             "Real-world set-up: 1° beams, CFAR, Doppler clustering"])


def _radr_app(p):
    _pipe(p, [("radar", "61 beams", "1° beams over the 60° view; first hit each"),
              ("gauge", "Echo vs threshold", "random strength (Swerling) vs CFAR + rain clutter"),
              ("points", "Points", "distance, angle, Doppler speed"),
              ("check", "Group + track", "same speed within 2 m; 3 of 4 scans")],
          "Like a real radar's signal chain: beams → detections → objects → tracks")


def _radr_calc(p):
    o = QPointF(60, 160)
    p.setPen(QPen(_c(COL["radar"], 0.4), 1))
    for k in range(-6, 7):
        a = math.radians(k * 5)
        p.drawLine(o, QPointF(o.x() + 330 * math.cos(a), o.y() + 330 * math.sin(a)))
    p.setPen(Qt.NoPen); p.setBrush(_c(OTHER)); p.drawRect(QRectF(280, 140, 40, 40))
    for k in range(-2, 3):
        p.setBrush(_c(HL)); p.drawEllipse(QPointF(282, 160 + k * 8), 3.5, 3.5)
    _vehicle(p, QRectF(10, 148, 50, 24), OURS, "")
    _ladder(p, [("1  Beams hitting the truck", "5 beams", "1° beams that end on its back"),
                ("2  Echo above threshold (13 dB)?", "4 of 5 ✓", "13 dB above the noise = the CFAR threshold"),
                ("3  Same speed, within 2 m", "→ 1 object", "points of one object move at the same speed"),
                ("4  Seen in 3 of 4 scans", "→ track R2", "R2 = radar track no. 2")], "SEEN · R2")


def _radr_match(p):
    _match(p, [("Beams", "antenna array, ~1°", "61 beams of 1°", "same"),
               ("Detection", "CFAR threshold on noise", "Swerling echo vs CFAR", "same"),
               ("Rain", "clutter + loss", "random rain clutter + loss", "same"),
               ("Grouping", "points → objects", "by distance + speed", "same"),
               ("Waves", "multipath, ghosts", "—", "no")])


def _radr_limits(p):
    _limits(p, ["No multipath / ghost targets", "No interference from other radars"],
            ["Same processing chain as a real radar", "Detection is random like a real one"])


# ------------------------------------------------------------------ V2V
_PC5, _V2N = v2v.LINKS["pc5"], v2v.LINKS["v2n"]


def _v2v_real1(p):
    _road(p, 140, 200, 0, 450, lanes=2)
    a = QPointF(220, 156)
    S._rings(p, a, COL["V2V"], 170, n=3, period=2.0, width=2.2)
    _vehicle(p, QRectF(180, 144, 80, 24), OTHER, "")
    _icon(p, "V2V", QPointF(220, 120), 30, COL["V2V"])
    for i, (x, y) in enumerate(((40, 174), (360, 174), (380, 146), (60, 144))):
        _vehicle(p, QRectF(x, y - 10, 56, 20), OURS, "")
        f = S.ph(2.0, -0.1 * i)
        if f < 0.6:
            S._packet(p, a, QPointF(x + 28, y), f / 0.6, COL["V2V"])
        else:
            _mark(p, x + 28, y - 22, True, 8)
    _text(p, 220, 238, "one sender → everyone in range", COL["V2V"], 12, True, Qt.AlignCenter, 300)
    _callouts(p, ["On-board unit (OBU) + antenna in each vehicle",
                  "Broadcasts position, speed, braking — 10× a second",
                  "Direct, vehicle to vehicle: no tower (ad hoc / mesh)",
                  "Hard braking → a BRAKE ALERT at once"], x=450, w=340)


def _v2v_real2(p):
    p.setPen(Qt.NoPen); p.setBrush(_c("#1E293B"))
    p.drawRect(QRectF(0, 180, 440, 50)); p.drawRect(QRectF(300, 40, 50, 190))
    p.setBrush(_c("#334155")); p.setPen(QPen(_c("#64748B"), 1.4)); p.drawRect(QRectF(150, 50, 140, 120))
    _text(p, 220, 115, "building", MUTED, 12, True, Qt.AlignCenter, 120)
    _vehicle(p, QRectF(40, 192, 70, 24), OURS, "")                      # receiver, on the left
    _vehicle(p, QRectF(313, 60, 24, 60), OTHER, "", cab=False)            # sender, behind the corner
    p.setPen(QPen(_c(RED), 2, Qt.DashLine)); p.drawLine(QPointF(110, 200), QPointF(290, 140))
    _mark(p, 200, 170, False, 9)
    _text(p, 110, 252, "camera / radar: blocked", RED, 11, True, Qt.AlignCenter, 200)
    path = QPainterPath(QPointF(325, 120)); path.quadTo(QPointF(310, 205), QPointF(110, 205))
    f = S.ph(2.0)
    p.setPen(QPen(_c(COL["V2V"]), 2.4, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    pt = path.pointAtPercent(f)
    S._packet(p, pt, pt, 0, COL["V2V"])
    _mark(p, 75, 172, True, 9)
    _text(p, 330, 252, "radio: bends around (weaker)", COL["V2V"], 11, True, Qt.AlignCenter, 220)
    _callouts(p, ["Radio goes around corners and other vehicles", "C-V2X PC5 (direct) or DSRC (IEEE 802.11p)",
                  "5.9 GHz band · ~300–1000 m · ~20 ms", "India: 5.9 GHz not yet assigned → cellular today"],
              x=450, w=340)


def _v2v_app(p):
    _pipe(p, [("truck", "Sender", "builds a message 10×/s: position (GPS ± 2.5 m), speed, brake"),
              ("code", "Channel (Python)", f"in range? ({_PC5['range_m']:.0f} m, {_PC5['nlos_range_m']:.0f} m "
                                           "behind buildings)"),
              ("dice", "Lost or late?", f"random loss · delay {_PC5['delay_ms']:.0f} ± {_PC5['jitter_ms']:.0f} ms"),
              ("inbox", "Receiver", "my lane? ahead? fresh? → brake on it")],
          "The radio is simulated at MESSAGE level: its effects (range, blocking, loss, delay) — not the waves")


def _v2v_calc(p):
    p.setPen(Qt.NoPen); p.setBrush(_c("#1E293B")); p.drawRect(QRectF(0, 170, 390, 50))
    p.setBrush(_c("#334155")); p.drawRect(QRectF(170, 70, 90, 90))
    _text(p, 215, 120, "building", MUTED, 10, True, Qt.AlignCenter, 90)
    _vehicle(p, QRectF(20, 182, 70, 24), OURS, "")
    _vehicle(p, QRectF(290, 182, 80, 24), OTHER, "")
    f = S.ph(2.2)
    S._packet(p, QPointF(290, 194), QPointF(90, 194), f, COL["V2V"])
    TT._dim(p, 90, 290, 240, "120 m · line not blocked")
    _ladder(p, [("1  In range? (line of sight)", f"120 ≤ {_PC5['range_m']:.0f} m  ✓",
                 f"120 m = sender ↔ us · {_PC5['range_m']:.0f} m = direct-link range in the open"),
                ("2  Lost? chance 1 + 5 + 3 % = 9 %", "random 0.42 > 0.09 → delivered",
                 "1 % base + 5 % set in the test + 3 % rain · a new draw each"),
                ("3  Arrives after", f"{_PC5['delay_ms']:.0f} ± {_PC5['jitter_ms']:.0f} ms → 18 ms",
                 f"{_PC5['delay_ms']:.0f} ms average, ± {_PC5['jitter_ms']:.0f} ms random (this time 18)"),
                ("4  In my lane, ahead, same way?", "✓ gap 18.25 m → BRAKE",
                 "30 m centre to centre − 3.5 (½ ours) − 8.25 (½ its)")], "DELIVERED in 18 ms → brake")


def _v2v_match(p):
    _match(p, [("Radio link", "OBU + antenna, direct", "a Python 'channel' object", "approx"),
               ("Broadcast", "all in range receive", "all in range receive", "same"),
               ("Around obstacles", "bends, gets weaker", "building: 450 → 150 m, +60 % loss", "approx"),
               ("Standards", "C-V2X PC5 / DSRC, 5.9 GHz", "their range, delay, size, loss", "approx"),
               ("Busy channel", "collisions, slower sending", "load model (DCC): more loss", "approx"),
               ("Message", "BSM / CAM + signature", "same fields, plain data", "approx"),
               ("Mesh relay", "multi-hop forwarding", "one hop only", "no"),
               ("Waves", "fading, reflections", "one random loss instead", "no")])


def _v2v_limits(p):
    _limits(p, ["No radio waves: fading / reflections → a random loss", "One hop: no relaying through others",
                "No real encoding / security signing"],
            ["Range, blocking, loss and delay follow real C-V2X numbers",
             "The SAFETY logic (lane, ahead, fresh) is the real thing",
             "Worst cases (50 % loss, slow GPS) are repeatable"],
            "Change it live: Collision test → V2V → link, loss %, GNSS, blocking")


def _v2n_real(p):
    pts = [QPointF(60, 200), QPointF(150, 110), QPointF(270, 70), QPointF(390, 110), QPointF(450, 200)]
    _vehicle(p, QRectF(20, 190, 80, 24), OTHER, "")
    _vehicle(p, QRectF(400, 190, 80, 24), OURS, "")
    _icon(p, "tower", pts[1], 60, REAL_C); _icon(p, "cloud", pts[2], 90, REAL_C); _icon(p, "tower", pts[3], 60, REAL_C)
    _text(p, 270, 120, "operator network", REAL_C, 11, True, Qt.AlignCenter, 160)
    f = S.ph(3.0) * 4
    k = min(3, int(f))
    for i in range(4):
        _arrow(p, pts[i], pts[i + 1], MUTED, 1.4, 7, dashed=True)
    S._packet(p, pts[k], pts[k + 1], f - k, COL["V2V"])
    _callouts(p, ["Through the mobile network (4G / 5G)", "Works today with a SIM — no line of sight",
                  "~50–200 ms (slower than direct)", "✕ Needs coverage; no network = no message"], x=480, w=310)


def _v2n_app(p):
    _pipe(p, [("truck", "Sender", "same message, 10×/s"),
              ("code", "Channel (Python)", f"no blocking · range {_V2N['range_m']:.0f} m"),
              ("dice", "Lost or late?", f"{_V2N['base_loss']:.0%} + setup · {_V2N['delay_ms']:.0f} ± "
                                        f"{_V2N['jitter_ms']:.0f} ms"),
              ("inbox", "Receiver", "same checks → brake on it")],
          "The same channel as the direct link, with the cellular numbers")


def _v2n_calc(p):
    _gap_scene(p, "300 m · behind a building", x1=330)
    p.setPen(QPen(_c("#64748B"), 1.4)); p.setBrush(_c("#334155")); p.drawRect(QRectF(170, 50, 90, 70))
    _text(p, 215, 90, "building", MUTED, 10, True, Qt.AlignCenter, 90)
    d = _V2N["delay_ms"]
    _ladder(p, [("1  Buildings block?", "no (the network relays)", "it goes via the towers, not in a straight line"),
                ("2  Lost?", f"chance {_V2N['base_loss']:.0%} + 5 % → delivered",
                 f"{_V2N['base_loss']:.0%} cellular + 5 % set in the test"),
                ("3  Arrives after", f"{d:.0f} ± {_V2N['jitter_ms']:.0f} ms → 96 ms",
                 f"{d:.0f} ms average, ± {_V2N['jitter_ms']:.0f} ms random (this time 96)"),
                ("4  At 40 km/h in 96 ms", "the truck drives 1.1 m", "11.1 m/s × 0.096 s")], "DELIVERED in 96 ms")


def _v2n_match(p):
    _match(p, [("Path", "tower → network → tower", "one delay number", "approx"),
               ("Delay", "50–200 ms, varies", f"{_V2N['delay_ms']:.0f} ± {_V2N['jitter_ms']:.0f} ms", "same"),
               ("Buildings", "no effect", "no effect", "same"),
               ("Coverage gaps", "no signal = nothing", "—", "no"),
               ("Network load", "busy cells slower", "—", "no")])


def _v2n_limits(p):
    _limits(p, ["No coverage gaps or busy cells", "No network path (one delay number)"],
            ["Delay and loss match measured 4G / 5G values", "Same safety logic as the direct link"])


# ------------------------------------------------------------------ FUSION
def _fus_real(p):
    obj = QPointF(330, 160)
    p.setPen(Qt.NoPen); p.setBrush(_c(OTHER)); p.drawRoundedRect(QRectF(300, 140, 60, 40), 4, 4)
    srcs = [("camera", QPointF(60, 70), QPointF(-14, -8)), ("LiDAR", QPointF(60, 160), QPointF(6, 4)),
            ("radar", QPointF(60, 250), QPointF(12, -6))]
    f = min(1.0, S.T / 2.0)
    for i, (k, pt, off) in enumerate(srcs):
        _icon(p, k, pt, 40, COL[k])
        guess = QPointF(obj.x() + off.x(), obj.y() + off.y())
        p.setPen(QPen(_c(COL[k], 0.5), 1.2, Qt.DashLine)); p.drawLine(QPointF(pt.x() + 24, pt.y()), guess)
        p.setPen(QPen(_c(COL[k]), 2)); p.setBrush(Qt.NoBrush)
        rr = 26 - 0 * i
        p.drawEllipse(guess, rr * (1 - 0.5 * f) + 6, rr * 0.6 * (1 - 0.5 * f) + 4)
    p.setPen(QPen(_c(HL), 2.6)); p.setBrush(_c(HL, 0.2)); p.drawEllipse(obj, 10 + 8 * (1 - f), 7 + 6 * (1 - f))
    _text(p, 330, 220, "one object, more sure", HL, 12, True, Qt.AlignCenter, 200)
    _callouts(p, ["Each sensor sees the object a little differently", "Fusion matches them: same place, same speed",
                  "Combined into one object, more sure (e.g. Kalman)", "One sensor blind (fog)? The others go on"],
              x=450, w=340)


FUS_REAL = ("Real world: several sensors → one, more certain, picture", _fus_real)


def _fus_app(p):
    _pipe(p, [("list", "4 lists in", "camera · LiDAR · radar · V2V (switched on)"),
              ("filter", "My lane only", "within 2.2 m of our path, ahead"),
              ("merge", "Same object", "merged; nearest distance wins"),
              ("check", "Target", "nearest one + its speed → braking")],
          "Simple and safe: the nearest distance of any sensor is used")


def _fus_calc(p):
    rows = [("LiDAR", "12.4 m", True), ("camera", "— (fog)", False), ("radar", "12.6 m", True), ("V2V", "13.5 m", True)]
    for i, (k, t, ok) in enumerate(rows):
        al = S._appear(i, 0.3)
        y = 60 + i * 46
        _icon(p, k, QPointF(50, y + 12), 30, _al(COL[k], al))
        _text(p, 80, y + 18, f"{k}: {t}", _al(TXT if ok else MUTED, al), 14, True, w=200)
        _arrow(p, QPointF(250, y + 12), QPointF(330, 150), _al(COL[k] if ok else "#334155", al), 1.6, 7)
    _ladder(p, [("1  In my lane? (|y| ≤ 2.2 m)", "all 3 ✓", "y = sideways offset · 2.2 m = ½ our lane"),
                ("2  Same object (T1) → nearest", "min(12.4, 12.6, 13.5) = 12.4 m",
                 "T1 = the same object id from all sensors"),
                ("3  Its speed (radar)", "11.1 − 3.0 = 8.1 m/s",
                 "11.1 = our speed · 3.0 = how fast we close in (radar)"),
                ("4  Camera blind in fog", "the others carry on", "its range in fog is shorter than the gap")],
            "TARGET · 12.4 m · 8.1 m/s")


def _fus_match(p):
    _match(p, [("Match", "by place + speed (gating)", "by object id (sim) / distance (real)", "approx"),
               ("Combine", "weighted (Kalman filter)", "nearest distance wins (safe)", "approx"),
               ("Lane", "path prediction", "2.2 m corridor along the route", "same"),
               ("Blind sensor", "others continue", "others continue", "same"),
               ("Speed", "estimated over time", "radar / V2V, or from two looks", "same")])


def _fus_limits(p):
    _limits(p, ["No weighting of sensors (Kalman)", "Simulated set-up matches by id, not by position"],
            ["'Nearest wins' is the safe choice for braking", "Real-world set-up: matches tracks by position",
             "Kalman fusion is listed as an option to add"])


def _fusr_app(p):
    _pipe(p, [("list", "3 trackers", "camera C · LiDAR L · radar R (ids, no names)"),
              ("merge", "Same object?", "tracks near each other = one"),
              ("filter", "Plausible?", "a standing camera-only object needs LiDAR / radar"),
              ("check", "Target", "nearest in my lane → braking")],
          "No names, no ids from the scene: only positions — like a real fusion")


def _fusr_calc(p):
    for i, (k, t, x) in enumerate((("camera", "C3: 14.8 m", 150), ("LiDAR", "L4: 14.5 m", 158), ("radar", "R2: 14.6 m", 154))):
        y = 70 + i * 50
        _icon(p, k, QPointF(40, y), 30, COL[k])
        _text(p, 64, y + 6, t, TXT, 13, True, w=120)
        p.setPen(Qt.NoPen); p.setBrush(_c(COL[k])); p.drawEllipse(QPointF(200 + x, 140), 6, 6)
    p.setPen(QPen(_c(HL), 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(355, 140), 26, 22)
    _ladder(p, [("1  Tracks near each other", "C3 · L4 · R2 → one object",
                 "C = camera, L = LiDAR, R = radar track (numbered)"),
                ("2  Camera-only standing object?", "no — LiDAR + radar agree ✓",
                 "stops false brakes on shadows / road marks"),
                ("3  In my lane, nearest", "14.5 m", "the nearest of the three distances")], "TARGET · 14.5 m")


def _fusr_match(p):
    _match(p, [("Match", "by position (gating)", "by position", "same"),
               ("Combine", "weighted (Kalman)", "nearest wins", "approx"),
               ("False objects", "plausibility checks", "camera-only needs a 2nd sensor", "same")])


def _fusr_limits(p):
    _limits(p, ["No weighting of sensors (Kalman)", "Simple position matching (no prediction)"],
            ["Matches tracks by position only — like a real fusion",
             "A camera-only standing object needs a 2nd sensor (fewer false brakes)",
             "Kalman fusion is listed as an option to add"])


# ------------------------------------------------------------------ BRAKING
def _brk_real(p):
    _road(p, 150, 210, 0, 450, lanes=1)
    f = min(1.0, S.T / 4.0)
    x = 20 + 200 * (1 - (1 - f) ** 2)
    _vehicle(p, QRectF(x, 166, 90, 28), OURS, "")
    _vehicle(p, QRectF(360, 164, 80, 32), OTHER, "stopped")
    stage = 0 if f < 0.35 else 1 if f < 0.7 else 2
    for i, (t, c) in enumerate((("measure", COL["radar"]), ("WARN", AMBER), ("AUTO BRAKE", RED))):
        al = 1.0 if i <= stage else 0.25
        r = QRectF(20 + i * 140, 70, 130, 40)
        p.setPen(QPen(_c(c, al), 2)); p.setBrush(_c(c, 0.2 * al)); p.drawRoundedRect(r, 10, 10)
        _text(p, r.center().x(), r.top() + 26, t, _al(c, al), 13, True, Qt.AlignCenter, 120)
    _callouts(p, ["Sensors measure distance + closing speed", "Time to collision = distance ÷ closing speed",
                  "~2–3 s: warn · ~1.5 s: brake automatically (AEB)", "Wet / snowy road: weaker braking"], x=460, w=330)


BRK_REAL = ("Real world: automatic emergency braking (AEB)", _brk_real)


def _brk_app(p):
    _pipe(p, [("check", "Target", "its distance + speed (from fusion)"),
              ("clock", "Time to collision", "distance ÷ closing speed"),
              ("gauge", "Braking needed", "to stop 3 m short"),
              ("brake", "Decide", "follow · brake · FULL BRAKE; new speed every 0.1 s")],
          f"Warn below {ft.TTC_WARN_S:g} s · full brake (AEB) below {ft.TTC_CRIT_S:g} s · grip from the climate")


def _brk_calc(p):
    _gap_scene(p, "25 m · we drive 40 km/h", obj="stopped", x1=94 + 25 * 8 + 20)
    a = min(ft.A_FULL, 1.15 * TT._BAREQ)
    _ladder(p, [("1  Closing speed", "40 km/h = 11.1 m/s", "40 ÷ 3.6 · the truck ahead stands still (0)"),
                ("2  Time to collision", f"25 ÷ 11.1 = {TT._BTTC:.2f} s  (< 3 s: warn)",
                 "25 m = the gap now · 3 s = the warning limit"),
                ("3  Braking to stop 3 m short", f"11.1² ÷ (2 × 22) = {TT._BAREQ:.2f} m/s²",
                 "22 = 25 − 3 m (stop 3 m short) · v² ÷ 2d"),
                ("4  ≥ 2 m/s² → brake", f"{a:.2f} m/s² (no AEB: {TT._BTTC:.2f} > 1.5 s)",
                 f"2 = comfort limit · × 1.15 margin · AEB only below 1.5 s")],
            f"BRAKE {a:.1f} m/s² → stops in time")


def _brk_match(p):
    _match(p, [("TTC", "distance ÷ closing speed", "the same", "same"),
               ("Warn / AEB", "~2–3 s / ~1.5 s", f"{ft.TTC_WARN_S:g} s / {ft.TTC_CRIT_S:g} s", "same"),
               ("Brake force", "brakes, tyres, load", f"max {ft.A_FULL:g} m/s² × road grip", "approx"),
               ("Wet / snow", "less grip", "grip from the climate (70 %, 60 %)", "same"),
               ("Brake delay", "air brakes ~0.3–0.5 s", "— (0.1 s steps)", "no"),
               ("Slope / load", "longer stopping", "—", "no")])


def _brk_limits(p):
    _limits(p, ["No brake-system delay (air brakes)", "No slope or load effects", "A simple truck (no skidding)"],
            ["Same TTC / AEB rule as real systems", "Wet / snowy roads brake weaker", "Every decision is logged"])


# ------------------------------------------------------------------ register
def register(decks):
    def five(real, app, calc, match, limits, app_cap, calc_cap):
        return _make(TAGS5, [real, (app_cap, app), (calc_cap, calc),
                             ("Real world ↔ our app: what is the same, simplified or left out", match),
                             ("Limits — and why the results still hold", limits)])

    decks["easy_camera"] = five(CAM_REAL, _cam_app, _cam_calc, _cam_match, _cam_limits,
                                "Our app: the camera's limits applied to the known positions",
                                "Detection: the truck ahead in fog — one example")
    decks["easy_camera_real"] = five(CAM_REAL, _camr_app, _camr_calc, _camr_match, _camr_limits,
                                     "Our app (real-world set-up): the 3D picture's pixels are analysed",
                                     "Detection: distance from the picture row")
    decks["easy_lidar"] = five(LID_REAL, _lid_app, _lid_calc, _lid_match, _lid_limits,
                               "Our app: every laser ray traced in the 3D yard",
                               "Detection: points on the truck ahead")
    decks["easy_lidar_real"] = five(LID_REAL, _lidr_app, _lidr_calc, _lidr_match, _lidr_limits,
                                    "Our app (real-world set-up): raw points → clusters → objects",
                                    "Detection: grouping the points")
    decks["easy_radar"] = five(RAD_REAL, _rad_app, _rad_calc, _rad_match, _rad_limits,
                               "Our app: the radar equation decides each scan",
                               "Detection: a truck 60 m ahead")
    decks["easy_radar_real"] = five(RAD_REAL, _radr_app, _radr_calc, _radr_match, _radr_limits,
                                    "Our app (real-world set-up): beams → echoes → objects → tracks",
                                    "Detection: from beams to a track")
    decks["easy_fusion"] = five(FUS_REAL, _fus_app, _fus_calc, _fus_match, _fus_limits,
                                "Our app: four lists → one target", "Detection: the target in fog")
    decks["easy_fusion_real"] = five(FUS_REAL, _fusr_app, _fusr_calc, _fusr_match, _fusr_limits,
                                     "Our app (real-world set-up): tracks matched by position",
                                     "Detection: three tracks → one target")
    decks["easy_brake"] = five(BRK_REAL, _brk_app, _brk_calc, _brk_match, _brk_limits,
                               "Our app: time to collision → brake decision", "Calculation: a stopped truck 25 m ahead")
    decks["easy_v2v"] = _make(("REAL: RADIO", "REAL: AROUND", "OUR APP", "DETECTION", "REAL ↔ APP", "LIMITS"), [
        ("Real world: each vehicle broadcasts by radio, directly to the others", _v2v_real1),
        ("Real world: radio reaches around obstacles — the standards", _v2v_real2),
        ("Our app: message-level radio — its effects, not its waves", _v2v_app),
        ("Detection: one brake alert from the truck ahead", _v2v_calc),
        ("Real world ↔ our app: what is the same, simplified or left out", _v2v_match),
        ("Limits — and why the results still hold", _v2v_limits)])
    decks["easy_v2v_v2n"] = five(("Real world: messages through the mobile network (V2N)", _v2n_real), _v2n_app,
                                 _v2n_calc, _v2n_match, _v2n_limits,
                                 "Our app: the same channel with cellular numbers",
                                 "Detection: a message through the network")
