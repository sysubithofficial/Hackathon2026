"""V2V (vehicle-to-vehicle) messages for Collision Testing -- simulated, India settings.

Each connected vehicle (the test trucks with V2V on, and a share of the scene's vehicles) sends its state 10 times a
second (a BSM / CAM-like message: position as its GNSS reports it, speed, heading, length, braking) and, the moment
it brakes hard (>= BRAKE_ALERT m/s², a collision, a stop), an emergency brake alert (EEBL / DENM-like) at once.
The channel decides per message and receiver: delivered or lost, and when.

Links (India: the 5.9 GHz band is not yet assigned -- PC5 is the coming direct link, V2N works on today's networks):
  pc5  Direct C-V2X (PC5 sidelink): ~20 ms, ~450 m in line of sight, ~150 m when buildings block the line (and
       60 % more loss there).
  v2n  Cellular 4G/5G (V2N, through the operator's network): ~90 ms (varies 40 - 200 ms), no blocking by
       buildings (the network relays it), ~3 % loss.
Plus the loss set in the setup (0 - 50 %); heavy rain adds a little (fog: nothing -- radio is not affected by fog).
GNSS: the sender's position error (slowly drifting): NavIC / GPS ~2.5 m, GAGAN (SBAS) ~1.2 m, RTK ~0.1 m.

Plain data (no ASN.1 / J2735 encoding, no 1609.2 signing): the safety logic, not the radio, is tested.

Heavy traffic (channel load): on the direct link every vehicle in range shares one radio channel. Each message takes
~AIRTIME_MS of it, so the CHANNEL BUSY RATIO (CBR) = vehicles in range x their message rate x AIRTIME_MS. Above
DCC_TARGET the senders slow down (congestion control, ETSI DCC / SAE J3161: 10 -> 5 -> 2 messages a second), and
above CBR_LOSS_FROM messages collide (more loss). "Extra connected vehicles nearby" (setup) adds vehicles that are
only counted for this load (not simulated one by one). Cellular (V2N): no shared channel; a little more delay.
"""
import math
import random
import time

# one message on the air, what is in it (real standards, for the info window / detection details)
MSG_BYTES = 300               # a state message (SAE J2735 BSM / ETSI CAM) incl. security signature + certificate
ALERT_BYTES = 350             # a brake alert (EEBL / DENM)
AIRTIME_MS = 0.2              # PC5: the share of the channel one message takes (~2 of 10 sub-channels for 1 ms)
DCC_TARGET = 0.6              # congestion control keeps the channel at most this busy (senders slow down)
CBR_LOSS_FROM = 0.3           # above this, messages collide: up to +15 % loss at DCC_TARGET
VERIFY_PER_S = 2000           # a real V2V unit's signature checks a second (hardware security module, typical)
MSG_FIELDS = [                # (key, name, unit, meaning)
    ("tx", "Sender id", "", "who sends it (temporary id, changes for privacy in real systems)"),
    ("t", "Time stamp", "ms", "when it was made -- the receiver computes its age"),
    ("lat", "Latitude", "°", "its position from its GNSS (with the GNSS error)"),
    ("lon", "Longitude", "°", "its position from its GNSS"),
    ("hd", "Heading", "°", "direction it drives (0 = north) -- tells 'same way as me?'"),
    ("v", "Speed", "m/s", "how fast it drives"),
    ("a", "Acceleration", "m/s²", "negative = braking (how hard)"),
    ("brake", "Brake flag", "", "brakes on yes / no"),
    ("L", "Length", "m", "its length -- for the bumper-to-bumper gap"),
    ("alert", "Message type", "", "state (10× a second) or BRAKE ALERT (sent at once on hard braking)"),
]

LINKS = {
    "pc5": {"label": "Direct C-V2X (PC5)", "delay_ms": 20.0, "jitter_ms": 8.0, "range_m": 450.0, "nlos_range_m": 150.0,
            "base_loss": 0.01, "blocked_loss": 0.6, "blocking": True},
    "v2n": {"label": "Cellular 4G/5G (V2N)", "delay_ms": 90.0, "jitter_ms": 40.0, "range_m": 3000.0,
            "nlos_range_m": 3000.0, "base_loss": 0.03, "blocked_loss": 0.0, "blocking": False},
}
GNSS = {"navic": ("NavIC / GPS (~2.5 m)", 2.5), "gagan": ("GAGAN SBAS (~1.2 m)", 1.2), "rtk": ("RTK (~0.1 m)", 0.1)}
MODES = {"brake": "Brakes on it (automatic)", "warn": "Warns only (the AV brakes on its sensors)"}
DEFAULTS = {"link": "pc5", "loss_pct": 5, "block": True, "gnss": "navic", "mode": "brake", "connected_pct": 0,
            "bg_vehicles": 0}
RATE_HZ = 10.0
BRAKE_ALERT = 4.0             # m/s²: harder braking (or a sudden stop) sends a brake alert at once
STALE_S = 0.3                 # a message older than its delay + this is not used any more
ANTICIPATE_S = 0.8            # a brake alert: the receiver plans with the speed the sender brakes to this soon


def label(cfg):
    c = dict(DEFAULTS, **(cfg or {}))
    return (f"{LINKS[c['link']]['label']} · loss {c['loss_pct']:g} %"
            + (" · buildings block" if c.get("block") and LINKS[c["link"]]["blocking"] else "")
            + f" · {GNSS[c['gnss']][0]} · {MODES[c['mode']].split(' (')[0].lower()}"
            + (f" · {c['connected_pct']:g} % of the scene's vehicles connected" if c.get("connected_pct") else "")
            + (f" · +{c['bg_vehicles']:g} connected vehicles nearby (load)" if c.get("bg_vehicles") else ""))


def load_of(n_in_range, link="pc5"):
    """Channel load with n other connected vehicles in range -> {cbr_demand, rate_hz, cbr, extra_loss, delay_ms+}.
    PC5: shared channel, congestion control (DCC) slows the senders down to keep it at most DCC_TARGET busy.
    V2N: no shared channel (the operator's network): the rate stays, a little more delay with many vehicles."""
    n = max(0, int(n_in_range))
    if link != "pc5":
        return {"n": n, "cbr_demand": None, "cbr": None, "rate_hz": RATE_HZ, "extra_loss": 0.0,
                "extra_delay_ms": min(40.0, 0.02 * n)}
    demand = n * RATE_HZ * AIRTIME_MS / 1000.0
    rate = RATE_HZ if demand <= DCC_TARGET * 1.05 else max(1.0, RATE_HZ * DCC_TARGET / demand)
    cbr = min(1.0, n * rate * AIRTIME_MS / 1000.0)
    extra = 0.15 * max(0.0, cbr - CBR_LOSS_FROM) / (DCC_TARGET - CBR_LOSS_FROM)
    return {"n": n, "cbr_demand": demand, "cbr": cbr, "rate_hz": rate, "extra_loss": min(0.3, extra),
            "extra_delay_ms": 0.0}


def connected(obj_id, pct):
    """Is this scene vehicle connected (deterministic per id: the same share in every run)?"""
    if pct <= 0:
        return False
    if pct >= 100:
        return True
    h = 0
    for ch in str(obj_id):
        h = (h * 131 + ord(ch)) % 1000003
    return (h % 100) < pct


def _xy(lat0, lon0):
    kx = 111320.0 * math.cos(math.radians(lat0))
    return lambda lat, lon: ((lon - lon0) * kx, (lat - lat0) * 111320.0)


class Channel:
    """The V2V of one collision test. step(now, senders, receivers, climate) each tick; inbox(rx, now) -> the latest
    fresh message of every sender delivered to rx."""

    CELL = 50.0

    def __init__(self, cfg, buildings=None, origin=(0.0, 0.0), seed=7):
        self.cfg = dict(DEFAULTS, **(cfg or {}))
        self.link = LINKS[self.cfg["link"]]
        self.rng = random.Random(seed)
        self.err = {}                                      # tx -> (east, north) m: its GNSS error, drifting
        self.last_gen = {}                                 # tx -> time of its last periodic message
        self.prev_brake = {}                               # tx -> braking at its last message
        self.pending = []                                  # (deliver_at, rx, msg)
        self.latest = {}                                   # (rx, tx) -> msg delivered
        self.stats = {}                                    # rx -> {sent, rx, lost, alerts, delay_sum}
        self.events = []                                   # (t, rx, tx, kind, text)
        self.first_rx = {}                                 # (rx, tx) -> (t, distance) of the first message of a run
        self.tx_log = {}                                   # tx -> {n, alerts, last: msg} (what each one sends)
        self.rx_log = {}                                   # rx -> [(t, msg)] the latest deliveries (detection details)
        self.bg = max(0, int(self.cfg.get("bg_vehicles") or 0))   # extra connected vehicles nearby (load only)
        self.load = {}                                     # id -> load_of(...) + {"real": vehicles in range}
        self._load_t = -1e9
        self.rx_times = {}                                 # rx -> [times of deliveries] (the last 2 s: msgs / s)
        self.perf = {"steps": 0, "ms_sum": 0.0, "ms_max": 0.0, "pairs": 0, "msgs": 0, "t0": None}
        self._xy = _xy(*origin)
        self.grid = {}                                     # (i, j) -> [polygon xy] of the buildings there
        if self.cfg.get("block") and self.link["blocking"]:
            for b in buildings or []:
                poly = [self._xy(p[0], p[1]) for p in b.get("polygon") or []]
                if len(poly) < 3:
                    continue
                xs, ys = [p[0] for p in poly], [p[1] for p in poly]
                for i in range(int(min(xs) // self.CELL), int(max(xs) // self.CELL) + 1):
                    for j in range(int(min(ys) // self.CELL), int(max(ys) // self.CELL) + 1):
                        self.grid.setdefault((i, j), []).append(poly)

    # ---- the line of sight: a building between them? ----
    @staticmethod
    def _cross(p, q, a, b):
        def o(u, v, w):
            return (v[0] - u[0]) * (w[1] - u[1]) - (v[1] - u[1]) * (w[0] - u[0])
        return (o(p, q, a) * o(p, q, b) < 0) and (o(a, b, p) * o(a, b, q) < 0)

    def blocked(self, a_ll, b_ll):
        if not self.grid:
            return False
        a, b = self._xy(*a_ll), self._xy(*b_ll)
        seen = set()
        n = max(1, int(math.hypot(b[0] - a[0], b[1] - a[1]) // (self.CELL / 2)))
        for k in range(n + 1):                              # (the cells along the line)
            x, y = a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n
            for poly in self.grid.get((int(x // self.CELL), int(y // self.CELL)), ()):
                if id(poly) in seen:
                    continue
                seen.add(id(poly))
                for u, v in zip(poly, poly[1:] + poly[:1]):
                    if self._cross(a, b, u, v):
                        return True
        return False

    # ---- one tick ----
    def _gnss(self, tx, dt):
        """The sender's position error (m): a slowly drifting random walk around 0 with the GNSS's sigma."""
        sigma = GNSS[self.cfg["gnss"]][1]
        e = self.err.get(tx)
        if e is None:
            e = (self.rng.gauss(0, sigma), self.rng.gauss(0, sigma))
        k = math.exp(-dt / 20.0)                           # (correlated over ~20 s, as GNSS errors are)
        s = sigma * math.sqrt(max(0.0, 1 - k * k))
        e = (e[0] * k + self.rng.gauss(0, s), e[1] * k + self.rng.gauss(0, s))
        self.err[tx] = e
        return e

    def _st(self, rx):
        return self.stats.setdefault(rx, {"sent": 0, "rx": 0, "lost": 0, "alerts": 0, "delay_sum": 0.0, "blocked": 0})

    def step(self, now, senders, receivers, climate=None):
        """senders: [{id, label, lat, lon, hd, v (m/s), a (m/s²), L, brake (bool)}] (connected only);
        receivers: {id: (lat, lon)} (the test AVs with V2V on)."""
        t_cpu = time.perf_counter()
        if self.perf["t0"] is None:
            self.perf["t0"] = now
        rain = ((climate or {}).get("precip") or {})
        extra = 0.03 * float(rain.get("rate") or 0) if rain.get("type") == "rain" else 0.0
        base = self.link["base_loss"] + self.cfg["loss_pct"] / 100.0 + extra
        if now - self._load_t >= 0.5:                       # the channel load around each vehicle (2× a second)
            self._load_t = now
            self._update_load(senders, receivers)
        for s in senders:
            tx = s["id"]
            braking = bool(s.get("brake")) or float(s.get("a") or 0.0) <= -BRAKE_ALERT
            edge = braking and not self.prev_brake.get(tx, False)
            last = self.last_gen.get(tx, -1e9)
            rate = (self.load.get(tx) or {}).get("rate_hz", RATE_HZ)       # (congestion control: slower)
            if not edge and now - last < 1.0 / rate - 1e-3:
                continue
            dt = now - last if last > -1e8 else 0.1
            if not edge:                                    # (on its schedule: 10 a second on average, not every
                iv = 1.0 / rate                             #  other tick)
                self.last_gen[tx] = last + iv if now - last < 2 * iv else now
            self.prev_brake[tx] = braking
            ex, ey = self._gnss(tx, min(1.0, dt))
            kx = 111320.0 * math.cos(math.radians(s["lat"]))
            msg = {"tx": tx, "label": s.get("label") or tx, "t": now, "lat": s["lat"] + ey / 111320.0,
                   "lon": s["lon"] + ex / kx, "hd": s.get("hd"), "v": float(s.get("v") or 0.0),
                   "a": float(s.get("a") or 0.0), "L": float(s.get("L") or 4.9), "brake": braking, "alert": edge,
                   "err_m": math.hypot(ex, ey)}
            tl = self.tx_log.setdefault(tx, {"n": 0, "alerts": 0, "last": None})
            tl["n"] += 1
            tl["alerts"] += int(edge)
            tl["last"] = msg
            self.perf["msgs"] += 1
            for rx, pos in receivers.items():
                if rx == tx:
                    continue
                st = self._st(rx)
                st["sent"] += 1
                self.perf["pairs"] += 1
                ld = self.load.get(rx) or {}
                d = math.hypot(*[p - q for p, q in zip(self._xy(*pos), self._xy(s["lat"], s["lon"]))])
                blocked = self.link["blocking"] and self.cfg.get("block") and d > 12 and self.blocked(pos, (s["lat"], s["lon"]))
                rng = self.link["nlos_range_m"] if blocked else self.link["range_m"]
                p_loss = base + (self.link["blocked_loss"] if blocked else 0.0) + ld.get("extra_loss", 0.0)
                p_loss += max(0.0, (d - 0.7 * rng) / (0.3 * rng)) * 0.9 if d > 0.7 * rng else 0.0  # (fades at the edge)
                if d > rng or self.rng.random() < min(1.0, p_loss):
                    st["lost"] += 1
                    st["blocked"] += int(bool(blocked))
                    if edge:
                        self.events.append((now, rx, tx, "lost", f"brake alert from {msg['label']} LOST"
                                            + (" (a building in the way)" if blocked else "")))
                    continue
                delay = max(0.004, (self.rng.gauss(self.link["delay_ms"], self.link["jitter_ms"])
                                    + ld.get("extra_delay_ms", 0.0)) / 1000.0)
                self.pending.append((now + delay, rx, dict(msg, delay=delay, dist=d, blocked=bool(blocked))))
        keep = []
        for at, rx, m in self.pending:
            if at > now:
                keep.append((at, rx, m))
                continue
            key = (rx, m["tx"])
            cur = self.latest.get(key)
            st = self._st(rx)
            st["rx"] += 1
            st["delay_sum"] += m["delay"]
            if cur is None or m["t"] >= cur["t"]:
                self.latest[key] = m
            lg = self.rx_log.setdefault(rx, [])
            lg.append((now, m))
            if len(lg) > 40:
                del lg[:len(lg) - 40]
            rt = self.rx_times.setdefault(rx, [])
            rt.append(now)
            if len(rt) > 400 or (rt and now - rt[0] > 2.5):
                self.rx_times[rx] = [x for x in rt if now - x <= 2.0]
            if key not in self.first_rx or now - self.first_rx[key][0] > 30.0:
                self.first_rx[key] = (now, m["dist"])
            if m["alert"]:
                st["alerts"] += 1
                self.events.append((now, rx, m["tx"], "alert", f"brake alert from {m['label']} "
                                    f"({m['delay'] * 1000:.0f} ms, {m['dist']:.0f} m)"))
        self.pending = keep
        ms = (time.perf_counter() - t_cpu) * 1000.0
        self.perf["steps"] += 1
        self.perf["ms_sum"] += ms
        self.perf["ms_max"] = max(self.perf["ms_max"], ms)

    def _update_load(self, senders, receivers):
        """Vehicles in radio range of each one (the senders simulated + the extra 'nearby' ones) -> load_of."""
        pos = {s["id"]: self._xy(s["lat"], s["lon"]) for s in senders}
        for rx, p in receivers.items():
            pos.setdefault(rx, self._xy(*p))
        rng = self.link["range_m"]
        cell = max(50.0, rng)
        grid = {}
        for s in senders:
            x, y = pos[s["id"]]
            grid.setdefault((int(x // cell), int(y // cell)), []).append(s["id"])
        load = {}
        for vid, (x, y) in pos.items():
            i, j = int(x // cell), int(y // cell)
            n = 0
            for di in (-1, 0, 1):
                for dj in (-1, 0, 1):
                    for o in grid.get((i + di, j + dj), ()):
                        if o != vid:
                            ox, oy = pos[o]
                            n += (x - ox) ** 2 + (y - oy) ** 2 <= rng * rng
            ld = load_of(n + self.bg, self.cfg["link"])
            ld["real"] = n
            load[vid] = ld
        self.load = load

    def load_info(self, vid, now):
        """{n (simulated) , bg, rate_hz, cbr, cbr_demand, extra_loss, rx_per_s (simulated), rx_per_s_total}"""
        ld = dict(self.load.get(vid) or load_of(self.bg, self.cfg["link"]), bg=self.bg)
        ld.setdefault("real", 0)
        rt = [x for x in self.rx_times.get(vid, ()) if now - x <= 2.0]
        ld["rx_per_s"] = len(rt) / 2.0
        loss = min(1.0, self.link["base_loss"] + self.cfg["loss_pct"] / 100.0 + ld.get("extra_loss", 0.0))
        ld["rx_per_s_total"] = ld["rx_per_s"] + self.bg * ld["rate_hz"] * (1.0 - loss)
        ld["verify_pct"] = 100.0 * ld["rx_per_s_total"] / VERIFY_PER_S
        return ld

    def perf_info(self, now):
        """The app's own cost of V2V: ms per tick (avg / max), messages made / deliveries checked per second."""
        p = self.perf
        span = max(1e-3, now - (p["t0"] or now))
        return {"ms_avg": p["ms_sum"] / p["steps"] if p["steps"] else 0.0, "ms_max": p["ms_max"],
                "msgs_per_s": p["msgs"] / span, "pairs_per_s": p["pairs"] / span, "pending": len(self.pending)}

    def inbox(self, rx, now):
        """The latest fresh message of every sender delivered to rx (age within its delay + STALE_S)."""
        out = []
        for (r, tx), m in self.latest.items():
            if r == rx and now - m["t"] <= m["delay"] + STALE_S:
                out.append(dict(m, age=now - m["t"]))
        return out

    def summary(self, rx):
        st = self._st(rx)
        n = st["rx"] + st["lost"]
        return {"sent": st["sent"], "received": st["rx"], "lost": st["lost"], "alerts": st["alerts"],
                "loss_pct": round(100.0 * st["lost"] / n, 1) if n else 0.0,
                "delay_ms": round(1000.0 * st["delay_sum"] / st["rx"], 1) if st["rx"] else None,
                "blocked": st["blocked"]}
