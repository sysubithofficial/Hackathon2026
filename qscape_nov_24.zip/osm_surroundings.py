"""
osm_surroundings.py -- the yard's real-world surroundings for the 3D view.

"Update 3D" (3D map view) downloads buildings, roads, railways, fences / walls,
trees, water and land use around the yard from OpenStreetMap (Overpass API),
converts them to simple shapes in lat/lng and saves them as
sites/<site>/data/osm_surroundings.json, so the 3D view shows them from then on
(also offline) until the next update.

Street details (all optional keys -- older files without them still load):
  roads        + lanes / oneway / sidewalk / surface / crossing (when tagged)
  road_marks   zebra crossings, stop lines, speed bumps / humps / tables / cushions,
               rumble strips: {kind, lat, lon, dir (road bearing deg), len (across), depth (along)}
  medians      raised dividers between the two halves of a dual carriageway
               (found from parallel one-way roads): {line, widths}
  points       + bus stops / shelters, benches, waste baskets, statues / monuments /
               memorials / artworks, billboards, traffic / stop / give-way signs,
               flagpoles, street cabinets, transformers, post boxes, fountains, clocks,
               concrete blocks; "dir" = the bearing (deg) the object's front faces
               (signals / signs face their traffic, lamps / shelters / benches the road);
               street lamps also along roads tagged lit=yes (where none are mapped);
               traffic signals one per approach of the junction, at the kerb
  trees        [lat, lng] or [lat, lng, type] (1 broadleaf, 2 conifer, 3 palm)
  areas        + "paved" (squares / pedestrian areas), "island" (traffic islands), "sand"

Why OpenStreetMap and not Google Maps: Google's terms do not allow downloading or
storing its map data (buildings / roads); OpenStreetMap data is free to download
and use under the ODbL licence -- the 3D view shows the required attribution
"(c) OpenStreetMap contributors".
"""

import json
import math
import os
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime

# GET is used: on this network POSTed queries are rejected, GET ones are not.
OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",          # busy at times: answers 504 quickly
    "https://overpass.kumi.systems/api/interpreter",
    "https://lz4.overpass-api.de/api/interpreter",
    "https://z.overpass-api.de/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
REQUEST_TIMEOUT_S = 60
USER_AGENT = "yard-yard-simulation/1.0 (yard 3D view)"
ATTRIBUTION = "© OpenStreetMap contributors"

# heights (m) when a building has no height / levels in OpenStreetMap
DEFAULT_BUILDING_HEIGHT = {
    "warehouse": 12, "industrial": 11, "commercial": 9, "retail": 8, "office": 12, "hangar": 12,
    "house": 7, "residential": 9, "detached": 7, "apartments": 14, "garage": 3.5, "garages": 3.5,
    "shed": 3, "roof": 5, "kiosk": 3, "service": 4, "farm_auxiliary": 6, "barn": 8,
}
LEVEL_HEIGHT_M = 3.2

ROAD_WIDTH = {
    "motorway": 14, "trunk": 12, "primary": 10, "secondary": 9, "tertiary": 8,
    "unclassified": 6.5, "residential": 6.5, "living_street": 5, "service": 5,
    "motorway_link": 7, "trunk_link": 7, "primary_link": 7, "secondary_link": 6, "tertiary_link": 6,
    "track": 3.5, "footway": 2, "path": 1.8, "cycleway": 2, "pedestrian": 4, "steps": 2,
}
LANE_WIDTH_M = 3.3                   # a road with "lanes" but no "width"
BARRIER_HEIGHT = {"fence": 2.0, "wall": 2.5, "retaining_wall": 1.5, "hedge": 1.5,
                  "guard_rail": 0.8, "city_wall": 4.0, "jersey_barrier": 0.9,
                  "kerb": 0.15, "handrail": 1.0, "cable_barrier": 0.8, "chain": 0.5, "railing": 1.1,
                  "planter": 0.6}
AREA_KINDS = {                       # (tag, value regex) -> area kind used for colouring
    ("natural", r"water"): "water", ("landuse", r"reservoir|basin"): "water", ("leisure", r"swimming_pool"): "water",
    ("natural", r"wood|scrub"): "wood", ("landuse", r"forest|orchard|plant_nursery"): "wood",
    ("landuse", r"grass|meadow|recreation_ground|village_green|greenfield|cemetery|allotments"): "grass",
    ("natural", r"grassland|heath|wetland"): "grass",
    ("leisure", r"park|pitch|garden|playground|sports_centre|golf_course|track|stadium"): "grass",
    ("amenity", r"parking"): "parking",
    ("area:highway", r"traffic_island"): "island", ("traffic_calming", r"island"): "island",
    ("area:highway", r".+"): "paved", ("place", r"square"): "paved", ("amenity", r"marketplace"): "paved",
    ("natural", r"sand|beach"): "sand",
    ("landuse", r"commercial|retail"): "commercial",
    ("landuse", r"industrial|railway|construction|brownfield|depot|port"): "industrial",
    ("landuse", r"residential"): "residential", ("landuse", r"farmland|farmyard"): "farmland",
}
WOOD_TREE_SPACING_M = {"wood": 9.0}  # wooded areas get trees (deterministic, about this far apart)
TREE_ROW_SPACING_M = 7.0
MAX_TREES = 9000                     # all trees together (the 3D view / LiDAR stay fast)
MAX_POINTS = 6000                    # all point objects together (lamps, poles, signs, benches ...)
MAX_PER_POINT_KIND = 2000
MAX_LIT_LAMPS = 1500                 # lamps added along lit=yes roads
MAX_ROAD_MARKS = 3000
LIT_LAMP_SPACING_M = {"road": 32.0, "path": 25.0}

MOTOR_RX = re.compile(r"motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|"
                      r"service|road|busway|\w+_link")
MEDIAN_RX = re.compile(r"motorway|trunk|primary|secondary|tertiary|unclassified|residential|\w+_link")
LAMP_ROADS_RX = re.compile(r"motorway|trunk|primary|secondary|\w+_link")   # lamps placed along these
SMALL_RX = re.compile(r"footway|path|cycleway|steps|pedestrian|bridleway|track")
PALM_RX = re.compile(r"cocos|palm|areca|phoenix|roystonea|borassus|elaeis|arecaceae|washingtonia|caryota", re.I)
# left-hand traffic (rough boxes: south, north, west, east): signs / signals stand on the left of the traffic
LHT_BOXES = [(6, 24.5, 68, 98), (24.5, 36, 74.6, 98), (49.8, 61, -11, 2), (24, 46, 123, 146),
             (-44, -10, 112, 154), (-48, -34, 166, 179), (-35, -22, 16, 33), (-11, 7.5, 95, 120),
             (5.5, 20.5, 97.3, 105.6), (22.1, 22.6, 113.8, 114.5), (17.6, 18.6, -78.5, -76)]


def _query(s, w, n, e, details=True):
    core = [
        'way["building"]', 'relation["building"]', 'way["highway"]',
        'way["railway"~"rail|siding|spur|yard|industrial"]', 'way["barrier"]', 'node["natural"="tree"]',
        'way["natural"~"water|wood|scrub|grassland|heath|wetland|tree_row|sand|beach"]', 'way["landuse"]',
        'way["leisure"~"park|pitch|garden|playground|sports_centre|swimming_pool|golf_course|track|stadium"]',
        'way["amenity"~"^(parking|marketplace)$"]',
        'relation["type"="multipolygon"]["landuse"]',
        'relation["type"="multipolygon"]["natural"~"water|wood|scrub|grassland|heath|wetland"]',
        'relation["type"="multipolygon"]["leisure"~"park|pitch|garden|playground|sports_centre|golf_course|stadium"]',
        'relation["type"="multipolygon"]["amenity"="parking"]',
        'way["waterway"]', 'way["power"~"line|minor_line"]', 'node["power"~"pole|tower|portal"]',
        'node["highway"~"street_lamp|traffic_signals|stop|give_way"]',
        'node["man_made"~"mast|flagpole|tower|lamp|surveillance"]', 'node["emergency"="fire_hydrant"]',
        'node["barrier"~"bollard|gate|lift_gate"]', 'node["advertising"]',
    ]
    det = [                                                   # street furniture / road details
        'node["highway"~"crossing|bus_stop|speed_camera"]', 'node["traffic_calming"]', 'way["traffic_calming"]',
        'node["traffic_sign"]', 'node["public_transport"="platform"]',
        'node["amenity"~"^(bench|waste_basket|shelter|post_box|fountain|clock)$"]', 'node["leisure"="picnic_table"]',
        'node["historic"~"^(memorial|monument|statue|wayside_cross|wayside_shrine)$"]',
        'way["historic"~"^(memorial|monument)$"]', 'node["tourism"="artwork"]', 'way["tourism"="artwork"]',
        'node["man_made"~"^(street_lamp|utility_pole|street_cabinet)$"]',
        'node["power"~"^(transformer|catenary_mast)$"]', 'node["barrier"~"^(block|swing_gate)$"]',
        'way["area:highway"]', 'way["place"="square"]',
    ] if details else []
    body = "".join(f"{q};" for q in core + det)            # (the global bbox keeps the GET URL short)
    return f"[out:json][timeout:120][bbox:{s:.7f},{w:.7f},{n:.7f},{e:.7f}];({body});out geom;"


# point objects (lamp posts, poles, hydrants ...): kind -> (match, default height m); the first match wins
def _bus(t):
    return t.get("highway") == "bus_stop" or (t.get("public_transport") == "platform" and t.get("bus") == "yes")


def _statue(t):
    return (t.get("historic") == "statue" or t.get("memorial") in ("statue", "bust")
            or (t.get("tourism") == "artwork" and t.get("artwork_type") in ("statue", "bust")))


POINT_KINDS = [
    ("street_lamp", lambda t: t.get("highway") == "street_lamp" or t.get("man_made") in ("lamp", "street_lamp"), 8.0),
    ("power_tower", lambda t: t.get("power") == "tower", 28.0),
    ("power_tower", lambda t: t.get("power") == "portal", 15.0),      # substation portal
    ("power_pole", lambda t: t.get("power") in ("pole", "catenary_mast") or t.get("man_made") == "utility_pole", 11.0),
    ("transformer", lambda t: t.get("power") == "transformer", 2.2),
    ("traffic_signals", lambda t: t.get("highway") == "traffic_signals", 5.5),
    ("stop_sign", lambda t: t.get("highway") == "stop", 2.6),
    ("give_way_sign", lambda t: t.get("highway") == "give_way", 2.6),
    ("bus_shelter", lambda t: (_bus(t) and t.get("shelter") == "yes")
     or (t.get("amenity") == "shelter" and t.get("shelter_type") == "public_transport"), 2.7),
    ("bus_stop", _bus, 2.8),
    ("shelter", lambda t: t.get("amenity") == "shelter", 2.7),
    ("statue", _statue, 4.5),
    ("monument", lambda t: t.get("historic") == "monument" or t.get("memorial") in ("obelisk", "column"), 8.0),
    ("memorial", lambda t: t.get("historic") in ("memorial", "wayside_cross", "wayside_shrine"), 2.0),
    ("artwork", lambda t: t.get("tourism") == "artwork", 3.0),
    ("billboard", lambda t: t.get("advertising") in ("billboard", "board"), 8.0),
    ("sign", lambda t: "traffic_sign" in t or "advertising" in t, 2.6),
    ("camera", lambda t: t.get("man_made") == "surveillance" or t.get("highway") == "speed_camera", 5.0),
    ("flagpole", lambda t: t.get("man_made") == "flagpole", 10.0),
    ("water_tower", lambda t: t.get("man_made") == "water_tower", 20.0),
    ("mast", lambda t: t.get("man_made") in ("mast", "tower"), 15.0),
    ("fire_hydrant", lambda t: t.get("emergency") == "fire_hydrant", 0.8),
    ("bollard", lambda t: t.get("barrier") == "bollard", 1.0),
    ("block", lambda t: t.get("barrier") == "block", 0.8),
    ("gate", lambda t: t.get("barrier") in ("gate", "lift_gate", "swing_gate"), 1.4),
    ("street_cabinet", lambda t: t.get("man_made") == "street_cabinet", 1.3),
    ("bench", lambda t: t.get("amenity") == "bench" or t.get("leisure") == "picnic_table", 0.9),
    ("waste_basket", lambda t: t.get("amenity") == "waste_basket", 0.9),
    ("post_box", lambda t: t.get("amenity") == "post_box", 1.3),
    ("fountain", lambda t: t.get("amenity") == "fountain", 1.5),
    ("clock", lambda t: t.get("amenity") == "clock", 4.0),
]
# how a point is turned: "traffic" = faces the traffic on the nearest road (signs), "road" = faces the road
# (lamp arms, shelters, benches, statues ...); others keep a random / power-line turn
FACING = {"stop_sign": "traffic", "give_way_sign": "traffic", "sign": "traffic", "camera": "traffic",
          "traffic_signals": "traffic",
          "street_lamp": "road", "bus_stop": "road", "bus_shelter": "road", "shelter": "road", "bench": "road",
          "billboard": "road", "statue": "road", "monument": "road", "memorial": "road", "artwork": "road",
          "street_cabinet": "road", "post_box": "road", "waste_basket": "road", "fire_hydrant": "road"}
KERB_KINDS = {"street_lamp", "bus_stop", "bus_shelter", "stop_sign", "give_way_sign", "sign", "camera",
              "billboard", "fire_hydrant", "waste_basket", "post_box"}       # moved off the carriageway
# traffic calming -> (road mark kind, depth along the road m)
CALMING = {"bump": ("bump", 0.9), "yes": ("bump", 0.9), "hump": ("hump", 3.7), "table": ("table", 6.0),
           "cushion": ("cushion", 2.5), "rumble_strip": ("rumble_strip", 4.0), "dip": ("hump", 3.0)}
UNMARKED = ("unmarked", "no", "informal")


def _fetch(query, progress=None, attempts_per_endpoint=2):
    errors = []
    for attempt in range(attempts_per_endpoint):
        for url in list(OVERPASS_ENDPOINTS):
            if progress:
                progress(f"Contacting {urllib.parse.urlparse(url).netloc} ...")
            try:
                req = urllib.request.Request(url + "?data=" + urllib.parse.quote(query),
                                             headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_S) as r:
                    data = json.load(r)
                if OVERPASS_ENDPOINTS[0] != url:                 # the next download asks this one first
                    OVERPASS_ENDPOINTS.remove(url)
                    OVERPASS_ENDPOINTS.insert(0, url)
                return data
            except Exception as e:                       # busy server / network -> next one
                errors.append(f"{urllib.parse.urlparse(url).netloc}: {e}")
        if attempt + 1 < attempts_per_endpoint:
            time.sleep(4 + attempt * 6)
    raise RuntimeError("OpenStreetMap (Overpass) did not answer:\n" + "\n".join(errors[-5:]))


def _num(text):
    m = re.search(r"-?\d+(?:\.\d+)?", str(text or ""))
    return float(m.group()) if m else None


def _height(tags):
    h = _num(tags.get("height")) or _num(tags.get("building:height"))
    if h and h > 0.5:
        return h
    levels = _num(tags.get("building:levels"))
    if levels and levels > 0:
        return levels * LEVEL_HEIGHT_M + 1.0
    return DEFAULT_BUILDING_HEIGHT.get(tags.get("building"), 8.0)


def _coords(el):
    return [[round(p["lat"], 7), round(p["lon"], 7)] for p in el.get("geometry", []) if p]


def _area_kind(tags):
    for (key, rx), kind in AREA_KINDS.items():
        if key in tags and re.fullmatch(rx, tags[key]):
            return kind
    return None


def _tree_type(tags):
    """1 broadleaf, 2 conifer, 3 palm, 0 unknown (the 3D view picks one by the climate)."""
    txt = " ".join(str(tags.get(k, "")) for k in ("genus", "species", "taxon", "species:en", "leaf_type", "name"))
    if PALM_RX.search(txt):
        return 3
    lt = tags.get("leaf_type", "")
    return 1 if lt == "broadleaved" else 2 if lt == "needleleaved" else 0


def _tree(lat, lng, typ):
    return [round(lat, 7), round(lng, 7), typ] if typ else [round(lat, 7), round(lng, 7)]


def _rings(members):
    """A multipolygon relation's outer ways (pieces) joined into closed rings [[lat, lng], ...]."""
    segs = [[[round(p["lat"], 7), round(p["lon"], 7)] for p in m["geometry"] if p]
            for m in members if m.get("role") in ("outer", "") and m.get("type") == "way" and m.get("geometry")]
    segs = [s for s in segs if len(s) >= 2]
    rings = []
    while segs:
        ring = segs.pop(0)
        changed = True
        while ring[0] != ring[-1] and changed:
            changed = False
            for i, s in enumerate(segs):
                if s[0] == ring[-1]:
                    ring += s[1:]
                elif s[-1] == ring[-1]:
                    ring += s[::-1][1:]
                elif s[-1] == ring[0]:
                    ring = s[:-1] + ring
                elif s[0] == ring[0]:
                    ring = s[::-1][:-1] + ring
                else:
                    continue
                segs.pop(i)
                changed = True
                break
        if len(ring) >= 4 and ring[0] == ring[-1]:
            rings.append(ring)
    return rings


def _inside(lat, lng, poly):
    c = False
    for (ya, xa), (yb, xb) in zip(poly, poly[1:] + poly[:1]):
        if (ya > lat) != (yb > lat) and lng < xa + (lat - ya) * (xb - xa) / (yb - ya):
            c = not c
    return c


def _area_trees(poly, spacing, box, budget, typ=0):
    """Trees filling a wooded area (a jittered grid, the same every time), inside `box` only."""
    import random
    lats = [p[0] for p in poly]; lngs = [p[1] for p in poly]
    s, n = max(min(lats), box[0]), min(max(lats), box[2])
    w, e = max(min(lngs), box[1]), min(max(lngs), box[3])
    if s >= n or w >= e:
        return []
    dlat = spacing / 111320.0
    dlng = spacing / (111320.0 * max(0.2, math.cos(math.radians((s + n) / 2))))
    rnd = random.Random(round(s * 1e5) * 31 + round(w * 1e5))
    out = []
    lat = s + dlat / 2
    while lat < n and len(out) < budget:
        lng = w + dlng / 2
        while lng < e and len(out) < budget:
            y, x = lat + rnd.uniform(-0.35, 0.35) * dlat, lng + rnd.uniform(-0.35, 0.35) * dlng
            if _inside(y, x, poly):
                out.append(_tree(y, x, typ))
            lng += dlng
        lat += dlat
    return out


def _row_trees(line, spacing, typ=0):
    out = []
    for (a, b) in zip(line, line[1:]):
        kx = 111320.0 * math.cos(math.radians(a[0]))
        d = math.hypot((b[1] - a[1]) * kx, (b[0] - a[0]) * 111320.0)
        k = max(1, int(d // spacing))
        for i in range(k):
            f = i / k
            out.append(_tree(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, typ))
    if line:
        out.append(_tree(line[-1][0], line[-1][1], typ))
    return out


# ---------------- local metric frame + road index (placing street furniture along the roads) ----------------
class _Frame:
    """lat/lng <-> metres (x east, y north) around a centre."""
    def __init__(self, lat0, lng0):
        self.lat0, self.lng0 = lat0, lng0
        self.kx = 111320.0 * max(0.2, math.cos(math.radians(lat0)))

    def xy(self, lat, lng):
        return ((lng - self.lng0) * self.kx, (lat - self.lat0) * 111320.0)

    def ll(self, x, y):
        return [round(self.lat0 + y / 111320.0, 7), round(self.lng0 + x / self.kx, 7)]


def _bearing(dx, dy):
    return math.degrees(math.atan2(dx, dy)) % 360.0


class _RoadIndex:
    """Segments of the roads on a 30 m grid: nearest segment of a point."""
    CELL = 30.0

    def __init__(self, roads, frame):
        self.roads, self.segs, self.grid = roads, [], {}
        for ri, r in enumerate(roads):
            pts = r["_xy"]
            for a, b in zip(pts, pts[1:]):
                if a == b:
                    continue
                si = len(self.segs)
                self.segs.append((a[0], a[1], b[0], b[1], ri))
                for cx in range(int(math.floor(min(a[0], b[0]) / self.CELL)), int(math.floor(max(a[0], b[0]) / self.CELL)) + 1):
                    for cy in range(int(math.floor(min(a[1], b[1]) / self.CELL)), int(math.floor(max(a[1], b[1]) / self.CELL)) + 1):
                        self.grid.setdefault((cx, cy), []).append(si)

    def nearest(self, x, y, max_d, accept=None):
        """-> (dist, px, py, seg_bearing, road_index) of the nearest segment within max_d, or None."""
        best, seen = None, set()
        c0x, c0y = int(math.floor((x - max_d) / self.CELL)), int(math.floor((y - max_d) / self.CELL))
        c1x, c1y = int(math.floor((x + max_d) / self.CELL)), int(math.floor((y + max_d) / self.CELL))
        for cx in range(c0x, c1x + 1):
            for cy in range(c0y, c1y + 1):
                for si in self.grid.get((cx, cy), ()):
                    if si in seen:
                        continue
                    seen.add(si)
                    ax, ay, bx, by, ri = self.segs[si]
                    if accept is not None and not accept(ri, ax, ay, bx, by):
                        continue
                    dx, dy = bx - ax, by - ay
                    L2 = dx * dx + dy * dy
                    t = max(0.0, min(1.0, ((x - ax) * dx + (y - ay) * dy) / L2))
                    px, py = ax + dx * t, ay + dy * t
                    d = math.hypot(x - px, y - py)
                    if d <= max_d and (best is None or d < best[0]):
                        best = (d, px, py, _bearing(dx, dy), ri)
        return best


def _length(pts):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:]))


def _along(pts, step, start=None):
    """Points every `step` m along a polyline (x, y) -> [(x, y, bearing)]."""
    out, carry = [], (step / 2 if start is None else start)
    for a, b in zip(pts, pts[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        if L < 1e-6:
            continue
        brg = _bearing(b[0] - a[0], b[1] - a[1])
        d = carry
        while d <= L:
            f = d / L
            out.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, brg))
            d += step
        carry = d - L
    return out


def _unit(brg):
    r = math.radians(brg)
    return math.sin(r), math.cos(r)


def _road_width(tags):
    w = _num(tags.get("width"))
    if w and 1 <= w <= 60:
        return w
    lanes = _num(tags.get("lanes"))
    kind = tags["highway"]
    if lanes and 1 <= lanes <= 12 and MOTOR_RX.fullmatch(kind):
        return max(ROAD_WIDTH.get(kind, 5) * (0.5 if tags.get("oneway") in ("yes", "-1") else 1.0), lanes * LANE_WIDTH_M)
    return ROAD_WIDTH.get(kind, 5)


def convert(osm, box=None):
    """Overpass JSON -> {buildings, roads, railways, barriers, trees, areas, waterways, points, power_lines,
    road_marks, medians}. box = (south, west, north, east): wooded areas are filled with trees inside it."""
    out = {"buildings": [], "roads": [], "railways": [], "barriers": [], "trees": [],
           "areas": [], "waterways": [], "points": [], "power_lines": [], "road_marks": [], "medians": []}
    woods, rows, nodes, calm_ways, art_ways, bollard_lines = [], [], [], [], [], []
    elements = osm.get("elements", [])
    if box is None:
        lats = [el["lat"] for el in elements if el.get("type") == "node" and "lat" in el] or [0.0]
        lngs = [el["lon"] for el in elements if el.get("type") == "node" and "lon" in el] or [0.0]
        center = ((min(lats) + max(lats)) / 2, (min(lngs) + max(lngs)) / 2)
    else:
        center = ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
    F = _Frame(*center)
    lht = any(s <= center[0] <= n and w <= center[1] <= e for s, n, w, e in LHT_BOXES)
    for el in elements:
        tags = el.get("tags", {})
        if el["type"] == "node":
            if tags.get("natural") == "tree":
                out["trees"].append(_tree(el["lat"], el["lon"], _tree_type(tags)))
            else:
                nodes.append(el)
            continue
        if "power" in tags and tags["power"] in ("line", "minor_line"):
            pts = _coords(el)
            if len(pts) >= 2:
                out["power_lines"].append({"kind": tags["power"], "line": pts})
            continue
        if el["type"] == "relation":                        # multipolygons: buildings, land use, woods, water ...
            if "building" in tags:
                for m in el.get("members", []):
                    if m.get("role") == "outer" and m.get("geometry"):
                        pts = [[round(p["lat"], 7), round(p["lon"], 7)] for p in m["geometry"]]
                        if len(pts) >= 4:
                            out["buildings"].append({"name": tags.get("name", ""), "kind": tags["building"],
                                                     "height": _height(tags), "polygon": pts})
            else:
                kind = _area_kind(tags)
                if kind:
                    for ring in _rings(el.get("members", [])):
                        out["areas"].append({"kind": kind, "polygon": ring, "name": tags.get("name", "")})
                        if kind == "wood":
                            woods.append((ring, _tree_type(tags)))
            continue
        if tags.get("natural") == "tree_row":
            pts = _coords(el)
            if len(pts) >= 2:
                rows.append((pts, _tree_type(tags)))
            continue
        pts = _coords(el)
        if len(pts) < 2:
            continue
        closed = len(pts) >= 4 and pts[0] == pts[-1]
        if ("building" in tags or "building:part" in tags) and closed:
            out["buildings"].append({"name": tags.get("name", ""),
                                     "kind": tags.get("building") or tags.get("building:part"),
                                     "height": _height(tags), "polygon": pts,
                                     "min_height": _num(tags.get("min_height")) or 0.0,
                                     "roof_shape": tags.get("roof:shape", ""),
                                     "roof_height": _num(tags.get("roof:height")) or 0.0})
        elif "highway" in tags and tags.get("area") != "yes":
            r = {"kind": tags["highway"], "name": tags.get("name", ""), "width": _road_width(tags), "line": pts}
            lanes = _num(tags.get("lanes"))
            if lanes and 1 <= lanes <= 12:
                r["lanes"] = int(lanes)
            ow = tags.get("oneway")
            if ow in ("yes", "-1") or (ow is None and (tags.get("junction") == "roundabout" or r["kind"] == "motorway")):
                r["oneway"] = -1 if ow == "-1" else 1
            sw = tags.get("sidewalk") or tags.get("sidewalk:both") and "both"
            if sw in ("both", "left", "right"):
                r["sidewalk"] = sw
            if re.search(r"unpaved|gravel|dirt|ground|earth|sand|grass|mud|compacted", tags.get("surface", "")):
                r["surface"] = "unpaved"
            cr = tags.get("footway") == "crossing" or tags.get("cycleway") == "crossing" or tags.get("path") == "crossing"
            if cr:
                marked = tags.get("crossing") not in UNMARKED and tags.get("crossing:markings") != "no"
                r["crossing"] = "zebra" if marked else "unmarked"
            r["_xy"] = [F.xy(p[0], p[1]) for p in pts]
            r["_nodes"] = el.get("nodes") or []
            r["_lit"] = tags.get("lit") == "yes" and tags.get("tunnel") in (None, "no")
            r["_ref"] = tags.get("ref", "")
            out["roads"].append(r)
            if "traffic_calming" in tags and not closed:
                calm_ways.append((tags, pts))
        elif "railway" in tags:
            out["railways"].append({"kind": tags["railway"], "line": pts})
        elif "barrier" in tags:
            if tags["barrier"] in BARRIER_HEIGHT:
                out["barriers"].append({"kind": tags["barrier"],
                                        "height": _num(tags.get("height")) or BARRIER_HEIGHT[tags["barrier"]],
                                        "line": pts})
            elif tags["barrier"] in ("bollard", "block"):
                bollard_lines.append((tags["barrier"], pts))
        elif "waterway" in tags:
            out["waterways"].append({"kind": tags["waterway"], "line": pts})
        elif ("historic" in tags or tags.get("tourism") == "artwork") and closed and "landuse" not in tags:
            art_ways.append((tags, pts))
        elif "traffic_calming" in tags and not closed:
            calm_ways.append((tags, pts))
        elif closed:
            kind = "paved" if "highway" in tags else _area_kind(tags)
            if kind:
                out["areas"].append({"kind": kind, "polygon": pts, "name": tags.get("name", "")})
                if kind == "wood":
                    woods.append((pts, _tree_type(tags)))

    roads = out["roads"]
    index = _RoadIndex(roads, F)
    node_roads = {}                                       # node id -> [(road index, vertex index)]
    for ri, r in enumerate(roads):
        for vi, nid in enumerate(r["_nodes"]):
            node_roads.setdefault(nid, []).append((ri, vi))
    is_motor = lambda ri: bool(MOTOR_RX.fullmatch(roads[ri]["kind"]))
    motor_only = lambda ri, *_: is_motor(ri)
    side = -1.0 if lht else 1.0                           # +1: traffic keeps right (signs on its right)

    def on_motor_road(nid):
        return [(ri, vi) for ri, vi in node_roads.get(nid, ()) if is_motor(ri) and not roads[ri].get("crossing")]

    def vertex_bearing(ri, vi):
        xy = roads[ri]["_xy"]
        a, b = xy[max(0, vi - 1)], xy[min(len(xy) - 1, vi + 1)]
        return _bearing(b[0] - a[0], b[1] - a[1])

    def mark(kind, x, y, brg, length, depth):
        if len(out["road_marks"]) < MAX_ROAD_MARKS:
            lat, lng = F.ll(x, y)
            out["road_marks"].append({"kind": kind, "lat": lat, "lon": lng, "dir": int(round(brg)) % 360,
                                      "len": round(length, 1), "depth": round(depth, 1)})

    pts_out, per_kind = out["points"], {}

    def add_point(kind, x, y, height, name="", face=None):
        if len(pts_out) >= MAX_POINTS or per_kind.get(kind, 0) >= MAX_PER_POINT_KIND:
            return
        per_kind[kind] = per_kind.get(kind, 0) + 1
        lat, lng = F.ll(x, y)
        p = {"kind": kind, "lat": lat, "lon": lng, "height": height}
        if name:
            p["name"] = name
        if face is not None:
            p["dir"] = int(round(face)) % 360
        pts_out.append(p)

    def kerb_place(x, y, kind, facing):
        """(x, y, facing bearing) at the road side: on / in a carriageway -> moved to its kerb (the traffic side)."""
        motor = facing == "traffic" or kind in KERB_KINDS
        near = index.nearest(x, y, 30.0 if facing == "traffic" else 25.0, motor_only if motor else None)
        if near is None:
            return x, y, None
        d, px, py, brg, ri = near
        hw = roads[ri]["width"] / 2
        ux, uy = _unit(brg)
        rx, ry = uy, -ux                                   # the right of the road's direction
        s = (x - px) * rx + (y - py) * ry                  # > 0: right of the road line
        if d < 0.3:
            s_side = side                                  # on the centre line: the traffic side of the forward way
        else:
            s_side = 1.0 if s > 0 else -1.0
        if kind in KERB_KINDS and d < hw + 0.4:            # standing in the carriageway -> to the kerb
            x, y = px + rx * s_side * (hw + 0.7), py + ry * s_side * (hw + 0.7)
        if facing == "road":
            face = _bearing(-rx * s_side, -ry * s_side)
        else:                                              # face the traffic that has this side as its own
            travel = brg if s_side == side else (brg + 180.0)
            face = travel + 180.0
        return x, y, face

    # ---- point objects
    crossing_nodes = set()
    for r in roads:
        if r.get("crossing"):
            crossing_nodes.update(r["_nodes"])
    lamps_xy = []
    for el in nodes:
        tags, nid = el.get("tags", {}), el.get("id")
        x, y = F.xy(el["lat"], el["lon"])
        hw_tag = tags.get("highway")
        # zebra crossings / stop lines / speed bumps on the road
        on = on_motor_road(nid)
        if on:
            ri, vi = on[0]
            brg, wid = vertex_bearing(ri, vi), roads[ri]["width"]
            cr = tags.get("crossing")
            if ((hw_tag == "crossing" or (hw_tag == "traffic_signals" and cr)) and nid not in crossing_nodes
                    and cr not in UNMARKED and tags.get("crossing:markings") != "no"):
                mark("zebra", x, y, brg, wid, 3.0)
            if hw_tag == "stop":
                mark("stop_line", x, y, brg, wid, 0.4)
            if tags.get("traffic_calming") in CALMING:
                k, depth = CALMING[tags["traffic_calming"]]
                mark(k, x, y, brg, wid, depth)
        elif tags.get("traffic_calming") in CALMING:
            near = index.nearest(x, y, 8.0, motor_only)
            if near:
                k, depth = CALMING[tags["traffic_calming"]]
                mark(k, near[1], near[2], near[3], roads[near[4]]["width"], depth)
        for kind, match, default_h in POINT_KINDS:
            if not match(tags):
                continue
            h = _num(tags.get("height")) or default_h
            name = tags.get("name") or tags.get("ref") or ""
            if kind == "traffic_signals" and on:           # one signal per approach, at its kerb
                arms = []
                for ri, vi in on:
                    xy = roads[ri]["_xy"]
                    for vj in (vi - 1, vi + 1):
                        if 0 <= vj < len(xy):
                            ow = roads[ri].get("oneway", 0)
                            if ow and (vj - vi) * ow > 0:      # one-way: no traffic comes from ahead
                                continue
                            arms.append((_bearing(xy[vj][0] - x, xy[vj][1] - y), roads[ri]["width"]))
                set_back = max([w for _, w in arms] + [6.0]) / 2 + 1.5
                for a_brg, wid in arms[:4]:
                    ax, ay = _unit(a_brg)
                    travel = (a_brg + 180.0) % 360.0           # the approaching traffic drives towards the node
                    tx, ty = _unit(travel)
                    rx, ry = ty * side, -tx * side             # its own side
                    add_point(kind, x + ax * set_back + rx * (wid / 2 + 0.8), y + ay * set_back + ry * (wid / 2 + 0.8),
                              h, name, a_brg)
                break
            facing = FACING.get(kind)
            face = None
            if facing:
                if on and facing == "traffic":
                    ri, vi = on[0]
                    brg, wid = vertex_bearing(ri, vi), roads[ri]["width"]
                    fwd = tags.get("direction") != "backward"
                    travel = brg if fwd else brg + 180.0
                    tx, ty = _unit(travel)
                    rx, ry = ty * side, -tx * side
                    x, y, face = x + rx * (wid / 2 + 0.7), y + ry * (wid / 2 + 0.7), travel + 180.0
                else:
                    x, y, face = kerb_place(x, y, kind, facing)
                d_tag = _num(tags.get("direction")) if re.fullmatch(r"\d+(\.\d+)?", str(tags.get("direction", ""))) else None
                if d_tag is not None:
                    face = d_tag
            add_point(kind, x, y, h, name, face)
            if kind == "street_lamp":
                lamps_xy.append((x, y))
            break

    # statues / memorials mapped as areas -> at their centre
    for tags, pts in art_ways:
        for kind, match, default_h in POINT_KINDS:
            if match(tags):
                xy = [F.xy(p[0], p[1]) for p in pts[:-1]]
                cx, cy = sum(p[0] for p in xy) / len(xy), sum(p[1] for p in xy) / len(xy)
                cx, cy, face = kerb_place(cx, cy, kind, FACING.get(kind, "road"))
                add_point(kind, cx, cy, _num(tags.get("height")) or default_h, tags.get("name", ""), face)
                break
    # traffic calming mapped as a short way along the road
    for tags, pts in calm_ways:
        k = tags.get("traffic_calming")
        if k == "island" or k not in CALMING:
            continue
        xy = [F.xy(p[0], p[1]) for p in pts]
        L = _length(xy)
        mid = _along(xy, max(L, 0.1), start=L / 2)
        if not mid:
            continue
        mx, my, brg = mid[0]
        near = index.nearest(mx, my, 8.0, motor_only)
        wid = roads[near[4]]["width"] if near else 6.0
        mark(CALMING[k][0], mx, my, brg, wid, min(12.0, max(CALMING[k][1], L)))
    # marked crossings mapped as footways across the road
    for r in roads:
        if r.get("crossing") == "zebra":
            xy = r["_xy"]
            L = _length(xy)
            if 2 <= L <= 60:
                mx, my, brg = _along(xy, L, start=L / 2)[0]
                mark("zebra", mx, my, brg + 90.0, L, max(2.5, min(5.0, r["width"] + 1.0)))
    # rows of bollards / blocks
    for kind, line in bollard_lines:
        xy = [F.xy(p[0], p[1]) for p in line]
        for x, y, _b in _along(xy, 1.6 if kind == "bollard" else 2.0, start=0.0):
            add_point(kind, x, y, 1.0 if kind == "bollard" else 0.8)

    # medians: between the two one-way halves of a dual carriageway (parallel, opposite directions)
    paired, median_xy = set(), []

    def dual(ri):
        return roads[ri].get("oneway") and MEDIAN_RX.fullmatch(roads[ri]["kind"]) and not roads[ri].get("crossing")
    for i, r in enumerate(roads):
        if not dual(i):
            continue
        xy = r["_xy"] if r["oneway"] > 0 else r["_xy"][::-1]
        name = r["name"] or r["_ref"]
        run, runs = [], []
        for x, y, brg in _along(xy, 8.0, start=0.0):
            def partner(rj, ax, ay, bx, by, brg=brg):
                if rj <= i or not dual(rj):
                    return False
                nj = roads[rj]["name"] or roads[rj]["_ref"]
                if name and nj and nj != name:
                    return False
                b2 = _bearing(bx - ax, by - ay) if roads[rj]["oneway"] > 0 else _bearing(ax - bx, ay - by)
                return abs(((b2 - brg) % 360.0) - 180.0) < 25.0
            near = index.nearest(x, y, 40.0, partner)
            gap = near and near[0] - (r["width"] + roads[near[4]]["width"]) / 2
            if near and 0.6 <= gap <= 15.0 and index.nearest(x, y, near[0] - 0.5,
                                                             lambda rj, *_: rj != i and rj != near[4]
                                                             and not SMALL_RX.fullmatch(roads[rj]["kind"])) is None:
                run.append((F.ll((x + near[1]) / 2, (y + near[2]) / 2), round(gap, 1)))
                paired.update((i, near[4]))
            else:
                if len(run) >= 3:
                    runs.append(run)
                run = []
        if len(run) >= 3:
            runs.append(run)
        for run in runs:
            out["medians"].append({"line": [p for p, _ in run], "widths": [g for _, g in run]})
            median_xy.append([F.xy(p[0], p[1]) for p, _ in run])

    # street lamps where none are mapped (lamps are rarely mapped): along roads tagged lit=yes and along the
    # main roads (trunk / primary / secondary) -- at the kerb, both sides of wide roads, double-arm lamps on
    # the medians of dual carriageways. "gen": 1 = placed here, not mapped (the 3D view draws them, the
    # simulated LiDAR ignores them).
    grid = {}
    for x, y in lamps_xy:
        grid.setdefault((int(x // 20), int(y // 20)), []).append((x, y))

    def lamp_near(x, y, d=14.0):
        cx, cy = int(x // 20), int(y // 20)
        return any(math.hypot(x - a, y - b) < d for i in (-1, 0, 1) for j in (-1, 0, 1)
                   for a, b in grid.get((cx + i, cy + j), ()))

    added = [0]

    def gen_lamp(kind, x, y, h, face):
        if added[0] >= MAX_LIT_LAMPS or lamp_near(x, y) or len(pts_out) >= MAX_POINTS:
            return
        add_point(kind, x, y, h, "", face)
        pts_out[-1]["gen"] = 1
        grid.setdefault((int(x // 20), int(y // 20)), []).append((x, y))
        added[0] += 1

    for line in median_xy:
        for x, y, brg in _along(line, LIT_LAMP_SPACING_M["road"]):
            gen_lamp("street_lamp_double", x, y, 10.0, brg + 90.0)
    for ri, r in enumerate(roads):
        main = bool(LAMP_ROADS_RX.fullmatch(r["kind"]))
        if not (r["_lit"] or main) or r["kind"] == "steps" or r.get("crossing"):
            continue
        if ri in paired:                                  # lit from the median
            continue
        small = bool(SMALL_RX.fullmatch(r["kind"]))
        step = LIT_LAMP_SPACING_M["path" if small else "road"]
        hw = r["width"] / 2
        both = not small and r["width"] >= 12
        for k, (x, y, brg) in enumerate(_along(r["_xy"], step)):
            ux, uy = _unit(brg)
            s = 1.0 if (not both or k % 2 == 0) else -1.0
            if not both:
                s = -side                                  # one row: on the far side of the traffic (oncoming)
            lx, ly = x + uy * s * (hw + 0.6), y - ux * s * (hw + 0.6)
            other = index.nearest(lx, ly, 8.0, lambda rj, *_: rj != ri and not SMALL_RX.fullmatch(roads[rj]["kind"]))
            if other and other[0] < roads[other[4]]["width"] / 2 + 0.3:
                continue                                   # (would stand on another road)
            gen_lamp("street_lamp", lx, ly, 4.5 if small else (10.0 if r["width"] >= 10 else 8.0),
                     _bearing(-uy * s, ux * s))

    # trees: the mapped ones, tree rows, then wooded areas filled (smallest areas first: small groves stay
    # complete when the budget runs out)
    for line, typ in rows:
        out["trees"] += _row_trees(line, TREE_ROW_SPACING_M, typ)
    if box is not None:
        for poly, typ in sorted(woods, key=lambda w: len(w[0])):
            room = MAX_TREES - len(out["trees"])
            if room <= 0:
                break
            out["trees"] += _area_trees(poly, WOOD_TREE_SPACING_M["wood"], box, room, typ)
    out["trees"] = out["trees"][:MAX_TREES]
    for r in roads:                                       # (working fields)
        for k in ("_xy", "_nodes", "_lit", "_ref"):
            r.pop(k, None)
    for k in ("road_marks", "medians"):
        if not out[k]:
            del out[k]
    return out


def download(bounds, margin_m=250, progress=None):
    """bounds = [[south, west], [north, east]] of the yard. Returns the converted data.
    One query for everything; when it fails, a second try without the street furniture."""
    (s, w), (n, e) = bounds
    dlat = margin_m / 111320.0
    dlon = margin_m / (111320.0 * max(0.2, abs(math.cos(math.radians((s + n) / 2)))))
    box = (s - dlat, w - dlon, n + dlat, e + dlon)
    try:
        osm = _fetch(_query(*box), progress, attempts_per_endpoint=1)
    except RuntimeError:
        if progress:
            progress("Street details not available -- downloading buildings / roads only ...")
        osm = _fetch(_query(*box, details=False), progress)
    if progress:
        progress("Converting the OpenStreetMap data ...")
    data = convert(osm, box)
    data["bbox"] = [[box[0], box[1]], [box[2], box[3]]]
    data["fetched_at"] = datetime.now().isoformat(timespec="seconds")
    data["source"] = "OpenStreetMap (Overpass API)"
    data["attribution"] = ATTRIBUTION
    try:                                                  # the ground height (hills) for the 3D view
        import terrain
        data["terrain"] = terrain.download(data["bbox"], progress)
    except Exception as ex:                               # (optional: the 3D view stays flat without it)
        print(f"[3D] ground height not downloaded: {ex}")
    return data


def save(data, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))
    os.replace(tmp, path)


def load(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def summary(data):
    import collections
    pts = collections.Counter(("placed_" if p.get("gen") else "") + p["kind"] for p in data.get("points", []))
    def plural(n, k):
        w = k.replace("_", " ")
        return f"{n} {w}" + ("" if n == 1 or w.endswith("s") else "es" if w.endswith(("ch", "sh", "x")) else "s")
    pole_txt = ", ".join(plural(n, k) for k, n in pts.most_common())
    marks = collections.Counter(m["kind"] for m in data.get("road_marks", []))
    mark_txt = ", ".join(plural(n, k) for k, n in marks.most_common())
    med = data.get("medians", [])
    return (f"{len(data.get('buildings', []))} buildings, {len(data.get('roads', []))} roads, "
            f"{len(data.get('railways', []))} railways, {len(data.get('barriers', []))} fences/walls, "
            f"{len(data.get('trees', []))} trees, {len(data.get('areas', []))} areas, "
            f"{len(data.get('waterways', []))} waterways, "
            f"{len(data.get('power_lines', []))} power lines" + (f", {pole_txt}" if pole_txt else "")
            + (f", {len(med)} medians" if med else "") + (f", {mark_txt}" if mark_txt else "")
            + (f"; ground height {data['terrain'].get('min_m')} .. {data['terrain'].get('max_m')} m"
               if data.get("terrain") else ""))
