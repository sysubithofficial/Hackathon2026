"""Graphics of the info window's TECHNICAL OVERVIEW (quick to explain to an evaluator, little reading):

  PipelineView  the code's pipeline as boxes (stage + module · function), snaking over rows, animated: a data
                token travels to the current stage, which pulses; click a box or ◀ / ▶ / Play to go step by step.
  number_tiles  key parameters as big-number tiles (value · name · where).
  pros_cons     advantages / limitations as ✓ / ✕ rows side by side.
  chips         libraries / checks as coloured chips (wrapping).
"""
import math
import time

from PyQt5.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QPainter, QPen
from PyQt5.QtWidgets import QFrame, QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

from sensor_graphics import _arrow, _c, _text

MONO = "Consolas"
BG = "#0A0F1C"


class PipelineView(QWidget):
    """The pipeline stages [(stage, where, what)] as an animated, clickable flow of boxes."""
    stepChanged = pyqtSignal(int)
    W, PER_ROW, BW, BH, GX, GY = 800.0, 4, 176.0, 78.0, 32.0, 36.0

    def __init__(self, stages, col="#60A5FA", parent=None):
        super().__init__(parent)
        self.stages, self.col = stages, col
        self.n = len(stages)
        self.step, self.prev = 1, 1
        self.rows = max(1, math.ceil(self.n / self.PER_ROW))
        self.H = 16 + self.rows * self.BH + (self.rows - 1) * self.GY + 8
        self.t0 = time.monotonic()
        self.timer = QTimer(self); self.timer.timeout.connect(self.update)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setFixedHeight(int(self.H))
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Click a stage, or use ◀ / ▶ / Play")

    # ---- geometry (logical 800-wide canvas; rows snake left→right, right→left …) ----
    def _box(self, i):
        r, c = divmod(i, self.PER_ROW)
        if r % 2:
            c = self.PER_ROW - 1 - c
        x0 = (self.W - (self.PER_ROW * self.BW + (self.PER_ROW - 1) * self.GX)) / 2
        return QRectF(x0 + c * (self.BW + self.GX), 10 + r * (self.BH + self.GY), self.BW, self.BH)

    def _scale(self):
        sc = min(self.width() / self.W, 1.25)
        return sc, (self.width() - self.W * sc) / 2

    def go(self, k):
        k = max(1, min(self.n, k))
        if k != self.step:
            self.prev, self.step = self.step, k
            self.t0 = time.monotonic()
            self.update()
            self.stepChanged.emit(k)

    def resizeEvent(self, e):
        sc, _ = self._scale()
        self.setFixedHeight(int(self.H * max(0.6, sc)))
        super().resizeEvent(e)

    def showEvent(self, e):
        self.timer.start(40)
        super().showEvent(e)

    def hideEvent(self, e):
        self.timer.stop()
        super().hideEvent(e)

    def mousePressEvent(self, e):
        sc, dx = self._scale()
        p = QPointF((e.pos().x() - dx) / sc, e.pos().y() / sc)
        for i in range(self.n):
            if self._box(i).contains(p):
                self.go(i + 1)
                return

    def _link(self, i):
        """The arrow from box i to box i+1 (a, b)."""
        a, b = self._box(i), self._box(i + 1)
        if abs(a.center().y() - b.center().y()) < 1:            # same row
            if b.center().x() > a.center().x():
                return QPointF(a.right() + 2, a.center().y()), QPointF(b.left() - 2, b.center().y())
            return QPointF(a.left() - 2, a.center().y()), QPointF(b.right() + 2, b.center().y())
        return QPointF(a.center().x(), a.bottom() + 2), QPointF(b.center().x(), b.top() - 2)   # down a row

    def paintEvent(self, _e):
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), _c(BG))
            sc, dx = self._scale()
            p.translate(dx, 0); p.scale(sc, sc)
            T = time.monotonic() - self.t0
            col = self.col
            for i in range(self.n - 1):                          # arrows (done ones bright)
                a, b = self._link(i)
                _arrow(p, a, b, col if i + 1 < self.step else "#475569", 2.0, 8)
            for i, (stage, where, _what) in enumerate(self.stages):
                r = self._box(i)
                cur, done = i + 1 == self.step, i + 1 < self.step
                p.setPen(QPen(_c(col if (cur or done) else "#475569"), 2.4 if cur else 1.4))
                p.setBrush(_c(col, 0.22 if cur else 0.08 if done else 0.03))
                p.drawRoundedRect(r, 10, 10)
                if cur:                                            # (pulse)
                    a = 0.35 + 0.65 * abs(math.sin(T * 3.0))
                    p.setPen(QPen(_c("#FDE68A", a), 2.2, Qt.DashLine)); p.setBrush(Qt.NoBrush)
                    p.drawRoundedRect(r.adjusted(-4, -4, 4, 4), 12, 12)
                p.setPen(Qt.NoPen); p.setBrush(_c(col if (cur or done) else "#475569"))
                p.drawEllipse(QPointF(r.left() + 16, r.top() + 16), 11, 11)
                f = QFont(); f.setPixelSize(12); f.setBold(True); p.setFont(f); p.setPen(_c("#0B1220"))
                p.drawText(QRectF(r.left() + 5, r.top() + 5, 22, 22), Qt.AlignCenter, str(i + 1))
                _text(p, r.left() + 32, r.top() + 20, stage, "#F1F5F9" if (cur or done) else "#94A3B8", 12, True,
                      w=r.width() - 38)
                if where:
                    f = QFont(MONO); f.setPixelSize(10); p.setFont(f)
                    p.setPen(_c("#93C5FD" if (cur or done) else "#64748B"))
                    p.drawText(QRectF(r.left() + 8, r.top() + 36, r.width() - 14, r.height() - 38),
                               Qt.AlignLeft | Qt.AlignTop | Qt.TextWrapAnywhere, where)
            # the data token: from the previous stage to this one, then circling the current box
            f = min(1.0, T / 0.7)
            ca, cb = self._box(self.prev - 1).center(), self._box(self.step - 1).center()
            if f < 1.0 and self.prev != self.step:
                pt = QPointF(ca.x() + (cb.x() - ca.x()) * f, ca.y() + (cb.y() - ca.y()) * f)
            else:
                r = self._box(self.step - 1)
                ang = T * 2.4
                pt = QPointF(r.center().x() + (r.width() / 2 + 2) * math.cos(ang),
                             r.center().y() + (r.height() / 2 + 2) * math.sin(ang))
            p.setPen(QPen(_c("#0B1220"), 1.5)); p.setBrush(_c("#FDE68A")); p.drawEllipse(pt, 6, 6)
        except Exception:
            import sys
            sys.excepthook(*sys.exc_info())
        finally:
            p.end()


def number_tiles(params, col, per_row=3):
    """Key parameters as tiles: the value big, its name, where to change it (monospace)."""
    w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 0, 0, 0); g.setSpacing(8)
    for i, (name, value, where) in enumerate(params):
        f = QFrame(); f.setObjectName("tile")
        f.setStyleSheet(f"QFrame#tile {{ background: #0F172A; border: 1px solid #1F2937; border-top: 3px solid {col}; "
                        "border-radius: 8px; }")
        v = QVBoxLayout(f); v.setContentsMargins(10, 6, 10, 8); v.setSpacing(2)
        a = QLabel(value); a.setWordWrap(True)
        a.setStyleSheet(f"color: {col}; font-size: {16 if len(value) <= 18 else 13}px; font-weight: 800; "
                        "background: transparent;")
        b = QLabel(name); b.setWordWrap(True)
        b.setStyleSheet("color: #E5E7EB; font-size: 12px; font-weight: 700; background: transparent;")
        c = QLabel(where); c.setWordWrap(True); c.setTextInteractionFlags(Qt.TextSelectableByMouse)
        c.setStyleSheet(f"color: #64748B; font-size: 10px; font-family: {MONO}; background: transparent;")
        for x in (a, b, c):
            v.addWidget(x)
        g.addWidget(f, i // per_row, i % per_row)
    for k in range(per_row):
        g.setColumnStretch(k, 1)
    return w


def pros_cons(pros, cons, titles=("ADVANTAGES", "LIMITATIONS")):
    """✓ / ✕ rows side by side."""
    w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(10)
    for title, items, colr, mark in ((titles[0], pros, "#34D399", "✓"), (titles[1], cons, "#F87171", "✕")):
        f = QFrame(); f.setObjectName("pc")
        f.setStyleSheet(f"QFrame#pc {{ background: #0F172A; border: 1px solid {colr}; border-radius: 10px; }}")
        v = QVBoxLayout(f); v.setContentsMargins(10, 8, 10, 10); v.setSpacing(5)
        t = QLabel(title); t.setStyleSheet(f"color: {colr}; font-size: 11px; font-weight: 800; letter-spacing: 1px; "
                                           "background: transparent;")
        v.addWidget(t)
        for it in items:
            row = QHBoxLayout(); row.setSpacing(8)
            m = QLabel(mark); m.setFixedSize(22, 22); m.setAlignment(Qt.AlignCenter)
            m.setStyleSheet(f"background: {colr}; color: #0B1220; border-radius: 11px; font-weight: 900;")
            x = QLabel(it); x.setWordWrap(True)
            x.setStyleSheet("color: #E5E7EB; font-size: 12px; background: transparent;")
            row.addWidget(m, 0, Qt.AlignTop); row.addWidget(x, 1)
            v.addLayout(row)
        v.addStretch(1)
        h.addWidget(f, 1)
    return w


def chips(items, colr, per_row=2):
    """[(title, text)] as chips: the title coloured, the text below (a grid)."""
    w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 0, 0, 0); g.setSpacing(6)
    for i, (a, b) in enumerate(items):
        c = QColor(colr)
        x = QLabel(f"<b style='color:{colr}'>{a}</b><br><span style='color:#CBD5E1'>{b}</span>")
        x.setWordWrap(True); x.setTextFormat(Qt.RichText)
        x.setStyleSheet(f"background: rgba({c.red()},{c.green()},{c.blue()},0.08); border: 1px solid "
                        f"rgba({c.red()},{c.green()},{c.blue()},0.45); border-radius: 8px; padding: 6px 8px; "
                        "font-size: 12px;")
        g.addWidget(x, i // per_row, i % per_row)
    for k in range(per_row):
        g.setColumnStretch(k, 1)
    return w
