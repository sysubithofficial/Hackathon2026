"""Yards -> "Choose from map ...": a new yard from a boundary chosen on the map (no CC files needed).

The window shows a satellite / street map. Search a place (name, address or "lat, lng"), then set the yard's
boundary: draw a rectangle, click a polygon, take the visible area, or use the searched place's own outline
(OpenStreetMap). Saving
  1. writes sites/<yard>/cc_config/<yard>_MapParamFile_<date>.csv -- the boundary as the CC map file has it
     (location_corner1..4 = the bounding rectangle, operational_area = the drawn outline) and
     "created_from,map";
  2. downloads the yard's surroundings from OpenStreetMap (as "Update 3D": buildings, roads, fences, trees,
     water, poles ...) into sites/<yard>/data/osm_surroundings.json.
The app then loads the yard: the 2D map, the 3D view (buildings / roads / objects) and obstacle scenarios on its
roads.
"""
import csv
import json
import math
import os
import re
import time
import urllib.parse
import urllib.request

from PyQt5.QtCore import QThread, QTimer, QUrl, Qt, pyqtSignal
from PyQt5.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                             QMessageBox, QProgressBar, QPushButton, QSplitter, QVBoxLayout, QWidget)

import site_config as cfg

NOMINATIM = "https://nominatim.openstreetmap.org/search"
USER_AGENT = "qscape/1.0 (site boundary search)"
WARN_KM = 2.5                    # a side longer than this: slow to download (asked)
MAX_KM = 8.0                     # longer: refused
_RUNNING = []                    # search / download threads (kept until they end, also after the window closed)


def _start(job):
    _RUNNING.append(job)
    job.finished.connect(lambda: _RUNNING.remove(job) if job in _RUNNING else None)
    job.start()

PAGE = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="lib/leaflet/leaflet.css">
<style>html,body,#map{margin:0;height:100%;background:#111827}
.hint{position:absolute;z-index:1000;left:50%;transform:translateX(-50%);top:8px;background:rgba(17,24,39,.88);
color:#F9FAFB;font:13px sans-serif;padding:6px 12px;border-radius:6px;pointer-events:none;display:none}</style>
</head><body><div id="map"></div><div class="hint" id="hint"></div>
<script src="lib/leaflet/leaflet.js"></script>
<script>
var map = L.map('map', {doubleClickZoom: false}).setView([__LAT__, __LNG__], __ZOOM__);
var sat = L.tileLayer('https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  {maxZoom: 20, maxNativeZoom: 19, attribution: 'Imagery &copy; Esri'});
var streets = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  {maxZoom: 20, maxNativeZoom: 19, attribution: '&copy; OpenStreetMap contributors'});
sat.addTo(map);
L.control.layers({'Satellite': sat, 'Streets': streets}).addTo(map);
L.control.scale({imperial: false}).addTo(map);
var pts = [], shape = null, handles = [], mode = 'none', rectA = null, found = null, current = null;
function hint(t) { var h = document.getElementById('hint'); h.textContent = t || ''; h.style.display = t ? 'block' : 'none'; }
function redraw() {
  if (shape) { map.removeLayer(shape); shape = null; }
  handles.forEach(function (m) { map.removeLayer(m); }); handles = [];
  if (pts.length >= 2) {
    shape = L.polygon(pts, {color: '#FBBF24', weight: 3, fillColor: '#FBBF24', fillOpacity: 0.12}).addTo(map);
    shape.on('mousedown', function (e) {                  // drag inside the area: move the whole area
      if (mode !== 'none' || pts.length < 3) return;
      map.dragging.disable(); L.DomEvent.stop(e);
      var start = e.latlng, orig = pts.map(function (p) { return L.latLng(p.lat, p.lng); });
      function mv(ev) { var dl = ev.latlng.lat - start.lat, dg = ev.latlng.lng - start.lng;
        pts = orig.map(function (p) { return L.latLng(p.lat + dl, p.lng + dg); }); redraw(); }
      function up() { map.off('mousemove', mv); map.off('mouseup', up); map.dragging.enable(); }
      map.on('mousemove', mv); map.on('mouseup', up);
    });
  }
  pts.forEach(function (p, i) {
    var m = L.circleMarker(p, {radius: 6, color: '#111827', weight: 2, fillColor: '#FBBF24', fillOpacity: 1}).addTo(map);
    m.bindTooltip('Drag: move this corner · right-click: delete it', {direction: 'top'});
    m.on('mousedown', function (e) {                      // drag a corner
      map.dragging.disable(); L.DomEvent.stop(e);
      function mv(ev) { pts[i] = ev.latlng; redraw(); }
      function up() { map.off('mousemove', mv); map.off('mouseup', up); map.dragging.enable(); }
      map.on('mousemove', mv); map.on('mouseup', up);
    });
    m.on('contextmenu', function (e) {                    // right-click: delete the corner (at least 3 stay)
      L.DomEvent.stop(e); if (pts.length > 3) { pts.splice(i, 1); redraw(); }
    });
    handles.push(m);
  });
  if (pts.length >= 3 && mode === 'none') pts.forEach(function (p, i) {   // midpoints: drag one = a new corner
    var q = pts[(i + 1) % pts.length], mid = L.latLng((p.lat + q.lat) / 2, (p.lng + q.lng) / 2);
    var m = L.circleMarker(mid, {radius: 4, color: '#111827', weight: 1, fillColor: '#FFFFFF', fillOpacity: 0.85}).addTo(map);
    m.bindTooltip('Drag: add a corner here', {direction: 'top'});
    m.on('mousedown', function (e) {
      map.dragging.disable(); L.DomEvent.stop(e);
      pts.splice(i + 1, 0, e.latlng); var k = i + 1; redraw();
      function mv(ev) { pts[k] = ev.latlng; redraw(); }
      function up() { map.off('mousemove', mv); map.off('mouseup', up); map.dragging.enable(); }
      map.on('mousemove', mv); map.on('mouseup', up);
    });
    handles.push(m);
  });
}
function scaleBy(f) {                                   // grow / shrink the area around its centre
  if (pts.length < 3) return;
  var cl = 0, cg = 0; pts.forEach(function (p) { cl += p.lat; cg += p.lng; }); cl /= pts.length; cg /= pts.length;
  pts = pts.map(function (p) { return L.latLng(cl + (p.lat - cl) * f, cg + (p.lng - cg) * f); }); redraw();
}
function setMode(m) {
  mode = m; rectA = null;
  map.getContainer().style.cursor = m === 'none' ? '' : 'crosshair';
  if (m === 'rect') { pts = []; redraw(); hint('Click one corner of the yard, then the opposite corner'); }
  else if (m === 'poly') { pts = []; redraw(); hint('Click the corners of the yard one by one -- double-click the last one'); }
  else { hint(''); redraw(); }                          // (editing handles: midpoints back)
}
map.on('click', function (e) {
  if (mode === 'rect') {
    if (!rectA) { rectA = e.latlng; pts = [rectA]; redraw(); hint('Now click the opposite corner'); return; }
    var a = rectA, b = e.latlng;
    pts = [L.latLng(Math.max(a.lat, b.lat), Math.min(a.lng, b.lng)), L.latLng(Math.min(a.lat, b.lat), Math.min(a.lng, b.lng)),
           L.latLng(Math.min(a.lat, b.lat), Math.max(a.lng, b.lng)), L.latLng(Math.max(a.lat, b.lat), Math.max(a.lng, b.lng))];
    redraw(); setMode('none');
  } else if (mode === 'poly') { pts.push(e.latlng); redraw(); }
});
map.on('dblclick', function (e) { if (mode === 'poly') { if (pts.length >= 3) setMode('none'); } });
function fromView() {
  var b = map.getBounds(), dy = (b.getNorth() - b.getSouth()) * 0.1, dx = (b.getEast() - b.getWest()) * 0.1;
  var n = b.getNorth() - dy, s = b.getSouth() + dy, w = b.getWest() + dx, e = b.getEast() - dx;
  pts = [L.latLng(n, w), L.latLng(s, w), L.latLng(s, e), L.latLng(n, e)]; setMode('none'); redraw();
}
function clearAll() { pts = []; setMode('none'); redraw(); }
function setPoly(arr) { pts = arr.map(function (p) { return L.latLng(p[0], p[1]); }); setMode('none'); redraw();
  if (pts.length) map.fitBounds(L.latLngBounds(pts).pad(0.15)); }
function goTo(lat, lng, bbox, outline) {
  if (found) { map.removeLayer(found); found = null; }
  if (outline && outline.length) {
    found = L.polyline(outline.concat([outline[0]]), {color: '#60A5FA', weight: 2, dashArray: '6 5'}).addTo(map);
  }
  if (bbox) map.fitBounds([[bbox[0], bbox[2]], [bbox[1], bbox[3]]], {maxZoom: 18});
  else map.setView([lat, lng], 17);
}
function showCurrent(arr) {        // the yard that is loaded now (for orientation)
  current = L.polygon(arr, {color: '#9CA3AF', weight: 1, dashArray: '4 4', fill: false, interactive: false}).addTo(map);
}
function getPoly() { return JSON.stringify(pts.map(function (p) { return [p.lat, p.lng]; })); }
</script></body></html>"""


def _km(lat0, a, b):
    kx = 111.32 * math.cos(math.radians(lat0))
    return abs(b[1] - a[1]) * kx, abs(b[0] - a[0]) * 111.32


def polygon_area_m2(pts):
    if len(pts) < 3:
        return 0.0
    lat0 = sum(p[0] for p in pts) / len(pts)
    kx = 111320.0 * math.cos(math.radians(lat0))
    xy = [(p[1] * kx, p[0] * 111320.0) for p in pts]
    return abs(sum(x0 * y1 - x1 * y0 for (x0, y0), (x1, y1) in zip(xy, xy[1:] + xy[:1]))) / 2.0


def bounding_corners(pts):
    """The CC map file's 4 corners (as the CC portal: 1 = north-west, 2 = south-west, 3 = south-east, 4 = north-east)."""
    s, n = min(p[0] for p in pts), max(p[0] for p in pts)
    w, e = min(p[1] for p in pts), max(p[1] for p in pts)
    return [(n, w), (s, w), (s, e), (n, e)]


def write_map_param(site_id, display_name, pts, folder):
    """The yard's map parameter file (CC format) from the boundary `pts` [(lat, lng)]; returns its path."""
    os.makedirs(folder, exist_ok=True)
    stamp = time.strftime("%d-%B-%Y-%I_%M_%S %p")
    path = os.path.join(folder, f"{site_id}_MapParamFile_{stamp}.csv")
    rows = [["KEY", "VALUE", "DESC"], ["version", "3.1", "Version"], ["shipyard_name", site_id, ""],
            ["display_name", display_name or site_id, ""],
            ["created_from", "map", "Yard boundary chosen on the map (Yards -> Choose from map)"]]
    for i, (lat, lng) in enumerate(bounding_corners(pts), 1):
        rows.append([f"location_corner{i}", f"{lat:.8f},{lng:.8f}", f"Location corner{i}"])
    rows.append(["operational_area", json.dumps([[round(p[1], 8), round(p[0], 8)] for p in pts]),
                 "Yard outline [lon, lat]"])
    with open(path, "w", encoding="utf-8", newline="") as f:
        csv.writer(f).writerows(rows)
    return path


def create_site(site_id, display_name, pts):
    """sites/<id>/ with the map parameter file + the usual folders; checked by loading it. Returns (data, info)."""
    from config_loader import load_site
    d = cfg.site_dir(site_id)
    cc = os.path.join(d, "cc_config")
    write_map_param(site_id, display_name, pts, cc)
    for sub in ("data", "logs", "routes"):
        os.makedirs(os.path.join(d, sub), exist_ok=True)
    import auth
    auth.set_site_owner(site_id)                           # (who made it: who may see it -- auth.can_see_site)
    data, info, _w = load_site(cc, site_id)
    return data, info


def update_site_area(site_id, pts):
    """Yards -> "Edit this yard's area on the map": the yard's new boundary `pts` [(lat, lng)] into its map parameter
    file. A copy of the newest one is written with a new date (the loader takes the newest): every row as it was,
    only location_corner1..4 (the bounding rectangle) and operational_area (the outline) changed. The old file goes
    to sites/<yard>/backup/map_param/ (outside cc_config: the loader searches it recursively). The yard is loaded once
    to check it -- if that fails, the old file is put back. Returns (info, old file name)."""
    import shutil
    from config_loader import find_cc_files, load_site
    cc = os.path.join(cfg.site_dir(site_id), "cc_config")
    old = find_cc_files(cc).get("map_param")
    rows = []
    if old and old.lower().endswith(".csv"):
        with open(old, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
            rows = [r for r in csv.reader(f)]
    elif old:                                              # (an Excel export: its rows as text)
        import pandas as pd
        raw = pd.read_excel(old, header=None, dtype=object)
        rows = [["" if (v is None or (isinstance(v, float) and math.isnan(v))) else str(v) for v in r]
                for _, r in raw.iterrows()]
    if not rows:
        rows = [["KEY", "VALUE", "DESC"], ["shipyard_name", site_id, ""]]
    new_vals = {f"location_corner{i}": f"{lat:.8f},{lng:.8f}" for i, (lat, lng) in enumerate(bounding_corners(pts), 1)}
    new_vals["operational_area"] = json.dumps([[round(p[1], 8), round(p[0], 8)] for p in pts])
    done = set()
    for r in rows:
        if r and r[0].strip() in new_vals:
            k = r[0].strip()
            while len(r) < 2:
                r.append("")
            r[1] = new_vals[k]; done.add(k)
    for k, v in new_vals.items():                          # (keys the file did not have yet)
        if k not in done:
            rows.append([k, v, "Yard outline [lon, lat]" if k == "operational_area" else f"Location {k[9:]}"])
    stamp = time.strftime("%d-%B-%Y-%I_%M_%S %p")
    path = os.path.join(cc, f"{site_id}_MapParamFile_{stamp}.csv")
    with open(path, "w", encoding="utf-8", newline="") as f:
        csv.writer(f).writerows(rows)
    moved = None
    if old and os.path.abspath(old) != os.path.abspath(path):
        bdir = os.path.join(cfg.site_dir(site_id), "backup", "map_param")
        os.makedirs(bdir, exist_ok=True)
        moved = os.path.join(bdir, os.path.basename(old))
        shutil.move(old, moved)
    try:
        _data, info, _w = load_site(cc, site_id)
    except Exception:
        os.remove(path)                                    # (does not load: the old file back)
        if moved:
            shutil.move(moved, old)
        raise
    return info, os.path.basename(old) if old else None


class _Search(QThread):
    done = pyqtSignal(list, str)

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.text = text

    def run(self):
        t = self.text.strip()
        m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$", t)
        if m:                                              # "lat, lng"
            lat, lng = float(m.group(1)), float(m.group(2))
            self.done.emit([{"name": f"{lat:.6f}, {lng:.6f}", "lat": lat, "lng": lng, "bbox": None, "outline": None}], "")
            return
        q = urllib.parse.urlencode({"q": t, "format": "jsonv2", "limit": 8, "polygon_geojson": 1,
                                    "polygon_threshold": 0.00003})
        try:
            req = urllib.request.Request(f"{NOMINATIM}?{q}", headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=20) as r:
                res = json.load(r)
        except Exception as e:
            self.done.emit([], f"Search failed: {e}")
            return
        out = []
        for it in res:
            outline = None
            g = it.get("geojson") or {}
            ring = None
            if g.get("type") == "Polygon":
                ring = g["coordinates"][0]
            elif g.get("type") == "MultiPolygon":
                ring = max((p[0] for p in g["coordinates"]), key=len, default=None)
            if ring and len(ring) >= 4:
                outline = [[c[1], c[0]] for c in ring[:-1]]
                if len(outline) > 60:                      # (a handy number of corners)
                    step = len(outline) / 60.0
                    outline = [outline[int(i * step)] for i in range(60)]
            bb = it.get("boundingbox")
            out.append({"name": it.get("display_name", ""), "kind": f"{it.get('category', '')} {it.get('type', '')}".strip(),
                        "lat": float(it["lat"]), "lng": float(it["lon"]),
                        "bbox": [float(x) for x in bb] if bb else None, "outline": outline})
        self.done.emit(out, "" if out else "Nothing found.")


class _Download(QThread):
    progress = pyqtSignal(str)
    done = pyqtSignal(object, str)

    def __init__(self, bounds, parent=None):
        super().__init__(parent)
        self.bounds = bounds

    def run(self):
        try:
            import osm_surroundings
            self.done.emit(osm_surroundings.download(self.bounds, progress=self.progress.emit), "")
        except Exception as e:
            self.done.emit(None, str(e))


class ChooseYardDialog(QDialog):
    """New yard from a boundary chosen on the map."""

    def __init__(self, parent=None, center=None, current_outline=None, edit_site=None, edit_name=None):
        super().__init__(parent)
        from PyQt5.QtWebEngineWidgets import QWebEngineSettings, QWebEngineView
        self.setObjectName("themedDialog")
        self.edit_site = edit_site                         # (Yards -> Edit this yard's area: this yard's outline)
        self.setWindowTitle(f"Edit the yard area -- {edit_name or edit_site}" if edit_site
                            else "New yard -- choose from the map")
        self.resize(1280, 820)
        self.site_id = None
        self.result_info = None
        self.pts = []
        self._ready = False
        self._results = []
        self._jobs = []
        lay = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search: a place, an address or  lat, lng  (e.g. 42.7105, -84.6430)")
        self.search.returnPressed.connect(self._do_search)
        top.addWidget(self.search, 1)
        b = QPushButton("Search")
        b.clicked.connect(self._do_search)
        top.addWidget(b)
        lay.addLayout(top)

        split = QSplitter(Qt.Horizontal)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.addWidget(QLabel("Search results"))
        self.results = QListWidget()
        self.results.itemClicked.connect(self._pick_result)
        ll.addWidget(self.results, 1)
        self.outline_btn = QPushButton("Use this place's outline as the boundary")
        self.outline_btn.setToolTip("The selected place's own outline from OpenStreetMap (dashed blue on the map) -- "
                                    "e.g. a warehouse site or an industrial area")
        self.outline_btn.setEnabled(False)
        self.outline_btn.clicked.connect(self._use_outline)
        ll.addWidget(self.outline_btn)
        ll.addSpacing(8)
        ll.addWidget(QLabel("Boundary"))
        for text, tip, js in (
                ("Draw a rectangle", "Click one corner, then the opposite corner", "setMode('rect')"),
                ("Draw a polygon", "Click the corners one by one, double-click the last one", "setMode('poly')"),
                ("Use the visible area", "The map area you see now (a little inside its edges)", "fromView()"),
                ("Clear", "Remove the boundary", "clearAll()")):
            bb = QPushButton(text)
            bb.setToolTip(tip + ". Corners can be dragged afterwards.")
            bb.clicked.connect(lambda _=False, j=js: self._js(j))
            ll.addWidget(bb)
        rs = QHBoxLayout()                                 # resize around the centre
        for text, f, tip in (("Grow 10 %", 1.1, "Make the area 10 % larger (around its centre)"),
                             ("Shrink 10 %", 1 / 1.1, "Make the area 10 % smaller (around its centre)")):
            bb = QPushButton(text); bb.setToolTip(tip)
            bb.clicked.connect(lambda _=False, k=f: self._js(f"scaleBy({k})"))
            rs.addWidget(bb)
        ll.addLayout(rs)
        how = QLabel("Edit: drag a corner · drag a white midpoint to add a corner · right-click a corner to delete "
                     "it · drag inside the area to move it")
        how.setWordWrap(True)
        how.setStyleSheet("color:#9CA3AF; font-weight:400;")
        ll.addWidget(how)
        self.size_label = QLabel("No boundary yet.")
        self.size_label.setWordWrap(True)
        ll.addWidget(self.size_label)
        ll.addSpacing(8)
        ll.addWidget(QLabel("Yard name (no spaces):"))
        self.id_edit = QLineEdit()
        self.id_edit.setPlaceholderText("e.g. lansing_dc2")
        ll.addWidget(self.id_edit)
        ll.addWidget(QLabel("Display name:"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("e.g. Lansing DC 2")
        ll.addWidget(self.name_edit)
        ll.addWidget(QLabel("Project name:"))
        self.project_edit = QLineEdit(cfg.PROJECT_NAME)
        self.project_edit.setPlaceholderText("letters, digits, _ and -")
        self.project_edit.setToolTip("This yard's project: its AVs' ids / topics are "
                                     "<yard>_<project>_<truck id>; shown in the top bar when the yard is loaded")
        ll.addWidget(self.project_edit)
        self.dl_chk = QCheckBox("Download buildings, roads, fences, trees ... now (Update 3D)")
        self.dl_chk.setChecked(True)
        self.dl_chk.setToolTip("From OpenStreetMap, for the 3D view and the obstacle scenarios "
                               "(can also be done later with Update 3D in the 3D view)")
        ll.addWidget(self.dl_chk)
        if edit_site:                                      # edit: the yard is given -- no name / id / project fields
            for w in (self.id_edit, self.name_edit, self.project_edit):
                w.setVisible(False)
            for i in range(ll.count()):
                it = ll.itemAt(i).widget()
                if isinstance(it, QLabel) and it.text() in ("Yard name (no spaces):", "Display name:", "Project name:"):
                    it.setVisible(False)
            self.dl_chk.setText("Download the surroundings again for the new area (Update 3D)")
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        ll.addWidget(self.progress)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color:#9CA3AF; font-weight:400;")
        ll.addWidget(self.status)
        row = QHBoxLayout()
        self.save_btn = QPushButton("Save the new area" if edit_site else "Create the yard")
        self.save_btn.clicked.connect(self._save)
        row.addWidget(self.save_btn)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        ll.addLayout(row)
        left.setMinimumWidth(330)
        left.setMaximumWidth(420)
        split.addWidget(left)

        self.web = QWebEngineView()
        st = self.web.settings()
        st.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
        lat, lng = center or (42.7105, -84.6430)
        html = PAGE.replace("__LAT__", f"{lat:.7f}").replace("__LNG__", f"{lng:.7f}").replace("__ZOOM__", "15")
        self.web.loadFinished.connect(lambda ok: self._loaded(ok, current_outline))
        self.web.setHtml(html, QUrl.fromLocalFile(os.path.join(cfg.ASSETS_DIR, "web") + os.sep))
        split.addWidget(self.web)
        split.setStretchFactor(1, 1)
        lay.addWidget(split, 1)
        note = QLabel("Map data © OpenStreetMap contributors (search: Nominatim) · Imagery © Esri. The yard gets "
                      "its boundary and surroundings; its AVs, obstacles and routes are added in the app.")
        note.setWordWrap(True)
        note.setStyleSheet("color:#9CA3AF; font-weight:400;")
        lay.addWidget(note)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.timer.start(400)

    # ---- the map page ----
    def _loaded(self, ok, current_outline):
        self._ready = ok
        if not ok:
            self.status.setText("The map page could not be loaded.")
            return
        if current_outline and len(current_outline) >= 3:
            arr = json.dumps([list(map(float, p)) for p in current_outline])
            self._js(f"showCurrent({arr})")                # (grey dashed: the yard as it is now)
            if self.edit_site:
                self._js(f"setPoly({arr})")                # edit: the outline, ready to be changed

    def _js(self, code, cb=None):
        if self._ready:
            if cb:
                self.web.page().runJavaScript(code, cb)
            else:
                self.web.page().runJavaScript(code)

    def _poll(self):
        self._js("getPoly()", self._got_poly)

    def _got_poly(self, text):
        try:
            pts = [tuple(map(float, p)) for p in json.loads(text or "[]")]
        except (TypeError, ValueError):
            return
        if pts == self.pts:
            return
        self.pts = pts
        if len(pts) < 3:
            self.size_label.setText("No boundary yet." if not pts else f"{len(pts)} corner(s) so far ...")
            return
        c = bounding_corners(pts)
        wx, hy = _km(sum(p[0] for p in pts) / len(pts), c[1], c[3])
        area = polygon_area_m2(pts)
        warn = ""
        if max(wx, hy) > MAX_KM:
            warn = f"\nToo large: at most {MAX_KM:.0f} km a side."
        elif max(wx, hy) > WARN_KM:
            warn = "\nLarge: the download takes long."
        self.size_label.setText(f"{len(pts)} corners · {wx * 1000:.0f} m × {hy * 1000:.0f} m · "
                                f"{area / 10000:.1f} ha{warn}")

    # ---- search ----
    def _do_search(self):
        t = self.search.text().strip()
        if not t:
            return
        self.status.setText("Searching ...")
        job = _Search(t)
        job.done.connect(self._search_done)
        self._jobs.append(job)
        _start(job)

    def _search_done(self, results, err):
        self._results = results
        self.results.clear()
        for r in results:
            it = QListWidgetItem(r["name"] + (f"\n({r['kind']})" if r.get("kind") else ""))
            it.setToolTip(r["name"])
            self.results.addItem(it)
        self.status.setText(err)
        if len(results) == 1:
            self.results.setCurrentRow(0)
            self._pick_result(self.results.item(0))

    def _pick_result(self, item):
        r = self._results[self.results.row(item)]
        self.outline_btn.setEnabled(bool(r.get("outline")))
        self._js(f"goTo({r['lat']}, {r['lng']}, {json.dumps(r['bbox'])}, {json.dumps(r.get('outline'))})")
        if not self.name_edit.text().strip():
            self.name_edit.setText(r["name"].split(",")[0][:40])

    def _use_outline(self):
        row = self.results.currentRow()
        if 0 <= row < len(self._results) and self._results[row].get("outline"):
            self._js(f"setPoly({json.dumps(self._results[row]['outline'])})")

    # ---- create ----
    def _save_edit(self):
        """Edit mode: the new outline into this yard's map parameter file (+ the surroundings again)."""
        if len(self.pts) < 3:
            QMessageBox.warning(self, "Yard", "The area needs at least 3 corners.")
            return
        c = bounding_corners(self.pts)
        wx, hy = _km(sum(p[0] for p in self.pts) / len(self.pts), c[1], c[3])
        if max(wx, hy) > MAX_KM:
            QMessageBox.warning(self, "Yard", f"The area is {wx:.1f} km × {hy:.1f} km -- at most {MAX_KM:.0f} km a side.")
            return
        if QMessageBox.question(self, "Yard", f"Save the new area of '{self.edit_site}' "
                                              f"({wx * 1000:.0f} m × {hy * 1000:.0f} m)?\n\nThe old map file is kept in "
                                              f"sites/{self.edit_site}/backup/map_param/.") != QMessageBox.Yes:
            return
        try:
            info, old = update_site_area(self.edit_site, self.pts)
        except Exception as e:
            QMessageBox.critical(self, "Yard", f"The new area could not be saved (nothing was changed): "
                                               f"{type(e).__name__}: {e}")
            return
        self.site_id, self.result_info = self.edit_site, info
        if not self.dl_chk.isChecked():
            self.accept()
            return
        self._set_busy(True, "Downloading the surroundings of the new area from OpenStreetMap ...")
        job = _Download(info["bounds"])
        job.progress.connect(self.status.setText)
        job.done.connect(self._downloaded)
        self._jobs.append(job)
        _start(job)

    def _save(self):
        import yard_manager
        if self.edit_site:
            return self._save_edit()
        sid = self.id_edit.text().strip()
        if not yard_manager.valid_site_id(sid):
            QMessageBox.warning(self, "Yard", "Enter a yard name: letters, digits, _ and - (no spaces).")
            return
        if os.path.exists(cfg.site_dir(sid)):
            QMessageBox.warning(self, "Yard", f"A yard '{sid}' already exists.")
            return
        if len(self.pts) < 3:
            QMessageBox.warning(self, "Yard", "Set the yard's boundary first (draw a rectangle / polygon, use the "
                                              "visible area, or a searched place's outline).")
            return
        c = bounding_corners(self.pts)
        wx, hy = _km(sum(p[0] for p in self.pts) / len(self.pts), c[1], c[3])
        if max(wx, hy) > MAX_KM:
            QMessageBox.warning(self, "Yard", f"The boundary is {wx:.1f} km × {hy:.1f} km -- at most {MAX_KM:.0f} km a side.")
            return
        if max(wx, hy) > WARN_KM and QMessageBox.question(
                self, "Yard", f"The boundary is {wx:.1f} km × {hy:.1f} km: downloading its surroundings "
                              "takes long. Create it anyway?") != QMessageBox.Yes:
            return
        project = re.sub(r"[^A-Za-z0-9_\-]", "", self.project_edit.text().strip())
        if not project:
            QMessageBox.warning(self, "Yard", "Enter the project name: letters, digits, _ and - (no spaces).")
            return
        try:
            data, info = create_site(sid, self.name_edit.text().strip() or sid, self.pts)
            cfg.save_site_project_name(sid, project)
        except Exception as e:
            QMessageBox.critical(self, "Yard", f"The yard could not be created: {type(e).__name__}: {e}")
            return
        self.site_id, self.result_info = sid, info
        if not self.dl_chk.isChecked():
            self.accept()
            return
        self._set_busy(True, "Downloading the surroundings from OpenStreetMap ...")
        job = _Download(info["bounds"])
        job.progress.connect(self.status.setText)
        job.done.connect(self._downloaded)
        self._jobs.append(job)
        _start(job)

    def _set_busy(self, busy, text=""):
        self.progress.setVisible(busy)
        self.save_btn.setEnabled(not busy)
        self.status.setText(text)

    def _downloaded(self, data, err):
        import osm_surroundings
        self._set_busy(False)
        if data is None:
            QMessageBox.warning(self, "Update 3D", f"The yard '{self.site_id}' was {'saved' if self.edit_site else 'created'}, "
                                                   f"but its surroundings could not be downloaded now:\n\n{err}\n\n"
                                                   "Use Update 3D (3D view) after loading the yard.")
        else:
            osm_surroundings.save(data, os.path.join(cfg.site_dir(self.site_id), "data", "osm_surroundings.json"))
            self.download_summary = osm_surroundings.summary(data)
        self.accept()

    def reject(self):
        if any(j.isRunning() for j in self._jobs if isinstance(j, _Download)):
            return                                         # (wait for the download: the yard is already saved)
        super().reject()

    def done(self, r):
        self.timer.stop()
        for j in self._jobs:                               # (a search still running: its answer is not wanted)
            try:
                j.done.disconnect()
            except TypeError:
                pass
        super().done(r)
