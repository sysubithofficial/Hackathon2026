"""Sensor set-up for collision testing (top bar "Sensors"): SIMULATED or REAL-WORLD processing.

  sim   the current way: each sensor is a model on the scene's objects (fast, repeatable -- tests the braking logic)
  real  each sensor processes its own measurements like on a real truck (camera picture, LiDAR point cloud, radar
        echoes, tracking) -- tests perception too; slower (camera pictures are rendered for every truck)

The choice is kept in config/app_settings.json ("collision_sensors": {"mode"}) and applies to collision tests
started after it. V2V works the same in both (it is already message based).
"""
from PyQt5.QtCore import QRectF, Qt
from PyQt5.QtGui import QColor, QPainter
from PyQt5.QtWidgets import (QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout,
                             QWidget)

MODES = ("sim", "real")
# the real-world set-up: the mechanism of each sensor -- (id, name, integrated?, words to find it in the info window)
REAL_METHODS = {
    "camera": [("free_space", "Picture processing (free space / ground contact)", True, "Picture processing"),
               ("yolo", "YOLO v8 / v11 object detection (neural network)", False, "YOLO"),
               ("depth", "Depth network / stereo cameras", False, "Depth estimation")],
    "LiDAR": [("grid", "Point-cloud clustering (grid / Euclidean)", True, "Point-cloud clustering"),
              ("pointpillars", "PointPillars / CenterPoint (neural network)", False, "PointPillars")],
    "radar": [("beam_cfar", "Beam scan + CFAR + clustering", True, "Beam scan"),
              ("fft", "Raw signal: FFT range-Doppler map + CFAR", False, "Raw radar"),
              ("imaging4d", "4D imaging radar (height + many points)", False, "4D imaging")],
    "fusion": [("track", "Tracking per sensor + matching by position", True, "Tracking per sensor"),
               ("kalman", "Kalman / IMM multi-object tracking", False, "Kalman")],
}


def real_methods():
    """{sensor: chosen id} of the real-world set-up (config/app_settings.json, defaults: the integrated ones)."""
    try:
        import site_config as cfg
        saved = ((cfg.APP_SETTINGS or {}).get("collision_sensors") or {}).get("real_methods") or {}
    except Exception:
        saved = {}
    out = {}
    for k, opts in REAL_METHODS.items():
        ids = [o[0] for o in opts]
        out[k] = saved.get(k) if saved.get(k) in ids else opts[0][0]
    return out


def method(sensor, mid):
    return next((o for o in REAL_METHODS[sensor] if o[0] == mid), REAL_METHODS[sensor][0])


def effective(sensor, mid):
    """The mechanism a test really uses: the chosen one if integrated, else the integrated one."""
    o = method(sensor, mid)
    return o if o[2] else next(x for x in REAL_METHODS[sensor] if x[2])
TITLE = {"sim": "Simulated set-up", "real": "Real-world set-up"}
SHORT = {"sim": "Simulated", "real": "Real-world"}
COL = {"sim": "#60A5FA", "real": "#34D399"}

ROWS = {  # sensor -> (simulated, real-world) -- short headers + one line
    "camera": (("Object model", "Scene objects inside its view and within ½ the visibility are seen; name and "
                                "distance from the scene. The picture is only for showing."),
               ("Picture processing", "The rendered picture → road / obstacle split per column → distance from the "
                                      "camera's height and tilt (ground contact) → tracked (C1, C2 …).")),
    "LiDAR": (("Ray-traced, labelled", "Real ray tracing, but the points are counted per object they hit (known): "
                                       "≥ 4 points = detected."),
              ("Point-cloud clustering", "Unlabelled points → ground removal → clustering → nearest point = distance "
                                         "→ tracked (L1 …).")),
    "radar": (("Signal formula", "Per object: echo strength from the radar equation + weather → detection chance; "
                                 "speed from the scene."),
              ("Echo processing", "1° beams traced to the outlines → echo power, fluctuation, CFAR threshold → points "
                                  "with Doppler → clusters → tracked (R1 …); rain clutter; standing echoes confirmed "
                                  "slower.")),
    "V2V": (("Messages", "GPS position, speed, braking; radio delay / loss — the same in both."),
            ("Messages", "The same: already message based.")),
    "fusion": (("By scene id", "Each sensor's objects merged by their scene id; the nearest in the lane is braked "
                               "for."),
               ("By position", "Tracks merged by position (matched to the real object only to name it in the "
                               "reports); unknown objects in the lane are braked for too.")),
}
NOTES = {"sim": "Fast and repeatable — for testing the braking logic. A sensor never misses what is in its range and "
                "never sees something that is not there.",
         "real": "The sensors find the objects themselves: misses, wrong distances, phantom objects and late "
                 "detections can happen — as on a real truck. Slower: every truck's camera picture is rendered and "
                 "processed (~1 picture a second per truck on a PC without 3D acceleration). At night the 3D scene "
                 "has no headlights, so the camera sees little."}


class _Icon(QWidget):
    def __init__(self, key, col):
        super().__init__()
        self.key, self.col = key, col
        self.setFixedSize(22, 22)

    def paintEvent(self, _e):
        import sensor_graphics as sg
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing)
            if self.key == "fusion":
                p.setPen(QColor(self.col)); p.drawText(QRectF(0, 0, 22, 22), Qt.AlignCenter, "⨁")
            else:
                sg.draw_icon(p, self.key, QRectF(1, 1, 20, 20), sg.COL.get(self.key, self.col))
        finally:
            p.end()


class SensorModeDialog(QDialog):
    """Two cards (simulated / real-world), each sensor's mechanism in a short header + one line."""

    def __init__(self, parent, current):
        super().__init__(parent)
        self.setWindowTitle("Sensor set-up — collision testing")
        self.setModal(True)
        self.choice = current if current in MODES else "sim"
        self.methods = real_methods()
        self.setStyleSheet("""
            QDialog { background: #0B1220; } QLabel { color: #E5E7EB; background: transparent; }
            QPushButton { background: #1F2937; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px;
                          padding: 7px 16px; }
            QPushButton:hover { background: #273449; }""")
        lay = QVBoxLayout(self); lay.setContentsMargins(16, 14, 16, 14); lay.setSpacing(10)
        h = QLabel("<span style='font-size:17px; font-weight:800'>How should the sensors work?</span><br>"
                   "<span style='color:#94A3B8'>Click a set-up. It applies to collision tests started after this. "
                   "V2V is the same in both.</span>")
        h.setTextFormat(Qt.RichText); lay.addWidget(h)
        row = QHBoxLayout(); row.setSpacing(12)
        self.cards = {}
        self._building = True
        for i, m in enumerate(MODES):
            c = self._card(m, i)
            self.cards[m] = c
            row.addWidget(c, 1)
        self._building = False
        lay.addLayout(row, 1)
        bb = QHBoxLayout()
        self.status = QLabel(); bb.addWidget(self.status, 1)
        ok = QPushButton("Use this set-up"); ok.clicked.connect(self.accept)
        ok.setStyleSheet("background: #065F46; border-color: #34D399; font-weight: 700;")
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        bb.addWidget(cancel); bb.addWidget(ok)
        lay.addLayout(bb)
        self._mark()
        self.resize(1100, 660)

    def _card(self, m, idx):
        col = COL[m]
        f = QFrame(); f.setObjectName("mcard"); f.setCursor(Qt.PointingHandCursor)
        f.mousePressEvent = lambda _e, mm=m: self._pick(mm)
        v = QVBoxLayout(f); v.setContentsMargins(14, 12, 14, 12); v.setSpacing(8)
        t = QLabel(f"<span style='font-size:16px; font-weight:800; color:{col}'>{TITLE[m]}</span>"
                   f"<br><span style='color:#94A3B8'>{NOTES[m]}</span>")
        t.setTextFormat(Qt.RichText); t.setWordWrap(True); v.addWidget(t)
        g = QGridLayout(); g.setHorizontalSpacing(10); g.setVerticalSpacing(8)
        for r, (key, pair) in enumerate(ROWS.items()):
            head, line = pair[idx]
            g.addWidget(_Icon(key, col), r, 0, Qt.AlignTop)
            name = {"camera": "Camera", "LiDAR": "LiDAR", "radar": "Radar", "V2V": "V2V", "fusion": "Fusion"}[key]
            if m == "real" and key in REAL_METHODS:              # (the real-world set-up: choose the mechanism)
                box = QWidget(); bl = QVBoxLayout(box); bl.setContentsMargins(0, 0, 0, 0); bl.setSpacing(3)
                hl = QLabel(f"<b>{name}</b> · mechanism:"); hl.setTextFormat(Qt.RichText); bl.addWidget(hl)
                cb = QComboBox()
                cb.setStyleSheet("QComboBox { background: #0F172A; color: #E5E7EB; border: 1px solid #334155; "
                                 "border-radius: 6px; padding: 3px 6px; } QComboBox QAbstractItemView { background: "
                                 "#0F172A; color: #E5E7EB; selection-background-color: #1D4ED8; }")
                for mid, mname, ok, _f in REAL_METHODS[key]:
                    cb.addItem(("✔  " if ok else "✖  ") + mname + ("" if ok else "  (not integrated)"), mid)
                    cb.setItemData(cb.count() - 1, QColor("#34D399" if ok else "#FBBF24"), Qt.ForegroundRole)
                cb.setCurrentIndex(max(0, cb.findData(self.methods.get(key))))
                bl.addWidget(cb)
                st = QLabel(); st.setWordWrap(True); st.setTextFormat(Qt.RichText)
                bl.addWidget(st)
                cb.currentIndexChanged.connect(lambda _i, kk=key, c_=cb, s_=st: self._method_picked(kk, c_, s_))
                self._method_picked(key, cb, st)
                g.addWidget(box, r, 1)
                continue
            x = QLabel(f"<b>{name}</b> · <span style='color:{col}; font-weight:700'>{head}</span><br>"
                       f"<span style='color:#CBD5E1; font-size:11px'>{line}</span>")
            x.setTextFormat(Qt.RichText); x.setWordWrap(True)
            g.addWidget(x, r, 1)
        g.setColumnStretch(1, 1)
        v.addLayout(g); v.addStretch(1)
        return f

    def _method_picked(self, key, cb, label):
        mid = cb.currentData()
        self.methods[key] = mid
        o = method(key, mid)
        if o[2]:
            line = {"camera": ROWS["camera"][1][1], "LiDAR": ROWS["LiDAR"][1][1], "radar": ROWS["radar"][1][1],
                    "fusion": ROWS["fusion"][1][1]}[key]
            label.setText(f"<span style='color:#34D399; font-weight:700'>Integrated</span> "
                          f"<span style='color:#CBD5E1; font-size:11px'>— {line}</span>")
        else:
            label.setText(f"<span style='color:#FBBF24; font-weight:700'>NOT INTEGRATED</span> "
                          f"<span style='color:#CBD5E1; font-size:11px'>— the test uses "
                          f"<b>{effective(key, mid)[1]}</b> instead. What it would take: info window (ⓘ) → "
                          f"{ {'camera': 'Camera', 'LiDAR': 'LiDAR', 'radar': 'Radar', 'fusion': 'Sensor fusion'}[key]} "
                          f"→ Method.</span>")
        if self.choice != "real" and not getattr(self, "_building", False):
            self._pick("real")

    def _pick(self, m):
        self.choice = m
        self._mark()

    def _mark(self):
        for m, f in self.cards.items():
            on = m == self.choice
            c = QColor(COL[m])
            f.setStyleSheet(f"QFrame#mcard {{ background: {'rgba(%d,%d,%d,0.10)' % (c.red(), c.green(), c.blue()) if on else '#0F172A'};"
                            f" border: {3 if on else 1}px solid {COL[m] if on else '#334155'}; border-radius: 12px; }}")
        self.status.setText(f"Selected: <b style='color:{COL[self.choice]}'>{TITLE[self.choice]}</b>")
        self.status.setTextFormat(Qt.RichText)
