"""
site_config.py -- where every file lives, and which site is active.

Project layout
--------------
    config/                      settings shared by every site
        app_settings.json        active site, map zoom, hardware publishing (MQTT), drive side ...
        obstacle_types.json      car / outer truck / pedestrian / van / bus ...: icon, speeds, default size
        climates.json            the climates (sky, light, visibility, rain / snow, sensor effects)
        vehicle_dimensions.json  the AV's body (tractor) -- the starting point of a NEW site's vehicles/
        users.json               the users (made at the first start)
    sites/<site_id>/             ONE folder per site
        cc_config/               the site's map parameter file (made by Sites -> New site from the map)
        vehicles/                the site's AV model (made on first use): vehicle_dimensions.json,
                                 truck_cameras.json (optional), lidar.json (optional)
        routes/                  saved drive routes (*.txt)
        data/                    created by the app: avs.json, obstacles.json, scenarios.json,
                                 osm_surroundings.json
        reports/collision_tests/ the collision tests' results and replays
        collision_setups.json    saved collision test set-ups
    assets/   icons/  web/ (yard3d.html, three.min.js, Leaflet)  styles/ (styles.qss)
    generated/                   files the app rebuilds itself (the map page)
"""

import json
import os
import re

from PyQt5.QtCore import QUrl

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_DIR = os.path.join(ROOT_DIR, "config")
SITES_DIR = os.path.join(ROOT_DIR, "sites")
ASSETS_DIR = os.path.join(ROOT_DIR, "assets")
ICONS_DIR = os.path.join(ASSETS_DIR, "icons")
WEB_DIR = os.path.join(ASSETS_DIR, "web")
STYLES_DIR = os.path.join(ASSETS_DIR, "styles")
GENERATED_DIR = os.path.join(ROOT_DIR, "generated")

APP_SETTINGS_FILE = os.path.join(CONFIG_DIR, "app_settings.json")
OBSTACLE_TYPES_FILE = os.path.join(CONFIG_DIR, "obstacle_types.json")

STYLESHEET_FILE = os.path.join(STYLES_DIR, "styles.qss")
THREE_JS_FILE = os.path.join(WEB_DIR, "three.min.js")
YARD3D_HTML_FILE = os.path.join(WEB_DIR, "yard3d.html")      # the map's "3D" view
MAP_HTML_FILE = os.path.join(GENERATED_DIR, "site_map.html")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _strip_comments(d):
    return {k: v for k, v in d.items() if not str(k).startswith("_")}


APP_SETTINGS = _load_json(APP_SETTINGS_FILE)
OBSTACLE_TYPES = _strip_comments(_load_json(OBSTACLE_TYPES_FILE))


# ---------------------------------------------------------------------------
# Sites (the active one is known first: the vehicles are kept per site)
# ---------------------------------------------------------------------------
def available_sites():
    """Folders in sites/ that contain a map parameter file (in cc_config/ or the folder itself), sorted by name."""
    from config_loader import find_cc_files        # (pandas import kept off the hot path)
    sites = []
    if os.path.isdir(SITES_DIR):
        for name in sorted(os.listdir(SITES_DIR)):
            folder = os.path.join(SITES_DIR, name)
            if os.path.isdir(folder) and find_cc_files(cc_config_dir(name)):
                sites.append(name)
    return sites


def site_dir(site_id):
    return os.path.join(SITES_DIR, site_id)


def cc_config_dir(site_id):
    """Where a site's map parameter file is: <site>/cc_config/, or the site folder itself."""
    sub = os.path.join(site_dir(site_id), "cc_config")
    return sub if os.path.isdir(sub) else site_dir(site_id)


def _pick_active_site():
    wanted = os.environ.get("YARD_SITE") or APP_SETTINGS.get("active_site")
    sites = available_sites()
    if wanted in sites:
        return wanted
    if not sites:
        raise FileNotFoundError(
            f"No site found. Create one from the map (first start), or put a site's map parameter file in "
            f"{os.path.join(SITES_DIR, '<site>', 'cc_config')}")
    print(f"[site] '{wanted}' has no map parameter file -- using '{sites[0]}'")
    return sites[0]


ACTIVE_SITE = _pick_active_site()

# ---- the site's AV model: sites/<site>/vehicles/ (dimensions, cameras, LiDAR). config/ keeps the shared starting
# point a new site is made from.
VEHICLE_FILE_NAMES = ("vehicle_dimensions.json", "truck_cameras.json", "lidar.json")


def vehicles_dir(site_id):
    return os.path.join(site_dir(site_id), "vehicles")


def ensure_site_vehicles(site_id):
    """The first time a site is used: its vehicles folder from config/."""
    import shutil
    vdir = vehicles_dir(site_id)
    if os.path.exists(os.path.join(vdir, "vehicle_dimensions.json")):
        return vdir
    os.makedirs(vdir, exist_ok=True)
    for name in VEHICLE_FILE_NAMES:
        src = os.path.join(CONFIG_DIR, name)
        if os.path.exists(src) and not os.path.exists(os.path.join(vdir, name)):
            shutil.copy2(src, os.path.join(vdir, name))
    print(f"[vehicles] site '{site_id}': its AV model made in {vdir}")
    return vdir


VEHICLES_DIR = ensure_site_vehicles(ACTIVE_SITE)
VEHICLE_DIMENSIONS_FILE = os.path.join(VEHICLES_DIR, "vehicle_dimensions.json")
VEHICLE_DIMENSIONS = _strip_comments(_load_json(VEHICLE_DIMENSIONS_FILE))
TRUCK_CAMERAS_FILE = os.path.join(VEHICLES_DIR, "truck_cameras.json")
TRUCK_CAMERAS = _strip_comments(_load_json(TRUCK_CAMERAS_FILE)) if os.path.exists(TRUCK_CAMERAS_FILE) \
    else {"origin_height_m": 0.479, "cameras": []}
# simulated roof LiDAR (beams, range, mount, reflectivities -> intensity); {} = the 3D page's defaults
LIDAR_FILE = os.path.join(VEHICLES_DIR, "lidar.json")
LIDAR = _strip_comments(_load_json(LIDAR_FILE)) if os.path.exists(LIDAR_FILE) else {}


def is_collision_camera(c):
    """A camera used by collision testing ("use": "collision") -- not one of the Camera View panel's cameras."""
    return str((c or {}).get("use") or "perception").lower().startswith("collision")


def default_collision_camera(tractor, origin_height_m=0.479):
    """Collision testing's front camera: 90°, at the front of the cab, 2.4 m above the ground, looking ahead."""
    t = tractor or {}
    front_cm = -100.0 * (float(t.get("wheelbase", 3.1)) + float(t.get("front_overhang", 1.2))) - 10.0
    return {"enabled": True, "use": "collision", "id": "front_collision", "label": "Front camera (collision testing)",
            "model": "", "sensor": "", "purpose": "collision testing: sees what is ahead (front view)",
            "x_left_cm": 0.0, "y_cm": round(front_cm, 1), "z_cm": round(240.0 - 100.0 * float(origin_height_m), 1),
            "hfov_deg": 90.0, "vfov_deg": 59.0, "dfov_deg": 100.0, "yaw_deg": 0.0, "pitch_deg": -3.0,
            "max_range_m": 80.0, "color": "#F59E0B", "pose_from": "manual"}


def ensure_collision_camera(cams, tractor):
    """The AV's camera set gets the default front camera for collision testing if it has none (in memory).
    Returns True if one was added."""
    if cams is None:
        return False
    lst = cams.setdefault("cameras", [])
    if any(is_collision_camera(c) for c in lst):
        return False
    lst.append(default_collision_camera(tractor, float(cams.get("origin_height_m", 0.479))))
    return True


def collision_cameras():
    """The switched-on collision testing cameras of the AV (+ origin_height_m) -- front first."""
    oh = float(TRUCK_CAMERAS.get("origin_height_m", 0.479))
    cams = [dict(c, origin_height_m=oh) for c in TRUCK_CAMERAS.get("cameras", [])
            if is_collision_camera(c) and c.get("enabled", True) is not False]
    cams.sort(key=lambda c: abs(((float(c.get("yaw_deg", 0)) + 180) % 360) - 180))
    return cams


FRONT_CAMERA_PITCH = {"left_wide": -8.0, "right_standard": -5.0}


def front_cameras(cams, tractor):
    """The AV's (Camera View) cameras look AHEAD over the front of the AV: mounted at the front of the cab roof,
    yaw 0, a little down; models / fields of view stay."""
    out = dict(cams or {})
    front_cm = -100.0 * (float(tractor.get("wheelbase", 3.16)) + float(tractor.get("front_overhang", 1.12)) - 0.08)
    oh = float((cams or {}).get("origin_height_m", 0.479))
    above_cm = 100.0 * (max(float(tractor.get("sensor_bar_top", 2.82)), float(tractor.get("height", 3.19))) + 0.12 - oh)
    cl = []
    for c in (cams or {}).get("cameras", []):
        c = {k: v for k, v in c.items() if k != "calib"}
        c.update(yaw_deg=0.0, pitch_deg=FRONT_CAMERA_PITCH.get(c.get("id"), -6.0), y_cm=round(front_cm, 1),
                 z_cm=round(max(float(c.get("z_cm", 0)), above_cm), 1), pose_from="front view")
        cl.append(c)
    out["cameras"] = cl
    return out


def _compute_sensors():
    """SENSOR_CAMERAS (the Camera View panel's cameras, looking ahead) / SENSOR_LIDAR (used by the 3D pages); the
    collision testing camera is added to the AV's camera set if it has none."""
    global SENSOR_CAMERAS, SENSOR_LIDAR
    cams = dict(TRUCK_CAMERAS, cameras=[c for c in TRUCK_CAMERAS.get("cameras", [])
                                        if c.get("enabled", True) is not False and not is_collision_camera(c)])
    SENSOR_CAMERAS = front_cameras(cams, VEHICLE_DIMENSIONS.get("tractor", {}))
    SENSOR_LIDAR = dict(LIDAR)
    ensure_collision_camera(TRUCK_CAMERAS, VEHICLE_DIMENSIONS.get("tractor", {}))


SENSOR_CAMERAS = SENSOR_LIDAR = None
_compute_sensors()


# climate presets (Climate drop-down): sky, light, visibility, rain / snow, LiDAR effects
CLIMATES_FILE = os.path.join(CONFIG_DIR, "climates.json")
CLIMATES = (_load_json(CLIMATES_FILE).get("climates") if os.path.exists(CLIMATES_FILE) else None) or \
    [{"id": "clear", "label": "Clear sky", "icon": "mdi6.weather-sunny", "day": True}]


# ---------------------------------------------------------------------------
# Sites
# ---------------------------------------------------------------------------
def site_display_name(site_id):
    """The display_name in the site's map parameter file."""
    from config_loader import find_cc_files, read_key_values
    path = find_cc_files(cc_config_dir(site_id)).get("map_param")
    try:
        return (read_key_values(path).get("display_name") or site_id) if path else site_id
    except Exception:
        return site_id


def set_active_site(site_id):
    """Remembers the site chosen in the drop-down (used from the next start)."""
    settings = _load_json(APP_SETTINGS_FILE)
    settings["active_site"] = site_id
    with open(APP_SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=4)
    try:
        import auth
        auth.remember_site(site_id)                    # (the signed-in user's site at their next sign-in)
    except Exception:
        pass


def save_app_settings_section(section, values):
    """Merges `values` into one section of config/app_settings.json (e.g. the hardware publishing settings) and
    keeps APP_SETTINGS in step."""
    settings = _load_json(APP_SETTINGS_FILE)
    settings.setdefault(section, {}).update(values)
    with open(APP_SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=4)
    APP_SETTINGS.setdefault(section, {}).update(values)


# ---- AV ids: <site>_<project>_<AV id>, e.g. Technopark_project_CT1 (also their hardware topics) ----
DEFAULT_PROJECT_NAME = "project"


def site_project_file(site_id):
    return os.path.join(site_dir(site_id), "project.json")


def site_project_name(site_id=None):
    """The project name of a site (sites/<site>/project.json -- set when the site is created), else the default."""
    try:
        name = str(_load_json(site_project_file(site_id or ACTIVE_SITE)).get("project_name") or "").strip()
    except Exception:
        name = ""
    return name or str(APP_SETTINGS.get("project_name") or DEFAULT_PROJECT_NAME).strip() or DEFAULT_PROJECT_NAME


def save_site_project_name(site_id, name):
    os.makedirs(site_dir(site_id), exist_ok=True)
    with open(site_project_file(site_id), "w", encoding="utf-8") as f:
        json.dump({"project_name": name}, f, indent=4)


PROJECT_NAME = site_project_name(ACTIVE_SITE)          # (changes with the site selected)


def av_id(number, site=None, project=None):
    """The AV's id (and hardware topic id): <site (selected)>_<project name>_<AV id>."""
    return f"{site or ACTIVE_SITE}_{project or PROJECT_NAME}_{str(number).strip()}"


def av_number(av_id):
    """The AV id part of a full AV id: Technopark_project_530052 -> 530052."""
    m = re.match(r"^.+_([^_]+)$", str(av_id or ""))
    return m.group(1) if m else str(av_id or "")


def set_project_name(name):
    """The project name of the site loaded now (its own project.json; other sites keep theirs)."""
    global PROJECT_NAME
    save_site_project_name(ACTIVE_SITE, name)
    PROJECT_NAME = name


SITE_DIR = site_dir(ACTIVE_SITE)
CC_CONFIG_DIR = cc_config_dir(ACTIVE_SITE)
ROUTES_DIR = os.path.join(SITE_DIR, "routes")

# ---- this site's data: what users add / change while the app runs ----
DATA_DIR = os.path.join(SITE_DIR, "data")
AVS_FILE = os.path.join(DATA_DIR, "avs.json")
OBSTACLES_FILE = os.path.join(DATA_DIR, "obstacles.json")
SCENARIOS_FILE = os.path.join(DATA_DIR, "scenarios.json")      # saved obstacle scenarios
OSM_SURROUNDINGS_FILE = os.path.join(DATA_DIR, "osm_surroundings.json")   # "Update 3D" download

# ---- this site's logs ----
LOG_DIR = os.path.join(SITE_DIR, "logs")


def _natural_key(text):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", text)]


def route_meta(path):
    """A saved route's header ('# route: <name> | interval_ms=200 | loop=1 | ...', written by "Save as route")
    -> {"name": ..., "interval_ms": ..., "loop": ...}; {} for a route without that header."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            first = f.readline().strip()
    except OSError:
        return {}
    if not first.startswith("# route:"):
        return {}
    parts = [p.strip() for p in first[len("# route:"):].split("|")]
    meta = {"name": parts[0]}
    for p in parts[1:]:
        k, _, v = p.partition("=")
        if k.strip() and v.strip():
            meta[k.strip()] = v.strip()
    return meta


def site_routes():
    """{"Route 1": path, ..., "<saved name>": path} for every *.txt in this site's routes/ folder: routes without
    a name in their header are numbered, the others are listed by their own name."""
    if not os.path.isdir(ROUTES_DIR):
        return {}
    files = sorted((f for f in os.listdir(ROUTES_DIR) if f.lower().endswith(".txt")), key=_natural_key)
    out, i = {}, 0
    for f in files:
        p = os.path.join(ROUTES_DIR, f)
        name = route_meta(p).get("name")
        if not name or name in out:
            i += 1
            name = f"Route {i}"
        out[name] = p
    return out


# ---------------------------------------------------------------------------
# Icons
# ---------------------------------------------------------------------------
def icon_file(name):
    """Icon on disk (for Qt widgets)."""
    return os.path.join(ICONS_DIR, name)


def icon_url(name):
    """Icon as a file:// URL (for the map / web pages, wherever they are loaded from)."""
    return QUrl.fromLocalFile(icon_file(name)).toString()


def url_to_file(path_or_url):
    """Accepts a file:// URL or a path and returns a path on disk."""
    if isinstance(path_or_url, str) and path_or_url.startswith("file:"):
        return QUrl(path_or_url).toLocalFile()
    return path_or_url


# ---------------------------------------------------------------------------
# Folders
# ---------------------------------------------------------------------------
def ensure_layout():
    for folder in (DATA_DIR, LOG_DIR, GENERATED_DIR):
        os.makedirs(folder, exist_ok=True)


ensure_layout()
