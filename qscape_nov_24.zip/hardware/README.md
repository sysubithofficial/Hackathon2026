# Model vehicle for Collision Testing (ESP32 + L298N)

A small 4-wheel car that drives like one of the collision test's AVs (autonomous vehicles). It speeds up, brakes,
stops for AEB and turns, using the AV's live state that the app publishes over MQTT (topic `<prefix>/av<N>`).
Two cars, one with `AV_NO = 1` and one with `AV_NO = 2`, act out a convoy test, including a collision avoided by V2V.

```
 App (collision test) --MQTT--> broker (Mosquitto on the PC) --Wi-Fi--> ESP32 --> L298N --> 4 motors
```

## Parts

| Part | Use |
|---|---|
| ESP32-S (ESP32-WROOM-32S / NodeMCU-32S) | Wi-Fi, MQTT, motor control |
| L298N dual H-bridge | Drives the left pair and right pair of motors |
| 4 DC gear motors (TT motors, 3-6 V) | Two on the left side, two on the right side (wired in parallel per side) |
| Battery pack (4 cells) | Motors, through the L298N |
| USB power bank (or USB cable) | ESP32. Recommended: keeps the ESP32 alive when the motors pull the battery down |

## Wiring

```
 Battery +  ------------------------>  L298N  +12V (VS)
 Battery -  ------------------------>  L298N  GND  <------------  ESP32 GND   (COMMON GROUND: required)

 L298N OUT1 / OUT2  --> left  front motor + left  rear motor   (in parallel)
 L298N OUT3 / OUT4  --> right front motor + right rear motor   (in parallel)

 L298N ENA  <-- ESP32 GPIO25   (remove the ENA jumper)        L298N ENB  <-- ESP32 GPIO13   (remove the ENB jumper)
 L298N IN1  <-- ESP32 GPIO26                                  L298N IN3  <-- ESP32 GPIO33
 L298N IN2  <-- ESP32 GPIO27                                  L298N IN4  <-- ESP32 GPIO32

 ESP32 power: USB (power bank)
```

**ESP32-S3 board (DevKitC-1 style, two USB-C):** select **ESP32S3 Dev Module**; both sketches then use
ENA GPIO4, IN1 GPIO5, IN2 GPIO6, IN3 GPIO7, IN4 GPIO15, ENB GPIO16 (left pin row, 4th to 9th pin) and GND
(left row, bottom). Use the USB-C socket marked COM; with the one marked USB, set *USB CDC On Boot: Enabled*.

- **ENA / ENB jumpers:** remove them, or the speed cannot be controlled (the motors always run at full speed).
- **Pins:** GPIO 0, 2, 5, 12 and 15 are avoided; they are ESP32 boot pins and the car could start wrongly.
  The on-board LED (GPIO 2) shows the link instead.
- **Common ground** between the battery / L298N and the ESP32 is required. Without it the motors twitch
  or do not turn.
- **A side runs backwards:** swap its two motor wires, or set `LEFT_REVERSED` / `RIGHT_REVERSED` in the sketch.

### Battery

- **4 x AA (about 6 V, the sketch's default):** works with TT motors. The L298N loses about 2 V, so the motors
  get about 4 V: `MIN_DUTY` 130, `MAX_DUTY` 255. Use fresh alkaline or NiMH cells; weak cells make the car crawl. The L298N's own 5 V output is **not** reliable below 7 V, so power the ESP32 from USB.
- **4 x 18650 Li-ion (about 14.8 V):** too much for 3-6 V TT motors. Limit the speed with `MAX_DUTY` of about 90
  and `MIN_DUTY` of about 45. The L298N 5 V output can then feed the ESP32 `5V` / `VIN` pin (keep the L298N
  5 V jumper on; input at most 12 V for that jumper, otherwise use a separate 5 V regulator).
- Do not connect USB and an external 5 V to the ESP32 at the same time unless your board allows it.

## Software

### 1. The broker

**Free public broker (the sketch's default, nothing to install):** `test.mosquitto.org`, port 1883, no login.
In the app's publish dialog choose **Free public test broker … → test.mosquitto.org**. The dialog then sets a
unique topic prefix such as `yardsim/k3x9qa/hw`. Copy that prefix into the sketch's `TOPIC_PREFIX`. Anyone on the
internet can read these topics, so use them for test data only. The PC and the ESP32 only need internet access;
they can be on different networks. Some office networks block port 1883; a phone hotspot avoids that.

**Own broker on the PC (private, works without internet):** install Mosquitto (mosquitto.org/download). Version 2 accepts only local clients by default, so add a config
file `mosquitto.conf`:

```
listener 1883 0.0.0.0
allow_anonymous true
```

Run `mosquitto -c mosquitto.conf -v` and allow TCP port 1883 in the Windows firewall (private network).
The PC and the ESP32 must be on the same Wi-Fi. A phone hotspot works well for demos.

For a quick test without installing anything, the app's publish dialog also offers free public brokers
(test.mosquitto.org ...) with a unique topic prefix. Anyone can read those topics: test data only.

### 2. The ESP32 sketch

1. Arduino IDE: install the ESP32 board package (Espressif), select **ESP32 Dev Module** or **NodeMCU-32S**.
2. Library Manager: install **PubSubClient** (Nick O'Leary) and **ArduinoJson** (Benoit Blanchon, v7).
3. Open `hardware/esp32_l298n_car/esp32_l298n_car.ino` and set at the top:
   - `WIFI_SSID`, `WIFI_PASSWORD`;
   - `MQTT_HOST`: `test.mosquitto.org` (default), or the PC's IP address with your own broker (`ipconfig`);
   - `TOPIC_PREFIX`: exactly as in the app's publish dialog (e.g. `yardsim/k3x9qa/hw`);
   - `AV_NO`: 1 for the front AV, 2 for the AV behind it (the second car).
4. Upload, open the Serial Monitor (115200). It shows `MQTT connected, listening on yardsim/hw/av1`.

### 3. The app

1. **Collision Testing**: in the set-up, **Publish data to hardware (MQTT) ...**: the broker (the PC's IP or
   `localhost` when the broker runs on the same PC, port 1883), **Test connection**, the AVs to publish
   and the topic prefix.
2. Start the test. In the test window, click **📡 OFF ▶** to start publishing (or tick *Start publishing at
   once* in the dialog). The button turns **📡 ON** and shows the messages sent.
3. **End test** sends a last "ended" message: the cars stop.

Check the messages without a car: `python tools/mqtt_hw_monitor.py --host <PC IP> --prefix yardsim/hw`.

Drive the car without the app: `tools/mqtt_hw_simulator.py` sends the same messages as the app.
- `--check`: connection check only. It sends 20 "paused" messages, so the car stays stopped, reads them back and prints OK or the failed step (DNS, TCP port, MQTT).
- No option: a driving scenario in a loop.
- `--manual`: drive with typed commands (`go 60`, `left`, `right`, `brake`, `aeb`, `stop`, `end`).

Example: `python3 tools/mqtt_hw_simulator.py --host test.mosquitto.org --prefix yardsim/k3x9qa/hw --check`.

## How the car follows the AV

| Message field | Car |
|---|---|
| `status` not `running` (paused, held after a collision, finished, ended) | Stops, brake held |
| `kmh` (the AV's real speed) | Motor duty between `MIN_DUTY` (about 1 km/h) and `MAX_DUTY` (`KMH_FULL`, 30 km/h, and faster). A short push (`KICK_DUTY`) when it starts from standstill |
| `brake_mode` `full`, `aeb` or `hold` | Active brake at once (both L298N inputs high) |
| `brake_pct` (normal braking) | Duty reduced by that share |
| `yaw_rate` (deg/s, + = turning right) | Left / right speed difference (`YAW_FULL`, `STEER_GAIN`) |
| No message for 1 s (`FAILSAFE_MS`) | Stops: Wi-Fi, broker or app lost |

LED: fast blink = no link, slow blink = stopped / braking, on = driving.

The car is not position-controlled: it reproduces the speed, braking and turning of the AV, not its exact
path. On a table, start both cars in a line with the gap scaled down (for example 10 m in the test = 30 cm).

## Troubleshooting

| Problem | Cause / fix |
|---|---|
| `MQTT failed (state -2)` | Broker not reachable: wrong IP, firewall, `listener 1883 0.0.0.0` missing, other Wi-Fi |
| Connected, but the car never moves | Topic or prefix differs from the app's (check with the monitor), or publishing is OFF in the test window |
| Messages arrive in the monitor but not on the ESP32 | Buffer too small: keep `mqtt.setBufferSize(1024)` |
| Motors hum but do not turn | Raise `MIN_DUTY`; battery low; ENA / ENB jumpers still on |
| ESP32 resets when the motors start | Motor current pulls the supply down: power the ESP32 from USB / power bank, common ground |
| Car drifts to one side | Motors differ: lower that side's duty, or adjust `STEER_GAIN` |
| Only one side turns, for a few seconds | Check the Serial Monitor. `status=running` with very different L / R: the AV is turning (the sketch keeps both sides at least at `MIN_DUTY`). Otherwise upload `hardware/motor_test/motor_test.ino`: it runs each side alone, no Wi-Fi needed |
