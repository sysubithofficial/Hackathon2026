/*
  Collision Testing -> model vehicle: ESP32 + L298N + 4 DC motors (skid steering).

  The app's collision test publishes each test AV's (autonomous vehicle's) state on MQTT (hw_publish.py), 10x a second:
      topic    <prefix>/av<N>             e.g. yardsim/hw/av1      (N = the AV's place in the test, 1 = front)
      payload  {"status":"running","speed_pct":62,"brake":1,"brake_pct":45,"brake_mode":"braking",
                "yaw_rate":12.5,"kmh":15.5,"seq":812,...}       (~450 bytes JSON)
  This sketch drives the car like that AV:
      kmh        -> motor PWM (both sides)          brake / brake_mode -> slow down / active brake
      yaw_rate   -> left / right speed difference   status not "running" -> stop, brake held
  FAILSAFE: no message for FAILSAFE_MS (Wi-Fi / broker / app gone) -> the car stops.

  Serial Monitor (115200) commands, type and press Enter:
      + / -   top speed (MAX_DUTY) up / down       ] / [   slowest speed (MIN_DUTY) up / down
      > / <   more / less steering (STEER_GAIN)
      t       local test: both sides forward for 2 s, without MQTT (checks motors + wiring with Wi-Fi on)
  The log line every second shows what the app sent AND the exact pin levels sent to the L298N.

  ESP32-S3 board: select "ESP32S3 Dev Module" -- the pins switch to ENA 4, IN1 5, IN2 6, IN3 7, IN4 15, ENB 16.
  Wiring (see hardware/README.md):  L298N  ENA->GPIO25  IN1->GPIO26  IN2->GPIO27   (left motors  on OUT1/OUT2)
                                           ENB->GPIO13  IN3->GPIO33  IN4->GPIO32   (right motors on OUT3/OUT4)
                                           GND -> ESP32 GND (common ground!)   remove the ENA / ENB jumpers
  Libraries (Arduino IDE -> Library Manager):  PubSubClient (Nick O'Leary), ArduinoJson (Benoit Blanchon, v7)
  Board: "ESP32 Dev Module" (or "NodeMCU-32S" for an ESP32-S board), ESP32 Arduino core 2.x or 3.x.
*/
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// ------------------------------------------------------------------ settings: change these
const char* WIFI_SSID     = "YOUR_WIFI";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_HOST     = "test.mosquitto.org"; // free public broker (or your PC's IP when Mosquitto runs there)
const int   MQTT_PORT     = 1883;
const char* MQTT_USER     = "";                 // empty: no login (test.mosquitto.org needs none on port 1883)
const char* MQTT_PASS     = "";
const char* TOPIC_PREFIX  = "yardsim/CHANGE_ME/hw"; // COPY the "Topic prefix" from the app's "Publish to hardware"
                                                    // dialog, e.g. yardsim/k3x9qa/hw -- it must match exactly
const int   AV_NO         = 1;                  // which test AV this car is (1 = front AV, 2 = the AV behind it)

// motor limits -- set for a SLOW demo in one room (4 x AA, TT motors). See README: "Battery".
const int   PWM_FREQ      = 100;                // Hz: a low PWM frequency gives TT motors more pull at low speed
const int   PWM_BITS      = 8;                  // duty 0..255
// The car's speed follows the AV's REAL speed (kmh in the message), not its % of its own top speed:
//   0 km/h -> stop,  1 km/h -> about MIN_DUTY (crawl),  KMH_FULL and faster -> MAX_DUTY
const float KMH_FULL      = 30.0;               // AV speed (km/h) that gives the car's top speed
int         MIN_DUTY      = 75;                 // slowest speed at which BOTH sides still turn (raise if a side stands still)
int         MAX_DUTY      = 120;                // the car's top speed (lower = slower car, max 255)
                                                // live tuning in the Serial Monitor: + / - top speed, ] / [ slowest speed
const int   KICK_DUTY     = 200;                // short push when the car starts from standstill, so it starts
const unsigned long KICK_MS = 120;              //   moving even at a crawl speed (0 = no push)
const float YAW_FULL      = 40.0;               // deg/s of the AV that gives the full left / right difference
float       STEER_GAIN    = 0.3;                // 0 = no steering, 1 = the inner side stops at YAW_FULL
                                                // live tuning: > / < more / less steering
const float RAMP_PER_S    = 400.0;              // duty units per second (smooth start / stop)
const unsigned long FAILSAFE_MS = 1000;         // stop when no message came for this long

// pins -- picked automatically from the board selected in Tools -> Board
#if CONFIG_IDF_TARGET_ESP32S3                   // ESP32-S3 DevKitC-1 style board ("ESP32S3 Dev Module"), left pin row
const int ENA = 4,  IN1 = 5,  IN2 = 6;          // left side   (avoid 0, 3, 45, 46 = boot pins; 19/20 = USB;
const int IN3 = 7,  IN4 = 15, ENB = 16;         // right side   35-37 = PSRAM; 43/44 = serial; 48 = RGB LED)
#else                                           // ESP32 / NodeMCU ESP-32S (avoid 0, 2, 5, 12, 15 = boot pins)
const int ENA = 25, IN1 = 26, IN2 = 27;         // left side
const int ENB = 13, IN3 = 33, IN4 = 32;         // right side
#endif
const int LED = 2;                              // on-board LED (S3: the RGB LED, green): blinks fast = no link,
                                                // on = running, slow = stopped
bool ledOn = false;
void led(bool on) {
  if (on == ledOn) return;
  ledOn = on;
#if defined(RGB_BUILTIN)
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  rgbLedWrite(RGB_BUILTIN, 0, on ? 40 : 0, 0);
#else
  neopixelWrite(RGB_BUILTIN, 0, on ? 40 : 0, 0);
#endif
#else
  digitalWrite(LED, on ? HIGH : LOW);
#endif
}
const bool LEFT_REVERSED = false, RIGHT_REVERSED = false;   // a side runs backwards? set true (or swap its wires)

// ------------------------------------------------------------------
WiFiClient net;
PubSubClient mqtt(net);
char topic[96];
float targetL = 0, targetR = 0, dutyL = 0, dutyR = 0;   // signed duty (+ forward)
bool braking = true;
unsigned long lastMsg = 0, lastLoop = 0, testUntil = 0;
String status = "none", brakeMode = "none";
long lastSeq = -1, lost = 0, msgCount = 0;
int speedPctIn = 0, brakePctIn = 0;
float yawIn = 0, kmhIn = 0;
unsigned long kickUntil = 0;
int pinA[2], pinB[2], pinEn[2];                 // what was last sent to the L298N (0 = left, 1 = right), for the log

void pwmSetup(int pin) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, PWM_FREQ, PWM_BITS);
#else
  static int ch = 0;
  ledcSetup(ch, PWM_FREQ, PWM_BITS);
  ledcAttachPin(pin, ch);
  ch++;
#endif
}
void pwmWrite(int pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(pin == ENA ? 0 : 1, duty);
#endif
}

// one side: + forward, - backward; brake = both inputs HIGH with the enable on (short brake)
// After BRAKE_MS of braking the outputs are switched OFF (enable 0, inputs LOW): standing still needs no
// brake, it saves the battery, and with the enable at 0 V a loose IN wire can no longer make a side run.
const unsigned long BRAKE_MS = 500;
unsigned long brakeSince = 0;
bool released = false;                          // true = outputs off (log: HOLD)
void side(int en, int a, int b, float duty, bool brake, bool reversed) {
  int i = (en == ENA) ? 0 : 1;
  int va, vb, ve;
  if (brake && released) { va = LOW; vb = LOW; ve = 0; }
  else if (brake) { va = HIGH; vb = HIGH; ve = 255; }
  else {
    bool fwd = (duty >= 0) != reversed;
    va = fwd ? HIGH : LOW; vb = fwd ? LOW : HIGH; ve = (int)constrain(fabs(duty), 0, 255);
  }
  digitalWrite(a, va); digitalWrite(b, vb); pwmWrite(en, ve);
  pinA[i] = va; pinB[i] = vb; pinEn[i] = ve;
}

void stopCar() { targetL = targetR = 0; braking = true; }

void onMessage(char* t, byte* payload, unsigned int len) {
  JsonDocument doc;
  if (deserializeJson(doc, payload, len)) return;               // (not JSON: ignored)
  lastMsg = millis();
  msgCount++;
  status = doc["status"] | "none";
  long seq = doc["seq"] | -1L;
  if (lastSeq >= 0 && seq > lastSeq + 1) lost += seq - lastSeq - 1;
  lastSeq = seq;
  brakeMode = doc["brake_mode"] | "none";
  speedPctIn = doc["speed_pct"] | 0;
  brakePctIn = doc["brake_pct"] | 0;
  yawIn = doc["yaw_rate"] | 0.0f;
  kmhIn = doc["kmh"] | -1.0f;
  if (kmhIn < 0) kmhIn = speedPctIn * KMH_FULL / 100.0;         // (an older app without "kmh")

  bool hardBrake = brakeMode == "full" || brakeMode == "aeb" || brakeMode == "hold";
  // normal braking only slows the car down (the AV's speed falls as well); it stops only near standstill
  float eff = constrain(kmhIn / KMH_FULL, 0.0, 1.0) * 100.0 * (1.0 - 0.5 * brakePctIn / 100.0);  // 0..100
  if (status != "running" || hardBrake || kmhIn < 0.3) { stopCar(); return; }
  braking = false;
  float base = MIN_DUTY + (MAX_DUTY - MIN_DUTY) * eff / 100.0;
  float k = constrain(yawIn / YAW_FULL, -1.0, 1.0) * STEER_GAIN; // + = turning right: the left side faster
  targetL = constrain(base * (1.0 + k), MIN_DUTY, MAX_DUTY);   // (never below MIN_DUTY: the inner side would
  targetR = constrain(base * (1.0 - k), MIN_DUTY, MAX_DUTY);   //  stall; never above MAX_DUTY: speed limit)
}

const char* wifiReason(int s) {
  switch (s) {
    case WL_NO_SSID_AVAIL:   return "network not found: check WIFI_SSID (exact spelling and capitals) and that it is 2.4 GHz";
    case WL_CONNECT_FAILED:  return "refused: check WIFI_PASSWORD";
    case WL_CONNECTION_LOST: return "connection lost";
    case WL_DISCONNECTED:    return "no answer: wrong password, WPA3-only, 5 GHz-only or too far";
    default:                 return "not connected";
  }
}

void scanNetworks() {                           // what the ESP32 can see (it only sees 2.4 GHz networks)
  WiFi.disconnect(); delay(100);
  Serial.println("Networks the ESP32 can see (2.4 GHz only):");
  int n = WiFi.scanNetworks();
  if (n <= 0) Serial.println("  none -- move closer, or the hotspot is 5 GHz only");
  for (int i = 0; i < n && i < 15; i++)
    Serial.printf("  %-32s signal %4d dBm  channel %2d%s\n", WiFi.SSID(i).c_str(), WiFi.RSSI(i), WiFi.channel(i),
                  WiFi.SSID(i) == WIFI_SSID ? "   <-- WIFI_SSID found" : "");
  WiFi.scanDelete();
}

void connectWifi() {
  static bool started = false;
  static int fails = 0;
  if (WiFi.status() == WL_CONNECTED) return;
  if (!started) { WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); started = true; }
  else { WiFi.disconnect(); delay(200); }       // (begin() during a running attempt fails: "sta is connecting, cannot set config")
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.printf("Wi-Fi \"%s\" ", WIFI_SSID);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) {
    led(!ledOn); delay(150); Serial.print(".");
  }
  int s = WiFi.status();
  if (s == WL_CONNECTED) {
    fails = 0;
    Serial.println(" connected: " + WiFi.localIP().toString());
  } else {
    Serial.printf(" FAILED (status %d: %s)\n", s, wifiReason(s));
    if (fails++ % 5 == 0) scanNetworks();       // (first failure, then every 5th)
  }
}

void connectMqtt() {
  if (mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  String id = "esp32-av-" + String(AV_NO) + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  bool ok = strlen(MQTT_USER) ? mqtt.connect(id.c_str(), MQTT_USER, MQTT_PASS) : mqtt.connect(id.c_str());
  if (ok) {
    mqtt.subscribe(topic, 0);
    Serial.printf("MQTT connected, listening on %s\n", topic);
  } else {
    Serial.printf("MQTT failed (state %d) -- retrying\n", mqtt.state());
  }
}

void serialCommands() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '+') MAX_DUTY = min(MAX_DUTY + 5, 255);
    else if (c == '-') {                                  // (at the slowest speed: both go down together)
      if (MAX_DUTY - 5 < MIN_DUTY) MIN_DUTY = max(MIN_DUTY - 5, 30);
      MAX_DUTY = max(MAX_DUTY - 5, MIN_DUTY);
    }
    else if (c == ']') { MIN_DUTY = min(MIN_DUTY + 5, 255); MAX_DUTY = max(MAX_DUTY, MIN_DUTY); }
    else if (c == '[') MIN_DUTY = max(MIN_DUTY - 5, 30);
    else if (c == '>') STEER_GAIN = min(STEER_GAIN + 0.1f, 1.0f);
    else if (c == '<') STEER_GAIN = max(STEER_GAIN - 0.1f, 0.0f);
    else if (c == 't') {
      testUntil = millis() + 2000;
      Serial.printf(">> TEST: both sides forward at MAX_DUTY=%d for 2 s (MQTT ignored)\n", MAX_DUTY);
      continue;
    }
    else continue;
    Serial.printf(">> MIN_DUTY=%d (slowest)  MAX_DUTY=%d (top)  STEER_GAIN=%.1f  -- write these into the sketch to keep them\n",
                  MIN_DUTY, MAX_DUTY, STEER_GAIN);
  }
}

void setup() {
  Serial.begin(115200);
#if !defined(RGB_BUILTIN)
  pinMode(LED, OUTPUT);
#endif
  for (int p : {IN1, IN2, IN3, IN4}) { pinMode(p, OUTPUT); digitalWrite(p, LOW); }
  pwmSetup(ENA); pwmSetup(ENB);
  side(ENA, IN1, IN2, 0, true, LEFT_REVERSED); side(ENB, IN3, IN4, 0, true, RIGHT_REVERSED);
  snprintf(topic, sizeof(topic), "%s/av%d", TOPIC_PREFIX, AV_NO);
  delay(1000);
  Serial.printf("\nAV %d model car  pins: ENA=%d IN1=%d IN2=%d | ENB=%d IN3=%d IN4=%d  MIN_DUTY=%d MAX_DUTY=%d\n",
                AV_NO, ENA, IN1, IN2, ENB, IN3, IN4, MIN_DUTY, MAX_DUTY);
  Serial.println("Commands: + / - top speed, ] / [ slowest speed, > / < steering, t = 2 s motor test without MQTT");
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setBufferSize(1024);                     // (the app's messages are ~450 bytes; the default 256 drops them)
  mqtt.setKeepAlive(10);
  mqtt.setCallback(onMessage);
  connectWifi();
}

void loop() {
  static unsigned long lastTry = 0, lastPrint = 0;
  if ((WiFi.status() != WL_CONNECTED || !mqtt.connected()) && millis() - lastTry > 2000) {
    lastTry = millis();
    connectWifi();
    connectMqtt();
  }
  mqtt.loop();
  serialCommands();

  if (millis() - lastMsg > FAILSAFE_MS) stopCar();               // FAILSAFE: no fresh message -> stop

  // smooth duty changes; braking: at once
  unsigned long now = millis();
  float dt = (now - lastLoop) / 1000.0; lastLoop = now;
  float step = RAMP_PER_S * min(dt, 0.1f);
  if (braking) {
    dutyL = dutyR = 0;
    if (brakeSince == 0) brakeSince = now ? now : 1;
    released = now - brakeSince > BRAKE_MS;       // brake briefly, then outputs off
  } else {
    if (brakeSince != 0 || (dutyL == 0 && dutyR == 0)) {     // starting from standstill: a short push, then
      kickUntil = now + KICK_MS;                              // straight to the slowest moving speed
      dutyL = min(targetL, (float)MIN_DUTY); dutyR = min(targetR, (float)MIN_DUTY);
    }
    brakeSince = 0; released = false;
    dutyL += constrain(targetL - dutyL, -step, step);
    dutyR += constrain(targetR - dutyR, -step, step);
  }
  bool kick = !braking && now < kickUntil;
  float outL = kick ? max(dutyL, (float)KICK_DUTY) : dutyL;
  float outR = kick ? max(dutyR, (float)KICK_DUTY) : dutyR;
  if (now < testUntil) {                                          // 't' test: overrides MQTT for 2 s
    side(ENA, IN1, IN2, MAX_DUTY, false, LEFT_REVERSED);
    side(ENB, IN3, IN4, MAX_DUTY, false, RIGHT_REVERSED);
  } else {
    side(ENA, IN1, IN2, outL, braking, LEFT_REVERSED);
    side(ENB, IN3, IN4, outR, braking, RIGHT_REVERSED);
  }

  bool link = mqtt.connected() && millis() - lastMsg <= FAILSAFE_MS;
  led(!link ? (millis() / 120) % 2 : braking ? (millis() / 600) % 2 : true);
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    // app -> car: what came in | car -> L298N: what was sent to the pins (EN = speed 0..255)
    Serial.printf("app: %-8s %5.1f km/h brk=%3d%% %-8s yaw=%+5.1f msgs/s=%2ld lost=%ld | L298N: %s  "
                  "L IN1=%d IN2=%d ENA=%3d   R IN3=%d IN4=%d ENB=%3d\n",
                  status.c_str(), kmhIn, brakePctIn, brakeMode.c_str(), yawIn, msgCount, lost,
                  now < testUntil ? "TEST " : !braking ? "DRIVE" : released ? "HOLD " : "BRAKE",
                  pinA[0], pinB[0], pinEn[0], pinA[1], pinB[1], pinEn[1]);
    msgCount = 0;
  }
  delay(5);
}
