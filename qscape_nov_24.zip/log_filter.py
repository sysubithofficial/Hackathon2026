"""The terminal shows errors and warnings only.

The app's modules print a lot of routine information (every detection, every MQTT message, every vehicle update
...). install() puts a filter on stdout: a line goes through only when it reads as an error / a warning (error,
failed, warning, cannot, not found, missing, time-out, crash ...). Python's own error output (stderr: tracebacks,
warnings) and messages of native libraries (Qt, QtWebEngine) are not touched.

Everything is shown again with  "log": "all"  in config/app_settings.json, or the environment variable
YARD_LOG=all (e.g.  YARD_LOG=all ./run_ubuntu.sh).
"""
import os
import re
import sys
import threading

KEEP = re.compile(
    r"error|fail|warn|cannot|can't|could not|couldn't|unable|not found|missing|invalid|exception|traceback|"
    r"refused|time-?out|timed out|crash|abort|segmentation|not published|not usable|not saved|not drawn|"
    r"not built|not available|not loaded|not installed|not running|declined|stopped:|ended \(|!!!",
    re.IGNORECASE)


class _Filtered:
    def __init__(self, stream):
        self._s = stream
        self._buf = ""
        self._lock = threading.Lock()

    def write(self, text):
        if not isinstance(text, str):
            return self._s.write(text)
        out = []
        with self._lock:
            self._buf += text
            while "\n" in self._buf:
                line, self._buf = self._buf.split("\n", 1)
                if KEEP.search(line):
                    out.append(line + "\n")
            if len(self._buf) > 8192:                    # (no newline coming: judged as it is)
                if KEEP.search(self._buf):
                    out.append(self._buf)
                self._buf = ""
        for o in out:
            try:
                self._s.write(o)
            except Exception:
                pass
        return len(text)

    def flush(self):
        try:
            self._s.flush()
        except Exception:
            pass

    def __getattr__(self, name):                         # isatty, fileno, encoding ...
        return getattr(self._s, name)


def wanted():
    if os.environ.get("YARD_LOG", "").lower() == "all":
        return False
    try:
        import site_config as cfg
        return str((cfg.APP_SETTINGS or {}).get("log", "errors")).lower() != "all"
    except Exception:
        return True


def install():
    """stdout -> errors / warnings only (once; not with "log": "all")."""
    if sys.stdout is None or isinstance(sys.stdout, _Filtered) or not wanted():
        return
    sys.stdout = _Filtered(sys.stdout)
