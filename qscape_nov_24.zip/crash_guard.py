"""Keeps the app alive and leaves a trace when something goes wrong.

- PyQt5 (5.5+) ends the whole process (qFatal -> Windows "Qt5Core.dll 0xc0000409") when a Python exception
  escapes from a Qt callback (a timer, a button, paintEvent ...). install() sets sys.excepthook: the error is
  written to logs/app_errors.log (and the terminal) and the app goes on.
- A native crash (a graphics driver, Qt) cannot be caught: faulthandler writes the Python stack of every thread
  to logs/crash_native.log, so the place is known afterwards.
- use_angle(): on Windows, Qt draws with OpenGL ES through ANGLE (Direct3D) instead of the graphics card's
  OpenGL driver -- crashes inside the driver (e.g. Intel igxelpicd64.dll) are avoided. Environment variable
  YARD_OPENGL=desktop keeps the driver's OpenGL, =software uses the software renderer. Call it before the
  QApplication is made.
"""
import datetime
import faulthandler
import os
import sys
import threading
import traceback

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
_native = None
_lock = threading.Lock()
_count = {}


def _write(text):
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        path = os.path.join(LOG_DIR, "app_errors.log")
        if os.path.exists(path) and os.path.getsize(path) > 5_000_000:      # (keep it small: one old copy)
            os.replace(path, path + ".1")
        with open(path, "a", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass


def _hook(etype, value, tb):
    if issubclass(etype, KeyboardInterrupt):
        sys.__excepthook__(etype, value, tb)
        return
    text = "".join(traceback.format_exception(etype, value, tb))
    key = text[-400:]
    with _lock:
        n = _count[key] = _count.get(key, 0) + 1
    if n <= 3 or n in (10, 100, 1000):                 # (the same error in a timer: not thousands of copies)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        _write(f"\n=== {stamp}  (x{n}) ===\n{text}")
        try:
            sys.stderr.write(f"[error] {etype.__name__}: {value} -- the app goes on (logs/app_errors.log)\n")
        except Exception:
            pass


def install():
    """sys.excepthook (+ threads) -> logged, the app goes on; faulthandler -> logs/crash_native.log."""
    global _native
    sys.excepthook = _hook
    threading.excepthook = lambda a: _hook(a.exc_type, a.exc_value, a.exc_traceback)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        _native = open(os.path.join(LOG_DIR, "crash_native.log"), "a", encoding="utf-8")
        _native.write(f"\n--- started {datetime.datetime.now():%Y-%m-%d %H:%M:%S} (pid {os.getpid()}) ---\n")
        _native.flush()
        faulthandler.enable(_native, all_threads=True)
    except OSError:
        pass


def shutdown_qt(app):
    """After app.exec_() returned: delete the web views (3D / camera / sensor pages, map) while Qt still runs, and
    tell sip not to destroy Qt objects when Python exits -- web views without a parent (the hidden LiDAR sensor
    page, the camera page) were otherwise destroyed after Qt during Python's exit and crashed it (Windows:
    python.exe, sip.pyd, 0xc0000005, at offset e400)."""
    try:
        from PyQt5 import sip
    except ImportError:
        return
    try:
        from PyQt5.QtWebEngineWidgets import QWebEngineView
        views = [w for w in app.allWidgets() if isinstance(w, QWebEngineView)]
        for v in views:
            try:
                v.stop()
            except Exception:
                pass
        for v in views:
            try:
                if not sip.isdeleted(v):
                    sip.delete(v)
            except Exception:
                pass
        app.processEvents()
    except Exception:
        _hook(*sys.exc_info())
    try:
        sip.setdestroyonexit(False)
    except Exception:
        pass
    if _native is not None:
        try:
            _native.write("--- closed normally ---\n")
            _native.flush()
        except Exception:
            pass


def use_angle():
    """Windows: OpenGL ES via ANGLE (Direct3D) unless YARD_OPENGL says otherwise. Before QApplication."""
    if sys.platform != "win32":
        return
    from PyQt5.QtCore import QCoreApplication, Qt
    mode = os.environ.get("YARD_OPENGL", "angle").lower()
    if mode == "desktop":
        QCoreApplication.setAttribute(Qt.AA_UseDesktopOpenGL, True)
    elif mode == "software":
        QCoreApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)
    else:
        QCoreApplication.setAttribute(Qt.AA_UseOpenGLES, True)
