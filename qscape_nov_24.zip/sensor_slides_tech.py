"""TECHNICAL step-by-step pictures (the info window's View → Technical overview), registered into
sensor_slides.DECKS as "tech_<name>".

Every step has the same three parts, so an evaluator can follow the code without reading pages of text:
  top     the CODE: the module · function and the one or two lines that do this step (as in the source)
  middle  a PICTURE of what that code computes (animated)
  bottom  the CALCULATION with real numbers (computed with the models themselves: follow_test / v2v)

Decks: camera, lidar, radar, v2v, fusion, brake (simulated set-up), the real-world camera / LiDAR / radar / fusion,
cellular V2V, the test flow, the climate and collisions (the overview picture with the code of each step).
"""
import math

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QFont, QPainterPath, QPen, QPolygonF

import follow_test as ft
import sensor_slides as S
import v2v
from sensor_graphics import (AMBER, COL, GREEN, MUTED, OTHER, OURS, RED, TXT, _arrow, _c, _d_climate, _fog,
                             _mark, _road, _text, _vehicle)

H = 300
HL = "#FDE68A"
CODE_COL, WHERE_COL = "#A7F3D0", "#93C5FD"


def _clim(cid, fallback):
    try:
        import site_config as cfg
        for c in cfg.CLIMATES or []:
            if c.get("id") == cid:
                return c
    except Exception:
        pass
    return fallback


CLEAR = _clim("clear", {"visibility_m": 4500, "day": True})
FOG = _clim("fog", {"visibility_m": 120, "day": True, "lidar": {"extinction_per_m": 0.025}})
WHITEOUT = _clim("whiteout_fog", {"visibility_m": 12, "day": True, "lidar": {"extinction_per_m": 0.22}})
RAIN = _clim("heavy_rain", {"visibility_m": 350, "day": True, "precip": {"type": "rain", "rate": 1.0}})


def _dim(p, x0, x1, y, label, col=HL):
    """A distance line with arrows both ways and its label BELOW it (not across the line)."""
    _arrow(p, QPointF(x0, y), QPointF(x1, y), col, 1.6, 7, both=True)
    p.save(); p.setPen(QPen(_c(col), 1, Qt.DotLine))
    p.drawLine(QPointF(x0, y - 12), QPointF(x0, y + 4)); p.drawLine(QPointF(x1, y - 12), QPointF(x1, y + 4))
    p.restore()
    _text(p, (x0 + x1) / 2, y + 20, label, col, 12, True, Qt.AlignCenter, max(260, abs(x1 - x0) + 120))


# ------------------------------------------------------------------ the three parts of a step
def _mono(p, x, y, t, col, size=12, bold=False):
    f = QFont("Consolas"); f.setPixelSize(size); f.setBold(bold); p.setFont(f); p.setPen(_c(col))
    p.drawText(QRectF(x, y - size, 790 - x, size * 1.6), Qt.AlignLeft | Qt.AlignTop, t)


def _code(p, where, lines):
    """The code band at the top: module · function + its key lines. -> the band's bottom y."""
    h = 24 + 16 * len(lines)
    r = QRectF(6, 4, 788, h)
    p.setPen(QPen(_c("#1F2937"), 1)); p.setBrush(_c("#020617")); p.drawRoundedRect(r, 7, 7)
    p.setPen(Qt.NoPen); p.setBrush(_c(WHERE_COL)); p.drawRoundedRect(QRectF(6, 4, 4, h), 2, 2)
    _mono(p, 16, 19, "CODE  ·  " + where, WHERE_COL, 11, True)
    for i, ln in enumerate(lines):
        _mono(p, 16, 36 + 16 * i, ln, CODE_COL, 12)
    return r.bottom()


def _calc(p, text):
    r = QRectF(6, H - 36, 788, 30)
    p.setPen(QPen(_c(HL, 0.6), 1)); p.setBrush(_c(HL, 0.08)); p.drawRoundedRect(r, 7, 7)
    _text(p, 400, H - 16, text, HL, 12, True, Qt.AlignCenter, 770)


def _deck(steps):
    """steps = [(caption, where, [code lines], calculation, visual(p, top))] -> a DECKS entry."""
    def draw(p, s):
        cap, where, lines, calc, vis = steps[s - 1]
        top = _code(p, where, lines)
        try:
            vis(p, top + 8)
        finally:
            if calc:
                _calc(p, calc)
    return (H, [c for c, *_r in steps], draw)


def _wrap(base, codes):
    """A technical deck from an overview deck: each step's picture (scaled) with its code and calculation."""
    h0, caps, fn = base

    def draw(p, s):
        where, lines, calc = codes[min(s, len(codes)) - 1]
        top = _code(p, where, lines) + 6
        room = H - 42 - top
        sc = min(0.86, room / float(h0))
        p.save()
        p.translate((800 - 800 * sc) / 2, top); p.scale(sc, sc)
        fn(p, s)
        p.restore()
        if calc:
            _calc(p, calc)
    return (H, caps, draw)


def _plot(p, r, f, x0, x1, y0, y1, col, mark=None, xl="", yl="", hline=None, hcol=RED):
    """A small graph of f(x) in rect r; mark = x of an animated marker; hline = a threshold."""
    p.setPen(QPen(_c(MUTED), 1.2))
    p.drawLine(QPointF(r.left(), r.bottom()), QPointF(r.right(), r.bottom()))
    p.drawLine(QPointF(r.left(), r.top()), QPointF(r.left(), r.bottom()))
    X = lambda x: r.left() + (x - x0) / (x1 - x0) * r.width()                    # noqa: E731
    Y = lambda y: r.bottom() - (max(y0, min(y1, y)) - y0) / (y1 - y0) * r.height()  # noqa: E731
    if hline is not None:
        p.setPen(QPen(_c(hcol), 1.3, Qt.DashLine)); p.drawLine(QPointF(r.left(), Y(hline)), QPointF(r.right(), Y(hline)))
    path = QPainterPath()
    for i in range(121):
        x = x0 + (x1 - x0) * i / 120
        (path.moveTo if i == 0 else path.lineTo)(QPointF(X(x), Y(f(x))))
    p.setPen(QPen(_c(col), 2.4)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    if mark is not None:
        p.setPen(QPen(_c(HL), 1, Qt.DotLine))
        p.drawLine(QPointF(X(mark), r.bottom()), QPointF(X(mark), Y(f(mark))))
        p.setPen(Qt.NoPen); p.setBrush(_c(HL)); p.drawEllipse(QPointF(X(mark), Y(f(mark))), 5, 5)
    _text(p, r.right(), r.bottom() + 16, xl, MUTED, 10, False, Qt.AlignRight, 200)
    _text(p, r.left() + 4, r.top() + 10, yl, MUTED, 10, False, w=200)
    return X, Y


def _box(p, r, col, title, lines=(), al=1.0, mono=False):
    p.setPen(QPen(_c(col, al), 1.6)); p.setBrush(_c(col, 0.1 * al)); p.drawRoundedRect(r, 8, 8)
    _text(p, r.center().x(), r.top() + 16, title, _c(col, al).name(QColor.HexArgb), 12, True, Qt.AlignCenter,
          r.width() - 8)
    for i, t in enumerate(lines):
        if mono:
            _mono(p, r.left() + 8, r.top() + 36 + 15 * i, t, TXT, 11)
        else:
            _text(p, r.center().x(), r.top() + 34 + 15 * i, t, TXT, 11, False, Qt.AlignCenter, r.width() - 8)


def _flow_arrow(p, a, b, col=MUTED, period=1.6, packet=True):
    _arrow(p, a, b, col, 2, 9)
    if packet:
        S._packet(p, a, b, S.ph(period), COL["V2V"] if col == MUTED else col)


# ------------------------------------------------------------------ CAMERA (simulated set-up)
_CX, _CY, _COWN, _CL = 40.0, 0.8, 7.0, 16.5
_CGAP = _CX - _COWN / 2 - _CL / 2
_CRNG = ft.camera_range(FOG)
_CCONF = max(0.25, min(0.99, 1 - 0.75 * _CGAP / max(1.0, _CRNG)))


def _cam1(p, y):
    rows = [("'Truck_auto_1'", "8.55843", "76.88254", "16.5", "2.5", "'truck'", "True", "169", "5.6"),
            ("'Car_3'", "8.55851", "76.88247", "4.5", "1.8", "'car'", "False", "0", "0.0"),
            ("'Cone_2'", "8.55860", "76.88266", "0.5", "0.5", "'object'", "False", "-", "0.0")]
    _mono(p, 20, y + 14, "objs = [  # (id, lat, lon, length, width, kind, moving, heading, speed)", MUTED, 11)
    for i, r in enumerate(rows):
        al = S._appear(i, 0.3)
        _mono(p, 40, y + 36 + 20 * i, "(" + ", ".join(r) + "),", _c(TXT, al).name(QColor.HexArgb), 12)
    _arrow(p, QPointF(560, y + 56), QPointF(640, y + 56), MUTED, 2, 9)
    _box(p, QRectF(646, y + 30, 140, 56), COL["camera"], "camera_detect()", ["for every truck"])
    _text(p, 400, y + 120, "Python already KNOWS every object (the map's data) — the camera model decides which of them "
                           "the camera would see.", TXT, 12, False, Qt.AlignCenter, 760)


def _cam2(p, y):
    # map frame (east / north) on the left, truck frame (x ahead / y left) on the right
    o = QPointF(150, y + 120)
    _arrow(p, o, QPointF(270, y + 120), MUTED, 1.6, 7); _text(p, 276, y + 124, "east", MUTED, 10, w=40)
    _arrow(p, o, QPointF(150, y + 10), MUTED, 1.6, 7); _text(p, 156, y + 14, "north", MUTED, 10, w=40)
    h = math.radians(30 + 10 * math.sin(S.T))                       # (our heading, animated a little)
    hx, hy = math.sin(h), -math.cos(h)
    _arrow(p, o, QPointF(o.x() + 90 * hx, o.y() + 90 * hy), OURS, 2.6, 9)
    _text(p, o.x() + 92 * hx + 4, o.y() + 92 * hy, "heading h", OURS, 10, True, w=70)
    ob = QPointF(250, y + 30)
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"])); p.drawEllipse(ob, 6, 6)
    _text(p, ob.x() + 8, ob.y() - 4, "object (e, n)", COL["camera"], 10, True, w=100)
    p.setPen(QPen(_c(MUTED), 1, Qt.DotLine)); p.drawLine(o, ob)
    _arrow(p, QPointF(330, y + 80), QPointF(420, y + 80), HL, 2.4, 10)
    _text(p, 375, y + 66, "rotate", HL, 11, True, Qt.AlignCenter, 80)
    # truck frame
    t = QPointF(470, y + 110)
    _vehicle(p, QRectF(t.x() - 30, t.y() - 10, 60, 20), OURS, "")
    _arrow(p, t, QPointF(780, t.y()), MUTED, 1.6, 7); _text(p, 730, t.y() + 16, "x ahead", MUTED, 10, w=60)
    _arrow(p, t, QPointF(t.x(), y + 10), MUTED, 1.6, 7); _text(p, t.x() + 4, y + 14, "y left", MUTED, 10, w=60)
    px = t.x() + 280 * min(1.0, S.ph(2.5) * 1.6)
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"])); p.drawEllipse(QPointF(px, t.y() - 10), 6, 6)
    _dim(p, t.x(), t.x() + 280, t.y() + 30, "x = 40.0 m (y = 0.8 m)")


def _cam3(p, y):
    o = QPointF(110, y + 100)
    path = QPainterPath(o); path.lineTo(o.x() + 600, o.y() - 600); path.lineTo(o.x() + 600, o.y() + 600)
    p.save(); p.setClipRect(QRectF(0, y, 800, 190))
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"], 0.12)); p.drawPath(path)
    p.setPen(QPen(_c(COL["camera"], 0.7), 1.2)); p.drawLine(o, QPointF(o.x() + 200, o.y() - 200))
    p.drawLine(o, QPointF(o.x() + 200, o.y() + 200))
    p.restore()
    _vehicle(p, QRectF(30, o.y() - 12, 80, 24), OURS, "")
    _text(p, 250, y + 20, "+45°", COL["camera"], 11, True, w=50); _text(p, 250, y + 186, "−45°", COL["camera"], 11,
                                                                         True, w=50)
    for (x, yy, ok, lab) in ((520, o.y() - 8, True, "Truck_auto_1: 1.1° ✓"), (300, o.y() - 150 + 60, False,
                                                                                "beside: 60° ✕")):
        p.setPen(Qt.NoPen); p.setBrush(_c(GREEN if ok else RED)); p.drawEllipse(QPointF(x, yy), 6, 6)
        _text(p, x + 10, yy - 4, lab, GREEN if ok else RED, 11, True, w=180)
    a = S.ph(2.0)
    p.setPen(QPen(_c(HL), 2)); p.drawLine(o, QPointF(o.x() + 400, o.y() - 400 * math.tan(math.radians(45 * (2 * a - 1)))))


def _cam4(p, y):
    _road(p, y + 60, y + 150)
    _fog(p, QRectF(420, y + 60, 380, 90), 50, seed=3, a=0.18)
    _vehicle(p, QRectF(20, y + 88, 70, 30), OURS, "own 7 m")
    tx = 90 + _CGAP * 7
    _vehicle(p, QRectF(tx, y + 86, 16.5 * 7 * 0.6, 34), OTHER, "Truck_auto_1")
    _dim(p, 90, tx, y + 40, f"gap = 40 − 3.5 − 8.25 = {_CGAP:.2f} m")
    p.setPen(QPen(_c(COL["camera"]), 2.4, Qt.DashLine)); x = 90 + _CRNG * 7 * min(1.0, S.ph(2.5) * 1.4)
    p.drawLine(QPointF(x, y + 56), QPointF(x, y + 156))
    _text(p, x, y + 172, f"range {_CRNG:.0f} m", COL["camera"], 12, True, Qt.AlignCenter, 120)


def _cam5(p, y):
    _text(p, 20, y + 14, "angle seen from the camera  →", MUTED, 11, w=300)
    X = lambda a: 400 + a * 40                                                       # noqa: E731
    p.setPen(QPen(_c(MUTED), 1)); p.drawLine(QPointF(X(-8), y + 120), QPointF(X(8), y + 120))
    for a in range(-8, 9, 2):
        _text(p, X(a), y + 138, f"{a}°", MUTED, 10, False, Qt.AlignCenter, 40)
    van, car = math.degrees(math.atan2(1.0, 15.0)), math.degrees(math.atan2(0.9, 30.0))
    p.setPen(Qt.NoPen); p.setBrush(_c(OTHER, 0.9)); p.drawRoundedRect(QRectF(X(-van), y + 40, X(van) - X(-van), 26), 5, 5)
    _text(p, 400, y + 58, f"van at 15 m: ±{van:.1f}°", TXT, 11, True, Qt.AlignCenter, 200)
    g = S.ph(2.5)
    p.setBrush(_c(RED, 0.5 + 0.4 * g)); p.drawRoundedRect(QRectF(X(-car), y + 80, X(car) - X(-car), 26), 5, 5)
    _text(p, X(car) + 10, y + 98, f"car at 30 m: ±{car:.1f}° — 100 % covered → HIDDEN", RED, 11, True, w=330)


def _cam6(p, y):
    r = QRectF(70, y + 10, 380, 150)
    f = lambda g: max(0.25, min(0.99, 1 - 0.75 * g / _CRNG))                       # noqa: E731
    _plot(p, r, f, 0, _CRNG, 0, 1.0, COL["camera"], mark=_CGAP * min(1.0, S.ph(3.0) * 1.5), xl="gap (m) →",
          yl="confidence", hline=0.5, hcol=AMBER)
    _text(p, r.right() - 60, r.bottom() - 150 * 0.5 - 4, "0.5", AMBER, 10, True, w=40)
    _text(p, 480, y + 40, "≥ 0.5 → its type ('truck')", GREEN, 13, True, w=300)
    _text(p, 480, y + 66, "< 0.5 → only 'object'", AMBER, 13, True, w=300)
    _text(p, 480, y + 100, "(far away / poor visibility = less sure)", MUTED, 11, w=300)


def _cam7(p, y):
    _box(p, QRectF(20, y + 10, 420, 150), COL["camera"], "one detection (a Python dict)",
         ["{'id': 'Truck_auto_1', 'label': 'Truck_auto_1',", f" 'gap': {_CGAP:.2f}, 'x': 40.0, 'y': 0.8,",
          f" 'cls': 'truck', 'conf': {_CCONF:.2f},", " 'sensor': 'camera'}"], mono=True)
    _flow_arrow(p, QPointF(446, y + 85), QPointF(540, y + 85), COL["camera"])
    _box(p, QRectF(546, y + 40, 240, 90), "#F472B6", "Follower.perceive()", ["in our lane? |y| ≤ 2.2 m ✓",
                                                                            "→ fusion with the other sensors"])


TECH_CAMERA = [
    ("Input: every object the map knows, as a tuple", "shipyard._route_tick → follow_test.cameras_detect",
     ["objs = scene_objects()   # every 100 ms", "dets = cameras_detect(me, own_len, objs, climate, cams)"],
     "the camera model gets the full list — it never looks at pixels in the Simulated set-up", _cam1),
    ("Into the truck's frame: rotate by our heading", "follow_test._local",
     ["e, n = (lon − lon0)·111320·cos(lat0), (lat − lat0)·111320", "x = e·sin(h) + n·cos(h);  y = −e·cos(h) + n·sin(h)"],
     "Truck_auto_1 → x = 40.0 m ahead, y = 0.8 m to the left", _cam2),
    ("Inside the 90° view? Compare its angle", "follow_test._fov_detect",
     ["ang = atan2(y, x)", "if abs(ang) > hfov / 2: continue        # hfov = 90°"],
     "atan2(0.8, 40) = 1.1°  →  |1.1°| ≤ 45°  ✓", _cam3),
    ("Close enough? The gap against the range in this climate", "follow_test._fov_detect / camera_range",
     ["gap = x − own_len / 2 − its_len / 2", "rng = min(80, 0.5 · visibility)   # × 0.45 night, − rain / snow"],
     f"gap {_CGAP:.2f} m  <  range {_CRNG:.0f} m (fog, visibility {FOG.get('visibility_m')} m)  →  seen", _cam4),
    ("Hidden behind a nearer object? (occlusion)", "follow_test._fov_detect",
     ["a0, a1 = ang ∓ atan(W/2 / x)        # its angular width", "cover = overlap with nearer ones;  if cover ≥ 0.7: hidden"],
     "the van covers 100 % of the car's angle (≥ 70 %)  →  the car is NOT seen", _cam5),
    ("Type and confidence", "follow_test.camera_detect.classify",
     ["conf = clip(1 − 0.75 · gap / rng, 0.25, 0.99)", "cls = kind if conf >= 0.5 else 'object'"],
     f"1 − 0.75 × {_CGAP:.2f} / {_CRNG:.0f} = {_CCONF:.2f}  →  'truck'", _cam6),
    ("Output: one dict per detection → fusion", "follow_test._fov_detect → Follower.perceive",
     ["out.append({'id', 'label', 'gap', 'x', 'y', 'cls', 'conf', 'sensor': 'camera'})"],
     "the same format for every sensor — fusion only compares gaps", _cam7)]


# ------------------------------------------------------------------ LiDAR (simulated set-up)
_EXT_W = float((WHITEOUT.get("lidar") or {}).get("extinction_per_m") or 0.22)
_EXT_F = float((FOG.get("lidar") or {}).get("extinction_per_m") or 0.025)


def _lid1(p, y):
    _box(p, QRectF(20, y + 30, 220, 110), WHERE_COL, "Python (shipyard)", ["4× a second:", "runJavaScript(",
                                                                         "'lidarDetect({...})')"])
    _box(p, QRectF(560, y + 30, 220, 110), COL["LiDAR"], "3D sensor page", ["yard3d.html (three.js)",
                                                                           "scans every truck's LiDAR"])
    f = S.ph(2.0)
    _arrow(p, QPointF(246, y + 66), QPointF(554, y + 66), MUTED, 2, 9)
    _arrow(p, QPointF(554, y + 110), QPointF(246, y + 110), MUTED, 2, 9)
    if f < 0.5:
        S._packet(p, QPointF(246, y + 66), QPointF(554, y + 66), f * 2, WHERE_COL, "positions (JSON)")
    else:
        S._packet(p, QPointF(554, y + 110), QPointF(246, y + 110), (f - 0.5) * 2, COL["LiDAR"], "detections (JSON)")


def _lid2(p, y):
    _road(p, y + 120, y + 170, lanes=1)
    s = QPointF(90, y + 100)
    _vehicle(p, QRectF(20, y + 100, 90, 30), OURS, "")
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"])); p.drawEllipse(s, 5, 5)
    p.setPen(QPen(_c("#64748B"), 1.5)); p.setBrush(_c(OTHER)); p.drawRect(QRectF(430, y + 60, 200, 70))
    _text(p, 530, y + 92, "box of Truck_auto_1", TXT, 11, True, Qt.AlignCenter, 200)
    k = int(S.ph(2.4) * 9)
    for i in range(9):
        ang = math.radians(-14 + i * 3.6)
        end = QPointF(s.x() + 600, s.y() + 600 * math.tan(ang))
        hit = 430 if y + 60 <= s.y() + (430 - s.x()) * math.tan(ang) <= y + 130 else None
        if hit is None:
            t_g = (y + 145 - s.y()) / max(1e-6, math.tan(ang)) if ang > 0 else None
            end = QPointF(s.x() + t_g, y + 145) if t_g and t_g < 600 else end
        else:
            end = QPointF(430, s.y() + (430 - s.x()) * math.tan(ang))
        on = i == k
        p.setPen(QPen(_c(COL["LiDAR"], 0.95 if on else 0.3), 2.2 if on else 1)); p.drawLine(s, end)
        if i <= k:
            p.setPen(Qt.NoPen); p.setBrush(_c(HL if hit else "#94A3B8")); p.drawEllipse(end, 3.5, 3.5)
    _text(p, 660, y + 40, "nearest hit wins:\nground, wall or box", TXT, 11, True, w=140)


def _lid3(p, y):
    r = QRectF(70, y + 10, 400, 150)
    X, Y = _plot(p, r, lambda d: math.exp(-2 * _EXT_F * d), 0, 30, 0, 1, GREEN, xl="distance (m) →",
                 yl="chance a return survives")
    path = QPainterPath()
    for i in range(121):
        d = 30 * i / 120
        (path.moveTo if i == 0 else path.lineTo)(QPointF(X(d), Y(math.exp(-2 * _EXT_W * d))))
    p.setPen(QPen(_c(RED), 2.4)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    m = 12 * min(1.0, S.ph(3.0) * 1.4)
    for e, c in ((_EXT_F, GREEN), (_EXT_W, RED)):
        p.setPen(Qt.NoPen); p.setBrush(_c(c)); p.drawEllipse(QPointF(X(m), Y(math.exp(-2 * e * m))), 5, 5)
    _text(p, 500, y + 30, f"fog ({_EXT_F:g}/m): 12 m → {math.exp(-2 * _EXT_F * 12):.0%}", GREEN, 13, True, w=290)
    _text(p, 500, y + 60, f"whiteout ({_EXT_W:g}/m): 12 m → {math.exp(-2 * _EXT_W * 12):.2%}", RED, 13, True, w=290)
    _text(p, 500, y + 96, "each ray draws Math.random() against\nthis chance — lost rays give no point", MUTED, 11,
          w=290)


def _lid4(p, y):
    _vehicle(p, QRectF(20, y + 70, 100, 40), OURS, "our truck")
    p.setPen(QPen(_c("#64748B"), 1.5)); p.setBrush(_c(OTHER)); p.drawRect(QRectF(330, y + 50, 160, 80))
    n = int(S.ph(3.0) * 60)
    import random
    rnd = random.Random(2)
    for i in range(60):
        yy = y + 54 + rnd.uniform(0, 72)
        if i < n:
            p.setPen(Qt.NoPen); p.setBrush(_c(HL)); p.drawEllipse(QPointF(330 + rnd.uniform(-1, 2), yy), 2.6, 2.6)
    _text(p, 410, y + 150, f"acc['Truck_auto_1'].n = {n}", HL, 13, True, Qt.AlignCenter, 260)
    _dim(p, 120, 330, y + 30, "gap = 12.3 m (nearest point)")
    _text(p, 520, y + 70, "gap = √(max(0, |l| − ½W)² +\n         max(0, |f| − ½L)²)", TXT, 12, True, w=270)


def _lid5(p, y):
    for i, (n, ok, lab) in enumerate(((60, True, "Truck_auto_1: 60 points"), (2, False, "Cone_2: 2 points"))):
        yy = y + 30 + i * 70
        _text(p, 30, yy + 18, lab, TXT, 13, True, w=220)
        p.setPen(Qt.NoPen); p.setBrush(_c("#1F2937")); p.drawRoundedRect(QRectF(260, yy, 300, 26), 5, 5)
        w = 300 * min(1.0, n / 60.0) * min(1.0, S.ph(2.5) * 1.6)
        p.setBrush(_c(GREEN if ok else RED)); p.drawRoundedRect(QRectF(260, yy, max(6, w), 26), 5, 5)
        _mark(p, 600, yy + 13, ok, 12)
        _text(p, 620, yy + 18, "detected" if ok else "too few", GREEN if ok else RED, 13, True, w=150)
    p.setPen(QPen(_c(AMBER), 2, Qt.DashLine)); x = 260 + 300 * 4 / 60
    p.drawLine(QPointF(x, y + 20), QPointF(x, y + 140)); _text(p, x, y + 158, "min_points = 4", AMBER, 11, True,
                                                               Qt.AlignCenter, 120)


def _lid6(p, y):
    _box(p, QRectF(20, y + 20, 330, 120), COL["LiDAR"], "result per truck (JSON)",
         ["{id: 'Truck_auto_1', points: 60,", " gap: 12.3, x: 12.9, y: 0.4,", " lat: …, lng: …}"], mono=True)
    _flow_arrow(p, QPointF(356, y + 80), QPointF(440, y + 80), COL["LiDAR"])
    _box(p, QRectF(446, y + 20, 340, 120), WHERE_COL, "Python: _on_lidar_detect → _route_tick",
         ["kept 0.6 s (HOLD_S) — new data ~4× a second", "placed along our route, |y| ≤ 2.2 m",
          "→ Follower.perceive (sensor 'LiDAR')"])


TECH_LIDAR = [
    ("Python asks the 3D page ~4 times a second", "shipyard · page().runJavaScript",
     ["page.runJavaScript(f'lidarDetect({json.dumps(opt)})', self._on_lidar_detect)"],
     "asynchronous: the scan runs in JavaScript, the answer comes back as JSON", _lid1),
    ("Every ray of the LiDAR pattern is traced", "yard3d.html · scanTruck (JavaScript)",
     ["for (c of columns) for (r of rows) {  ray = beamDir(c, r);", "  t = rayBox(S, ray, box);  if (t < best) { best = t; hit = box } }"],
     "point = sensor + best × direction (+ range noise); the own cab is skipped", _lid2),
    ("The weather removes returns (extinction)", "yard3d.html · scanTruck",
     ["if (ext > 0 && Math.random() > Math.exp(-2 * ext * best)) { nLost++; continue }"],
     f"P(survive) = e^(−2 · ext · r): fog 12 m {math.exp(-2 * _EXT_F * 12):.0%} · whiteout 12 m "
     f"{math.exp(-2 * _EXT_W * 12):.2%}", _lid3),
    ("Points are counted on the object they hit", "yard3d.html · scanTruck",
     ["acc[hit.id].n++", "acc[hit.id].gap = Math.min(acc[hit.id].gap, gapToBody(point))"],
     "the gap is from the nearest point to our truck's body (its box)", _lid4),
    ("Enough points = a detection", "yard3d.html · lidarDetect",
     ["if (a.n < minPts || a.gap > reportM) return;   // minPts = config/lidar.json (4)", "dets.push({id, label, points, gap, x, y, lat, lng})"],
     "60 points ≥ 4 → detected;  2 points < 4 → not", _lid5),
    ("Back in Python → fusion", "shipyard._on_lidar_detect / _route_tick",
     ["dets = [d for d in res[truck]['dets'] if age < HOLD_S]   # 0.6 s", "lane = self._on_trail(trail, s, horizon, dets)"],
     "the LiDAR list goes to Follower.perceive like the camera's", _lid6)]


# ------------------------------------------------------------------ RADAR (simulated set-up)
_RM = ft.radar_margin_db(60.0, 20.0, CLEAR)
_RPD = ft.radar_pd(_RM)
_RRAIN = ft.radar_losses_db(RAIN, 60.0)


def _rad1(p, y):
    o = QPointF(110, y + 90)
    p.save(); p.setClipRect(QRectF(0, y, 800, 180))
    S._rings(p, o, COL["radar"], 600, n=4, period=2.2, a0=-30, span=60, width=2)
    p.restore()
    _vehicle(p, QRectF(30, o.y() - 12, 80, 24), OURS, "")
    _vehicle(p, QRectF(330, o.y() - 14, 120, 28), OTHER, "truck")
    _vehicle(p, QRectF(560, o.y() - 12, 70, 24), OTHER, "car (behind it)")
    _text(p, 600, y + 150, "radar: still a candidate (occlusion only at 95 %)", GREEN, 11, True, Qt.AlignCenter, 360)


def _rad2(p, y):
    for i, (k, v) in enumerate((("truck", 20), ("van", 13), ("car", 10), ("object", 3), ("pedestrian", -5))):
        yy = y + 8 + i * 30
        _text(p, 40, yy + 16, k, TXT, 12, True, w=100)
        w = (v + 10) * 12 * min(1.0, S._appear(i, 0.2))
        p.setPen(Qt.NoPen); p.setBrush(_c(COL["radar"], 0.85)); p.drawRoundedRect(QRectF(150, yy, w, 20), 4, 4)
        _text(p, 160 + w, yy + 15, f"{v:+d} dBsm", COL["radar"], 11, True, w=80)
    _text(p, 560, y + 50, "radar cross-section:\nhow strongly it\nreflects (by kind)", MUTED, 12, w=220)


def _rad3(p, y):
    r = QRectF(70, y + 10, 420, 150)
    f = lambda d: ft.radar_margin_db(d, 20.0, CLEAR)                               # noqa: E731
    fr = lambda d: ft.radar_margin_db(d, 20.0, RAIN)                               # noqa: E731
    X, Y = _plot(p, r, f, 10, 200, -20, 30, COL["radar"], mark=60 * min(1.0, S.ph(3.0) * 1.4) + 10 * (1 - min(1.0, S.ph(3.0) * 1.4)),
                 xl="distance (m) →", yl="margin (dB)", hline=0, hcol=AMBER)
    path = QPainterPath()
    for i in range(121):
        d = 10 + 190 * i / 120
        (path.moveTo if i == 0 else path.lineTo)(QPointF(X(d), Y(fr(d))))
    p.setPen(QPen(_c("#7DD3FC"), 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    _text(p, 520, y + 30, f"clear, 60 m: {_RM:+.1f} dB", COL["radar"], 13, True, w=270)
    _text(p, 520, y + 58, f"heavy rain: −{_RRAIN:.1f} dB more", "#7DD3FC", 13, True, w=270)
    _text(p, 520, y + 92, "0 dB = detected in half\nof the scans (dashed line)", AMBER, 11, True, w=270)


def _rad4(p, y):
    r = QRectF(70, y + 10, 400, 150)
    _plot(p, r, lambda m: 1 / (1 + math.exp(-m / ft.FRONT_RADAR["pd_slope_db"])), -10, 15, 0, 1, COL["radar"],
          mark=_RM * min(1.0, S.ph(3.0) * 1.3), xl="margin (dB) →", yl="Pd (per scan)", hline=0.5, hcol=AMBER)
    _text(p, 520, y + 40, f"margin {_RM:+.1f} dB → Pd {_RPD:.1%}", COL["radar"], 14, True, w=270)
    _text(p, 520, y + 80, "an S-curve: weak targets\nflicker, strong ones always", MUTED, 12, w=270)


def _rad5(p, y):
    import random
    rnd = random.Random(5)
    hits = [rnd.random() < 0.7 for _ in range(14)]
    n = int(S.ph(5.0) * 15)
    for i in range(min(n, 14)):
        x = 50 + i * 50
        h = hits[i]
        _mark(p, x, y + 40, h, 12)
        last3 = hits[max(0, i - 2):i + 1]
        conf = sum(last3) >= 2
        p.setPen(Qt.NoPen); p.setBrush(_c(GREEN if conf else "#334155")); p.drawRoundedRect(QRectF(x - 20, y + 70, 40, 18), 4, 4)
        _text(p, x, y + 100, "scan", MUTED, 9, False, Qt.AlignCenter, 40)
    _text(p, 30, y + 130, "row 1: this scan hit?  (random() < Pd)      row 2: confirmed (green) = 2 of the last 3 hit",
          TXT, 12, True, w=760)


def _rad6(p, y):
    r = QRectF(40, y + 10, 330, 140)
    sig = 0.08 * (1 + 10 ** (-_RM / 10))
    _plot(p, r, lambda x: math.exp(-0.5 * (x / max(0.02, sig * 3)) ** 2), -1, 1, 0, 1.1, COL["radar"],
          xl="range error (m) →", yl="noise (Gauss)")
    _text(p, 205, r.bottom() + 30, f"σ = 0.08 × (1 + 10^(−margin/10)) = {sig:.2f} m", TXT, 11, True, Qt.AlignCenter, 330)
    _vehicle(p, QRectF(420, y + 70, 90, 30), OURS, "40 km/h")
    _vehicle(p, QRectF(620, y + 70, 140, 30), OTHER, "20 km/h")
    _arrow(p, QPointF(430, y + 55), QPointF(510, y + 55), TXT, 2, 8); _arrow(p, QPointF(630, y + 55), QPointF(670, y + 55),
                                                                               TXT, 2, 8)
    _text(p, 590, y + 140, "v_rel = 5.6 − 11.1 = −5.6 m/s (closing)", COL["radar"], 12, True, Qt.AlignCenter, 380)


TECH_RADAR = [
    ("Candidates: inside the 60° beam, almost no occlusion", "follow_test.radar_detect → _fov_detect",
     ["cand = _fov_detect(me, L, objs, 400.0, 60, lambda ob, gap: 1.0, 0.95, 'radar', …)"],
     "the beam passes under / past the vehicle ahead — only 95 % cover hides", _rad1),
    ("How strongly each object reflects (radar cross-section)", "follow_test.radar_rcs_db",
     ["rcs = radar['rcs_dbsm'][kind]      # truck 20, car 10, pedestrian −5 dBsm"],
     "a parked object (never moved) loses 6 dB more (stationary-clutter filter)", _rad2),
    ("Signal margin from the radar equation + weather", "follow_test.radar_margin_db / radar_losses_db",
     ["m = (rcs − 20) − 40·log10(r / 120) − losses_db(climate, r)", "rain: γ = 1.1 · R^0.72 dB/km (ITU-R P.838), two-way"],
     f"truck at 60 m, clear: (20 − 20) − 40·log10(60/120) = {_RM:+.1f} dB", _rad3),
    ("Margin → detection probability per scan", "follow_test.radar_pd",
     ["pd = 1 / (1 + exp(−margin / 1.6))"], f"{_RM:+.1f} dB → Pd = {_RPD:.1%}", _rad4),
    ("Each scan draws; a small tracker confirms", "follow_test.radar_detect(track=…)",
     ["hit = rnd.random() < pd;   st['hits'] = (st['hits'] + [hit])[-3:]", "confirmed = sum(st['hits']) >= 2  or coasting ≤ 0.35 s"],
     "weak / far targets flicker and are confirmed late — as with a real radar tracker", _rad5),
    ("Distance with noise, speed from Doppler", "follow_test.radar_detect",
     ["st['gap'] = gap + rnd.gauss(0, 0.08 · (1 + 10 ** (−margin / 10)))", "v_rel = ob.speed · cos(Δheading) − ego_v"],
     "the speed is known at once — the camera / LiDAR need two looks", _rad6)]


# ------------------------------------------------------------------ V2V
def _v1(p, y):
    X = lambda ms: 60 + ms * 2.2                                                    # noqa: E731
    p.setPen(QPen(_c(MUTED), 1.2)); p.drawLine(QPointF(X(0), y + 90), QPointF(X(310), y + 90))
    for ms in range(0, 301, 100):
        S._packet(p, QPointF(X(ms), y + 70), QPointF(X(ms), y + 70), 0, COL["V2V"])
        _text(p, X(ms), y + 110, f"{ms} ms", MUTED, 10, False, Qt.AlignCenter, 60)
    f = S.ph(3.0)
    if f > 0.5:
        S._packet(p, QPointF(X(137), y + 40), QPointF(X(137), y + 40), 0, RED)
        _text(p, X(137), y + 22, "BRAKE ALERT: at once", RED, 11, True, Qt.AlignCenter, 160)
    _text(p, 60, y + 140, "state: every 100 ms (slower when the channel is busy) · alert: the moment it brakes ≤ −4 m/s²",
          TXT, 12, True, w=720)


def _v2(p, y):
    c = QPointF(200, y + 85)
    p.setPen(QPen(_c(MUTED), 1, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, 70, 70)
    _text(p, 200, y + 172, "σ = 2.5 m (NavIC / GPS)", MUTED, 10, False, Qt.AlignCenter, 200)
    path = QPainterPath(c)
    import random
    rnd = random.Random(3)
    ex = ey = 0.0
    pts = []
    for i in range(60):
        k = math.exp(-0.1 / 20.0)
        ex = ex * k + rnd.gauss(0, 2.5 * math.sqrt(1 - k * k)) * 6
        ey = ey * k + rnd.gauss(0, 2.5 * math.sqrt(1 - k * k)) * 6
        pts.append(QPointF(c.x() + ex * 4, c.y() + ey * 4))
    n = int(S.ph(4.0) * 60)
    for pt in pts[:n]:
        path.lineTo(pt)
    p.setPen(QPen(_c(AMBER), 1.6)); p.drawPath(path)
    p.setPen(Qt.NoPen); p.setBrush(_c(OURS)); p.drawEllipse(c, 5, 5)
    if n:
        p.setBrush(_c(AMBER)); p.drawEllipse(pts[n - 1], 5, 5)
    _text(p, 330, y + 50, "true position (blue) · reported position (amber)\ndrifts slowly — correlated over ~20 s, "
                          "as real GNSS errors are", TXT, 12, True, w=450)


def _v3(p, y):
    a, b = QPointF(80, y + 150), QPointF(700, y + 30)
    poly = [QPointF(330, y + 60), QPointF(450, y + 60), QPointF(450, y + 130), QPointF(330, y + 130)]
    p.setPen(QPen(_c("#64748B"), 1.6)); p.setBrush(_c("#334155")); p.drawPolygon(QPolygonF(poly))
    _text(p, 390, y + 100, "building", MUTED, 11, True, Qt.AlignCenter, 100)
    p.setPen(QPen(_c(RED), 2, Qt.DashLine)); p.drawLine(a, b)
    k = int(S.ph(3.0) * 4)
    for i in range(4):
        u, v = poly[i], poly[(i + 1) % 4]
        cross = i in (1, 3)
        p.setPen(QPen(_c((RED if cross else GREEN) if i <= k else "#475569"), 3.2)); p.drawLine(u, v)
    _vehicle(p, QRectF(50, y + 140, 60, 20), OURS, "")
    _vehicle(p, QRectF(670, y + 20, 60, 20), OTHER, "")
    _text(p, 560, y + 130, "each building edge: do the line and the edge\ncross? (orientation signs differ on both)",
          TXT, 11, True, w=240)


def _v4(p, y):
    x = 30
    parts = [("base 1 %", 0.01, MUTED), ("setup 5 %", 0.05, AMBER), ("rain 3 %", 0.03, "#7DD3FC"),
             ("busy 0–15 %", 0.04, "#FB923C")]
    for t, v, c in parts:
        w = v * 3000
        p.setPen(Qt.NoPen); p.setBrush(_c(c, 0.85)); p.drawRect(QRectF(x, y + 30, w, 26))
        _text(p, x + w / 2, y + 76, t, c, 10, True, Qt.AlignCenter, 110)
        x += w
    total = sum(v for _t, v, _c_ in parts)
    _text(p, x + 10, y + 48, f"p_loss = {total:.0%}", RED, 14, True, w=200)
    r = S.ph(1.2)
    import random
    val = random.Random(int(S.T / 1.2)).random()
    _text(p, 40, y + 120, f"random() = {val:.3f}  →  " + ("LOST ✕" if val < total else "delivered ✓"),
          RED if val < total else GREEN, 16, True, w=500)
    _text(p, 40, y + 150, "(a new draw for every message and every receiver)", MUTED, 11, w=500)
    del r


def _v5(p, y):
    _text(p, 30, y + 14, "self.pending  (arrival time, receiver, message)", WHERE_COL, 11, True, w=500)
    now = 12.30 + S.ph(4.0) * 0.06
    items = [(12.318, "Truck_auto_1"), (12.326, "Truck_auto_7"), (12.341, "Truck_auto_1"), (12.352, "Car_3")]
    for i, (at, tx) in enumerate(items):
        x = 40 + i * 150
        done = now >= at
        _box(p, QRectF(x, y + 30, 130, 60), GREEN if done else MUTED, f"t = {at:.3f}", [tx + (" ✓" if done else "")])
    _text(p, 400, y + 130, f"now = {now:.3f} s  →  delivered when now ≥ arrival time;  inbox keeps the latest per "
                           "sender", HL, 12, True, Qt.AlignCenter, 760)


def _v6(p, y):
    _road(p, y + 60, y + 130)
    p.setPen(Qt.NoPen); p.setBrush(_c(GREEN, 0.15)); p.drawRect(QRectF(130, y + 70, 660, 50))
    _vehicle(p, QRectF(20, y + 82, 100, 26), OURS, "our truck")
    S._packet(p, QPointF(500, y + 92), QPointF(500, y + 92), 0, COL["V2V"])
    _text(p, 500, y + 60, "reported position", COL["V2V"], 10, True, Qt.AlignCenter, 140)
    _arrow(p, QPointF(780, y + 75), QPointF(780, y + 115), AMBER, 1.4, 6, both=True)
    _text(p, 680, y + 150, "lane ± (2.2 + 1.5 × 2.5) = ± 5.95 m", AMBER, 11, True, Qt.AlignCenter, 260)
    _dim(p, 120, 490, y + 150, "gap = 30.0 − 3.5 − 8.25 = 18.25 m")


TECH_V2V = [
    ("When a vehicle sends", "v2v.Channel.step",
     ["edge = braking and not prev_brake[tx]", "if not edge and now − last < 1 / rate: continue     # rate = 10 Hz"],
     "state 10× a second + a BRAKE ALERT immediately on a hard brake", _v1),
    ("The reported position has a GNSS error", "v2v.Channel._gnss",
     ["k = exp(−dt / 20)", "e = e·k + gauss(0, σ·√(1 − k²))      # σ = 2.5 m"],
     "a slowly drifting error (random walk) — not a new random jump every message", _v2),
    ("Line of sight: does a building cut the line?", "v2v.Channel.blocked / _cross",
     ["for each building edge (u, v) near the line:", "    if o(a,b,u)·o(a,b,v) < 0 and o(u,v,a)·o(u,v,b) < 0: return True"],
     "blocked → reach 150 m instead of 450 m, and +60 % loss", _v3),
    ("Lost or delivered? One random draw", "v2v.Channel.step",
     ["p_loss = base + loss_pct + rain + busy (+0.6 blocked) + edge fade", "if d > reach or rng.random() < p_loss: lost"],
     "no radio waves — the channel decides with a probability", _v4),
    ("Delay: a queue sorted by arrival time", "v2v.Channel.step / inbox",
     ["delay = max(0.004, gauss(20, 8) / 1000)", "pending.append((now + delay, rx, msg))"],
     "delivered when now ≥ arrival time; older than delay + 0.3 s = not used", _v5),
    ("The receiver: in my lane, ahead, my way? → a detection", "shipyard._ctest_v2v_dets",
     ["x, off = place_on_route(msg.lat, msg.lon)", "if x > 0 and abs(off) <= 2.2 + 1.5·σ and Δheading ≤ 35°: dets.append(gap…)"],
     "gap = x − our length/2 − its length/2 = 30.0 − 3.5 − 8.25 = 18.25 m", _v6)]


# ------------------------------------------------------------------ FUSION
def _f1(p, y):
    for i, (k, t) in enumerate((("LiDAR", "{'id': 'T1', 'gap': 12.4}"), ("camera", "[]   (fog)"),
                                ("radar", "{'id': 'T1', 'gap': 12.6, 'v_rel': −3.0}"), ("V2V", "{'id': 'T1', 'gap': 13.5}"))):
        yy = y + 6 + i * 36
        p.setPen(QPen(_c(COL[k]), 1.4)); p.setBrush(_c(COL[k], 0.1)); p.drawRoundedRect(QRectF(20, yy, 470, 28), 6, 6)
        _mono(p, 30, yy + 18, f"{k:7s} {t}", TXT, 12)
        _flow_arrow(p, QPointF(494, yy + 14), QPointF(580, y + 80), COL[k], packet=False)
    _box(p, QRectF(584, y + 50, 200, 64), "#F472B6", "perceive()", ["4 lists in"])


def _f2(p, y):
    _road(p, y + 40, y + 150)
    p.setPen(Qt.NoPen); p.setBrush(_c(GREEN, 0.14)); p.drawRect(QRectF(120, y + 66, 670, 58))
    _vehicle(p, QRectF(20, y + 82, 100, 26), OURS, "")
    _text(p, 700, y + 62, "|y| ≤ 2.2 m", GREEN, 11, True, w=100)
    for x, yy, ok in ((420, y + 95, True), (560, y + 52, False)):
        p.setPen(Qt.NoPen); p.setBrush(_c(GREEN if ok else RED)); p.drawEllipse(QPointF(x, yy), 7, 7)
        _mark(p, x, yy - 18, ok, 8)
    _text(p, 590, y + 46, "parked car 4 m left → dropped", RED, 11, True, w=220)


def _f3(p, y):
    _box(p, QRectF(30, y + 10, 420, 130), "#F472B6", "best['T1']  (merged by id)",
         ["'gap': 12.4,", "'by': {'LiDAR': 12.4, 'radar': 12.6, 'V2V': 13.5},", "'sensors': {'LiDAR', 'radar', 'V2V'},",
          "'v_rel': −3.0"], mono=True)
    _text(p, 480, y + 50, "the same id from several sensors\n= one object; each sensor's own\ndistance is kept "
                          "(shown on the card)", TXT, 12, True, w=300)


def _f4(p, y):
    vals = [("T1", 12.4, True), ("Cone_2", 31.0, False), ("Car_9", 58.0, False)]
    for i, (n, g, best) in enumerate(vals):
        x = 60 + g * 11
        p.setPen(Qt.NoPen); p.setBrush(_c(GREEN if best else MUTED)); p.drawEllipse(QPointF(x, y + 70), 9 if best else 6,
                                                                                     9 if best else 6)
        _text(p, x, y + 100, f"{n}\n{g} m", GREEN if best else MUTED, 11, True, Qt.AlignCenter, 90)
    _vehicle(p, QRectF(10, y + 58, 50, 24), OURS, "")
    S._pulse(p, QRectF(60 + 12.4 * 11 - 14, y + 56, 28, 28), GREEN)
    _text(p, 520, y + 140, "target = min(best.values(), key=gap)", HL, 13, True, Qt.AlignCenter, 400)


def _f5(p, y):
    _box(p, QRectF(30, y + 10, 350, 130), COL["radar"], "radar / V2V give v_rel", ["v_lead = v + v_rel",
                                                                                  "= 11.1 − 3.0 = 8.1 m/s"])
    _box(p, QRectF(420, y + 10, 360, 130), COL["LiDAR"], "only camera / LiDAR", ["closing = (gap_prev − gap) / Δt",
                                                                                "v_lead = 0.6·old + 0.4·(v − closing)",
                                                                                "(only when the SAME sensors measure)"])


TECH_FUSION = [
    ("Four lists in — only switched-on sensors", "follow_test.Follower.perceive",
     ["for sensor, dets in (('LiDAR', lidar), ('camera', cam), ('radar', rad), ('V2V', v2v), …):",
      "    if sensor not in self.sensors: continue"], "V2V counts only in 'brakes on it' mode", _f1),
    ("Lane filter", "follow_test.Follower._in_lane", ["return d['x'] > 0 and abs(d['y']) <= CORRIDOR_HALF_M   # 2.2 m"],
     "objects beside our path ahead do not count", _f2),
    ("Merge by object id", "follow_test.Follower.perceive",
     ["b = best.get(d['id']);  by[sensor] = min(d['gap'], by.get(sensor, 1e9))", "best[id]['gap'] = min(b['gap'], d['gap'])"],
     "nearest distance of any sensor wins: 12.4 m (LiDAR)", _f3),
    ("Target = the nearest", "follow_test.Follower.perceive", ["near = min(best.values(), key=lambda d: d['gap'])"],
     "a target is kept 0.6 s (HOLD_S) after its last detection", _f4),
    ("Its speed", "follow_test.Follower.perceive",
     ["if v_rel is not None: v_lead = max(0, self.v + v_rel)", "elif same sensors: v_lead = 0.6·prev + 0.4·(v − closing)"],
     "radar / V2V: at once · camera / LiDAR: from two looks", _f5)]


# ------------------------------------------------------------------ BRAKING
_BV = 40 / 3.6
_BTTC = 25.0 / _BV
_BAREQ = _BV * _BV / (2 * (25.0 - ft.STOP_GAP_M))


def _b1(p, y):
    _road(p, y + 50, y + 110, lanes=1)
    _vehicle(p, QRectF(20, y + 64, 90, 30), OURS, "40 km/h")
    _vehicle(p, QRectF(500, y + 62, 140, 34), OTHER, "stopped")
    _dim(p, 110, 500, y + 140, "d = 25 m  ·  closing = 11.1 − 0 = 11.1 m/s")
    _text(p, 400, y + 30, "d = gap − closing × (time since the detection)", TXT, 12, True, Qt.AlignCenter, 500)


def _b2(p, y):
    x0, x1 = 60, 740
    Xs = lambda t: x0 + (x1 - x0) * min(6, t) / 6                                      # noqa: E731
    for a, b, c, lab in ((0, ft.TTC_CRIT_S, RED, "AEB"), (ft.TTC_CRIT_S, ft.TTC_WARN_S, AMBER, "warning"),
                         (ft.TTC_WARN_S, 6, GREEN, "ok")):
        p.setPen(Qt.NoPen); p.setBrush(_c(c, 0.8)); p.drawRect(QRectF(Xs(a), y + 60, Xs(b) - Xs(a), 26))
        _text(p, (Xs(a) + Xs(b)) / 2, y + 78, lab, "#0B1220", 12, True, Qt.AlignCenter, 120)
    m = Xs(6 - (6 - _BTTC) * min(1.0, S.ph(3.0) * 1.4))
    p.setBrush(_c("#FFFFFF")); p.drawPolygon(QPolygonF([QPointF(m, y + 58), QPointF(m - 8, y + 44), QPointF(m + 8, y + 44)]))
    _text(p, m, y + 30, f"TTC {_BTTC:.2f} s", "#FFFFFF", 12, True, Qt.AlignCenter, 120)
    for t in (0, ft.TTC_CRIT_S, ft.TTC_WARN_S, 6):
        _text(p, Xs(t), y + 106, f"{t:g} s", MUTED, 10, False, Qt.AlignCenter, 50)


def _b3(p, y):
    r = QRectF(70, y + 10, 400, 150)
    _plot(p, r, lambda d: _BV * _BV / (2 * max(0.5, d - ft.STOP_GAP_M)), 6, 60, 0, 10, RED,
          mark=60 - (60 - 25) * min(1.0, S.ph(3.0) * 1.4), xl="distance (m) →", yl="needed decel. (m/s²)",
          hline=ft.A_COMFORT, hcol=AMBER)
    _text(p, 500, y + 40, f"a_req = v² / (2·(d − 3))\n= 11.1² / 44 = {_BAREQ:.2f} m/s²", TXT, 13, True, w=290)
    _text(p, 500, y + 100, f"above {ft.A_COMFORT:g} (dashed): brake hard", AMBER, 12, True, w=290)


def _b4(p, y):
    rows = [(f"TTC < {ft.TTC_CRIT_S:g} s ?", f"a = −a_full ({ft.A_FULL:g} × grip)  FULL BRAKE (AEB)", RED, False),
            (f"a_req ≥ {ft.A_COMFORT:g} ?", f"a = −min(a_full, 1.15 × a_req) = −{min(ft.A_FULL, 1.15 * _BAREQ):.2f}",
             AMBER, True),
            ("otherwise", "follow: want = v_lead + 0.35·(d − set gap)", GREEN, False)]
    for i, (q, a, c, chosen) in enumerate(rows):
        yy = y + 10 + i * 50
        _box(p, QRectF(30, yy, 170, 40), c, q)
        _arrow(p, QPointF(204, yy + 20), QPointF(250, yy + 20), c, 2, 8)
        _box(p, QRectF(254, yy, 520, 40), c, a)
        if chosen:
            S._pulse(p, QRectF(254, yy, 520, 40), HL)


def _b5(p, y):
    r = QRectF(70, y + 10, 420, 150)
    a = min(ft.A_FULL, 1.15 * _BAREQ)
    X, Y = _plot(p, r, lambda t: max(0.0, _BV - a * t), 0, 5, 0, 12, OURS, mark=min(5.0, S.T % 5.0),
                 xl="time (s) →", yl="speed (m/s)")
    _text(p, 520, y + 40, "every 0.1 s:\nv = clip(v + a·dt, 0, v_max)", TXT, 13, True, w=270)
    _text(p, 520, y + 100, f"stops after {_BV / a:.1f} s", GREEN, 13, True, w=270)


TECH_BRAKE = [
    ("The target's distance now", "follow_test.Follower.step",
     ["d = tg['gap'] − (self.v − v_lead) · max(0, t − tg['t'])", "closing = self.v − v_lead"],
     "between detections the gap is advanced by the closing speed", _b1),
    ("Time to collision", "follow_test.Follower._update_ttc", ["ttc = d / closing if closing > 0.3 else None"],
     f"25 / 11.1 = {_BTTC:.2f} s  →  below {ft.TTC_WARN_S:g} s: a warning", _b2),
    ("Needed deceleration to stop 3 m short", "follow_test.Follower.step",
     ["a_req = closing ** 2 / (2 · (d − STOP_GAP_M))      # STOP_GAP_M = 3"], f"{_BAREQ:.2f} m/s²", _b3),
    ("Decide: AEB, brake or follow", "follow_test.Follower.step",
     ["if ttc < TTC_CRIT_S: a = −a_full", "elif a_req >= A_COMFORT: a = −min(a_full, a_req · 1.15)   else: follow"],
     f"TTC {_BTTC:.2f} s is not < 1.5 → no AEB;  a_req {_BAREQ:.2f} ≥ 2 → brake {min(ft.A_FULL, 1.15 * _BAREQ):.2f} m/s²", _b4),
    ("New speed every 100 ms", "follow_test.Follower.step",
     ["self.v = max(0, min(self.v_max, self.v + a · dt))      # dt = 0.1 s"],
     "the route position then moves: s += v · dt", _b5)]


# ------------------------------------------------------------------ CLIMATE
def _climate_rows():
    rows = []
    clear = (ft.camera_range(None), ft.lidar_range(None), ft.radar_range(None))
    for cid in ("clear", "night", "heavy_rain", "fog", "dense_fog", "whiteout_fog"):
        c = _clim(cid, None)
        if c is None:
            continue
        rows.append((str(c.get("label") or cid).split(" (")[0], ft.camera_range(c) / clear[0],
                     ft.lidar_range(c) / clear[1], ft.radar_range(c) / clear[2]))
    return rows


def _cl(p, y):
    p.save(); p.translate(40, y); p.scale(0.9, 0.62); _d_climate(p, _climate_rows()); p.restore()


TECH_CLIMATE = [
    ("One climate record → every sensor model", "config/climates.json → follow_test / yard3d.html",
     ["camera_range(c) · lidar_range(c) / exp(−2·ext·r) · radar_losses_db(c, r) · road_grip(c)"],
     "the bars: each sensor's range in each climate, as a share of clear weather", _cl)]


# ------------------------------------------------------------------ register
def register(decks):
    decks["tech_camera"] = _deck(TECH_CAMERA)
    decks["tech_lidar"] = _deck(TECH_LIDAR)
    decks["tech_radar"] = _deck(TECH_RADAR)
    decks["tech_v2v"] = _deck(TECH_V2V)
    decks["tech_fusion"] = _deck(TECH_FUSION)
    decks["tech_brake"] = _deck(TECH_BRAKE)
    decks["tech_climate"] = _deck(TECH_CLIMATE)
    # the real-world decks / the others: their overview picture with the code of each step
    W = {
        "camera_real": [
            ("yard3d.html frontCamShot → real_camera.decode_jpeg", ["img = decode_jpeg(b64decode(shot['jpeg']))   # numpy H×W×3"],
             "only pixels + calibration (fx, fy, camera height, pitch) — no object list"),
            ("real_camera.road_palette", ["road = colours of the bottom rows;  haze = colour at the top",
                                          "is_road(px) = distance(px, line road↔haze) ≤ 0.075"], "far road fades to the haze colour"),
            ("real_camera.detect", ["for u in range(0, W, 2):  scan v from the bottom up",
                                    "    first pixel off the road that rises ≥ 0.8 m = base row"], "lane markings are flat → ignored"),
            ("real_camera.detect", ["angle = atan((v_base − v_horizon) / fy)", "d = cam_height / tan(angle)"],
             "2.4 m / tan(9.2°) = 14.8 m"),
            ("real_camera.detect → real_sensors.Tracker('C')", ["objs = group neighbouring columns with similar d",
                                                               "tracks = tracker_C.update(t, objs)   # 2 of 3 pictures"],
             "width 2.5 m → 'truck';  contrast → confidence (≥ 0.42)")],
        "lidar_real": [
            ("yard3d.html lidarDetect(opt.cloud) → real_sensors.lidar_points", ["pts = lidar_points(me, res['pos'], res['cloud'])"],
             "(east, north, height) → (forward, left, height); nothing says what a point hit"),
            ("real_sensors.weather_filter", ["voxel 0.2 m;  within 12 m keep a point only with 2–6 neighbours"],
             "sparse fog / rain returns are dropped; the map's buildings / poles are removed on the page"),
            ("real_sensors.lidar_clusters", ["cells[floor(f/0.6), floor(l/0.6)].append(p)",
                                             "flood-fill the 8 neighbour cells → one cluster (≥ 5 points)"], "0.6 m grid"),
            ("real_sensors.lidar_clusters", ["inside = [p for p in cluster if abs(p.l) <= half_w + 0.3]",
                                             "gap = min(p.f for p in inside) − L / 2"], "the pole beside the corridor does not count"),
            ("real_sensors.Tracker('L') / match_truth", ["tracks = tracker_L.update(t, clusters)   # 2 of 3, coast 0.6 s",
                                                         "name = match_truth(f, l, scene)   # reports only"], "L4 → 'Truck_auto_1'")],
        "radar_real": [
            ("real_sensors.radar_scan", ["for az in range(−30, 31):   # 1° beams", "    t = _ray_box(origin, beam, outline)   # first hit"],
             "61 beams; a 2nd echo only under a high truck"),
            ("real_sensors.radar_scan", ["snr = 10 ** ((13 + margin) / 10) · expovariate(1)   # Swerling",
                                         "keep if 10·log10(snr) ≥ 13 (+4 if standing)        # CFAR"], "+ Poisson rain clutter"),
            ("real_sensors.radar_scan", ["pts.append(r = t + noise, az = az + gauss(0, 0.6), doppler = radial speed)"],
             "Doppler = relative speed along the beam"),
            ("real_sensors.radar_clusters", ["same group if within 2 m and |Δdoppler| < 1.5 m/s",
                                             "a single weak standing echo → dropped"], "points → objects"),
            ("real_sensors.Tracker('R', 3 of 4, static_age 8)", ["tracks = tracker_R.update(t, objs)"],
             "standing objects need 8 updates (clutter)")],
        "fusion_real": [
            ("real_sensors.Tracker × 3", ["camera C (2/3) · LiDAR L (2/3) · radar R (3/4)"], "tracks, no names"),
            ("shipyard._real_detect", ["standing camera-only object → needs LiDAR / radar to agree"], "plausibility"),
            ("Follower.perceive", ["target = nearest track in the lane (its edge within our width + 0.3 m)"],
             "unknown objects are braked for too")],
        "v2v_v2n": [
            ("v2v.LINKS['v2n']", ["{'delay_ms': 90, 'jitter_ms': 40, 'base_loss': 0.03, 'blocking': False}"], "up to the tower"),
            ("v2v.Channel.step", ["delay = gauss(90, 40) + extra_delay(load)"], "through the network, ~90 ms"),
            ("v2v.Channel.step", ["blocked = False  →  reach 3000 m"], "PC5 ~20 ms vs cellular ~90 ms")],
        "flow": [
            ("shipyard._route_tick (QTimer, 100 ms)", ["objs = scene_objects();  move other vehicles / stop & go"], ""),
            ("follow_test / yard3d.html / v2v", ["dets = {sensor: detect(...)} for the switched-on sensors"], ""),
            ("follow_test.Follower.perceive", ["target = nearest in lane (all sensors)"], ""),
            ("follow_test.Follower.step", ["v = speed from TTC / a_req / gap"], ""),
            ("shipyard._route_tick", ["if true_gap <= 0.2 and v > 0.05: _ctest_record_collision(...)"], "")],
        "collision": [
            ("shipyard._route_tick", ["near = min(truth_in_lane, key=gap)", "if near.gap <= 0.2 and v > 0.05: collision"],
             "the truth uses the real positions — never the sensors"),
            ("shipyard._ctest_record_collision → report", ["reason = climate / hidden / too late / setup (from the facts)"],
             "")],
    }
    for name, codes in W.items():
        if name in decks:
            decks["tech_" + name] = _wrap(decks[name], codes)
