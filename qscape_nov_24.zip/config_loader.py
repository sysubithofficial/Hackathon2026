"""
config_loader.py

Builds a whole shipyard from the configuration files downloaded from the CC
portal (CSV / XLSX) -- see load_site(). The result has the structure the map
code uses (mapParameter / parkingMap / dockDoor / lot / gate / rovers).

Two kinds of files:

* tables with a two-row header (dock doors, parking slots), e.g.

    DockDoorName | DockDoorId | ... | centroid_position          | bottom_left_corner_position | ...
                 |            |     | longitude | latitude | Alt | longitude | latitude | Alt     | ...

* KEY,VALUE,DESC lists (map parameters, gates, lots, rovers), e.g.

    rsu_location_1,"42.7108970142084, -84.64269103679612",RSU1 location
"""

import csv
import glob
import math
import os
import re
from datetime import datetime

import pandas as pd


# ---------------------------------------------------------------
# Low-level: read one sheet with a two-row header into flat columns
# ---------------------------------------------------------------
def _clean(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def read_config_table(path):
    """Returns a list of row dicts. Columns become 'name' for plain
    columns or 'group.sub' for grouped ones, all lower-cased, e.g.
    'dockdoorid', 'centroid_position.latitude'."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm", ".xls"):
        raw = pd.read_excel(path, header=None, dtype=object)
    else:
        # sep=None lets pandas sniff comma / tab / semicolon
        raw = pd.read_csv(path, header=None, dtype=object, sep=None,
                          engine="python", encoding="utf-8-sig")

    if len(raw) < 3:
        raise ValueError(f"{path}: expected 2 header rows plus data rows")

    top_row = [_clean(v) for v in raw.iloc[0]]
    sub_row = [_clean(v) for v in raw.iloc[1]]

    names = []
    last_group = None
    for top, sub in zip(top_row, sub_row):
        if top and sub:                       # start of a grouped block
            last_group = top
            names.append(f"{top}.{sub}".lower())
        elif top and not sub:                 # plain column
            last_group = None
            names.append(top.lower())
        elif not top and sub and last_group:  # continuation of a group
            names.append(f"{last_group}.{sub}".lower())
        else:
            names.append("")                  # empty column, ignored

    rows = []
    for _, r in raw.iloc[2:].iterrows():
        row = {}
        for name, value in zip(names, r):
            if name:
                row[name] = _clean(value)
        if any(row.values()):                 # skip fully blank lines
            rows.append(row)
    return rows


def _f(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _pos(row, prefix):
    """Builds {'latitude':..,'longitude':..,'altitude':..} from
    '<prefix>.latitude' etc. Returns None if lat/lon are missing."""
    lat = _f(row.get(f"{prefix}.latitude"))
    lon = _f(row.get(f"{prefix}.longitude"))
    if lat is None or lon is None:
        return None
    return {
        "latitude": lat,
        "longitude": lon,
        "altitude": _f(row.get(f"{prefix}.alt"), 0.0),
    }


def _pid(value):
    """pavement_marking_id as an int (the MQTT obj_slot_ids are numbers,
    e.g. 18587262). Falls back to the raw text if it isn't numeric."""
    if value in (None, ""):
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return value


def _first(row, *candidates):
    for c in candidates:
        if row.get(c):
            return row[c]
    return None


CORNERS = {
    "centroid_position": "centroidPosition",
    "bottom_left_corner_position": "bottomLeftCornerPosition",
    "bottom_right_corner_position": "bottomRightCornerPosition",
    "top_left_corner_position": "topLeftCornerPosition",
    "top_right_corner_position": "topRightCornerPosition",
}


def _slot_geometry(row, label):
    """Shared by dock and parking: centroid + 4 corners."""
    out = {}
    for col_prefix, key in CORNERS.items():
        pos = _pos(row, col_prefix)
        if pos is None:
            raise ValueError(f"{label}: missing/invalid '{col_prefix}' lat/lon")
        out[key] = pos
    return out


# ---------------------------------------------------------------
# Dock doors
# ---------------------------------------------------------------
def rows_to_docks(rows, source=""):
    docks = []
    for i, row in enumerate(rows, start=3):
        dock_id = _first(row, "dockdoorid", "dock_door_id")
        if not dock_id:
            print(f"[config] {source} row {i}: no DockDoorId, skipped")
            continue
        try:
            item = {
                "dockdoorId": dock_id,
                "dockDoorName": _first(row, "dockdoorname", "dock_door_name") or dock_id,
                "pavementMarkingId": _pid(_first(row, "pavement_marking_id")),
                "width": _f(row.get("width")),
                "height": _f(row.get("height")),
                "dockdoorOrientation": _f(row.get("dockdoor_orientation")),
                "dockdoorParkingOrientation": _f(row.get("dockdoor_parking_orientation")),
            }
            item.update(_slot_geometry(row, f"dock {dock_id}"))
            dd = _pos(row, "dockdoor_position")
            if dd:
                item["dockdoorPosition"] = dd
                # 'orientation' (radians) = compass direction from the slot centre to the
                # dock door -- what the map uses to turn a backed-in trailer the right way
                c = item["centroidPosition"]
                dx = (dd["longitude"] - c["longitude"]) * math.cos(math.radians(c["latitude"]))
                dy = dd["latitude"] - c["latitude"]
                if dx or dy:
                    item["orientation"] = math.atan2(dx, dy) % (2 * math.pi)
            docks.append(item)
        except ValueError as e:
            print(f"[config] {source} row {i}: {e} -- skipped")
    return docks


# ---------------------------------------------------------------
# Parking slots  (assumes the same header style as the dock sheet;
# only the ID column name differs)
# ---------------------------------------------------------------
def rows_to_parking(rows, source=""):
    slots = []
    for i, row in enumerate(rows, start=3):
        name = _first(row, "parkingslotname", "parking_slot_name",
                      "parkingslotid", "parking_slot_id", "slotname", "slotid")
        if not name:
            print(f"[config] {source} row {i}: no parking slot name/id, skipped")
            continue
        try:
            item = {
                "parkingSlotName": name,
                "pavementMarkingId": _pid(_first(row, "pavement_marking_id")),
                "markingType": _f(row.get("marking_type")),
                "width": _f(row.get("width")),
                "height": _f(row.get("height")),
                "orientation": _f(row.get("orientation")),
            }
            item.update(_slot_geometry(row, f"parking {name}"))
            slots.append(item)
        except ValueError as e:
            print(f"[config] {source} row {i}: {e} -- skipped")
    return slots


# ---------------------------------------------------------------
# Table files (dock doors, parking slots)
# ---------------------------------------------------------------
_CONVERTERS = {
    "dock": rows_to_docks,
    "parking": rows_to_parking,
}
_ID_KEY = {
    "dock": "dockdoorId",
    "parking": "parkingSlotName",
}


def _expand(paths):
    """Accepts file paths, glob patterns or folders."""
    files = []
    for p in paths or []:
        if os.path.isdir(p):
            for ext in ("*.csv", "*.xlsx", "*.xls"):
                files.extend(sorted(glob.glob(os.path.join(p, ext))))
        elif any(ch in p for ch in "*?["):
            files.extend(sorted(glob.glob(p)))
        else:
            files.append(p)
    return files


def load_category(kind, paths):
    """Loads + merges every file for one category. Later files win on
    duplicate IDs. Returns a list of items (possibly empty)."""
    convert = _CONVERTERS[kind]
    id_key = _ID_KEY[kind]
    merged = {}
    for path in _expand(paths):
        if not os.path.exists(path):
            print(f"[config] {kind}: file not found, ignored: {path}")
            continue
        items = convert(read_config_table(path), source=os.path.basename(path))
        for item in items:
            key = str(item[id_key])
            if key in merged:
                print(f"[config] {kind} '{key}' appears again in "
                      f"{os.path.basename(path)} -- using the later one")
            merged[key] = item
        print(f"[config] {kind}: {len(items)} item(s) from {os.path.basename(path)}")
    return list(merged.values())


# ===============================================================
# Whole site from the CC configuration files
# ===============================================================
# The CC portal exports one file per kind, named like
#   client84_MapParamFile_22-September-2026-10_55_21 AM.csv
# Kinds are recognised from the file name; if a kind is downloaded more than
# once, the newest export (date in the name, else file time) is used.
CC_FILE_KINDS = [                       # (kind, regex on the lower-cased file name)
    ("map_param", r"mapparam"),
    ("dock", r"dockdoor"),
    ("parking", r"parkingslot"),
    ("gate", r"gateconfig|gatefile"),
    ("lot", r"lotconfig|lotfile"),
    ("rover", r"roverfile|roverconfig"),
]
CC_EXTENSIONS = (".csv", ".xlsx", ".xls")

_STAMP_RE = re.compile(r"(\d{1,2})-([A-Za-z]+)-(\d{4})-(\d{1,2})_(\d{2})_(\d{2})\s*([AP]M)?", re.I)


def _export_time(path):
    m = _STAMP_RE.search(os.path.basename(path))
    if m:
        day, month, year, hh, mm, ss, ampm = m.groups()
        try:
            stamp = datetime.strptime(f"{day} {month} {year} {hh}:{mm}:{ss} {ampm or 'AM'}",
                                      "%d %B %Y %I:%M:%S %p")
            return stamp.timestamp()
        except ValueError:
            pass
    return os.path.getmtime(path)


def find_cc_files(folder):
    """{kind: newest file} for every CC export in `folder` (searched recursively)."""
    found = {}
    for root, _dirs, files in os.walk(folder):
        for name in files:
            if not name.lower().endswith(CC_EXTENSIONS) or name.startswith("~$"):
                continue
            low = name.lower()
            for kind, pattern in CC_FILE_KINDS:
                if re.search(pattern, low):
                    found.setdefault(kind, []).append(os.path.join(root, name))
                    break
    chosen = {}
    for kind, paths in found.items():
        paths.sort(key=_export_time)
        chosen[kind] = paths[-1]
        for older in paths[:-1]:
            print(f"[config] {kind}: newer export used, ignoring {os.path.basename(older)}")
    return chosen


def read_key_values(path):
    """KEY,VALUE,DESC style files (map params, gates, lots, rovers) ->
    {key: value}. Blank rows and repeated keys (first one wins) are skipped."""
    if path.lower().endswith((".xlsx", ".xls")):
        raw = pd.read_excel(path, header=None, dtype=object)
        rows = [[_clean(v) for v in r] for _, r in raw.iterrows()]
    else:
        with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
            rows = [[c.strip() for c in r] for r in csv.reader(f)]
    out = {}
    for r in rows:
        if r and r[0] and r[0].upper() != "KEY" and r[0] not in out:
            out[r[0]] = r[1] if len(r) > 1 else ""
    return out


def _latlon(text):
    """'42.7108, -84.6426' -> (42.7108, -84.6426); None if not a coordinate."""
    try:
        a, b = [float(p) for p in str(text).split(",")[:2]]
        return a, b
    except (TypeError, ValueError):
        return None


def _app_point(lat, lon):
    # the app's existing data uses the 'lattitude' spelling
    return {"lattitude": str(lat), "longitude": str(lon)}


def _numbered(kv, pattern):
    """Sorted numbers n for which `pattern % n` exists, e.g. 'rsu_location_%d'."""
    rx = re.compile("^" + re.escape(pattern).replace("%d", r"(\d+)") + "$")
    return sorted({int(m.group(1)) for k in kv for m in [rx.match(k)] if m})


def _rsus(kv, shipyard):
    rsus = []
    for n in _numbered(kv, "rsu_location_%d"):
        loc = _latlon(kv.get(f"rsu_location_{n}"))
        if not loc:
            continue
        cam = _latlon(kv.get(f"camera_location_{n}")) or loc
        corners = [_latlon(kv.get(f"rsu_coverage_{n}_corner_{c}")) for c in (1, 2, 3, 4)]
        if not all(corners):
            corners = [loc] * 4
        rsus.append({
            "rsuId": f"{shipyard}_rsu_{n:02d}",      # same ids as the CC portal / MQTT
            "rsuLocation": _app_point(*loc),
            "cameras": {
                "cameraLocation": _app_point(*cam),
                "cameraUrl": kv.get(f"camera_url_{n}", ""),
                "cameraUrlHigh": kv.get(f"camera_url_{n}_high", ""),
                "cameraOrentation": kv.get(f"camera_orientation_{n}", kv.get(f"rsu_orientation_{n}", "")),
            },
            "rsuCoverage": {f"corner{i + 1}": _app_point(*p) for i, p in enumerate(corners)},
        })
    return rsus


def _mecs(kv, shipyard):
    mecs = []
    for n in _numbered(kv, "mec_location_%d"):
        loc = _latlon(kv.get(f"mec_location_{n}"))
        if loc:
            mecs.append({"mecId": f"{shipyard}_mec_{n:02d}", "locationId": n,
                         "locationvalue": _app_point(*loc)})
    return mecs


def _gates(kv):
    gates = []
    # corner_1..4 = bottom-left, bottom-right, top-left, top-right (as in the CC portal)
    corner_keys = ["bottomLeftCornerPosition", "bottomRightCornerPosition",
                   "topLeftCornerPosition", "topRightCornerPosition"]
    for n in _numbered(kv, "gate_name_%d") or _numbered(kv, "gate_id_%d"):
        corners = [_latlon(kv.get(f"gate_location_{n}_corner_{c}")) for c in (1, 2, 3, 4)]
        if not all(corners):
            print(f"[config] gate {n}: corners missing, skipped")
            continue
        loc = _latlon(kv.get(f"gate_location_{n}")) or corners[0]
        gates.append({
            "gateId": kv.get(f"gate_id_{n}", f"gate_{n:02d}"),
            "gateName": kv.get(f"gate_name_{n}") or kv.get(f"gate_id_{n}", f"Gate{n:02d}"),
            "gateType": kv.get(f"gate_type_{n}", ""),
            "gateStatus": kv.get(f"gate_status_{n}", ""),
            "gateLocation": _app_point(*loc),
            "gateLocationCorner": {k: _app_point(*p) for k, p in zip(corner_keys, corners)},
        })
    return gates


def _lots(kv):
    lots = []
    for n in _numbered(kv, "lot_id_%d"):
        corners = [_latlon(kv.get(f"corner_position_{n}_{c}"))
                   for c in _numbered(kv, f"corner_position_{n}_%d")]
        corners = [c for c in corners if c]
        if len(corners) < 3:
            print(f"[config] lot {n}: fewer than 3 corners, skipped")
            continue
        lots.append({
            "id": kv.get(f"lot_id_{n}"),
            "lotName": kv.get(f"lot_name_{n}") or kv.get(f"lot_id_{n}"),
            "handShakeLots": [{"handShakeLot": kv[f"handshake_lot_{n}_{h}"]}
                              for h in _numbered(kv, f"handshake_lot_{n}_%d")],
            "numberOfCorners": str(len(corners)),
            "cornerPositions": [_app_point(*c) for c in corners],
        })
    return lots


def _rovers(kv):
    """Rovers (yard dogs) from the rover file: keys like 'type3_rover_id_1'."""
    rovers = {}
    rx = re.compile(r"^(?:(type\d+)_)?rover_(id|name|license_number|type|zone)_(\d+)$")
    for key, value in kv.items():
        m = rx.match(key)
        if m and value:
            prefix, field, n = m.group(1) or "", m.group(2), m.group(3)
            rovers.setdefault((prefix, int(n)), {})[field] = value
    return [r for _k, r in sorted(rovers.items()) if r.get("id")]


def _operational_area(kv):
    """'operational_area' is a JSON-ish list of [lon, lat] pairs -> [[lat, lon], ...]."""
    nums = re.findall(r"-?\d+(?:\.\d+)?", kv.get("operational_area", ""))
    pts = [[float(nums[i + 1]), float(nums[i])] for i in range(0, len(nums) - 1, 2)]
    return pts if len(pts) >= 3 else []


def load_site(folder, site_id=None):
    """Builds the whole yard from the CC configuration files in `folder`.

    Returns (data, info, warnings):
      data  -- the structure the map uses: mapParameter (rsu, mecLocation),
               parkingMap, dockDoor, lot, gate, rovers
      info  -- shipyard_name, display_name, bounds, center, operational_area, files
      warnings -- human-readable problems (missing files, items outside the yard)
    """
    files = find_cc_files(folder)
    warnings = []
    mp = read_key_values(files["map_param"]) if "map_param" in files else {}
    # a yard chosen on the map (Yards -> Choose from map): only its boundary -- no slots / docks / rovers yet
    from_map = str(mp.get("created_from", "")).strip().lower() == "map"
    for kind, _pattern in CC_FILE_KINDS:
        if kind not in files and kind != "gate" and not from_map:      # gates can also come from map params
            warnings.append(f"No {kind.replace('_', ' ')} file found.")
    for kind, path in files.items():
        print(f"[config] {kind:9s} <- {os.path.basename(path)}")

    shipyard = mp.get("shipyard_name") or site_id or os.path.basename(os.path.normpath(folder))

    slots = load_category("parking", [files["parking"]]) if "parking" in files else []
    docks = load_category("dock", [files["dock"]]) if "dock" in files else []
    gate_kv = read_key_values(files["gate"]) if "gate" in files else mp
    lots = _lots(read_key_values(files["lot"])) if "lot" in files else []
    rovers = _rovers(read_key_values(files["rover"])) if "rover" in files else []

    # yard boundary: the 4 map corners, else everything that was loaded
    corners = [c for c in (_latlon(mp.get(f"location_corner{i}")) for i in (1, 2, 3, 4)) if c]
    if not corners:
        corners = [(s["centroidPosition"]["latitude"], s["centroidPosition"]["longitude"])
                   for s in slots + docks]
    if not corners:
        raise ValueError(f"{folder}: no map parameter, parking or dock file -- nothing to show")
    lat_min = min(c[0] for c in corners); lat_max = max(c[0] for c in corners)
    lon_min = min(c[1] for c in corners); lon_max = max(c[1] for c in corners)

    # anything well outside the yard (~300 m) is from another site's export
    margin = 0.003

    def inside(item):
        c = item["centroidPosition"]
        return (lat_min - margin <= c["latitude"] <= lat_max + margin and
                lon_min - margin <= c["longitude"] <= lon_max + margin)

    for label, items, kind in (("dock doors", docks, "dock"), ("parking slots", slots, "parking")):
        outside = [i for i in items if not inside(i)]
        if outside:
            items[:] = [i for i in items if inside(i)]
            c = outside[0]["centroidPosition"]
            warnings.append(
                f"{len(outside)} {label} in {os.path.basename(files[kind])} lie outside the "
                f"{shipyard} yard (e.g. {c['latitude']:.5f}, {c['longitude']:.5f}) and were not "
                f"loaded -- this file looks like it belongs to another site.")

    gates = _gates(gate_kv)
    if not gates and not from_map:
        warnings.append("No gates found (no gate file, and none in the map parameter file).")

    data = {
        "mapParameter": {"rsu": _rsus(mp, shipyard), "mecLocation": _mecs(mp, shipyard)},
        "parkingMap": {"locations": slots},
        "dockDoor": {"locations": docks},
        "lot": {"lots": lots},
        "gate": {"gate": gates},
        "rovers": rovers,
    }
    info = {
        "shipyard_name": shipyard,
        "display_name": mp.get("display_name") or shipyard,
        "location": mp.get("location", ""),
        "time_zone": mp.get("time_zone", ""),
        "bounds": [[lat_min, lon_min], [lat_max, lon_max]],
        "center": [(lat_min + lat_max) / 2, (lon_min + lon_max) / 2],
        "operational_area": _operational_area(mp),
        "created_from": "map" if from_map else "cc_files",
        "files": {k: os.path.basename(v) for k, v in files.items()},
    }
    print(f"[config] {shipyard}: site loaded")
    for w in warnings:
        print(f"[config] WARNING: {w}")
    return data, info, warnings