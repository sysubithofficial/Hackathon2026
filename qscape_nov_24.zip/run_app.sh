#!/usr/bin/env bash
# Q-SCAPE -- start the app from its own .venv (made once by setup_app.sh).
#   Ubuntu:   bash run_app.sh          Windows:  in Git Bash:  bash run_app.sh   (or double-click run_app.bat)
cd "$(dirname "$0")" || exit 1
export PYTHONNOUSERSITE=1                        # (~/.local packages: not used)
unset PYTHONPATH
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) VPY=.venv/Scripts/python.exe ;;
  *) VPY=.venv/bin/python ;;
esac
if [ ! -f "$VPY" ]; then
  echo "No .venv here (or it was made on another OS) -- run once:  bash setup_app.sh"
  exit 1
fi
if [ "$(id -u 2>/dev/null)" = 0 ]; then
  export QTWEBENGINE_DISABLE_SANDBOX=1           # (Qt WebEngine runs as root only without its sandbox)
fi
exec "$VPY" main.py "$@"
