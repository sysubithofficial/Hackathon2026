"""The info window's TECHNICAL OVERVIEW: how our simulation application does it in code -- for engineers and
evaluators ("how does the Python logic detect the objects?").

TECH[name] (name = an option's picture deck, e.g. "camera", "camera_real", "v2v", or a topic without options:
"flow", "climate", "collision", "real") ->
  summary   one paragraph
  pipeline  [(stage, where in the code, what it does)]
  code      the core logic, simplified (Python / JavaScript as in the module)
  libs      [(library / technology, what for)]
  params    [(name, value, where)]
  timing    how often / how costly
  pros      advantages of the way it is done
  cons      limitations
  verify    how to check it in the running app
An option not in our app: generic(method, used) builds the same from its method data (how it would be added).
The numbers are taken from the modules (follow_test, real_sensors, real_camera, v2v), so they stay true.
"""
import follow_test as ft
import v2v

_C, _R = ft.FRONT_CAMERA, ft.FRONT_RADAR
_P5, _V2N = v2v.LINKS["pc5"], v2v.LINKS["v2n"]

_ARCH_LIBS = [("PyQt5", "the desktop app: windows, widgets, the 100 ms QTimer that drives every test step"),
              ("Qt WebEngine (Chromium)", "hosts the map page and the hidden 3D sensor page inside the app"),
              ("runJavaScript / QWebChannel", "the bridge: Python sends positions as JSON, the page returns results")]

TECH = {
    # ------------------------------------------------------------------ the whole application
    "flow": {
        "summary": "A PyQt5 desktop application. A <b>100 ms test loop in Python</b> moves every AV along "
                   "its route, asks its sensors what they detect, fuses that into one target, decides the speed, and "
                   "checks the ground truth for a collision. The map (Leaflet / folium) and the 3D world (three.js) run "
                   "as web pages inside the app; Python and the pages talk through Qt WebEngine.",
        "pipeline": [
            ("Timer tick", "shipyard.MapWindow · QTimer (FOLLOW_STEP_MS = 100)", "one step per truck every 100 ms"),
            ("Scene snapshot", "shipyard._route_tick", "every object as (id, label, lat, lon, length, width, kind, "
                                                       "moving, heading, speed)"),
            ("Sensors", "follow_test.cameras_detect / radar_detect · yard3d.html lidarDetect · v2v.Channel",
             "each switched-on sensor gives its detections (simulated or real-world processing)"),
            ("Fusion", "follow_test.Follower.perceive", "the nearest object in the lane = the target"),
            ("Control", "follow_test.Follower.step", "TTC, needed deceleration, follow / brake / AEB → new speed"),
            ("Move", "shipyard._route_tick · _route_pose", "s += v·dt along the route polyline → lat / lon / heading"),
            ("Ground truth", "shipyard._route_tick", "real gap to the nearest object in the lane; ≤ 0.2 m = collision"),
            ("Display / save", "collision_panel (3× a second) · reports JSON", "cards, detection details, results")],
        "code": "def _route_tick(truck):                      # every 100 ms (QTimer)\n"
                "    objs   = scene_objects()                # positions from the map state\n"
                "    dets   = {s: detect(s, truck, objs, climate) for s in truck.sensors_on}\n"
                "    dets['V2V'] = channel.inbox(truck)      # if V2V is on\n"
                "    target = ctl.perceive(t, **dets)        # nearest in lane (fusion)\n"
                "    v      = ctl.step(t, dt)                # follow / brake / AEB\n"
                "    s     += v * dt                         # along the route\n"
                "    truth  = nearest_real_object_in_lane(s) # ground truth (judging only)\n"
                "    if truth.gap <= 0.2 and v > 0.05:\n"
                "        record_collision(truck, truth, dets)",
        "libs": _ARCH_LIBS + [("folium / Leaflet", "the 2D yard map"),
                              ("three.js (WebGL)", "the 3D world: LiDAR ray scan, camera pictures, accident scenes"),
                              ("numpy", "the real-world camera's picture processing"),
                              ("paho-mqtt", "optional: publishing the trucks' states to hardware"),
                              ("JSON files", "config/ (sensors, climates), sites/<yard>/ (routes, reports)")],
        "params": [("Control step", "100 ms", "shipyard.FOLLOW_STEP_MS"),
                   ("LiDAR detections", "~4 per second", "shipyard (runJavaScript lidarDetect)"),
                   ("Test window refresh", "~3 per second", "collision_panel")],
        "timing": "Pure Python per truck and step: well under a millisecond for the simulated models; the LiDAR scan "
                  "runs in the 3D page (JavaScript); real-world camera pictures are the slowest part (~1 per second per "
                  "truck).",
        "pros": ["Deterministic structure: every step is the same pipeline, easy to log and explain",
                 "Perception and ground truth are separate: the truck never sees the truth",
                 "Sensors can be switched on / off and the climate changed while it runs",
                 "No special hardware: runs on an office PC"],
        "cons": ["Single-threaded Python loop: many trucks + real-world cameras slow it down",
                 "Simplified physics (point-mass speed, no tyre / steering model)",
                 "Some random draws (radar, V2V loss) make two runs not exactly identical"],
        "verify": ["Detection details of a truck card: what each sensor gives at this moment",
                   "Log ▸ in the test window: every detection, braking, TTC warning with time stamps",
                   "Results / Reports: per-loop numbers and every collision with each sensor's view"]},

    # ------------------------------------------------------------------ camera
    "camera": {
        "summary": "<b>Geometry, not image processing.</b> The camera is a model on the scene's object list: an object "
                   "is detected when it is inside the field of view, closer than the camera's range in this climate and "
                   "not hidden behind a nearer object. Pure Python (math only).",
        "pipeline": [
            ("Objects into the truck frame", "follow_test._local",
             "lat / lon → metres (111 320 m per degree), rotated by our heading → x forward, y left"),
            ("Field of view + range", "follow_test._fov_detect",
             f"angle = atan2(y, x) within ±{_C['hfov_deg'] / 2:g}°; gap = x − own L/2 − its L/2 ≤ range × reach(width)"),
            ("Range from the climate", "follow_test.camera_range",
             f"min({_C['max_range_m']:g} m, {_C['visibility_share']:g} × visibility) × {_C['night']:g} at night × "
             f"(1 − {_C['precip_loss']:g} × rain / snow rate)"),
            ("Occlusion", "follow_test._fov_detect",
             f"objects sorted by distance; angular width ±atan(W/2 ÷ x); covered ≥ {ft.OCCLUDED_SHARE:.0%} by nearer ones "
             "→ hidden"),
            ("Type + confidence", "follow_test.camera_detect.classify",
             "conf = clip(1 − 0.75 × gap / range, 0.25, 0.99); type = kind if conf ≥ 0.5 else 'object'"),
            ("Several cameras", "follow_test.cameras_detect", "config truck_cameras.json; nearest result per object"),
            ("To fusion", "Follower.perceive", "kept when |y| ≤ 2.2 m (the lane)")],
        "code": "def camera_detect(ego, ego_len, objects, climate):\n"
                "    rng = min(80, 0.5 * climate.visibility_m)     # × 0.45 at night, − rain / snow\n"
                "    for ob in sorted(objects, key=distance):\n"
                "        x, y = to_truck_frame(ego, ob.lat, ob.lon)  # forward, left (m)\n"
                "        if x <= 0: continue                         # behind the camera\n"
                "        gap = x - ego_len / 2 - ob.L / 2           # bumper to bumper\n"
                "        if abs(atan2(y, x)) > radians(45): continue # outside the 90° view\n"
                "        if gap > rng * reach(ob.W): continue        # beyond the range\n"
                "        if covered_by_nearer(ob) >= 0.7: continue   # occlusion\n"
                "        conf = clip(1 - 0.75 * gap / rng, 0.25, 0.99)\n"
                "        yield dict(id=ob.id, label=ob.label, gap=gap, x=x, y=y,\n"
                "                   cls=ob.kind if conf >= 0.5 else 'object', conf=conf)",
        "libs": [("Python math", "the whole model (no packages)"),
                 ("three.js frontCamShot", "renders the camera picture — only for showing, not for detecting")],
        "params": [("hfov / max range", f"{_C['hfov_deg']:g}° / {_C['max_range_m']:g} m", "follow_test.FRONT_CAMERA"),
                   ("Share of the visibility", f"{_C['visibility_share']:g}", "FRONT_CAMERA"),
                   ("Night factor / rain-snow loss", f"{_C['night']:g} / {_C['precip_loss']:g}", "FRONT_CAMERA"),
                   ("Occluded share", f"{ft.OCCLUDED_SHARE:g}", "follow_test.OCCLUDED_SHARE"),
                   ("Visibility", "per climate", "config/climates.json visibility_m"),
                   ("Cameras per truck", "hfov / yaw / range", "config truck_cameras.json")],
        "timing": "Every 100 ms per truck; a few microseconds per object (occlusion compares with the nearer objects).",
        "pros": ["Fast, deterministic and repeatable — isolates the braking logic", "Every result can be explained by a "
                 "formula (range, angle, occlusion)", "The climate's effect is transparent (visibility share)"],
        "cons": ["No picture is analysed: no misses inside the range, no false objects", "The name comes from the scene "
                 "(a real camera only knows 'a truck')", "Exact distance (a real mono camera must estimate it)",
                 "Occlusion only by angular width, not by height", "Confidence is a formula, not a detector's score"],
        "verify": ["Detection details → camera tile: gap, type, confidence, or why not seen (range / hidden)",
                   "Change the climate: the camera range in the header changes (½ the visibility)",
                   "Bird's-eye view: the camera's view cone and range"]},
    "camera_real": {
        "summary": "<b>Classic monocular image processing with numpy</b> (free space / ground contact, a 'stixel'-like "
                   "method). The 3D page renders the truck's camera picture; Python finds where the road ends in each "
                   "pixel column and turns that row into a distance with the camera's height and tilt. No object list "
                   "and no machine learning.",
        "pipeline": [
            ("Render", "yard3d.html frontCamShot (three.js) via runJavaScript",
             "JPEG (base64) + calibration: width, height, fx, fy, camera height, pitch"),
            ("Decode", "real_camera.decode_jpeg", "QImage.fromData → numpy float32 H × W × 3 (0–1)"),
            ("Road model", "real_camera.road_palette",
             "road colours from the bottom rows + the haze colour; a pixel is road when its RGB lies within 0.075 of "
             "the line road colour ↔ haze"),
            ("Free space", "real_camera.detect", "every 2nd column scanned bottom → up; where the road stops for good "
                                                 "(rises ≥ 0.8 m) = an obstacle's base row"),
            ("Distance", "real_camera.detect", "angle below horizon = atan((v − v_horizon) / fy); "
                                               "d = camera height ÷ tan(angle); side y = −(u − cx) × d / fx"),
            ("Objects", "real_camera.detect", "neighbouring columns at about the same distance = one object; width → "
                                              "type; contrast → confidence (reported ≥ 0.42)"),
            ("Tracking", "real_sensors.Tracker('C', 2 of 3, coast 1.2 s)",
             "nearest-neighbour association, alpha-beta smoothing (0.6 new / 0.4 old) → tracks C1, C2 …"),
            ("Names (reports only)", "real_sensors.match_truth", "the scene object whose outline (± 2 m + 15 %) holds "
                                                                  "the track")],
        "code": "img = decode_jpeg(b64decode(shot['jpeg']))        # numpy H×W×3\n"
                "road, haze = road_palette(img, bottom_rows)\n"
                "for u in range(0, W, 2):                          # every 2nd column\n"
                "    for v in range(H - 1, v_horizon, -1):         # bottom → up\n"
                "        if not near_line(img[v, u], road, haze, tol=0.075):\n"
                "            if rises_at_least(u, v, 0.8):          # not a lane marking\n"
                "                base[u] = v; break\n"
                "ang = atan((base - v_horizon) / fy)\n"
                "dist = cam_height / tan(ang)                      # flat road\n"
                "objs = group_columns(base, dist)                  # width → type, contrast → conf\n"
                "tracks = tracker_C.update(t, objs)                # C1, C2 … (2 of 3 pictures)",
        "libs": [("numpy", "per-pixel colour distances, column scans"), ("PyQt5 QImage", "JPEG decoding"),
                 ("three.js (WebGL)", "renders the picture with the climate's fog / rain / night"),
                 ("base64 / json", "the picture and calibration from the page")],
        "params": [("Column step", "2 px", "real_camera.STEP"), ("Road tolerance", "0.075 (RGB 0–1)",
                                                                  "real_camera.GROUND_TOL"),
                   ("Min. obstacle height", "0.8 m", "real_camera.MIN_OBST_M"),
                   ("Min. confidence", "0.42", "real_camera.MIN_CONF"), ("Max range", "120 m", "real_camera.MAX_RANGE_M"),
                   ("Tracker", "2 of 3, coast 1.2 s, gate 2 m", "shipyard (real-world set-up)")],
        "timing": "Rendering is the cost: ~1 picture a second per truck without 3D acceleration; the numpy processing "
                  "takes tens of milliseconds per picture.",
        "pros": ["A real perception chain: misses, wrong distances and phantom objects can happen", "No training data, "
                 "no GPU, no ML licence — every step is explainable", "Scored against the truth (match_truth)"],
        "cons": ["Objects lower than ~0.8 m are missed", "Flat-road assumption: slopes give wrong distances",
                 "Two objects side by side at the same distance merge", "The 3D scene has no headlights: little at night",
                 "Rendered pictures are cleaner than real ones (domain gap)", "Slower than the simulated set-up"],
        "verify": ["Detection details → camera image: green = found (its ground-contact line and distance), grey dashed "
                   "= the truth", "The camera tile explains a miss ('not found in the picture')"]},

    # ------------------------------------------------------------------ LiDAR
    "lidar": {
        "summary": "<b>Real ray tracing in the 3D scene (JavaScript, three.js)</b>: the truck's LiDAR beam pattern is "
                   "cast against the ground, buildings and the vehicles' boxes; each return survives the climate with a "
                   "probability. Points are counted per object they hit; enough points = a detection.",
        "pipeline": [
            ("Positions to the page", "shipyard._push_yard3d → yard3d.html", "all trucks, trailers, obstacles (JSON)"),
            ("Ask ~4× a second", "shipyard · runJavaScript('lidarDetect(opt)')", "asynchronous; the callback "
                                                                                "_on_lidar_detect receives JSON"),
            ("Ray scan", "yard3d.html scanTruck", "every channel × azimuth: a ray from the sensor pose; nearest hit of "
                                                   "ground plane / rayBox / rayWall / compound models; own cab skipped"),
            ("Weather per ray", "yard3d.html", "survives with exp(−2 × extinction × r); false returns near the sensor "
                                               "with probability 'clutter'; extra range noise"),
            ("Count per object", "yard3d.html", "points on each object + its nearest point's gap to our body"),
            ("Detection", "yard3d.html lidarDetect", "≥ min_points (config/lidar.json, 4) within the report range → "
                                                     "{id, label, points, gap, x, y, lat, lng}"),
            ("In Python", "shipyard._route_tick", "detections younger than 0.6 s; placed along the route; lane filter")],
        "code": "// yard3d.html (JavaScript), per truck and scan\n"
                "for (c of columns) for (r of rows) {             // the LiDAR's beam pattern\n"
                "  ray = beamDir(c, r) rotated to the truck pose\n"
                "  best = hitGround(ray); obj = null\n"
                "  for (tg of targetsNear[c]) {                    // boxes / walls at this azimuth\n"
                "    t = rayBox(sensor, ray, tg); if (t > 0 && t < best) { best = t; obj = tg }\n"
                "  }\n"
                "  if (Math.random() < clutter) best = Math.min(best, nearClutter())\n"
                "  if (Math.random() > Math.exp(-2 * ext * best)) continue   // lost in fog\n"
                "  if (obj) { acc[obj].n++; acc[obj].gap = Math.min(acc[obj].gap, gapToBody(pt)) }\n"
                "}\n"
                "return objects with acc.n >= minPts              // config/lidar.json",
        "libs": [("three.js", "the 3D scene, vehicle models, poses"), ("JavaScript ray–box / ray–wall intersection",
                                                                       "the scan itself (no GPU raycaster)"),
                 ("Qt WebEngine runJavaScript", "Python ↔ page, results as JSON")],
        "params": [("Min. points", "4", "config/lidar.json detection.min_points"),
                   ("Report range", f"{ft.REPORT_RANGE_M:g} m (tests)", "follow_test.REPORT_RANGE_M"),
                   ("Beam pattern", "channels, angles, range", "config/lidar.json"),
                   ("Extinction / noise / clutter", "per climate", "config/climates.json lidar.*"),
                   ("Detection hold", f"{ft.HOLD_S:g} s", "follow_test.HOLD_S")],
        "timing": "~4 scans a second per truck, tens of thousands of rays in JavaScript; the Python side only handles "
                  "the detection list.",
        "pros": ["Occlusion, blind zone and point density come from the geometry itself", "Weather acts ray by ray "
                 "(like real extinction)", "The same scan feeds the 3D / LiDAR views"],
        "cons": ["Points are labelled by what they hit: perfect grouping", "Boxes / simple models, no beam divergence "
                 "or multiple echoes", "Reflectivity is not used for detecting", "Range limited by the configured "
                 "short-range LiDARs (~15 m used)"],
        "verify": ["LiDAR / 3D view: the point cloud on the vehicles", "Detection details → LiDAR tile: points and "
                   "gap; whiteout fog: 0 points"]},
    "lidar_real": {
        "summary": "<b>Unlabelled point cloud → grid clustering in pure Python.</b> The same ray scan, but the page "
                   "returns only the points (east, north, height) — not what they hit. Python filters the weather, "
                   "clusters, measures and tracks, like a real LiDAR stack.",
        "pipeline": [
            ("Raw cloud", "yard3d.html lidarDetect(opt.cloud)", "points ≥ 0.3 m high, the map's static structure "
                                                                 "removed, ahead within 60 m"),
            ("Into our frame", "real_sensors.lidar_points", "(east, north, height) → (forward, left, height)"),
            ("Weather filter", "real_sensors.weather_filter", "0.2 m voxels; within 12 m a point needs neighbours "
                                                              "(2–6) — sparse fog / rain returns dropped"),
            ("Clustering", "real_sensors.lidar_clusters", "0.6 m grid cells; touching cells (8 neighbours, flood "
                                                          "fill) = one object; ≥ 5 points"),
            ("Distance", "real_sensors.lidar_clusters", "nearest point inside our corridor (half width + 0.3 m)"),
            ("Tracking", "real_sensors.Tracker('L', 2 of 3, coast 0.6 s)", "tracks L1, L2 …"),
            ("Names (reports only)", "real_sensors.match_truth", "matched to the scene object at its position")],
        "code": "pts = lidar_points(me, res['pos'], res['cloud'])  # (fwd, left, h)\n"
                "pts = weather_filter(pts, voxel=0.2, near_m=12)  # density (outlier) filter\n"
                "cells = defaultdict(list)\n"
                "for p in pts: cells[floor(p.f / 0.6), floor(p.l / 0.6)].append(p)\n"
                "for c0 in cells:                                 # flood fill over 8 neighbours\n"
                "    cluster = flood_fill(cells, c0)\n"
                "    if len(cluster) < 5: continue\n"
                "    inside = [p for p in cluster if abs(p.l) <= half_w + 0.3]\n"
                "    gap = min(p.f for p in inside) - L / 2        # nearest point in our corridor\n"
                "tracks = tracker_L.update(t, clusters)           # L1, L2 …",
        "libs": [("Python dict / math", "the grid, flood fill and filters (no packages)"),
                 ("three.js", "the ray scan producing the cloud")],
        "params": [("Grid cell", "0.6 m", "real_sensors.CELL_M"), ("Min. points", "5", "real_sensors.LIDAR_MIN_PTS"),
                   ("Corridor margin", "0.3 m", "real_sensors.LANE_MARGIN_M"),
                   ("Tracker", "2 of 3, coast 0.6 s, gate 1.5 m", "shipyard (real-world set-up)")],
        "timing": "O(number of points) per scan — a few milliseconds for a few thousand points.",
        "pros": ["Real perception: grouping errors, phantoms and misses can happen", "Fast and simple — easy to "
                 "explain and tune", "No training or GPU"],
        "cons": ["Close objects can merge, a long truck can split", "Flat-ground assumption (height threshold)",
                 "No class (truck / pole / person)", "Whiteout fog: a wall of returns near the sensor"],
        "verify": ["Detection details → LiDAR tile: track id (L4), points, matched name or 'unknown object'"]},

    # ------------------------------------------------------------------ radar
    "radar": {
        "summary": "<b>An object-level physical model</b> (Python math + random): the radar equation gives each object's "
                   "signal margin in this weather; the detection is a random draw with that probability every scan; a "
                   "small tracker confirms targets; the Doppler speed comes with the detection.",
        "pipeline": [
            ("Candidates", "follow_test._fov_detect", f"±{_R['hfov_deg'] / 2:g}°, up to 400 m, occlusion only at "
                                                       f"{_R['occluded_share']:.0%} (the beam passes under vehicles)"),
            ("Radar cross-section", "follow_test.radar_rcs_db", "truck 20, car 10, van 13, pedestrian −5 dBsm"),
            ("Signal margin", "follow_test.radar_margin_db", f"(RCS − {_R['ref_rcs_dbsm']:g}) − 40·log10(r / "
                                                             f"{_R['max_range_m']:g}) − weather loss − "
                                                             f"{_R['clutter_static_db']:g} dB if it never moved"),
            ("Weather", "follow_test.radar_losses_db", "rain: ITU-R P.838 γ = 1.1 × R^0.72 dB/km two-way + "
                                                       "backscatter + wet radome; snow; fog; road spray"),
            ("Detection chance", "follow_test.radar_pd", f"Pd = 1 / (1 + e^(−margin / {_R['pd_slope_db']:g}))"),
            ("Tracker", "follow_test.radar_detect(track=…)", f"random draw per scan; confirmed {_R['confirm']} of "
                                                              f"{_R['window']}; coast {_R['coast_s']:g} s"),
            ("Distance + speed", "follow_test.radar_detect", "gap + Gaussian noise σ = 0.08 × (1 + 10^(−margin/10)); "
                                                             "v_rel = its speed × cos(Δheading) − ours")],
        "code": "for d in fov_candidates(range=400, hfov=60):\n"
                "    rcs    = radar_rcs_db(d.kind)                       # dBsm\n"
                "    margin = (rcs - 20) - 40*log10(r / 120) - weather_db(climate, r)\n"
                "    if not d.moving: margin -= 6                        # stationary-clutter filter\n"
                "    pd  = 1 / (1 + exp(-margin / 1.6))\n"
                "    hit = random() < pd                                 # this scan\n"
                "    track.hits = (track.hits + [hit])[-3:]\n"
                "    if hit: track.gap = d.gap + gauss(0, 0.08 * (1 + 10**(-margin / 10)))\n"
                "    if sum(track.hits) >= 2 or coasting(0.35 s):\n"
                "        yield dict(d, gap=track.gap,\n"
                "                   v_rel=d.speed * cos(dh) - ego_v)      # Doppler",
        "libs": [("Python math + random", "the radar equation, Pd draws, noise")],
        "params": [("Max range (truck, Pd 50 %)", f"{_R['max_range_m']:g} m", "follow_test.FRONT_RADAR"),
                   ("Field of view", f"{_R['hfov_deg']:g}°", "FRONT_RADAR"),
                   ("Pd slope", f"{_R['pd_slope_db']:g} dB", "FRONT_RADAR"),
                   ("Confirm / window / coast", f"{_R['confirm']} / {_R['window']} / {_R['coast_s']:g} s", "FRONT_RADAR"),
                   ("Rain k / α", f"{_R['rain_k']:g} / {_R['rain_alpha']:g}", "FRONT_RADAR (ITU-R P.838, 77 GHz)"),
                   ("Extra loss / range share", "per climate", "config/climates.json radar.*")],
        "timing": "Every 100 ms per truck; microseconds per object.",
        "pros": ["Physically motivated and calibrated (radar equation, ITU rain model)", "Weak / far targets flicker "
                 "and confirm late — like a real tracker", "Speed known at once (Doppler)"],
        "cons": ["No echoes are simulated: no multipath, ghosts or interference", "No angular resolution limit "
                 "(exact positions)", "RCS fixed per object class", "Speed taken from the scene"],
        "verify": ["Detection details → radar tile: margin (dB), Pd, coasting, v_rel", "Heavy rain: the margin drops "
                   "by the weather loss"]},
    "radar_real": {
        "summary": "<b>A beam scan with echo points, CFAR and clustering</b> (pure Python): 1° beams are traced to the "
                   "objects' outlines, each echo gets a power from the radar equation with random (Swerling) "
                   "fluctuation; above the CFAR threshold it becomes a point with range, angle and Doppler; points are "
                   "clustered and tracked.",
        "pipeline": [
            ("Beams", "real_sensors.radar_scan", "61 beams of 1° across ±30°"),
            ("First hits", "real_sensors._ray_box", "slab-method ray vs oriented box; a 2nd echo only under a high "
                                                    "truck (−10 dB)"),
            ("Echo power", "real_sensors.radar_scan", "RCS spread over the beams it covers; SNR = 10^((13 dB + "
                                                      "margin)/10) × Exp(1) (Swerling fluctuation)"),
            ("CFAR threshold", "real_sensors.radar_scan", "13 dB (+4 dB for standing echoes); range noise, ±0.6° angle "
                                                          "noise, radial Doppler"),
            ("Clutter", "real_sensors.radar_scan", "Poisson false points (λ = 0.15 + 1.5 × rain / snow rate) at 3–35 m"),
            ("Clustering", "real_sensors.radar_clusters", "within 2 m and Doppler within 1.5 m/s = one object; a single "
                                                          "weak standing echo dropped"),
            ("Tracking", "real_sensors.Tracker('R', 3 of 4, coast 0.5 s, static age 8)", "tracks R1, R2 …")],
        "code": "for az in range(-30, 31):                         # 1° beams\n"
                "    hits = sorted(ray_box(beam(az), ob) for ob in scene_outlines)\n"
                "    for t, ob in hits[:2]:                        # 2nd echo only under a truck\n"
                "        margin = radar_margin_db(t, rcs_share(ob, az), climate)\n"
                "        snr = 10**((13 + margin) / 10) * expovariate(1)   # Swerling\n"
                "        thr = 13 + (4 if standing(ob) else 0)          # CFAR\n"
                "        if 10*log10(snr) >= thr:\n"
                "            pts.append(r=t + noise, az=az + noise, doppler=radial_speed(ob))\n"
                "pts += rain_clutter(poisson(0.15 + 1.5 * rain_rate))\n"
                "objs = cluster(pts, dist=2.0, doppler=1.5)\n"
                "tracks = tracker_R.update(t, objs)                 # R1, R2 … (3 of 4)",
        "libs": [("Python math + random", "ray–box, radar equation, Swerling, Poisson clutter")],
        "params": [("Beam width", "1°", "real_sensors.RADAR_BEAM_DEG"), ("CFAR", "13 dB", "real_sensors.RADAR_CFAR_DB"),
                   ("Standing echo extra", "4 dB", "real_sensors.RADAR_STATIC_DB"),
                   ("Tracker", "3 of 4, coast 0.5 s, static age 8", "shipyard (real-world set-up)")],
        "timing": "Every 100 ms per truck: 61 beams × the objects nearby — about a millisecond.",
        "pros": ["Detections come from echoes, not from the object list", "Clutter, flicker and late confirmation of "
                 "standing targets appear naturally", "Explainable without a signal-processing toolbox"],
        "cons": ["Not a full signal simulation: no chirps, FFT or range-Doppler map", "Box outlines only (no "
                 "materials, multipath)", "Angle accuracy idealised"],
        "verify": ["Detection details → radar tile: track id, power, Doppler; 'no echo track' explains a miss"]},

    # ------------------------------------------------------------------ V2V
    "v2v": {
        "summary": "<b>A message-level channel model in Python (v2v.Channel) — no radio signal.</b> Every connected "
                   "vehicle produces a state message 10× a second (and a brake alert at once); for every receiver the "
                   "channel decides lost or delivered, and when, from the distance, a building on the line of sight, a "
                   "random loss draw and a Gaussian delay. The receiver turns fresh messages into V2V detections.",
        "pipeline": [
            ("Senders", "shipyard → v2v.Channel.step", "connected vehicles: id, label, lat, lon, heading, speed, accel, "
                                                       "length, brake"),
            ("Schedule", "v2v.Channel.step", f"state every {1000 / v2v.RATE_HZ:g} ms (congestion control slower); "
                                             f"BRAKE ALERT at once on a brake edge (≤ −{v2v.BRAKE_ALERT:g} m/s²)"),
            ("GNSS error", "v2v.Channel._gnss", "a random walk correlated over ~20 s with the GNSS σ (NavIC 2.5 m, "
                                                "GAGAN 1.2 m, RTK 0.1 m)"),
            ("Line of sight", "v2v.Channel.blocked", "the map's building polygons in a grid; segment-crossing test "
                                                     "along the line sender ↔ receiver"),
            ("Loss", "v2v.Channel.step", f"base {_P5['base_loss']:.0%} + setup % + rain + busy channel (+60 % blocked, "
                                         "fading in the last 30 % of the range); random draw"),
            ("Delay", "v2v.Channel.step", f"gauss({_P5['delay_ms']:g}, {_P5['jitter_ms']:g}) ms → a pending queue "
                                          "(arrival time, receiver, message)"),
            ("Inbox", "v2v.Channel.inbox", f"latest message per sender; older than delay + {v2v.STALE_S:g} s dropped"),
            ("Receiver logic", "shipyard._ctest_v2v_dets", "placed on our route: ahead? |beside| ≤ 2.2 m + 1.5 × GNSS "
                                                           "σ? heading within 35°? → gap, v_rel, brake"),
            ("Fusion", "Follower.perceive", "used like a sensor in brake mode ('V2V')")],
        "code": "def step(now, senders, receivers):\n"
                "    for s in senders:\n"
                "        if not (brake_edge(s) or due(s, 1 / rate)): continue\n"
                "        msg = dict(s, lat=s.lat + gnss_err.n, lon=s.lon + gnss_err.e, t=now)\n"
                "        for rx in receivers:\n"
                "            d = distance(rx, s)\n"
                "            blocked = link.blocking and crosses_building(rx, s)\n"
                "            reach = link.nlos_range if blocked else link.range      # 150 / 450 m\n"
                "            p_loss = base + setup_loss + rain + busy + (0.6 if blocked else 0)\n"
                "            p_loss += fade(d, reach)                              # last 30 %\n"
                "            if d > reach or random() < p_loss: lost += 1; continue\n"
                "            pending.append((now + gauss(20, 8) / 1000, rx, msg))\n"
                "    deliver everything whose arrival time has come → latest[(rx, tx)]",
        "libs": [("Python math + random", "distances, segment intersection, loss draws, Gaussian delay / GNSS"),
                 ("Map building outlines", "OpenStreetMap polygons of the yard (line-of-sight test)")],
        "params": [("PC5", f"{_P5['delay_ms']:g} ± {_P5['jitter_ms']:g} ms, {_P5['range_m']:g} m / "
                           f"{_P5['nlos_range_m']:g} m blocked, base loss {_P5['base_loss']:.0%}", "v2v.LINKS['pc5']"),
                   ("Rate / brake alert", f"{v2v.RATE_HZ:g} Hz / ≤ −{v2v.BRAKE_ALERT:g} m/s²", "v2v.RATE_HZ, BRAKE_ALERT"),
                   ("Stale after", f"delay + {v2v.STALE_S:g} s", "v2v.STALE_S"),
                   ("Congestion", f"airtime {v2v.AIRTIME_MS:g} ms, DCC target {v2v.DCC_TARGET:.0%}", "v2v.load_of"),
                   ("Loss %, GNSS, mode", "per test", "collision test setup → V2V")],
        "timing": "Every 100 ms: senders × receivers pairs; the V2V messages tab shows the measured cost (usually "
                  "well under 1 ms per step).",
        "pros": ["Captures what matters for braking: reach, blocking, loss, delay, GPS error", "Every message and "
                 "decision is logged (delivered / lost / used / why not)", "Scales to heavy traffic with a load "
                 "formula instead of simulating every vehicle"],
        "cons": ["No radio physics: no waveform, fading, multipath or interference", "Messages are plain Python data "
                 "(no ASN.1 encoding, no signing)", "Building test is the straight line only (no reflections)"],
        "verify": ["Detection details → V2V messages: sent / received / lost, every message held and its decision",
                   "Set 30 % loss in the setup: the lost count rises"]},
    "v2v_v2n": {
        "summary": "<b>The same v2v.Channel with the cellular link</b>: a longer, more variable delay, a 3 % base loss and "
                   "no building test (the network relays it). Chosen in the collision test setup.",
        "pipeline": [("Link", "v2v.LINKS['v2n']", f"delay {_V2N['delay_ms']:g} ± {_V2N['jitter_ms']:g} ms, range "
                                                    f"{_V2N['range_m']:g} m, base loss {_V2N['base_loss']:.0%}, "
                                                    "blocking off"),
                     ("Load", "v2v.load_of(link='v2n')", "no shared channel: the rate stays; +0.02 ms per vehicle "
                                                         "(max 40 ms) extra delay"),
                     ("Rest", "as Direct C-V2X", "GNSS error, queue, inbox, receiver checks, fusion")],
        "code": "LINKS['v2n'] = {'delay_ms': 90, 'jitter_ms': 40, 'range_m': 3000,\n"
                "                'base_loss': 0.03, 'blocking': False}\n"
                "# Channel.step: blocked is always False → reach = 3000 m\n"
                "delay = gauss(90, 40) + extra_delay(load)   # ms",
        "libs": [("Python math + random", "as Direct C-V2X")],
        "params": [("V2N link", "90 ± 40 ms, 3 % loss", "v2v.LINKS['v2n']")],
        "timing": "As Direct C-V2X.",
        "pros": ["Shows the effect of a longer delay on braking", "No building blocking"],
        "cons": ["No real network model (coverage holes, handovers)", "Delay is a Gaussian, not measured"],
        "verify": ["Pick 'Cellular' in the setup's V2V settings; the V2V tab shows ~90 ms delays"]},

    # ------------------------------------------------------------------ fusion
    "fusion": {
        "summary": "<b>Late fusion by object id</b> (follow_test.Follower.perceive): all switched-on sensors' detections "
                   "in the lane are merged by their scene id, the nearest one is the target, and its speed comes from "
                   "radar / V2V or from the change of the gap.",
        "pipeline": [("Inputs", "Follower.perceive", "LiDAR, camera, radar lists, V2V (brake mode), prediction"),
                     ("Lane filter", "Follower._in_lane", f"x > 0 and |y| ≤ {ft.CORRIDOR_HALF_M:g} m"),
                     ("Merge", "Follower.perceive", "by id; each sensor's own distance kept ('by'); sensors set"),
                     ("Target", "Follower.perceive", "the smallest gap"),
                     ("Speed", "Follower.perceive", "radar / V2V: v + v_rel; else gap change with the SAME sensors, "
                                                    "smoothed 0.6 / 0.4"),
                     ("Hold", "Follower.step", f"a target is used {ft.HOLD_S:g} s after its last detection"),
                     ("Bends", "shipyard._predicted_target", "a target out of every field of view is predicted along "
                                                             "the road for 4 s")],
        "code": "best = {}\n"
                "for sensor, dets in sensor_lists():               # only switched-on ones\n"
                "    for d in dets:\n"
                "        if not (d.x > 0 and abs(d.y) <= 2.2): continue   # our lane\n"
                "        b = best.setdefault(d.id, {'gap': d.gap, 'by': {}, 'sensors': set()})\n"
                "        b['by'][sensor] = d.gap; b['sensors'].add(sensor)\n"
                "        b['gap'] = min(b['gap'], d.gap)\n"
                "        if sensor in ('radar', 'V2V'): b['v_rel'] = d.v_rel\n"
                "target = min(best.values(), key=gap)\n"
                "target.v_lead = v + target.v_rel if has_v_rel else \\\n"
                "                0.6 * prev.v_lead + 0.4 * (v - (prev.gap - gap) / dt)",
        "libs": [("Python", "dicts and sets — no filter library")],
        "params": [("Lane half-width", f"{ft.CORRIDOR_HALF_M:g} m", "follow_test.CORRIDOR_HALF_M"),
                   ("Hold", f"{ft.HOLD_S:g} s", "follow_test.HOLD_S"), ("Prediction", "4 s", "shipyard.MapWindow.PREDICT_S")],
        "timing": "Every 100 ms per truck; negligible.",
        "pros": ["Simple, transparent, conservative (nearest wins)", "Shows which sensors saw the target"],
        "cons": ["Association by scene id is perfect (a real system matches by position)", "No accuracy weighting / "
                 "Kalman filter", "Only the nearest object in the lane (no cut-in prediction)"],
        "verify": ["Truck card: the sensor icons that see the target and each one's distance"]},
    "fusion_real": {
        "summary": "<b>Track-level fusion by position</b>: each sensor's tracker gives tracks (C…, L…, R…); they are placed "
                   "at their measured positions, tested against our lane, and the nearest confirmed one is the target. "
                   "Names come only from matching to the truth for the reports.",
        "pipeline": [("Trackers", "real_sensors.Tracker × 3", "camera C (2/3), LiDAR L (2/3), radar R (3/4)"),
                     ("To detections", "real_sensors.to_dets", "track → gap, lateral offset, v_rel"),
                     ("Lane test", "real_sensors.lane_offset", "its edge within our width + 0.3 m of the route"),
                     ("Plausibility", "shipyard._real_detect", "a standing camera-only object needs LiDAR / radar"),
                     ("Target", "Follower.perceive", "nearest in the lane (unknown objects too)"),
                     ("Names", "real_sensors.match_truth", "for cards and reports only")],
        "code": "for sensor, trk in trackers.items():\n"
                "    trk.update(t, measurements[sensor])        # predict, associate, alpha-beta\n"
                "    dets[sensor] = to_dets(trk.confirmed(t), me, L, scene, sensor)\n"
                "dets['camera'] = [d for d in dets['camera']\n"
                "                  if d.moving or confirmed_by(d, dets['LiDAR'], dets['radar'])]\n"
                "target = ctl.perceive(t, dets['LiDAR'], dets['camera'], radar_dets=dets['radar'])",
        "libs": [("Python", "nearest-neighbour association, alpha-beta filter")],
        "params": [("Lane margin", "0.3 m", "real_sensors.LANE_MARGIN_M"), ("Trackers", "C 2/3 · L 2/3 · R 3/4",
                                                                            "shipyard (real-world set-up)")],
        "timing": "Every 100 ms per truck; negligible.",
        "pros": ["No scene ids in the decision — phantoms are braked for, as on a real truck", "Each track is scored "
                 "against the truth (matched / unknown)"],
        "cons": ["Alpha-beta filter, no covariance (no Kalman)", "Per-sensor tracks, merged by the nearest in lane"],
        "verify": ["Cards show 'unknown object L5' for an unmatched track", "Reports: matched vs phantom tracks"]},

    # ------------------------------------------------------------------ braking
    "brake": {
        "summary": "<b>A rule-based longitudinal controller</b> (follow_test.Follower.step) on the perceived target: "
                   "keeps the set gap, brakes as hard as needed to stop short, full brake (AEB) at a critical TTC; "
                   "speed integrated every 100 ms.",
        "pipeline": [("Target", "Follower.step", f"used while younger than {ft.HOLD_S:g} s; its gap advanced by the "
                                                 "closing speed since the detection"),
                     ("TTC", "Follower._update_ttc", "gap ÷ closing speed (closing > 0.3 m/s)"),
                     ("AEB", "Follower.step", f"TTC < {ft.TTC_CRIT_S:g} s → −a_full (= {ft.A_FULL:g} m/s² × grip)"),
                     ("Needed deceleration", "Follower.step", f"a_req = closing² ÷ (2 × (gap − {ft.STOP_GAP_M:g})); "
                                                               f"≥ {ft.A_COMFORT:g} → brake 1.15 × a_req"),
                     ("Follow", "Follower.step", f"want = v_lead + {ft.GAP_GAIN:g} × (gap − set gap); accel ≤ "
                                                 f"{ft.ACCEL:g}, decel ≤ {ft.A_COMFORT:g} m/s²"),
                     ("Integrate", "Follower.step", "v = clip(v + a × dt, 0, v_max)"),
                     ("Ground truth", "Follower.truth", "the real TTC kept next to the perceived one")],
        "code": "if target is None:\n"
                "    a = clip(1.0 * (v_max - v), -A_COMFORT, ACCEL)        # drive on\n"
                "else:\n"
                "    d = tg.gap - (v - tg.v_lead) * (t - tg.t)\n"
                "    closing = v - tg.v_lead\n"
                "    ttc = d / closing if closing > 0.3 else None\n"
                "    a_req = closing**2 / (2 * (d - STOP_GAP)) if closing > 0 else 0\n"
                "    if ttc and ttc < TTC_CRIT:  a = -a_full              # AEB\n"
                "    elif a_req >= A_COMFORT:     a = -min(a_full, 1.15 * a_req)\n"
                "    else:\n"
                "        want = clip(tg.v_lead + GAP_GAIN * (d - gap_set), 0, v_max)\n"
                "        a = clip(want - v, -A_COMFORT, ACCEL)\n"
                "v = clip(v + a * dt, 0, v_max)                            # dt = 0.1 s",
        "libs": [("Python math", "the controller")],
        "params": [("Full brake", f"{ft.A_FULL:g} m/s² × road grip", "follow_test.A_FULL, road_grip"),
                   ("Comfort / accel", f"{ft.A_COMFORT:g} / {ft.ACCEL:g} m/s²", "A_COMFORT, ACCEL"),
                   ("TTC warning / critical", f"{ft.TTC_WARN_S:g} / {ft.TTC_CRIT_S:g} s", "TTC_WARN_S, TTC_CRIT_S"),
                   ("Stop gap", f"{ft.STOP_GAP_M:g} m", "STOP_GAP_M"), ("Gap gain", f"{ft.GAP_GAIN:g} 1/s", "GAP_GAIN")],
        "timing": "Every 100 ms per truck; negligible.",
        "pros": ["Transparent rules — every braking is explained in the log", "Grip per climate changes the stopping "
                 "distance"],
        "cons": ["Braking acts at once (no actuator delay)", "Point-mass model: no load, no tyres, no steering",
                 "No planning ahead (MPC)"],
        "verify": ["Log: 'FULL BRAKE (AEB, TTC 1.2 s)', TTC warnings", "Results: full brakes, lowest TTC per loop"]},

    # ------------------------------------------------------------------ topics without options
    "climate": {
        "summary": "<b>One climate record drives every sensor model</b> (config/climates.json): visibility, day / night, "
                   "rain / snow rate, LiDAR extinction / noise / clutter, radar extra loss, road grip. The 3D page "
                   "renders the same climate (fog, rain, night) for the pictures.",
        "pipeline": [("Climate record", "config/climates.json → site_config.CLIMATES", "chosen in the toolbar / per "
                                                                                       "loop in a test plan"),
                     ("Camera", "follow_test.camera_range", "½ visibility, night × 0.45, rain / snow loss"),
                     ("LiDAR", "yard3d.html (CLIMATE.lidar)", "per-ray survival exp(−2·ext·r), noise, clutter"),
                     ("Radar", "follow_test.radar_losses_db", "rain ITU-R P.838, snow, fog, spray, radome"),
                     ("V2V", "v2v.Channel.step", "heavy rain +3 % loss; fog nothing"),
                     ("Braking", "follow_test.road_grip", "full brake × grip (rain 0.7, snow 0.6, fog 0.9)")],
        "code": "{\"id\": \"dense_fog\", \"visibility_m\": 40, \"day\": true,\n"
                " \"lidar\": {\"extinction_per_m\": 0.075, \"noise_m\": 0.02, \"clutter\": 0.02},\n"
                " \"radar\": {\"extra_loss_db\": 0}, \"road_grip\": 0.9}",
        "libs": [("JSON", "the climate records"), ("three.js fog / particles", "the rendered look")],
        "params": [("All values", "per climate", "config/climates.json")],
        "timing": "Read once; applied every step.",
        "pros": ["One source for every sensor — consistent", "Easy to add a climate (a JSON entry)"],
        "cons": ["One value per climate (no patches of fog)", "Rendering and models are separate (the picture may look "
                 "different from the model's range)"],
        "verify": ["Climate effects topic: the table of each sensor's range per climate"]},
    "collision": {
        "summary": "<b>Ground truth is computed separately from perception</b> every step: the real nearest object in "
                   "the truck's lane and its real gap. Touching while moving = a collision record with every sensor's "
                   "view, the camera shots, the 3D scene and an automatic reason.",
        "pipeline": [("Truth", "shipyard._route_tick", "objects on our path ahead, |y| ≤ 2.2 m; gap = x − L/2 − its L/2"),
                     ("Touch", "shipyard._route_tick", "gap ≤ 0.2 m, moving > 0.05 m/s, not already in contact"),
                     ("Record", "shipyard._ctest_record_collision", "speeds, each sensor's last detection, camera "
                                                                    "picture, 3D accident scene, log"),
                     ("Hold", "shipyard._route_tick", "both stand hold_s seconds"),
                     ("Reason", "collision report", "climate / hidden obstacle / seen too late / setup — from the facts"),
                     ("V2V proof", "shipyard._v2v_episode", "'prevented by V2V' when only V2V knew in time")],
        "code": "truth = [obj for obj in on_trail(ahead) if abs(obj.y) <= 2.2]\n"
                "near = min(truth, key=gap)\n"
                "if near.gap <= 0.2 and v > 0.05 and contact != near.id:\n"
                "    record_collision(truck, near, sensors_snapshot, camera_shot, scene_3d)\n"
                "    hold(truck, hold_s); hold(near, hold_s)",
        "libs": [("Python", "the checks"), ("three.js", "the 3D accident scene"), ("JSON", "the saved report")],
        "params": [("Touch distance", "0.2 m", "shipyard._route_tick"), ("Hold", "setup", "collision test setup")],
        "timing": "Every 100 ms per truck.",
        "pros": ["Judging is independent of what the sensors saw", "Every collision is fully documented"],
        "cons": ["Bodies are rectangles (no exact shapes)", "100 ms steps: the touch moment is within one step"],
        "verify": ["Collisions ▸ in the test window; the results summary; Reports → Collision tests"]},
    "real": {
        "summary": "<b>The real-world set-up replaces each sensor's model with processing of its own measurements</b>: "
                   "camera pictures (numpy free-space method), unlabelled LiDAR points (grid clustering), radar echoes "
                   "(beam scan + CFAR); then per-sensor trackers. Pick Camera / LiDAR / Radar / Fusion with this set-up "
                   "for each one's details.",
        "pipeline": [("Camera", "real_camera.detect", "picture → road model → column scan → distance → objects"),
                     ("LiDAR", "real_sensors.lidar_clusters", "points → weather filter → grid clusters → nearest point"),
                     ("Radar", "real_sensors.radar_scan / radar_clusters", "beams → echoes → CFAR → clusters"),
                     ("Tracking", "real_sensors.Tracker", "C…, L…, R… tracks"),
                     ("Scoring", "real_sensors.match_truth", "tracks matched to the truth for the reports")],
        "code": "mode = app_settings['collision_sensors']['mode']   # 'sim' | 'real'\n"
                "if mode == 'real':\n"
                "    dets = _real_detect(truck, ...)               # trackers C / L / R\n"
                "else:\n"
                "    dets = simulated models (follow_test)",
        "libs": [("numpy", "camera pictures"), ("Python", "clustering, CFAR, trackers"), ("three.js", "pictures + "
                                                                                                   "point clouds")],
        "params": [("Set-up", "sim / real", "config/app_settings.json collision_sensors.mode")],
        "timing": "Slower: every truck's camera picture is rendered (~1 / s per truck).",
        "pros": ["Tests perception too: misses, phantoms, wrong distances"], "cons": ["Slower; rendered pictures are "
                                                                                       "cleaner than real ones"],
        "verify": ["The test window shows REAL-WORLD sensors; the reports record the set-up"]},
}


def generic(m, used):
    """The technical overview of an option NOT in our app: how it would be added (from its method data)."""
    comp = m.get("compare") or []
    return {
        "summary": f"<b>Not in our app yet.</b> {m.get('note', '')} The tests use <b>{used.get('short', '')}</b>.",
        "pipeline": [("Step", "to add", n) for n in (m.get("needs") or [])],
        "code": None,
        "how": m.get("how", ""),
        "libs": [],
        "params": [],
        "timing": "",
        "pros": [f"{a}: {it}" for a, _now, it in comp],
        "cons": [f"{a}: today {now}" for a, now, _it in comp],
        "verify": [],
        "effort": f"{m.get('cplx') or '?'} complexity — {m.get('effort', '')}",
        "generic": True}


def for_option(key, opt, used):
    """The technical overview for a topic (no option) or the picked option."""
    if opt is None:
        return TECH.get(key)
    if not opt.get("ok"):
        return generic(opt, used or {})
    return TECH.get(opt.get("deck")) or TECH.get(key)
