"""Collision testing -> hardware: each chosen AV's (autonomous vehicle's) live state as an MQTT message on a topic
of its own.

Used to drive real model vehicles (e.g. an ESP32 board + motors) the same way as the AVs of the test: the board
subscribes to its AV's topic and sets its motor speed / brake / steering from the message.

  topic   <prefix>/av<N>           N = the AV's place in the test (1 = the front AV) -- or a topic of its own
          <prefix>/status          retained: online / the test's AVs and topics; "offline" if the app goes away
  payload JSON, ~450 bytes (fits ArduinoJson on an ESP32), sent <rate> times a second (default 10):

  {"v": 1, "seq": 812, "ts": 1763456789123, "test": "ctest:1763456700000", "av": 1, "truck": 1, "id": "...",
   "name": "AV 1", "status": "running",              running | paused | held (after a collision) | finished | ended
   ("truck": the same number as "av" -- kept for listeners made before the AV naming)
   "lat": 8.55312, "lon": 76.88101, "heading": 87.3,  degrees clockwise from north
   "x": 12.3, "y": -4.5,                              metres east / north of the route's start (for a small track)
   "speed": 8.33, "kmh": 30.0, "top_kmh": 30.0, "speed_pct": 100,   speed_pct: of its top speed (motor PWM)
   "accel": -1.2, "yaw_rate": 3.4,                    m/s², degrees/s (+ = turning right)
   "brake": 1, "brake_pct": 45, "brake_mode": "braking",   none | braking | full | aeb | stop_go | hold
   "throttle_pct": 0, "state": "braking for AV 1",
   "ahead": {"name": "AV 1", "gap": 12.3, "ttc": 3.2, "by": ["LiDAR", "radar"]},   or null
   "route": {"name": "Quest_path", "s": 123.4, "total": 905.2, "loop": 1}}

On End test every AV gets one last message with status "ended", speed 0 and the brake on -- the hardware must
also stop by itself when no message came for ~1 s (connection lost). The publisher has its own MQTT connection
(not the app's MQTT switch / broker), so it can use a local broker on the same network as the boards.
"""
import json
import math
import threading
import time

try:
    import paho.mqtt.client as mqtt
except Exception:                                    # (shown in the dialog)
    mqtt = None

DEFAULTS = {"host": "localhost", "port": 1883, "tls": False, "ca": "", "username": "", "prefix": "yardsim/hw",
            "rate_hz": 10, "qos": 0, "trucks": [1, 2, 3], "topics": {}}
RATES = (1, 2, 5, 10, 20)
# free public brokers for a quick test (no login; ANYONE can read / write the topics -- test data only)
PUBLIC_BROKERS = [("test.mosquitto.org", 1883, "Eclipse Mosquitto test broker"),
                  ("broker.hivemq.com", 1883, "HiveMQ public broker"),
                  ("broker.emqx.io", 1883, "EMQX public broker")]


def unique_prefix():
    """A topic prefix nobody else uses on a public broker (yardsim/<6 letters>/hw)."""
    import random
    import string
    return "yardsim/" + "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(6)) + "/hw"
_SESSION_PW = {"pw": ""}                             # (the password is never saved: kept while the app runs)


def settings():
    try:
        import site_config as cfg
        s = dict((cfg.APP_SETTINGS or {}).get("hw_publish") or {})
    except Exception:
        s = {}
    out = dict(DEFAULTS, **{k: v for k, v in s.items() if k in DEFAULTS})
    out["password"] = _SESSION_PW["pw"]
    return out


def save_settings(s):
    _SESSION_PW["pw"] = s.get("password") or ""
    try:
        import site_config as cfg
        cfg.save_app_settings_section("hw_publish", {k: s[k] for k in DEFAULTS if k in s})
    except Exception as e:
        print("[hw publish] settings not saved:", e)


def topic_of(cfg_, n):
    """The topic of the test's AV n (1 = front)."""
    t = (cfg_.get("topics") or {}).get(str(n))
    return t.strip() if t and t.strip() else f"{cfg_.get('prefix', DEFAULTS['prefix']).rstrip('/')}/av{n}"


def _client(cid):
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid)
    except AttributeError:                           # (paho-mqtt 1.x)
        return mqtt.Client(client_id=cid)


class Publisher:
    """Its own MQTT connection; publish(states) from the GUI thread, the network in paho's thread."""

    def __init__(self, cfg_, test_id, route=""):
        self.cfg = dict(cfg_)
        self.test_id, self.route = test_id, route
        self.connected = False
        self.error = ""
        self.sent = 0
        self.failed = 0
        self.seq = {}
        self.last = {}                               # AV n -> last payload (dict)
        self._prev = {}                              # AV n -> (t, heading) for the yaw rate
        self._lock = threading.Lock()
        self.status_topic = f"{self.cfg['prefix'].rstrip('/')}/status"
        if mqtt is None:
            self.error = "paho-mqtt is not installed (pip install paho-mqtt)"
            self.client = None
            return
        self.client = _client(f"yardsim-hw-{int(time.time() * 1000) % 10 ** 9}")
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        if self.cfg.get("username"):
            self.client.username_pw_set(self.cfg["username"], self.cfg.get("password") or None)
        if self.cfg.get("tls"):
            try:
                self.client.tls_set(ca_certs=self.cfg.get("ca") or None)
            except Exception as e:
                self.error = f"TLS: {e}"
        self.client.will_set(self.status_topic, json.dumps({"online": False, "test": test_id}), qos=1, retain=True)
        self.client.reconnect_delay_set(1, 5)
        try:
            self.client.connect_async(self.cfg["host"], int(self.cfg["port"]), keepalive=15)
            self.client.loop_start()
        except Exception as e:
            self.error = str(e)

    # paho callbacks (its thread; v1 / v2 signatures)
    def _on_connect(self, _c, _u, _f, rc, *_a):
        ok = (rc == 0) if isinstance(rc, int) else not getattr(rc, "is_failure", False)
        self.connected = bool(ok)
        self.error = "" if ok else f"broker refused: {rc}"
        if ok:
            self._status(True)

    def _on_disconnect(self, *_a):
        if self.connected and not getattr(self, "_closing", False):
            self.error = "connection lost -- reconnecting"
        self.connected = False

    def _status(self, online, trucks=None):
        if trucks is not None:
            self._trucks = trucks
        msg = {"online": bool(online), "test": self.test_id, "route": self.route, "rate_hz": self.cfg["rate_hz"],
               "ts": int(time.time() * 1000),
               "avs": [{"av": n, "topic": topic_of(self.cfg, n), "name": nm}
                       for n, nm in getattr(self, "_trucks", [])]}
        msg["trucks"] = [{"truck": a["av"], "topic": a["topic"], "name": a["name"]} for a in msg["avs"]]   # (older)
        try:
            self.client.publish(self.status_topic, json.dumps(msg), qos=1, retain=True)
        except Exception:
            pass

    def announce(self, trucks):
        """AVs = [(n, name)] -- in the retained status message."""
        self._trucks = list(trucks)
        if self.connected:
            self._status(True)

    def payload(self, st, status):
        """st: {n, id, name, lat, lon, heading, x, y, v, a, v_max, a_full, state, hold, stop_go, target, ttc, route}"""
        n = st["n"]
        now = time.time()
        v = 0.0 if status in ("paused", "ended", "finished", "held") else max(0.0, st["v"])
        # yaw rate = speed x the road's curvature here (st["curv"], deg / m) -- not from heading jumps between
        # route points
        yaw = max(-90.0, min(90.0, v * float(st.get("curv") or 0.0))) if v > 0.2 else 0.0
        a = st["a"] if status == "running" else 0.0
        a_full = max(0.5, st.get("a_full") or 6.0)
        state = st.get("state") or ""
        if status in ("ended", "finished", "held", "paused"):
            bmode, bpct = "hold", 100
        elif st.get("stop_go") and "stop and go" in state:
            bmode, bpct = "stop_go", int(min(100, max(0.0, -a) / a_full * 100)) if a < 0 else (100 if v < 0.05 else 0)
        elif "AEB" in state:
            bmode, bpct = "aeb", 100
        elif "FULL BRAKE" in state:
            bmode, bpct = "full", 100
        elif a < -0.3:
            bmode, bpct = "braking", int(min(100, -a / a_full * 100))
        elif v < 0.05 and st.get("target"):
            bmode, bpct = "hold", 100                 # (stopped behind something: brake held)
        else:
            bmode, bpct = "none", 0
        tg = st.get("target")
        seq = self.seq[n] = self.seq.get(n, 0) + 1
        v_max = max(0.1, st.get("v_max") or 0.1)
        return {"v": 1, "seq": seq, "ts": int(now * 1000), "test": self.test_id, "av": n, "truck": n, "id": st.get("id"),
                "name": st.get("name"), "status": status,
                "lat": round(st["lat"], 7), "lon": round(st["lon"], 7), "heading": round(st["heading"] % 360.0, 1),
                "x": round(st.get("x", 0.0), 2), "y": round(st.get("y", 0.0), 2),
                "speed": round(v, 2), "kmh": round(v * 3.6, 1), "top_kmh": round(v_max * 3.6, 1),
                "speed_pct": int(round(min(100.0, v / v_max * 100))),
                "accel": round(a, 2), "yaw_rate": round(yaw, 1),
                "brake": 1 if bpct > 0 else 0, "brake_pct": bpct, "brake_mode": bmode,
                "throttle_pct": int(min(100, max(0.0, a) / 1.5 * 100)) if status == "running" else 0,
                "state": state[:60],
                "ahead": ({"name": tg.get("label"), "gap": round(float(tg.get("gap", 0.0)), 1),
                           "ttc": round(st["ttc"], 1) if st.get("ttc") is not None else None,
                           "by": sorted(tg.get("sensors") or [])} if tg else None),
                "route": st.get("route")}

    def publish(self, states):
        """states = [(st, status)] -- one message per AV on its own topic."""
        if self.client is None:
            return
        for st, status in states:
            msg = self.payload(st, status)
            self.last[st["n"]] = msg
            if not self.connected:
                continue
            try:
                r = self.client.publish(topic_of(self.cfg, st["n"]), json.dumps(msg, separators=(",", ":")),
                                        qos=int(self.cfg.get("qos", 0)))
                if r.rc == 0:
                    self.sent += 1
                else:
                    self.failed += 1
            except Exception as e:
                self.failed += 1
                self.error = str(e)

    def close(self, states=None):
        """The last message of each AV (status ended: stop) and the retained status offline."""
        if self.client is None:
            return
        self._closing = True
        try:
            if states and self.connected:
                for st, _s in states:
                    msg = self.payload(st, "ended")
                    m = self.client.publish(topic_of(self.cfg, st["n"]), json.dumps(msg, separators=(",", ":")), qos=1)
                    try:
                        m.wait_for_publish(0.5)
                    except Exception:
                        pass
            if self.connected:
                m = self.client.publish(self.status_topic, json.dumps({"online": False, "test": self.test_id,
                                                                       "ts": int(time.time() * 1000)}),
                                        qos=1, retain=True)
                try:
                    m.wait_for_publish(1.0)
                except Exception:
                    pass
            self.client.disconnect()
            self.client.loop_stop()
        except Exception as e:
            print("[hw publish] close:", e)

    def summary(self):
        n = len(self.last)
        if self.error and not self.connected:
            return f"MQTT ✖ {self.error}", "#EF4444"
        if not self.connected:
            return f"MQTT … connecting to {self.cfg['host']}:{self.cfg['port']}", "#FBBF24"
        return f"MQTT ▸ {n} AV{'s' if n != 1 else ''} ·{self.cfg['rate_hz']} Hz · {self.sent} sent", "#22D3EE"


def local_xy(lat0, lon0, lat, lon):
    kx = 111320.0 * math.cos(math.radians(lat0))
    return (lon - lon0) * kx, (lat - lat0) * 111320.0


# ---------------------------------------------------------------------------------------------- the set-up dialog
def test_connection(s, timeout=4.0):
    """(ok, text) -- connects once and publishes nothing."""
    if mqtt is None:
        return False, "paho-mqtt is not installed"
    res = {}
    ev = threading.Event()
    c = _client(f"yardsim-hwtest-{int(time.time() * 1000) % 10 ** 9}")

    def on_c(_c, _u, _f, rc, *_a):
        res["rc"] = rc
        ev.set()
    c.on_connect = on_c
    try:
        if s.get("username"):
            c.username_pw_set(s["username"], s.get("password") or None)
        if s.get("tls"):
            c.tls_set(ca_certs=s.get("ca") or None)
        c.connect_async(s["host"], int(s["port"]), keepalive=10)
        c.loop_start()
        ev.wait(timeout)
    except Exception as e:
        return False, str(e)
    finally:
        try:
            c.disconnect(); c.loop_stop()
        except Exception:
            pass
    if "rc" not in res:
        return False, f"no answer from {s['host']}:{s['port']} in {timeout:.0f} s"
    rc = res["rc"]
    ok = (rc == 0) if isinstance(rc, int) else not getattr(rc, "is_failure", False)
    return ok, ("connected" if ok else f"refused: {rc}")


def make_dialog(parent, trucks, current, in_test=False):
    """AVs = [(n, label)] of the setup; current = settings (+ "on"). in_test: opened from the running test's
    window (no 'start at once' choice -- its MQTT button starts / stops). -> PublishDialog."""
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                                 QLineEdit, QPushButton, QSpinBox, QVBoxLayout, QApplication)

    class PublishDialog(QDialog):
        def __init__(self):
            super().__init__(parent)
            self.setWindowTitle("Publish AV data to hardware (MQTT)")
            self.setModal(True)
            self.setStyleSheet("""
                QDialog { background: #0B1220; } QLabel { color: #E5E7EB; background: transparent; }
                QLabel#muted { color: #94A3B8; font-size: 11px; }
                QFrame#pane { background: #0F172A; border: 1px solid #334155; border-radius: 10px; }
                QLineEdit, QSpinBox, QComboBox { background: #111827; color: #E5E7EB; border: 1px solid #334155;
                    border-radius: 6px; padding: 4px 6px; }
                QComboBox QAbstractItemView { background: #0F172A; color: #E5E7EB; }
                QCheckBox { color: #E5E7EB; }
                QPushButton { background: #1F2937; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px;
                              padding: 6px 14px; }
                QPushButton:hover { background: #273449; }""")
            s = dict(current)
            lay = QVBoxLayout(self); lay.setContentsMargins(16, 14, 16, 14); lay.setSpacing(10)
            h = QLabel("<span style='font-size:16px; font-weight:800; color:#22D3EE'>Publish to hardware</span><br>"
                       "<span style='color:#94A3B8'>While the test runs, each chosen AV's speed, position "
                       "(lat, lon, heading), brake state and more go out as an MQTT message on its own topic, "
                       "e.g. for ESP32 model vehicles.</span>")
            h.setTextFormat(Qt.RichText); h.setWordWrap(True); lay.addWidget(h)
            self.on = QCheckBox("Start publishing at once when the test starts (otherwise: start / stop it with the "
                                "📡 MQTT button in the test window -- it is OFF by default)")
            self.on.setChecked(bool(s.get("on")))
            self.on.setStyleSheet("font-weight: 700;")
            self.on.setVisible(not in_test)
            lay.addWidget(self.on)
            # broker
            b = QFrame(); b.setObjectName("pane"); g = QGridLayout(b); g.setContentsMargins(12, 10, 12, 10)
            g.setHorizontalSpacing(8); g.setVerticalSpacing(6)
            g.addWidget(QLabel("<b>Broker</b>"), 0, 0)
            self.host = QLineEdit(str(s["host"])); self.host.setPlaceholderText("e.g. 192.168.1.20 (a PC on the "
                                                                              "boards' Wi-Fi)")
            self.port = QSpinBox(); self.port.setRange(1, 65535); self.port.setValue(int(s["port"]))
            g.addWidget(self.host, 0, 1, 1, 2); g.addWidget(self.port, 0, 3)
            self.tls = QCheckBox("TLS"); self.tls.setChecked(bool(s.get("tls")))
            self.ca = QLineEdit(str(s.get("ca") or "")); self.ca.setPlaceholderText("CA certificate (TLS, optional)")
            cab = QPushButton("Browse")
            cab.clicked.connect(lambda: self.ca.setText(QFileDialog.getOpenFileName(self, "CA certificate", "",
                                                                                     "Certificates (*.crt *.pem);;All (*)")[0]
                                                        or self.ca.text()))
            g.addWidget(self.tls, 1, 0); g.addWidget(self.ca, 1, 1, 1, 2); g.addWidget(cab, 1, 3)
            self.user = QLineEdit(str(s.get("username") or "")); self.user.setPlaceholderText("username (optional)")
            self.pw = QLineEdit(str(s.get("password") or "")); self.pw.setEchoMode(QLineEdit.Password)
            self.pw.setPlaceholderText("password (not saved)")
            g.addWidget(QLabel("Login"), 2, 0); g.addWidget(self.user, 2, 1); g.addWidget(self.pw, 2, 2, 1, 2)
            self.pubb = QComboBox()
            self.pubb.addItem("Free public test broker …", None)
            for h_, p_, n_ in PUBLIC_BROKERS:
                self.pubb.addItem(f"{h_}:{p_}  ({n_})", (h_, p_))
            self.pubb.setToolTip("Free public brokers for a quick test without your own broker -- no login, but "
                                 "ANYONE can read the topics: test data only. A unique topic prefix is set so "
                                 "others' data does not mix in. The ESP32 / test app must use the same broker and "
                                 "prefix.")
            self.pubb.activated.connect(self._public)
            tb = QPushButton("Test connection"); tb.clicked.connect(self._test)
            self.tres = QLabel(); self.tres.setObjectName("muted")
            hb = QHBoxLayout(); hb.addWidget(self.pubb); hb.addWidget(tb)
            hb.addWidget(self.tres, 1)
            g.addLayout(hb, 3, 0, 1, 4)
            self.pub_warn = QLabel("⚠ Public broker: anyone can read these messages and publish to these topics -- "
                                   "use it only for testing (no confidential data). Use the same broker + prefix in "
                                   "the ESP32 and the test app.")
            self.pub_warn.setWordWrap(True)
            self.pub_warn.setStyleSheet("color: #FBBF24; font-size: 11px;")
            g.addWidget(self.pub_warn, 4, 0, 1, 4)
            self.host.textChanged.connect(lambda h_: self.pub_warn.setVisible(
                h_.strip() in [b[0] for b in PUBLIC_BROKERS]))
            self.pub_warn.setVisible(str(s["host"]).strip() in [b[0] for b in PUBLIC_BROKERS])
            g.setColumnStretch(1, 1); g.setColumnStretch(2, 1)
            lay.addWidget(b)
            # topics + rate
            t = QFrame(); t.setObjectName("pane"); tg = QGridLayout(t); tg.setContentsMargins(12, 10, 12, 10)
            tg.setHorizontalSpacing(8); tg.setVerticalSpacing(6)
            tg.addWidget(QLabel("<b>Topic prefix</b>"), 0, 0)
            self.prefix = QLineEdit(str(s["prefix"])); tg.addWidget(self.prefix, 0, 1, 1, 2)
            self.rate = QComboBox()
            for r in RATES:
                self.rate.addItem(f"{r} messages / s per AV", r)
            self.rate.setCurrentIndex(max(0, self.rate.findData(int(s.get("rate_hz", 10)))))
            tg.addWidget(self.rate, 0, 3)
            self.qos = QComboBox(); self.qos.addItem("QoS 0 (fastest)", 0); self.qos.addItem("QoS 1", 1)
            self.qos.setCurrentIndex(max(0, self.qos.findData(int(s.get("qos", 0)))))
            tg.addWidget(self.qos, 0, 4)
            tg.addWidget(QLabel("<b>AVs</b>"), 1, 0, Qt.AlignTop)
            self.rows = []
            chosen = set(int(x) for x in (s.get("trucks") or []))
            topics = dict(s.get("topics") or {})
            for i, (n, lab) in enumerate(trucks):
                c = QCheckBox(f"AV {n}" + (" · front" if n == 1 else "") + f"  —  {lab}")
                c.setChecked(n in chosen)
                e = QLineEdit(topics.get(str(n), ""))
                e.setPlaceholderText(f"{s['prefix'].rstrip('/')}/av{n}")
                tg.addWidget(c, 1 + i, 1, 1, 2); tg.addWidget(e, 1 + i, 3, 1, 2)
                self.rows.append((n, c, e))
            self.prefix.textChanged.connect(lambda p: [e.setPlaceholderText(f"{p.rstrip('/')}/av{n}")
                                                       for n, _c, e in self.rows])
            note = QLabel("Topic per AV: empty = &lt;prefix&gt;/av&lt;N&gt; (N = its place in the test, 1 = front). "
                          "Status (retained): &lt;prefix&gt;/status. Hardware: stop when no message came for 1 s or "
                          "status is ended.")
            note.setObjectName("muted"); note.setWordWrap(True); note.setTextFormat(Qt.RichText)
            tg.addWidget(note, 2 + len(trucks), 0, 1, 5)
            tg.setColumnStretch(1, 1); tg.setColumnStretch(3, 1)
            lay.addWidget(t)
            ex = QLabel("<span style='color:#94A3B8; font-size:11px'>Message (JSON): "
                        "<code>{\"av\":1,\"status\":\"running\",\"lat\":8.55312,\"lon\":76.88101,\"heading\":87.3,"
                        "\"kmh\":30.0,\"speed_pct\":100,\"accel\":-1.2,\"yaw_rate\":3.4,\"brake\":1,\"brake_pct\":45,"
                        "\"brake_mode\":\"braking\",\"ahead\":{\"name\":\"AV 1\",\"gap\":12.3,\"ttc\":3.2}, …}"
                        "</code> — all fields: README → Publish to hardware.</span>")
            ex.setTextFormat(Qt.RichText); ex.setWordWrap(True); lay.addWidget(ex)
            bb = QHBoxLayout(); bb.addStretch()
            c = QPushButton("Cancel"); c.clicked.connect(self.reject); bb.addWidget(c)
            ok = QPushButton("OK"); ok.setStyleSheet("background:#155E75; border-color:#22D3EE; font-weight:700;")
            ok.clicked.connect(self.accept); ok.setDefault(True); bb.addWidget(ok)
            lay.addLayout(bb)
            self.resize(760, 0)

        def _public(self, _i=None):
            hp = self.pubb.currentData()
            self.pubb.setCurrentIndex(0)
            if not hp:
                return
            self.host.setText(hp[0]); self.port.setValue(int(hp[1]))
            self.tls.setChecked(False); self.ca.clear(); self.user.clear(); self.pw.clear()
            if self.prefix.text().strip().strip("/") in ("", DEFAULTS["prefix"]):
                self.prefix.setText(unique_prefix())          # (shared by everyone: a prefix of its own)
            self.tres.setText("public broker set -- Test connection to check it")

        def _test(self):
            self.tres.setText("connecting …"); QApplication.processEvents()
            ok, txt = test_connection(self.values())
            self.tres.setText(f"<span style='color:{'#34D399' if ok else '#F87171'}'>{'✔' if ok else '✖'} {txt}</span>")
            self.tres.setTextFormat(Qt.RichText)

        def values(self):
            return {"on": self.on.isChecked(), "host": self.host.text().strip() or "localhost",
                    "port": self.port.value(), "tls": self.tls.isChecked(), "ca": self.ca.text().strip(),
                    "username": self.user.text().strip(), "password": self.pw.text(),
                    "prefix": self.prefix.text().strip().strip("/") or DEFAULTS["prefix"],
                    "rate_hz": int(self.rate.currentData()), "qos": int(self.qos.currentData()),
                    "trucks": [n for n, c, _e in self.rows if c.isChecked()],
                    "topics": {str(n): e.text().strip() for n, _c, e in self.rows if e.text().strip()}}

    return PublishDialog()
