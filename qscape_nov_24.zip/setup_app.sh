#!/usr/bin/env bash
# Q-SCAPE -- one-time set-up: the app's own Python environment (.venv in this folder) and its packages.
#   Ubuntu:   bash setup_app.sh
#   Windows:  in Git Bash:  bash setup_app.sh        (or double-click setup_app.bat -- no Git Bash needed)
# Nothing is installed on the machine itself (no sudo / admin): everything goes into ./.venv.
# Then start the app with:  bash run_app.sh   (Windows: run_app.bat)
cd "$(dirname "$0")" || exit 1
export PYTHONNOUSERSITE=1                        # (~/.local packages: not used)
unset PYTHONPATH
warn() { echo "WARNING: $*" >&2; }
die() { echo "ERROR: $*" >&2; exit 1; }

case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) OS=windows ;;
  *) OS=linux ;;
esac

# ---------------------------------------------------------------- 1. Python 3.8 .. 3.12
echo "== 1/3  Python =="
PY=""
for c in python3 python py; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if (3, 8) <= sys.version_info[:2] <= (3, 12) else 1)' \
       >/dev/null 2>&1; then PY="$c"; break; fi
done
[ -n "$PY" ] || die "Python 3.8 - 3.12 not found (Ubuntu: sudo apt install python3 python3-venv; Windows: python.org)."
echo "  $("$PY" -c 'import sys; print(sys.executable, sys.version.split()[0])')"

# ---------------------------------------------------------------- 2. .venv + packages
echo "== 2/3  .venv and packages (pip, into .venv only) =="
rm -rf .venv                                     # (a .venv copied from another machine / OS: made again)
if ! "$PY" -m venv .venv >/dev/null 2>&1; then
  # Ubuntu without python3-venv: a .venv without pip, then pip downloaded into it
  rm -rf .venv
  "$PY" -m venv --without-pip .venv || die "could not create .venv"
  echo "  (python3-venv is not installed: pip is downloaded into .venv instead)"
  .venv/bin/python -c "import urllib.request; urllib.request.urlretrieve('https://bootstrap.pypa.io/get-pip.py', '.venv/get-pip.py')" \
    || die "could not download pip (internet / proxy?)"
  .venv/bin/python .venv/get-pip.py --no-warn-script-location || die "could not install pip into .venv"
  rm -f .venv/get-pip.py
fi
if [ "$OS" = windows ]; then VPY=.venv/Scripts/python.exe; else VPY=.venv/bin/python; fi
[ -x "$VPY" ] || [ -f "$VPY" ] || die "no Python in .venv ($VPY)"
"$VPY" -m pip install --upgrade pip >/dev/null 2>&1 || true
# PIP_CERT: a company network that inspects HTTPS -- point it to the company's root certificate (a .pem file), e.g.
#   PIP_CERT=/path/company_root.pem bash setup_app.sh        (certificate checks stay ON)
"$VPY" -m pip install --prefer-binary -r requirements.txt || die "pip could not install requirements.txt (internet / proxy? see PIP_CERT above)"

# ---------------------------------------------------------------- 3. check
echo "== 3/3  check =="
FAILED=""
for m in PyQt5.QtWebEngineWidgets PyQt5.QtWebChannel folium qtawesome numpy pandas paho.mqtt.client; do
  if QT_QPA_PLATFORM=offscreen "$VPY" -c "import $m" >/dev/null 2>&1; then echo "  ok      $m"
  else echo "  MISSING $m"; FAILED="$FAILED $m"; fi
done
if [ "$OS" = linux ]; then                       # (Qt's window system and Qt WebEngine: machine libraries)
  MISSING_LIBS=""
  LDC=$(command -v ldconfig || echo /sbin/ldconfig)
  for pair in libxcb-xinerama.so.0:libxcb-xinerama0 libxkbcommon-x11.so.0:libxkbcommon-x11-0 \
              libxcb-icccm.so.4:libxcb-icccm4 libxcb-image.so.0:libxcb-image0 libxcb-keysyms.so.1:libxcb-keysyms1 \
              libxcb-render-util.so.0:libxcb-render-util0 libxcb-xkb.so.1:libxcb-xkb1 libnss3.so:libnss3 \
              libxcomposite.so.1:libxcomposite1 libxdamage.so.1:libxdamage1 libxrandr.so.2:libxrandr2 \
              libxtst.so.6:libxtst6 libasound.so.2:libasound2; do
    lib=${pair%%:*}; deb=${pair##*:}
    if ! "$LDC" -p 2>/dev/null | grep -q "$lib"; then MISSING_LIBS="$MISSING_LIBS $deb"; fi
  done
  if [ -n "$MISSING_LIBS" ]; then
    warn "machine libraries Qt may need are missing:$MISSING_LIBS"
    warn "if the window does not open:  sudo apt install$MISSING_LIBS"
  else
    echo "  ok      machine libraries for Qt (xcb, WebEngine)"
  fi
fi
chmod +x run_app.sh 2>/dev/null || true
if [ -n "$FAILED" ]; then
  die "not ready -- missing:$FAILED"
fi
echo
echo "Ready. Start Q-SCAPE with:  bash run_app.sh" "$( [ "$OS" = windows ] && echo '  (or run_app.bat)')"
