"""Real-world camera processing (collision testing, sensor mode "real"): finds the obstacles IN THE PICTURE.

The picture is the truck's camera image rendered by the 3D page (this climate's fog / rain / night included).
Nothing from the scene is used -- only the pixels and the camera's calibration (focal length, height, pitch), as
a monocular driver-assist camera does. The method is the classic free-space / "stixel" approach:

  1. Road model: the colours of the road just in front of the truck (the bottom of the picture) + the haze colour
     (the sky / fog at the top): far road fades towards the haze, so a pixel counts as ROAD when its colour lies
     on the line between a road colour and the haze colour.
  2. Free space: each pixel column is scanned from the bottom up; the first place where the road stops for good
     (not a thin lane marking) is the BASE of an obstacle.
  3. Distance: flat road -- the base row's angle below the horizon gives the distance:
        d = camera height / tan(angle below the horizon)
  4. Objects: neighbouring columns with about the same distance form one object: its distance (nearest base),
     its side offset (y = -(u - cx) * d / fx), its width; the type is guessed from the width; the confidence
     from the contrast against the road.

What it cannot do (as a real camera): see in thick fog / at night without light (low contrast), separate two
objects at the same distance side by side, measure exactly on slopes, know names (the app tracks ids).
"""
import math

import numpy as np

STEP = 2                 # every 2nd pixel column (speed)
GROUND_TOL = 0.075       # RGB distance (0-1) to the road-colour / haze line that still counts as road
MIN_OBST_M = 0.8         # an obstacle must rise at least this high (m) above its base (lane markings, flat
                         # patches of another road colour do not; lower things -- a pallet -- are missed)
MIN_WIDTH_M = 0.35
MAX_RANGE_M = 120.0
MIN_CONF = 0.42          # fainter than this: not reported (a detector's score threshold)
_DEBUG = None            # (a dict: the intermediate masks are kept there -- tuning)


def decode_jpeg(data):
    """JPEG bytes -> HxWx3 float32 RGB 0-1 (Qt decodes; no extra packages)."""
    from PyQt5.QtGui import QImage
    img = QImage.fromData(data, "JPG")
    if img.isNull():
        return None
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = img.width(), img.height(), img.bytesPerLine()
    ptr = img.constBits()
    ptr.setsize(bpl * h)
    arr = np.frombuffer(ptr, np.uint8).reshape(h, bpl)[:, :w * 3].reshape(h, w, 3)
    return arr.astype(np.float32) / 255.0


def _seg_dist(px, a, b):
    """Distance of colours px (N,3) to the segments a[k] -> b (k palette colours) -> (N,) min over k, and the
    position t along that segment (0 = the road colour, 1 = the haze)."""
    ab = b[None, :] - a                                     # (K,3)
    L2 = np.maximum((ab * ab).sum(1), 1e-6)                 # (K,)
    ap = px[:, None, :] - a[None, :, :]                     # (N,K,3)
    t = np.clip((ap * ab[None]).sum(2) / L2[None], 0.0, 1.0)
    proj = a[None] + t[..., None] * ab[None]
    dk = np.sqrt(((px[:, None, :] - proj) ** 2).sum(2))
    k = dk.argmin(1)
    n = np.arange(len(px))
    return dk[n, k], t[n, k]


def _row_haze(t_rows, near_rows):
    """Per row: how far the road has faded to the haze (median t of the road pixels of that row), smoothed and
    never less towards the horizon (row 0 = just below the horizon)."""
    R = len(t_rows)
    out = np.zeros(R, np.float32)
    last = 0.0
    for r in range(R - 1, -1, -1):                          # from the bottom (near) up to the horizon (far)
        v = t_rows[r]
        if v is not None and near_rows[r] >= 6:
            last = max(last, v)
        out[r] = last
    return out


def road_palette(img, h0):
    """The road's colours: frequent colours of the band just in front of the AV (rows h0 .. bottom)."""
    band = img[h0:, ::2].reshape(-1, 3)
    q = np.round(band * 12) / 12
    cols, cnt = np.unique(q, axis=0, return_counts=True)
    keep = cols[cnt >= max(6, 0.015 * len(q))]
    if not len(keep):
        keep = cols[np.argsort(-cnt)[:3]]
    return keep[np.argsort(-cnt[cnt >= max(6, 0.015 * len(q))])][:14].astype(np.float32)


def detect(img, cam):
    """img: HxWx3 float RGB; cam: {fx, fy, cam_h, pitch_deg, lens_front_m} -> [{x (ahead of the lens, m), y (left,
    m), gap (m, from the AV's front), width_m, u0, u1, v (base row), cls, conf}] + debug info."""
    H, W, _ = img.shape
    fx, fy = float(cam["fx"]), float(cam["fy"])
    ch, pitch = float(cam.get("cam_h") or 2.4), math.radians(float(cam.get("pitch_deg") or 0.0))
    cx, cy = W / 2.0, H / 2.0
    vh = cy - fy * math.tan(pitch)                          # the horizon row
    v_top = int(math.ceil(vh + 2))
    if v_top >= H - 10:
        return [], {}
    rows = np.arange(H, dtype=np.float32)
    ang = np.arctan((rows - cy) / fy) + pitch               # below the horizon (rad)
    with np.errstate(divide="ignore"):
        dist = np.where(ang > 1e-4, ch / np.tan(np.maximum(ang, 1e-4)), np.inf)
    # haze colour: the top of the picture (sky / fog); road colours: the band in front of the AV
    haze = np.median(img[: max(3, int(H * 0.08))].reshape(-1, 3), axis=0)
    h0 = int(H * 0.75)                                      # (closer than ~7 m: LiDAR / radar territory)
    pal = road_palette(img, h0)
    sub = img[v_top:, ::STEP]                               # rows below the horizon, every STEP-th column
    R, C = sub.shape[:2]
    flat = sub.reshape(-1, 3)
    d0, t0 = _seg_dist(flat, pal, haze.astype(np.float32))
    d0, t0 = d0.reshape(R, C), t0.reshape(R, C)
    # how much the road has faded at each row (fog: more towards the horizon) -- from the road pixels themselves
    rd = d0 < GROUND_TOL
    t_rows = [float(np.median(t0[r][rd[r]])) if rd[r].any() else None for r in range(R)]
    tr = _row_haze(t_rows, rd.sum(1))
    # the road colours AT that fading for each row; a pixel is road when near one of them
    exp_ = pal[None, :, :] * (1 - tr[:, None, None]) + haze[None, None, :] * tr[:, None, None]   # (R,K,3)
    dd = np.sqrt(((sub[:, :, None, :] - exp_[:, None, :, :]) ** 2).sum(3)).min(2)               # (R,C)
    tol = GROUND_TOL + 0.06 * tr[:, None]                   # (far road: a little more spread)
    contrast = dd
    nonroad = dd > tol
    # rain / snow streaks are a pixel wide: an obstacle must cover a neighbouring column too
    nb = np.zeros_like(nonroad)
    nb[:, 1:] |= nonroad[:, :-1]
    nb[:, :-1] |= nonroad[:, 1:]
    nonroad &= nb
    # an obstacle base: non-road there AND most of the rows above it (as high as MIN_OBST_M at that distance)
    S = np.vstack([np.zeros((1, C), np.int32), np.cumsum(nonroad, 0).astype(np.int32)])
    rr = np.arange(R)
    dist_sub = dist[v_top:]
    k = np.clip(np.ceil(MIN_OBST_M * fy / np.maximum(dist_sub, 0.5)), 3, 60).astype(int)
    lo = np.maximum(0, rr + 1 - k)
    cnt = S[rr + 1] - S[lo]
    ratio = cnt / np.maximum(1, (rr + 1 - lo))[:, None]
    ok = nonroad & (ratio >= 0.7) & (dist_sub[:, None] <= MAX_RANGE_M)
    # the lowest such row per column (nearest obstacle)
    has = ok.any(0)
    base = np.where(has, R - 1 - np.argmax(ok[::-1], 0), -1)
    if _DEBUG is not None:
        _DEBUG.update(v_top=v_top, nonroad=nonroad, ok=ok, base=base, tr=tr)
    cols_u = np.arange(C) * STEP + STEP / 2.0
    d_col = np.where(has, dist_sub[np.clip(base, 0, R - 1)], np.inf)
    # group neighbouring columns whose base rows are close in the PICTURE (a vehicle's wheels touch the road a few
    # pixels lower than its chassis / bumper between them -- in metres that is a big jump, in pixels a small one)
    objs, cur = [], None
    for j in range(C):
        if not has[j]:
            cur = _close(objs, cur)
            continue
        b = int(base[j])
        tol = max(3, int(0.22 * (b + v_top - vh)))           # (rows: more room close by, where rows are coarse)
        if cur is not None and abs(b - cur["b_last"]) <= tol:
            cur["cols"].append(j); cur["b"].append(b); cur["b_last"] = b
        else:
            cur = _close(objs, cur)
            cur = {"cols": [j], "b": [b], "b_last": b}
    _close(objs, cur)
    out = []
    lf = float(cam.get("lens_front_m") or 0.0)
    for o in objs:
        j0, j1 = o["cols"][0], o["cols"][-1]
        bs = np.array(o["b"])
        b_near = int(np.percentile(bs, 90))                  # (its lowest base: where it stands on the road)
        d = float(dist_sub[b_near])
        ds = np.array([dist_sub[b] for b in bs])
        u0, u1 = cols_u[j0] - STEP / 2, cols_u[j1] + STEP / 2
        width = (u1 - u0) * d / fx
        if width < MIN_WIDTH_M:
            continue
        uc = (u0 + u1) / 2
        yl, yr = -(u0 - cx) * d / fx, -(u1 - cx) * d / fx       # (its left / right edge, m beside the centre line)
        y = 0.0 if yl * yr <= 0 else (yl if abs(yl) < abs(yr) else yr)   # (the edge nearest our path: lane test)
        vb = b_near + v_top
        # contrast against the road: over the lower part of the obstacle (its base row is blurred by the edge)
        c = float(np.median([np.median(contrast[max(0, base[j] - k[base[j]]):base[j] + 1, j]) for j in o["cols"]]))
        conf = float(max(0.2, min(0.99, 0.35 + 2.2 * (c - GROUND_TOL))))
        if conf < MIN_CONF:
            continue                                         # (too faint: as a detector's score threshold)
        cls = "truck" if width >= 2.1 else "car" if width >= 1.3 else "pedestrian" if width <= 0.9 else "object"
        if conf < 0.5:
            cls = "object"
        out.append({"x": round(d, 2), "y": round(y, 2), "y_c": round(-(uc - cx) * d / fx, 2), "half_w": 0.0,
                    "gap": round(max(0.0, d - lf), 2), "width_m": round(width, 2),
                    "u0": round(u0, 1), "u1": round(u1, 1), "v": vb, "cls": cls, "conf": round(conf, 2)})
    out.sort(key=lambda o: o["x"])
    return out, {"horizon": vh, "haze": haze.tolist(), "palette": len(pal), "free_cols": int((~has).sum())}


def _close(objs, cur):
    if cur is not None and len(cur["cols"]) >= 1:
        objs.append(cur)
    return None
