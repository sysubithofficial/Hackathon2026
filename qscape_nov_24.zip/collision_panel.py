"""Collision testing window (top bar "Collision Testing").

The AVs drive a saved route one behind the other; each brakes only on its own camera / LiDAR /
radar. One window:

- header: the route, the test's state, the climate (sensor ranges);
- a row of cards, one per truck: name, 2D / 3D follow, speed, brake badge, what it is doing, its top speed,
  Stop & go, its sensor switches (LiDAR / Camera / Radar ON-OFF while it drives), the gap to what is ahead with a
  bar (where each sensor puts it), TTC, collisions and "Detection details";
- the detection details of the truck picked (under the cards), with check-boxes for which sensors to show and,
  with several collision cameras (Vehicles window: "Used for: collision"), which camera:
    left  -- the camera image (rendered in this climate: fog, rain, snow, night) with its detections boxed (class,
             confidence, distance from the image) and what it misses (why), and how the distance is worked out;
    right -- a tile per sensor (distance, error, what it gives or why not), the real gap / TTC, and tabs: the
             bird's-eye sensor view and the objects table;
- footer: the collisions, the log of all trucks, Pause / Restart / End.

The app fills it with update_view(d) and details.set_camera(pixmap, overlay, calc).
"""
import math

from PyQt5.QtCore import QPointF, QRectF, QSize, Qt
from PyQt5.QtGui import QColor, QFont, QPainter, QPen, QPixmap
from PyQt5.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFrame, QGridLayout,
                             QHBoxLayout, QHeaderView, QLabel, QListWidget, QPushButton, QScrollArea, QSizePolicy,
                             QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QTabWidget, QToolButton, QVBoxLayout,
                             QWidget)

from follow_panel import (AMBER, CYAN, GREEN, GREY, PURPLE, RED, SENSOR_COL, STYLE, DistanceBar, SensorView,
                          _SafePaint, _badge)

SENSORS = (("LiDAR", "LiDAR"), ("camera", "Camera"), ("radar", "Radar"))
BLUE = "#3B82F6"
EXTRA_STYLE = """
QDialog#collisionTest { background: #0B1220; }
QFrame#ccard { background: #111827; border: 1px solid #1F2937; border-radius: 12px; }
QFrame#ccard[picked="true"] { border: 2px solid #3B82F6; }
QFrame#ccard[held="true"] { border: 2px solid #EF4444; }
QFrame#pane { background: #0F172A; border: 1px solid #1F2937; border-radius: 12px; }
QFrame#tile { background: #111827; border: 1px solid #1F2937; border-radius: 10px; }
QFrame#calc { background: #111827; border: 1px solid #1F2937; border-radius: 10px; }
QLabel#title { font-size: 16px; font-weight: 700; color: #F1F5F9; }
QLabel#route { border-radius: 9px; padding: 2px 10px; font-size: 11px; background: #172554; color: #BFDBFE; }
QLabel#lap { border-radius: 9px; padding: 2px 10px; font-size: 12px; font-weight: 700; background: #3B0764;
             color: #E9D5FF; border: 1px solid #7E22CE; }
QSpinBox { background: #0F172A; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px; padding: 2px 4px; }
QSpinBox:focus { border-color: #22C55E; }
QSpinBox:disabled { color: #64748B; }
QLabel#role { color: #93C5FD; font-size: 10px; font-weight: 700; letter-spacing: 1px; }
QLabel#tname { font-size: 13px; font-weight: 700; color: #F1F5F9; }
QLabel#speed { font-size: 30px; font-weight: 800; color: #F8FAFC; }
QLabel#unit { color: #94A3B8; font-size: 12px; }
QLabel#small { color: #CBD5E1; font-size: 11px; }
QLabel#section { color: #E2E8F0; font-size: 12px; font-weight: 700; }
QLabel#tileval { font-size: 20px; font-weight: 800; }
QLabel#formula { color: #E2E8F0; font-family: Consolas, 'Courier New', monospace; font-size: 12px; }
QPushButton#details { background: #172554; border-color: #1D4ED8; color: #DBEAFE; font-weight: 600; }
QPushButton#details:hover { background: #1E3A8A; }
QPushButton#details[on="true"] { background: #1D4ED8; color: #FFFFFF; }
QPushButton#mini { border-radius: 6px; padding: 3px 4px; font-weight: 700; font-size: 10px; }
QScrollArea { background: transparent; border: none; }
QCheckBox { spacing: 5px; color: #E5E7EB; }
QComboBox { background: #0F172A; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px; padding: 2px 6px; }
QTabWidget::pane { border: 1px solid #1F2937; border-radius: 8px; top: -1px; background: #0A0F1C; }
QTabBar::tab { background: #111827; color: #94A3B8; padding: 5px 14px; border: 1px solid #1F2937;
               border-bottom: none; border-top-left-radius: 7px; border-top-right-radius: 7px; margin-right: 2px; }
QTabBar::tab:selected { background: #1E293B; color: #F1F5F9; }
QSplitter::handle { background: #0B1220; }
"""


def _qicon(name, color):
    try:
        import qtawesome as qta
        return qta.icon(name, color=color)
    except Exception:
        return None


class ElideLabel(QLabel):
    """A one-line label that may get narrower than its text (a small screen): it then ends in '…' -- the whole
    text is its tooltip. Its natural width is still the whole text (shown in full when there is room)."""

    def __init__(self, text="", min_w=50):
        super().__init__()
        self._full, self._min_w = "", min_w
        self.setText(text)

    def setText(self, t):
        t = str(t or "")
        if t == self._full and self.text():
            return
        self._full = t
        self.setToolTip(t)
        self._apply()
        self.updateGeometry()

    def full_text(self):
        return self._full

    def _pad(self):
        m = self.contentsMargins()
        return m.left() + m.right() + 22                       # (the badge style's padding + border)

    def _apply(self):
        w = self.width() - self._pad()
        fm = self.fontMetrics()
        QLabel.setText(self, self._full if w <= 0 or fm.horizontalAdvance(self._full) <= w
                       else fm.elidedText(self._full, Qt.ElideRight, max(10, w)))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._apply()

    def sizeHint(self):
        s = super().sizeHint()
        return QSize(self.fontMetrics().horizontalAdvance(self._full) + self._pad(), s.height())

    def minimumSizeHint(self):
        return QSize(self._min_w, super().minimumSizeHint().height())


def _ttc_html(v):
    if v is None:
        return f"<span style='color:{GREY}'>--</span>"
    col = RED if v < 1.5 else AMBER if v < 3.0 else GREEN
    return f"<b style='color:{col}'>{v:.1f} s</b>"


def _switch_style(b, key, on):
    c = QColor(SENSOR_COL[key] if on else RED)
    b.setStyleSheet(f"background: rgba({c.red()},{c.green()},{c.blue()},{0.20 if on else 0.14}); "
                    f"color: {SENSOR_COL[key] if on else '#FCA5A5'}; "
                    f"border: 1px solid rgba({c.red()},{c.green()},{c.blue()},0.55);")


def _prop(w, name, value):
    if w.property(name) != value:
        w.setProperty(name, value)
        w.style().unpolish(w); w.style().polish(w)


SSTATE = {  # state -> (colour, word, signal bars 0-3 / -1 = off, meaning)
    "full": (GREEN, "OK", 3, "sees the vehicle ahead well"),
    "partial": ("#FB923C", "partial", 2, "sees something, but not clearly / not the vehicle ahead"),
    "low": (AMBER, "weak", 1, "sees it, but weakly (few points / weak echo / old message)"),
    "none": (RED, "none", 0, "does NOT see the vehicle ahead"),
    "far": ("#64748B", "far", 0, "the vehicle ahead is beyond its reach"),
    "idle": ("#64748B", "—", 0, "nothing in the lane ahead to detect"),
    "off": ("#475569", "off", -1, "switched off"),
}
SSTRIP = (("camera", "Camera"), ("LiDAR", "LiDAR"), ("radar", "Radar"), ("V2V", "V2V"))


class SensorStatusStrip(_SafePaint):
    """The card's sensor icons with their state (OK / partial / weak / none / far / — / off) and signal bars:
    what each sensor makes of the vehicle ahead right now. Hover: the details."""

    def __init__(self):
        super().__init__()
        self.st = {}
        self.setFixedHeight(32)
        self.setMouseTracking(True)
        self.setToolTip("")

    def set_status(self, st):
        if st != self.st:
            self.st = dict(st)
            self.update()

    def _cells(self):
        n = len(SSTRIP)
        w = (self.width() - (n - 1) * 4) / n
        return [QRectF(i * (w + 4), 1, w, self.height() - 2) for i in range(n)]

    def event(self, e):
        from PyQt5.QtCore import QEvent
        if e.type() == QEvent.ToolTip:
            from PyQt5.QtWidgets import QToolTip
            for (key, name), r in zip(SSTRIP, self._cells()):
                if r.contains(QPointF(e.pos())):
                    state, tip = self.st.get(key, ("idle", f"{name}: waiting ..."))
                    col, word, _b, mean = SSTATE.get(state, SSTATE["idle"])
                    QToolTip.showText(e.globalPos(), f"<b style='color:{col}'>{name}: {word.upper()}</b> — {mean}"
                                      f"<br>{tip}<br><span style='color:{GREY}'>OK · partial · weak · none · far "
                                      "(beyond its reach) · — (nothing ahead) · off</span>", self)
                    return True
            QToolTip.hideText()
            return True
        return super().event(e)

    def _paint(self, _e):
        import sensor_graphics as sg
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        f = QFont(); f.setPixelSize(10); f.setBold(True)
        for (key, name), r in zip(SSTRIP, self._cells()):
            state = (self.st.get(key) or ("idle", ""))[0]
            col, word, bars, _m = SSTATE.get(state, SSTATE["idle"])
            c = QColor(col)
            p.setPen(QPen(QColor(c.red(), c.green(), c.blue(), 150), 1.2))
            p.setBrush(QColor(c.red(), c.green(), c.blue(), 38 if state not in ("off", "idle", "far") else 18))
            p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 7, 7)
            icol = SENSOR_COL.get(key, "#E5E7EB") if state not in ("off",) else "#475569"
            ir = QRectF(r.x() + 4, r.center().y() - 9, 18, 18)
            sg.draw_icon(p, key, ir, icol)
            if state == "off":                                   # a slash through the icon
                p.setPen(QPen(QColor("#94A3B8"), 1.8)); p.drawLine(ir.bottomLeft(), ir.topRight())
            tx = r.x() + 25
            p.setFont(f); p.setPen(QColor(col if state != "off" else "#64748B"))   # the word on top ...
            p.drawText(QRectF(tx, r.y() + 1, r.right() - tx - 2, 14), Qt.AlignVCenter | Qt.AlignLeft, word)
            for k in range(3):                                   # ... the signal bars below it
                h = 3 + k * 2.5
                br = QRectF(tx + k * 5, r.bottom() - 4 - h, 3.5, h)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(col) if bars > k else QColor("#334155"))
                p.drawRect(br)
            if state == "none":                                   # a red ✕ on the icon
                p.setPen(QPen(QColor(RED), 2)); cx, cy = ir.right() - 2, ir.bottom() - 2
                p.drawLine(QPointF(cx - 3, cy - 3), QPointF(cx + 3, cy + 3))
                p.drawLine(QPointF(cx - 3, cy + 3), QPointF(cx + 3, cy - 3))
        p.end()


class AVCard(QFrame):
    """One AV (fixed width: the cards line up in one row)."""

    def __init__(self, vid, role, name, cb):
        super().__init__()
        self.setObjectName("ccard")
        self.vid, self.cb = vid, cb
        self.setFixedWidth(300)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Maximum)
        v = QVBoxLayout(self); v.setContentsMargins(12, 10, 12, 10); v.setSpacing(5)
        head = QHBoxLayout(); head.setSpacing(4)
        col = QVBoxLayout(); col.setSpacing(0)
        r = QLabel(role.upper()); r.setObjectName("role"); col.addWidget(r)
        n = QLabel(name); n.setObjectName("tname"); col.addWidget(n)
        head.addLayout(col, 1)
        self.view_btns = {}
        for view in ("2D", "3D"):
            b = QToolButton(); b.setObjectName("follow"); b.setText(view); b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"Follow {name} in the {view} view (green: following it)")
            b.clicked.connect(lambda _=False, vw=view: self.cb["follow2d" if vw == "2D" else "follow3d"](self.vid))
            head.addWidget(b, 0, Qt.AlignTop)
            self.view_btns[view] = b
        v.addLayout(head)
        self.sstrip = SensorStatusStrip()                     # what each sensor makes of the vehicle ahead now
        v.addWidget(self.sstrip)
        row = QHBoxLayout(); row.setSpacing(6)
        self.speed = QLabel("0"); self.speed.setObjectName("speed"); row.addWidget(self.speed, 0, Qt.AlignBottom)
        u = QLabel("km/h"); u.setObjectName("unit"); row.addWidget(u, 0, Qt.AlignBottom)
        row.addStretch()
        self.badge = QLabel(); self.badge.setObjectName("badge"); self.badge.setAlignment(Qt.AlignCenter)
        row.addWidget(self.badge, 0, Qt.AlignVCenter)
        v.addLayout(row)
        self.state = QLabel(); self.state.setObjectName("muted"); v.addWidget(self.state)
        ctl = QHBoxLayout(); ctl.setSpacing(6)
        self.spin = QDoubleSpinBox(); self.spin.setRange(1.0, 80.0); self.spin.setDecimals(0)
        self.spin.setPrefix("Top "); self.spin.setSuffix(" km/h"); self.spin.setKeyboardTracking(False)
        self.spin.setToolTip("Its top speed on the route (it still brakes on what its sensors detect)")
        self.spin.valueChanged.connect(lambda val: self.cb["speed"](self.vid, val))
        ctl.addWidget(self.spin, 1)
        self.sg = QPushButton("✋ Stop && go")
        self.sg.setToolTip("Stop this AV (braking, how long it stands, again every ...) -- the AVs behind it "
                           "have to detect it and brake")
        self.sg.clicked.connect(lambda: self.cb["stopgo"](self.vid))
        ctl.addWidget(self.sg)
        self.off = QPushButton("▶ Drive on"); self.off.setObjectName("accent"); self.off.setVisible(False)
        self.off.clicked.connect(lambda: self.cb["stopgo_off"](self.vid))
        ctl.addWidget(self.off)
        v.addLayout(ctl)
        sw = QHBoxLayout(); sw.setSpacing(4)                  # its sensors, switched while it drives
        self.sw = {}
        for key, text in SENSORS:
            b = QPushButton(text); b.setObjectName("mini"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"Switch its {text} on / off while it drives (all off: it sees nothing and runs into what "
                         "is ahead)")
            b.clicked.connect(lambda on, k=key: self.cb["sensor"](self.vid, k, on))
            sw.addWidget(b, 1)
            self.sw[key] = b
        v.addLayout(sw)
        vr = QHBoxLayout(); vr.setSpacing(6)                    # V2V: its switch + what it gets
        b = QPushButton("V2V"); b.setObjectName("mini"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
        b.setFixedWidth(88)
        b.setToolTip("V2V on / off while it drives: it sends its state + brake alerts and gets those of the connected "
                     "vehicles ahead")
        b.clicked.connect(lambda on: self.cb["sensor"](self.vid, "V2V", on))
        vr.addWidget(b)
        self.sw["V2V"] = b
        self.v2v = QLabel(); self.v2v.setObjectName("small"); self.v2v.setWordWrap(False)
        vr.addWidget(self.v2v, 1)
        v.addLayout(vr)
        self.gap = QLabel(); self.gap.setObjectName("small"); v.addWidget(self.gap)
        self.bar = DistanceBar(); self.bar.setMinimumHeight(52); self.bar.setMaximumHeight(54); v.addWidget(self.bar)
        foot = QHBoxLayout(); foot.setSpacing(6)
        self.ttc = QLabel(); self.ttc.setObjectName("small"); foot.addWidget(self.ttc, 1)
        self.coll = QLabel(); self.coll.setObjectName("small"); foot.addWidget(self.coll)
        v.addLayout(foot)
        self.det_btn = QPushButton("🔍  Detection details"); self.det_btn.setObjectName("details")
        self.det_btn.setCursor(Qt.PointingHandCursor)
        self.det_btn.setToolTip("Show its camera image, LiDAR and radar detections below the cards")
        self.det_btn.clicked.connect(lambda: self.cb["details"](self.vid))
        v.addWidget(self.det_btn)

    def set_compact(self, on):
        """A small screen with the details open: the card without its bar / state line / counters."""
        for w in (self.state, self.bar, self.coll):
            w.setVisible(not on)

    def update_view(self, d, f2d, f3d, picked):
        self.speed.setText(f"{d['speed']:.0f}")
        _badge(self.badge, *d["brake"])
        st = d.get("state") or ""
        self.state.setText(st if len(st) <= 46 else st[:44] + "…")
        self.state.setToolTip(st)
        want = d.get("set")
        if want is not None and not self.spin.hasFocus() and abs(self.spin.value() - want) >= 0.5:
            self.spin.blockSignals(True); self.spin.setValue(round(want)); self.spin.blockSignals(False)
        self.off.setVisible(bool(d.get("sg")))
        self.sg.setVisible(not d.get("sg"))
        for view, on in (("2D", f2d == self.vid), ("3D", f3d == self.vid)):
            _prop(self.view_btns[view], "on", on)
        det = d.get("det") or {}
        for key, text in SENSORS:
            on = key in d["sensors"]
            b = self.sw[key]
            b.setChecked(on)
            val = det.get(key)
            b.setText(f"{text}  {'OFF' if not on else (f'{val:.1f} m' if val is not None else 'ON')}")
            _switch_style(b, key, on)
        vv = d.get("v2v") or {}
        on = bool(vv.get("on"))
        b = self.sw["V2V"]
        b.setChecked(on)
        val = det.get("V2V")
        b.setText(f"V2V  {'OFF' if not on else (f'{val:.0f} m' if val is not None else 'ON')}")
        _switch_style(b, "V2V", on)
        txt = vv.get("text") or ""
        self.v2v.setText(txt if len(txt) <= 44 else txt[:42] + "…")
        self.v2v.setToolTip(vv.get("tip") or txt)
        st = dict(d.get("sstat") or {})
        for key, _t in SENSORS:                                  # (no status from the app yet: on / off only)
            st.setdefault(key, ("idle", "") if key in d["sensors"] else ("off", f"{key}: switched OFF"))
        st.setdefault("V2V", ("idle", "") if on else ("off", "V2V: switched OFF"))
        self.sstrip.set_status(st)
        if d.get("gap") is None:
            self.gap.setText(f"<span style='color:{GREY}'>Nothing in its lane ahead</span>")
            self.bar.set_values(None, d["set_gap"], None, None, d["stop"], None)
        else:
            real = max(0.0, d["gap"])
            col = GREEN if real >= d["set_gap"] * 0.7 else AMBER if real > d["stop"] else RED
            ahead = d["ahead"] if len(d["ahead"]) <= 22 else d["ahead"][:21] + "…"
            self.gap.setText(f"Gap to <b>{ahead}</b> &nbsp;<b style='color:{col}; font-size:13px'>{real:.1f} m</b>"
                             f" <span style='color:{GREY}'>set {d['set_gap']:g} m</span>")
            self.bar.set_values(real, d["set_gap"], det.get("LiDAR"), det.get("camera"), d["stop"], det.get("radar"))
        self.ttc.setText(f"TTC {_ttc_html(d['ttc'][0])} <span style='color:{GREY}'>· real</span> {_ttc_html(d['ttc'][1])}")
        self.ttc.setToolTip(f"Time to collision: perceived (what it brakes on) / real (true gap). Lowest: {d['ttc'][2]}")
        n = d["collisions"]
        self.coll.setText(f"<b style='color:{RED if n else GREEN}'>{n}</b> <span style='color:{GREY}'>coll. · "
                          f"{d['brakes']} brk</span>")
        self.coll.setToolTip(f"{n} collision(s), {d['brakes']} braking(s), {d['full']} full")
        _prop(self, "picked", bool(picked) and not d.get("held"))
        _prop(self, "held", bool(d.get("held")))
        _prop(self.det_btn, "on", bool(picked))
        self.det_btn.setText("🔍  Detection details ▴  (click to close)" if picked else "🔍  Detection details")
        self.det_btn.setToolTip("Close its detection details" if picked else
                                "Show its camera image, LiDAR and radar detections below the cards")


class CameraShot(_SafePaint):
    """The camera image with the camera's detections drawn on it (set_shot)."""

    def __init__(self):
        super().__init__()
        self.setMinimumSize(320, 180)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.pix, self.d = None, None

    def set_shot(self, pix, d):
        """pix: QPixmap of the image (w x h); d = {w, h, boxes: [{x0, y0, x1, y1, col, dashed, lines}], banner,
        banner_col, horizon, caption}"""
        self.pix, self.d = pix, d
        self.update()

    def _paint(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#05080F"))
        if self.pix is None or not self.d or not self.d.get("w"):
            p.setPen(QColor(GREY))
            p.drawText(QRectF(self.rect()), Qt.AlignCenter | Qt.TextWordWrap,
                       (self.d or {}).get("banner") or "camera: waiting for the image ...")
            p.end(); return
        W, H = self.d["w"], self.d["h"]
        k = min(self.width() / W, self.height() / H)
        ox, oy = (self.width() - W * k) / 2, (self.height() - H * k) / 2
        p.drawPixmap(QRectF(ox, oy, W * k, H * k), self.pix, QRectF(0, 0, self.pix.width(), self.pix.height()))
        hz = self.d.get("horizon")
        if hz is not None:
            p.setPen(QPen(QColor(255, 255, 255, 60), 1, Qt.DashLine))
            p.drawLine(QPointF(ox, oy + hz * k), QPointF(ox + W * k, oy + hz * k))
        f = QFont(); f.setPointSize(8); f.setBold(True); p.setFont(f)
        fm = p.fontMetrics()
        for b in self.d.get("boxes") or []:
            r = QRectF(ox + b["x0"] * k, oy + b["y0"] * k, (b["x1"] - b["x0"]) * k, (b["y1"] - b["y0"]) * k)
            col = QColor(b["col"])
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(col, 2, Qt.DashLine if b.get("dashed") else Qt.SolidLine))
            p.drawRect(r)
            lines = b.get("lines") or []
            if lines:
                tw = max(fm.width(t) for t in lines) + 10
                th = fm.height() * len(lines) + 6
                ty = r.top() - th - 2 if r.top() - th - 2 > oy else max(oy + 2, r.top() + 2)   # (no room: inside it)
                tx = max(ox, min(ox + W * k - tw, r.left()))
                bg = QColor(col); bg.setAlpha(225)
                p.setPen(Qt.NoPen); p.setBrush(bg)
                p.drawRoundedRect(QRectF(tx, ty, tw, th), 4, 4)
                p.setPen(QColor("#0B1220") if b["col"] not in (RED,) else QColor("#FFFFFF"))
                for i, t in enumerate(lines):
                    p.drawText(QPointF(tx + 5, ty + 3 + fm.ascent() + i * fm.height()), t)
        ban = self.d.get("banner")
        if ban:
            f.setPointSize(9); p.setFont(f)
            fm2 = p.fontMetrics()
            tw = min(W * k - 24, fm2.width(ban) + 28)
            lines = max(1, int(fm2.width(ban) / max(1, tw - 28)) + 1)
            r = QRectF(ox + (W * k - tw) / 2, oy + 10, tw, fm2.height() * lines + 10)
            bg = QColor(self.d.get("banner_col") or RED); bg.setAlpha(225)
            p.setPen(Qt.NoPen); p.setBrush(bg)
            p.drawRoundedRect(r, 6, 6)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(r.adjusted(10, 4, -10, -4), Qt.AlignCenter | Qt.TextWordWrap, ban)
        cap = self.d.get("caption")
        if cap:
            f.setPointSize(8); f.setBold(False); p.setFont(f)
            fm3 = p.fontMetrics()
            r = QRectF(ox + 6, oy + H * k - fm3.height() - 8, fm3.width(cap) + 12, fm3.height() + 4)
            p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 150)); p.drawRoundedRect(r, 4, 4)
            p.setPen(QColor(255, 255, 255, 210)); p.drawText(r, Qt.AlignCenter, cap)
        p.end()


class SensorTile(QFrame):
    """One sensor's result: name + state, the distance (large), the error, what it gives / why not."""

    def __init__(self, key, text):
        super().__init__()
        self.setObjectName("tile")
        self.key = key
        v = QVBoxLayout(self); v.setContentsMargins(10, 7, 10, 7); v.setSpacing(1)
        h = QHBoxLayout()
        sym = {"camera": "▼", "LiDAR": "▲", "radar": "◆", "V2V": "📡"}[key]
        n = QLabel(f"{sym} {text}"); n.setStyleSheet(f"color:{SENSOR_COL[key]}; font-weight:700;"); h.addWidget(n)
        h.addStretch()
        self.state = QLabel(); self.state.setObjectName("badge"); h.addWidget(self.state)
        v.addLayout(h)
        self.val = QLabel("--"); self.val.setObjectName("tileval"); v.addWidget(self.val)
        self.val.setMinimumHeight(30)                          # (2 x 2 on a small screen: never squeezed / cut)
        self.err = QLabel(); self.err.setObjectName("small"); v.addWidget(self.err)
        self.err.setMinimumHeight(16)
        self.info = QLabel(); self.info.setObjectName("muted"); self.info.setWordWrap(True)
        self.info.setMinimumHeight(30); self.info.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        v.addWidget(self.info, 1)

    def show_result(self, on, val, why):
        if not on:
            _badge(self.state, "OFF", RED)
            self.val.setText(f"<span style='color:{GREY}'>off</span>")
            self.err.setText("")
            self.info.setText("Switched off -- the AV brakes only on its other sensors.")
            return
        if not val:
            _badge(self.state, "NOT DETECTED", RED if why and "nothing in its lane" not in why else GREY)
            self.val.setText(f"<span style='color:{GREY}'>--</span>")
            self.err.setText("")
            self.info.setText(why or "")
            return
        _badge(self.state, "DETECTED", GREEN)
        self.val.setText(f"<span style='color:{SENSOR_COL[self.key]}'>{val[0]:.1f} m</span>")
        e = val[2]
        self.err.setText("" if e is None else
                         f"error to real <span style='color:{GREEN if abs(e) < 0.5 else AMBER if abs(e) < 1.5 else RED}'>"
                         f"{e:+.1f} m</span>")
        self.info.setText(str(val[1] or ""))


V2V_COLS = [("From", "The sender (its id is in the message)"),
            ("Message", "A state message (BSM / CAM, 10 a second) or a BRAKE ALERT (sent at once on hard braking)"),
            ("Age", "How old the message is now (only fresh ones -- delay + 0.3 s -- are kept)"),
            ("Radio delay", "How long the radio took to deliver it"),
            ("Ahead / beside", "Where its reported GNSS position is: metres ahead / beside (+ left) of this AV"),
            ("Speed", "Its speed, from the message"), ("Heading", "Its heading, from the message"),
            ("Accel.", "Its acceleration, from the message (negative: braking)"),
            ("Brake", "Its brake flag"), ("Length", "Its length (for the bumper-to-bumper gap)"),
            ("GNSS error", "How far its reported position is off (the test knows the truth -- for evaluation)"),
            ("Used?", "In this AV's lane ahead (used for braking / warning) -- or why not")]


class DetailsPane(QFrame):
    """The picked AV's detections: check-boxes (which sensors), camera selector, camera image + how the distance
    is worked out, a tile per sensor, gap / TTC, tabs bird's-eye / objects."""

    def __init__(self, cb):
        super().__init__()
        self.setObjectName("pane")
        self.cb = cb
        v = QVBoxLayout(self); v.setContentsMargins(12, 10, 12, 10); v.setSpacing(8)
        top = QHBoxLayout(); top.setSpacing(10)
        # (a small screen: the title shortens, the camera list narrows -- the ✕ always stays in view)
        self.title = ElideLabel("Detection details", 90); self.title.setObjectName("title"); top.addWidget(self.title)
        self.cam_pick = QComboBox(); self.cam_pick.setToolTip("Which collision testing camera (Vehicles window: "
                                                              "cameras 'Used for: collision')")
        self.cam_pick.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.cam_pick.setMinimumContentsLength(8)
        self.cam_pick.currentIndexChanged.connect(lambda i: self.cb["camera"](i) if "camera" in self.cb else None)
        top.addWidget(self.cam_pick)
        top.addStretch()
        lab = QLabel("Show"); lab.setObjectName("muted"); top.addWidget(lab)
        self.show_cb = {}
        for key, text in (("camera", "Camera"), ("LiDAR", "LiDAR"), ("radar", "Radar"), ("V2V", "V2V")):
            c = QCheckBox(text); c.setChecked(True)
            c.setStyleSheet(f"QCheckBox {{ color: {SENSOR_COL[key]}; font-weight: 700; }}")
            c.toggled.connect(self._shown_changed)
            top.addWidget(c)
            self.show_cb[key] = c
        self.focus_btn = QToolButton(); self.focus_btn.setObjectName("follow"); self.focus_btn.setText("⤢ Larger details")
        self.focus_btn.setToolTip("The AV cards hidden: the detection details (camera, tiles, bird's-eye view, "
                                  "objects, V2V messages) get the whole height -- again: the cards come back")
        self.focus_btn.clicked.connect(lambda: self.cb["focus"]() if "focus" in self.cb else None)
        top.addWidget(self.focus_btn)
        hide = QToolButton(); hide.setObjectName("follow"); hide.setText("✕ Close")
        hide.setToolTip("Close the details (or click 'Detection details' on the card again)")
        hide.clicked.connect(lambda: self.cb["details"](None))
        top.addWidget(hide)
        v.addLayout(top)
        self.body = QSplitter(Qt.Horizontal)
        self.body.setHandleWidth(10)
        # left: the camera image + how the distance is worked out
        self.cam_box = QWidget()
        cl = QVBoxLayout(self.cam_box); cl.setContentsMargins(0, 0, 0, 0); cl.setSpacing(6)
        # (a small screen: the headings wrap and the formula table may get narrower -- the pane fits the window)
        self.cam_title = QLabel("Camera view"); self.cam_title.setObjectName("section"); self.cam_title.setWordWrap(True)
        cl.addWidget(self.cam_title)
        self.cam = CameraShot(); cl.addWidget(self.cam, 1)
        calc = QFrame(); calc.setObjectName("calc")
        calc.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        kl = QVBoxLayout(calc); kl.setContentsMargins(10, 7, 10, 7); kl.setSpacing(2)
        self.calc_head = QLabel("Distance from the camera image"); self.calc_head.setObjectName("section")
        self.calc_head.setWordWrap(True)
        kl.addWidget(self.calc_head)
        self.calc_lines = QLabel(); self.calc_lines.setObjectName("formula"); self.calc_lines.setTextFormat(Qt.RichText)
        self.calc_lines.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        kl.addWidget(self.calc_lines)
        self.calc_note = QLabel(); self.calc_note.setObjectName("muted"); self.calc_note.setWordWrap(True)
        kl.addWidget(self.calc_note)
        cl.addWidget(calc)
        self.body.addWidget(self.cam_box)
        # right: a tile per sensor, gap / TTC, tabs
        right = QWidget()
        rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(6)
        tiles = QGridLayout(); tiles.setHorizontalSpacing(6); tiles.setVerticalSpacing(6)
        self._tile_grid, self._tile_cols = tiles, 0
        self.tiles = {}
        for key, text in (("camera", "Camera"), ("LiDAR", "LiDAR"), ("radar", "Radar"), ("V2V", "V2V")):
            t = SensorTile(key, text); self.tiles[key] = t
        self._place_tiles(4)                                   # (the window's width: 4 in a row, or 2 x 2 -- fit_width)
        self.tiles["V2V"].setToolTip("V2V: what the messages of the connected vehicle ahead say -- its reported "
                                     "distance, the message's age and radio delay, its speed, a brake alert; or why "
                                     "there is none (V2V off, it is not connected, lost, GNSS error).\n"
                                     "Click: the V2V messages tab (everything sent and received)")
        self.tiles["V2V"].setCursor(Qt.PointingHandCursor)
        self.tiles["V2V"].mousePressEvent = lambda _e: self.tabs.setCurrentIndex(2)
        rl.addLayout(tiles)
        self.ttc = QLabel(); self.ttc.setObjectName("small"); self.ttc.setWordWrap(True); rl.addWidget(self.ttc)
        self.tabs = QTabWidget()
        self.tabs.setMinimumHeight(190)                        # (a small screen: the tiles above keep their room)
        self.view = SensorView()
        self.tabs.addTab(self.view, "Bird's-eye view")
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["Object", "Real gap", "LiDAR", "Camera", "Radar", "V2V", "Lane"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.setAlternatingRowColors(False)
        self.table.setShowGrid(False)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        self.tabs.addTab(self.table, "Objects")
        # V2V messages: what it sends, what it receives (every field), used or why not, events
        vw = QWidget(); vl = QVBoxLayout(vw); vl.setContentsMargins(4, 4, 4, 4); vl.setSpacing(4)
        self.v2v_how = QLabel(); self.v2v_how.setTextFormat(Qt.RichText); self.v2v_how.setWordWrap(True)
        self.v2v_how.setObjectName("small"); vl.addWidget(self.v2v_how)
        self.v2v_head = QLabel(); self.v2v_head.setTextFormat(Qt.RichText); self.v2v_head.setWordWrap(True)
        self.v2v_head.setObjectName("small"); vl.addWidget(self.v2v_head)
        self.v2v_load = QLabel(); self.v2v_load.setTextFormat(Qt.RichText); self.v2v_load.setWordWrap(True)
        self.v2v_load.setObjectName("small"); vl.addWidget(self.v2v_load)
        mh = QHBoxLayout(); mh.setSpacing(6)
        self.v2v_msg_btn = QToolButton(); self.v2v_msg_btn.setObjectName("follow"); self.v2v_msg_btn.setCheckable(True)
        self.v2v_msg_btn.setChecked(True); self.v2v_msg_btn.setText("▾ What is in a V2V message (field by field)")
        self.v2v_msg_btn.toggled.connect(lambda on: (self.v2v_msg.setVisible(on), self.v2v_msg_btn.setText(
            ("▾" if on else "▸") + " What is in a V2V message (field by field)")))
        mh.addWidget(self.v2v_msg_btn); mh.addStretch()
        vl.addLayout(mh)
        self.v2v_msg = QLabel(); self.v2v_msg.setTextFormat(Qt.RichText); self.v2v_msg.setWordWrap(True)
        self.v2v_msg.setObjectName("small")
        self.v2v_msg.setStyleSheet("background: #0B1220; border: 1px solid #1E293B; border-radius: 6px; padding: 6px;")
        vl.addWidget(self.v2v_msg)
        self.v2v_table = QTableWidget(0, len(V2V_COLS))
        self.v2v_table.setHorizontalHeaderLabels([c for c, _t in V2V_COLS])
        for i, (_c, tip) in enumerate(V2V_COLS):
            self.v2v_table.horizontalHeaderItem(i).setToolTip(tip)
        self.v2v_table.verticalHeader().setVisible(False)
        self.v2v_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.v2v_table.setSelectionMode(QAbstractItemView.NoSelection)
        self.v2v_table.setShowGrid(False)
        hv = self.v2v_table.horizontalHeader()
        hv.setSectionResizeMode(QHeaderView.ResizeToContents)
        hv.setSectionResizeMode(len(V2V_COLS) - 1, QHeaderView.Stretch)
        vl.addWidget(self.v2v_table, 2)
        ev = QLabel("Latest messages and events"); ev.setObjectName("section"); vl.addWidget(ev)
        self.v2v_events = QListWidget(); self.v2v_events.setObjectName("log"); vl.addWidget(self.v2v_events, 1)
        self.v2v_table.setMinimumHeight(150); self.v2v_events.setMinimumHeight(110)
        from PyQt5.QtWidgets import QScrollArea
        vs = QScrollArea(); vs.setWidgetResizable(True); vs.setFrameShape(QFrame.NoFrame)
        vs.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        vw.setMinimumWidth(0)
        vs.setWidget(vw)
        self.tabs.addTab(vs, "V2V messages")
        rl.addWidget(self.tabs, 1)
        self.body.addWidget(right)
        self.body.setStretchFactor(0, 5)
        self.body.setStretchFactor(1, 6)
        v.addWidget(self.body, 1)
        self._shown_changed()

    def shown(self):
        return {k for k, c in self.show_cb.items() if c.isChecked()}

    def _shown_changed(self, *_a):
        s = self.shown()
        self.cam_box.setVisible("camera" in s)
        self.cam_pick.setVisible("camera" in s and self.cam_pick.count() > 1)
        for key, t in self.tiles.items():
            t.setVisible(key in s)
        for col, key in ((2, "LiDAR"), (3, "camera"), (4, "radar"), (5, "V2V")):
            self.table.setColumnHidden(col, key not in s)
        if "shown" in self.cb:
            self.cb["shown"](s)

    def set_cameras(self, labels, index=0):
        self.cam_pick.blockSignals(True)
        self.cam_pick.clear()
        self.cam_pick.addItems(labels)
        self.cam_pick.setCurrentIndex(max(0, min(index, len(labels) - 1)))
        self.cam_pick.blockSignals(False)
        self.cam_pick.setVisible("camera" in self.shown() and len(labels) > 1)

    def _place_tiles(self, cols):
        if cols == self._tile_cols:
            return
        self._tile_cols = cols
        for i, key in enumerate(("camera", "LiDAR", "radar", "V2V")):
            t = self.tiles[key]
            self._tile_grid.removeWidget(t)
            self._tile_grid.addWidget(t, i // cols, i % cols)
        for c in range(4):
            self._tile_grid.setColumnStretch(c, 1 if c < cols else 0)

    def fit_width(self, avail):
        """The room the pane has (the window's width): the sensor tiles 4 in a row, or 2 x 2 on a small screen."""
        self._place_tiles(4 if avail >= 1250 else 2)

    def set_av(self, name):
        self.title.setText(f"Detection details · {name}" if name else "Detection details")
        self.setVisible(bool(name))
        if "layout" in self.cb:
            self.cb["layout"](bool(name))

    def update_view(self, d):
        """d = {sensors_on, real, ahead, lidar / cam / radar: (dist, text, err) | None, why: {sensor: text},
        ttc, view, table, objects}"""
        on, shown = set(d["sensors_on"]) | ({"V2V"} if d.get("v2v_on") else set()), self.shown()
        vals = {"LiDAR": d.get("lidar"), "camera": d.get("cam"), "radar": d.get("radar"), "V2V": d.get("v2v")}
        for key, t in self.tiles.items():
            t.show_result(key in on, vals[key], (d.get("why") or {}).get(key, ""))
        tt = d["ttc"]
        fmt = lambda v: "--" if v is None else f"{v:.1f} s"
        gap = (f"<span style='color:{GREY}'>nothing in its lane ahead</span>" if d.get("real") is None
               else f"<b>{max(0.0, d['real']):.1f} m</b> to <b>{d['ahead']}</b>")
        self.ttc.setText(f"Real gap {gap} &nbsp;·&nbsp; TTC perceived {_ttc_html(tt[0])} · real {_ttc_html(tt[1])}"
                         f" &nbsp;<span style='color:{GREY}'>lowest {fmt(tt[2])} / {fmt(tt[3])} · {tt[4]} warning"
                         f"{'s' if tt[4] != 1 else ''}, {tt[5]} critical</span>")
        view = d.get("view")
        if view:
            view = dict(view)
            view["ranges"] = {k: r for k, r in (view.get("ranges") or {}).items() if k in shown}
            view["objs"] = [dict(o, det={s for s in o.get("det") or () if s in shown}) for o in view.get("objs") or []]
        self.view.set_data(view)
        rows = d.get("table") or []
        self.tabs.setTabText(1, f"Objects ({len(rows)})")
        self._fill_table(rows)
        self._fill_v2v(d.get("v2v_msgs"))

    def _fill_v2v(self, vm):
        """The V2V messages tab (MapWindow._v2v_messages)."""
        G = SENSOR_COL["V2V"]
        self.v2v_how.setText(
            "<span style='color:#94A3B8'>HOW V2V WORKS:</span> "
            f"<b style='color:{G}'>① SEND</b> each connected vehicle: its state 10× a second + a BRAKE ALERT at once "
            f"on hard braking → <b style='color:{G}'>② RADIO</b> delay, loss, range, buildings, channel load → "
            f"<b style='color:{G}'>③ RECEIVE</b> the latest message of every sender is kept → "
            f"<b style='color:{G}'>④ CHECK</b> fresh? in my lane, ahead, going my way? → "
            f"<b style='color:{G}'>⑤ USE</b> its distance, speed, brake → the AV brakes (like a sensor)")
        if not vm:
            self.v2v_head.setText(f"<span style='color:{GREY}'>No V2V in this test.</span>")
            self.v2v_load.setText(""); self.v2v_msg.setText("")
            self.v2v_table.setRowCount(0); self.v2v_events.clear()
            return
        ld, pf = vm.get("load"), vm.get("perf")
        if ld:
            if ld.get("cbr") is None:
                busy = (f"cellular: no shared radio channel · rate {ld['rate_hz']:.0f}/s · +{ld['extra_delay_ms']:.0f} ms "
                        "delay from the load")
            else:
                c = ld["cbr"] * 100
                col = G if c < 30 else AMBER if c < 55 else RED
                busy = (f"channel busy <b style='color:{col}'>{c:.0f} %</b>"
                        + (f" (would be {ld['cbr_demand'] * 100:.0f} % → congestion control slows every sender to "
                           f"<b>{ld['rate_hz']:.1f}</b> messages / s)" if ld["rate_hz"] < 9.95 else
                           f" · {ld['rate_hz']:.0f} messages / s each")
                        + (f" · <b style='color:{AMBER}'>+{ld['extra_loss'] * 100:.0f} % loss</b> (messages collide)"
                           if ld["extra_loss"] > 0.005 else " · no extra loss"))
            vpct = ld.get("verify_pct", 0.0)
            work = (f"≈ <b>{ld['rx_per_s_total']:.0f}</b> messages / s to check"
                    + (f" (a real unit checks ~2000 signatures / s: <b style='color:{RED if vpct > 100 else AMBER if vpct > 60 else G}'>"
                       f"{vpct:.0f} %</b> of it)" if ld["rx_per_s_total"] >= 1 else ""))
            app = (f" · <span style='color:{GREY}'>this app: V2V costs {pf['ms_avg']:.2f} ms per step (max "
                   f"{pf['ms_max']:.1f} ms), {pf['msgs_per_s']:.0f} messages made + {pf['pairs_per_s']:.0f} deliveries "
                   "worked out a second</span>" if pf else "")
            self.v2v_load.setText(
                f"<b style='color:{G}'>TRAFFIC</b> in radio range: <b>{ld['real']}</b> simulated vehicle"
                f"{'s' if ld['real'] != 1 else ''}" + (f" + <b>{ld['bg']}</b> extra nearby (load only)" if ld["bg"] else "")
                + f" · receives {ld['rx_per_s']:.0f} / s from the simulated ones · {busy}<br>"
                f"<b style='color:{G}'>WORKLOAD</b> {work}{app}")
        else:
            self.v2v_load.setText("")
        ex = vm.get("example")
        if ex:
            rows = "".join(
                f"<tr><td style='color:#E5E7EB; padding-right:10px'><b>{nm}</b></td>"
                f"<td style='color:{G}; padding-right:6px'>{val}</td><td style='color:{GREY}; padding-right:10px'>{unit}</td>"
                f"<td style='color:#CBD5E1'>{mean}</td></tr>" for nm, val, unit, mean in ex["fields"])
            x = ex.get("extra") or {}
            if ex["how"] == "received":
                dist = "" if x.get("dist") is None else f"{x['dist']:.0f} m away · "
                add = (f"<br><span style='color:{GREY}'>ADDED BY THE RECEIVER (not in the message):</span> age "
                       f"<b>{x.get('age_ms', 0):.0f} ms</b> · radio delay <b>{x.get('delay_ms', 0):.0f} ms</b> · {dist}"
                       f"its GNSS error <b>{x.get('err') or 0:.1f} m</b> (only the test knows) · decision: "
                       f"<b style='color:{G if str(x.get('use', '')).startswith('IN ITS LANE') else GREY}'>{x.get('use')}</b>")
            else:
                add = (f"<br><span style='color:{GREY}'>This AV receives nothing (V2V off or no sender) — this is its "
                       f"OWN last message as sent (GNSS error {x.get('err') or 0:.1f} m).</span>")
            self.v2v_msg.setText(
                f"<b>{'Received from' if ex['how'] == 'received' else 'Sent by this AV:'} {ex['from']}</b> "
                f"<span style='color:{GREY}'>· ~{ex['bytes']} bytes on the air (with the security signature) · in "
                f"this simulation plain data, no encoding / signing</span>"
                f"<table cellspacing='0' cellpadding='1'>{rows}</table>{add}")
        else:
            self.v2v_msg.setText(f"<span style='color:{GREY}'>No message yet.</span>")
        rows = vm.get("rows") or []
        self.tabs.setTabText(2, f"V2V messages ({len(rows)})" if vm.get("on") else "V2V messages (off)")
        s = vm.get("sent")
        rate = (ld or {}).get("rate_hz", 10.0)
        sent = (f"<b style='color:{G}'>SENDS</b> {s['n']} messages so far ({rate:.0f} a second"
                + (", slowed by congestion control" if rate < 9.95 else "") + f") + {s['alerts']} brake "
                f"alert{'s' if s['alerts'] != 1 else ''} · last: its GNSS position (error now {s['err'] or 0:.1f} m), "
                f"{s['v'] * 3.6:.0f} km/h, heading {s['hd'] if s['hd'] is None else round(s['hd'])}°, "
                f"{s['a']:+.1f} m/s², {'BRAKING' if s['brake'] else 'not braking'}, length {s['L']:.1f} m"
                if s else f"<b style='color:{GREY}'>SENDS</b> nothing (V2V off)")
        st = vm.get("stats")
        rec = (f"<b style='color:{G}'>RECEIVES</b> {st['received']} delivered, {st['lost']} lost ({st['loss_pct']:g} %)"
               + (f", {st['blocked']} blocked by buildings" if st.get("blocked") else "")
               + (f" · average radio delay {st['delay_ms']:g} ms" if st.get("delay_ms") is not None else "")
               + f" · {st['alerts']} brake alerts · holding <b>{len(rows)}</b> fresh message{'s' if len(rows) != 1 else ''} now"
               if st else f"<b style='color:{GREY}'>RECEIVES</b> nothing (V2V off)")
        self.v2v_head.setText(f"<span style='color:{GREY}'>{vm.get('link', '')}</span><br>{sent}<br>{rec}")
        tb = self.v2v_table
        tb.setRowCount(len(rows))
        for r, m in enumerate(rows):
            used = m["use"].startswith("IN ITS LANE")
            vals = [(m["from"], "#E5E7EB"), (m["kind"], RED if m["kind"].startswith("BRAKE") else "#CBD5E1"),
                    (f"{m['age_ms']:.0f} ms", "#CBD5E1"), (f"{m['delay_ms']:.0f} ms", "#CBD5E1"),
                    ("--" if m.get("ahead") is None else f"{m['ahead']:.1f} m / {m['left']:+.1f} m", "#CBD5E1"),
                    (f"{m['v'] * 3.6:.0f} km/h", "#CBD5E1"),
                    ("--" if m.get("hd") is None else f"{m['hd']:.0f}°", "#CBD5E1"),
                    (f"{m['a']:+.1f} m/s²", AMBER if m["a"] < -2 else "#CBD5E1"),
                    ("BRAKING" if m["brake"] else "no", RED if m["brake"] else GREY),
                    (f"{m['L']:.1f} m", "#CBD5E1"), (f"{m['err'] or 0:.1f} m", GREY),
                    (m["use"], G if used else GREY)]
            for c, (text, col) in enumerate(vals):
                it = tb.item(r, c)
                if it is None:
                    it = QTableWidgetItem(); tb.setItem(r, c, it)
                it.setText(text); it.setForeground(QColor(col)); it.setToolTip(text)
        ev = vm.get("events") or []
        if [self.v2v_events.item(i).text() for i in range(self.v2v_events.count())] != ev:
            self.v2v_events.clear()
            self.v2v_events.addItems(ev)

    def set_camera(self, pix, overlay, calc):
        """calc = {title, lines: [(name, formula, value)], note}"""
        self.cam.set_shot(pix, overlay)
        calc = calc or {}
        self.cam_title.setText(calc.get("camera") or "Camera view")
        self.calc_head.setText(calc.get("title") or "Distance from the camera image")
        rows = "".join(f"<tr><td style='color:#94A3B8; padding-right:10px'>{n}</td><td>{f}</td>"
                       f"<td style='padding-left:10px'><b>{v}</b></td></tr>" for n, f, v in calc.get("lines") or [])
        self.calc_lines.setText(f"<table cellspacing='0' cellpadding='1'>{rows}</table>" if rows else "")
        self.calc_lines.setVisible(bool(rows))
        self.calc_note.setText(calc.get("note") or "")

    def _fill_table(self, rows):
        tb = self.table
        if tb.rowCount() != len(rows):
            tb.setRowCount(len(rows))
        for r, row in enumerate(rows):
            cells = [(row["obj"], "#E5E7EB"), (row["real"], "#CBD5E1"), row["LiDAR"], row["camera"], row["radar"],
                     tuple(row.get("V2V") or ("--", GREY)), row["lane"]]
            for c, (text, col) in enumerate(cells):
                it = tb.item(r, c)
                if it is None:
                    it = QTableWidgetItem(); tb.setItem(r, c, it)
                if it.text() != text:
                    it.setText(text)
                it.setForeground(QColor(col))
                if c == 0:
                    f = it.font(); f.setBold(bool(row.get("bold"))); it.setFont(f)


class _SetupRow(QFrame):
    """One AV of the setup: its place, which AV, top speed, gap, its sensors."""

    def __init__(self, k, autos, new_label):
        super().__init__()
        self.setObjectName("tile")
        h = QHBoxLayout(self); h.setContentsMargins(10, 6, 10, 6); h.setSpacing(8)
        self.badge = QLabel(); self.badge.setObjectName("role"); self.badge.setFixedWidth(64)
        h.addWidget(self.badge)
        self.which = QComboBox(); self.which.setMinimumWidth(230)
        for vid, label in autos:
            self.which.addItem(label, vid)
        self.which.addItem(new_label, None)
        self.which.setToolTip("The yard's autonomous vehicle (AV) to use, or a new one just for this test (removed after)")
        h.addWidget(self.which, 1)
        self.kmh = QDoubleSpinBox(); self.kmh.setRange(5, 60); self.kmh.setDecimals(0)
        self.kmh.setPrefix("Top "); self.kmh.setSuffix(" km/h")
        self.kmh.setToolTip("Its top speed: it drives the route at this when nothing is in its lane ahead")
        h.addWidget(self.kmh)
        self.gap = QDoubleSpinBox(); self.gap.setRange(3, 60); self.gap.setDecimals(0)
        self.gap.setPrefix("Gap "); self.gap.setSuffix(" m"); self.gap.setValue(15)
        self.gap.setToolTip("The gap it keeps behind what is ahead of it (the start places the AVs this far apart)")
        h.addWidget(self.gap)
        self.sw = {}
        for key, text in SENSORS:
            b = QPushButton(text); b.setObjectName("mini"); b.setCheckable(True); b.setChecked(True)
            b.setCursor(Qt.PointingHandCursor); b.setFixedWidth(70)
            b.setToolTip(f"Its {text} on at the start (switched on / off while it drives on its card)")
            b.toggled.connect(lambda on, bb=b, kk=key, tt=text: (bb.setText(f"{tt} {'ON' if on else 'OFF'}"),
                                                                 _switch_style(bb, kk, on)))
            b.setText(f"{text} ON"); _switch_style(b, key, True)
            h.addWidget(b)
            self.sw[key] = b
        b = QPushButton(); b.setObjectName("mini"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
        b.setFixedWidth(62)
        b.setToolTip("V2V: it sends its state and brake alerts, and receives those of the connected vehicles ahead "
                     "(settings below)")
        b.toggled.connect(lambda on, bb=b: (bb.setText(f"V2V {'ON' if on else 'OFF'}"), _switch_style(bb, "V2V", on)))
        b.setChecked(False); b.setText("V2V OFF"); _switch_style(b, "V2V", False)
        h.addWidget(b)
        self.sw["V2V"] = b
        self.set_index(k)

    def set_index(self, k):
        self.badge.setText(f"AV {k + 1}" + ("\nFRONT" if k == 0 else ""))

    def values(self):
        return (self.which.currentData(), self.kmh.value(), self.gap.value(),
                {k for k, b in self.sw.items() if b.isChecked()})


PLAN_MAX = 20                  # loops planned one by one (later loops keep the last one's settings)


def plan_text(plan, base=None):
    """A loop plan in a few words per loop: 'L1 Clear sky · L2 Fog · L3 AV1 stop & go · L4 AV2 radar OFF'."""
    out = []
    for i, lp in enumerate(plan or []):
        bits = [lp.get("climate_label")] if lp.get("climate_label") else []
        for k, t in enumerate(lp.get("trucks") or []):
            b = (base or [None] * (k + 1))[k] if base and k < len(base) else None
            tb = []
            if b and abs(float(t.get("kmh", 0)) - float(b[0])) > 0.4:
                tb.append(f"{t['kmh']:g} km/h")
            off = [s for s in ("LiDAR", "camera", "radar") if s not in (t.get("sensors") or [])]
            if off:
                tb.append(" / ".join(off) + " OFF")
            if "V2V" in (t.get("sensors") or []):
                tb.append("V2V")
            if t.get("sg"):
                tb.append("stop & go")
            if tb:
                bits.append(f"AV{k + 1} " + ", ".join(tb))
        out.append(f"L{i + 1}: " + ("; ".join(bits) if bits else "as set"))
    return "  ·  ".join(out)


class _PlanRow(QFrame):
    """One AV in one loop of the plan: top speed, sensors, stop & go (after / stand / every)."""

    def __init__(self, k, name, t):
        super().__init__()
        self.setObjectName("tile")
        h = QHBoxLayout(self); h.setContentsMargins(10, 5, 10, 5); h.setSpacing(7)
        b = QLabel(f"AV {k + 1}"); b.setObjectName("role"); b.setFixedWidth(56); b.setToolTip(name); h.addWidget(b)
        n = QLabel(name); n.setObjectName("small"); n.setFixedWidth(150); h.addWidget(n)
        self.kmh = QDoubleSpinBox(); self.kmh.setRange(5, 60); self.kmh.setDecimals(0); self.kmh.setPrefix("Top ")
        self.kmh.setSuffix(" km/h"); self.kmh.setValue(float(t.get("kmh", 15))); h.addWidget(self.kmh)
        self.sw = {}
        for key, text in SENSORS:
            sb = QPushButton(); sb.setObjectName("mini"); sb.setCheckable(True); sb.setFixedWidth(78)
            sb.setCursor(Qt.PointingHandCursor)
            sb.toggled.connect(lambda on, bb=sb, kk=key, tt=text: (bb.setText(f"{tt} {'ON' if on else 'OFF'}"),
                                                                   _switch_style(bb, kk, on)))
            sb.setChecked(key in (t.get("sensors") or []))
            sb.setText(f"{text} {'ON' if sb.isChecked() else 'OFF'}"); _switch_style(sb, key, sb.isChecked())
            h.addWidget(sb)
            self.sw[key] = sb
        sb = QPushButton(); sb.setObjectName("mini"); sb.setCheckable(True); sb.setFixedWidth(64)
        sb.setCursor(Qt.PointingHandCursor)
        sb.setToolTip("V2V in this loop")
        sb.toggled.connect(lambda on, bb=sb: (bb.setText(f"V2V {'ON' if on else 'OFF'}"), _switch_style(bb, "V2V", on)))
        sb.setChecked("V2V" in (t.get("sensors") or []))
        sb.setText(f"V2V {'ON' if sb.isChecked() else 'OFF'}"); _switch_style(sb, "V2V", sb.isChecked())
        h.addWidget(sb)
        self.sw["V2V"] = sb
        sg = t.get("sg") or {}
        self.sg = QCheckBox("Stop && go"); self.sg.setChecked(bool(t.get("sg")))
        self.sg.setToolTip("In this loop it stops on its own (whatever its sensors see), stands, drives on -- the "
                           "AVs behind it must brake for it")
        h.addWidget(self.sg)
        self.after = QDoubleSpinBox(); self.after.setRange(0, 3600); self.after.setDecimals(0)
        self.after.setPrefix("after "); self.after.setSuffix(" s"); self.after.setValue(float(sg.get("delay", 20)))
        self.after.setToolTip("The first stop this long after the loop starts")
        self.stand = QDoubleSpinBox(); self.stand.setRange(1, 120); self.stand.setDecimals(0)
        self.stand.setPrefix("stand "); self.stand.setSuffix(" s"); self.stand.setValue(float(sg.get("hold", 6)))
        self.every = QDoubleSpinBox(); self.every.setRange(0, 3600); self.every.setDecimals(0)
        self.every.setPrefix("every "); self.every.setSuffix(" s"); self.every.setSpecialValueText("once")
        self.every.setValue(float(sg.get("repeat", 0)))
        self.every.setToolTip("Again every this many seconds in this loop (once: one stop)")
        for x in (self.after, self.stand, self.every):
            h.addWidget(x)
        self.sg.toggled.connect(lambda on: [x.setEnabled(on) for x in (self.after, self.stand, self.every)])
        for x in (self.after, self.stand, self.every):
            x.setEnabled(self.sg.isChecked())
        h.addStretch()

    def value(self):
        return {"kmh": self.kmh.value(), "sensors": [k for k, b in self.sw.items() if b.isChecked()],
                "sg": ({"delay": self.after.value(), "hold": self.stand.value(), "repeat": self.every.value(),
                        "decel": 3.0} if self.sg.isChecked() else None)}


class LoopPlanDialog(QDialog):
    """Different settings for each loop of a collision test: the climate, and per AV its top speed, sensors
    and stop & go. AVs = [(name, kmh, sensors)] (the setup's), climates = [(id, label)], plan = an earlier plan.
    plan() -> [{climate, climate_label, AVs: [{kmh, sensors, sg}]}] per loop."""

    def __init__(self, parent, n, trucks, climates, plan=None):
        super().__init__(parent)
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE)
        self.setWindowTitle("Loop plan")
        self.trucks, self.climates = trucks, climates
        lay = QVBoxLayout(self); lay.setContentsMargins(16, 12, 16, 12); lay.setSpacing(8)
        t = QLabel("Loop plan -- settings for each loop"); t.setObjectName("title"); lay.addWidget(t)
        s = QLabel("Each loop can have its own climate and, per AV, its top speed, sensors and stop & go. An AV "
                   "takes its settings when IT starts that loop; the climate changes when the front AV starts it."
                   + (f" Loops after {PLAN_MAX} keep loop {PLAN_MAX}'s settings." if n > PLAN_MAX else ""))
        s.setObjectName("muted"); s.setWordWrap(True); lay.addWidget(s)
        self.tabs = QTabWidget()
        self.pages = []
        base = {"climate": None, "trucks": [{"kmh": kmh, "sensors": list(sens), "sg": None} for _n, kmh, sens in trucks]}
        for i in range(min(n, PLAN_MAX)):
            lp = (plan or [])[i] if plan and i < len(plan) else base
            pg = QWidget(); pl = QVBoxLayout(pg); pl.setContentsMargins(8, 8, 8, 8); pl.setSpacing(6)
            ch = QHBoxLayout()
            cl = QLabel("Climate"); cl.setObjectName("section"); ch.addWidget(cl)
            cb = QComboBox(); cb.addItem("Keep the climate as it is", None)
            for cid, lab in climates:
                cb.addItem(lab, cid)
            j = cb.findData(lp.get("climate"))
            cb.setCurrentIndex(max(0, j))
            cb.setMinimumWidth(260)
            cb.view().setMinimumWidth(max([cb.fontMetrics().horizontalAdvance(cb.itemText(k))
                                           for k in range(cb.count())] or [200]) + 48)   # (full names in the list)
            ch.addWidget(cb); ch.addStretch()
            pl.addLayout(ch)
            rows = []
            for k, (name, kmh, sens) in enumerate(trucks):
                tv = (lp.get("trucks") or [])[k] if k < len(lp.get("trucks") or []) else \
                    {"kmh": kmh, "sensors": list(sens), "sg": None}
                r = _PlanRow(k, name, tv)
                pl.addWidget(r)
                rows.append(r)
            pl.addStretch()
            self.tabs.addTab(pg, f"Loop {i + 1}")
            self.pages.append((cb, rows))
        lay.addWidget(self.tabs, 1)
        bb = QHBoxLayout()
        cp = QPushButton("Copy this loop to all"); cp.setToolTip("Every loop gets the settings of the loop shown")
        cp.clicked.connect(self._copy_all); bb.addWidget(cp)
        rs = QPushButton("Reset"); rs.setToolTip("Every loop as the setup (the climate kept)")
        rs.clicked.connect(self._reset); bb.addWidget(rs)
        bb.addStretch()
        c = QPushButton("Cancel"); c.clicked.connect(self.reject); bb.addWidget(c)
        o = QPushButton("Use this plan"); o.setObjectName("accent"); o.setDefault(True); o.clicked.connect(self.accept)
        bb.addWidget(o)
        lay.addLayout(bb)
        self.resize(1080, 200 + 52 * max(1, len(trucks)))

    def _set(self, i, lp):
        cb, rows = self.pages[i]
        cb.setCurrentIndex(max(0, cb.findData(lp.get("climate"))))
        for r, t in zip(rows, lp["trucks"]):
            r.kmh.setValue(t["kmh"])
            for k, b in r.sw.items():
                b.setChecked(k in t["sensors"])
            r.sg.setChecked(bool(t["sg"]))
            if t["sg"]:
                r.after.setValue(t["sg"]["delay"]); r.stand.setValue(t["sg"]["hold"]); r.every.setValue(t["sg"]["repeat"])

    def _copy_all(self):
        cur = self.plan()[self.tabs.currentIndex()]
        for i in range(len(self.pages)):
            self._set(i, cur)

    def _reset(self):
        base = {"climate": None, "trucks": [{"kmh": kmh, "sensors": list(sens), "sg": None}
                                            for _n, kmh, sens in self.trucks]}
        for i in range(len(self.pages)):
            self._set(i, base)

    def plan(self):
        out = []
        for cb, rows in self.pages:
            out.append({"climate": cb.currentData(), "climate_label": cb.currentText() if cb.currentData() else None,
                        "trucks": [r.value() for r in rows]})
        return out


LAST_SETUP = "Last test"        # (the setup of the last test started -- kept automatically)


def load_setups(path):
    """Saved collision-test setups {name: setup} (CollisionSetupDialog.config()); {} if none / unreadable."""
    import json, os
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return {str(k): v for k, v in (d.get("setups") or {}).items() if isinstance(v, dict)}
    except (OSError, ValueError, AttributeError):
        return {}


def _write_setups(path, setups):
    import json, os
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"setups": setups}, f, indent=1, ensure_ascii=False)
    os.replace(tmp, path)


def save_setup(path, name, setup):
    import time
    s = load_setups(path)
    s[name] = dict(setup, saved=time.strftime("%Y-%m-%d %H:%M"))
    _write_setups(path, s)


def delete_setup(path, name):
    s = load_setups(path)
    if s.pop(name, None) is not None:
        _write_setups(path, s)


class CollisionSetupDialog(QDialog):
    """The setup of a collision test. routes = [name]; route_info(name) -> (text, two_way[, loop route]);
    autos = [(id, label)]; climate = text. values() -> (route, drive_side, rows [(id | None, kmh, gap, sensors
    (+ "V2V"))], hold_s, loops (1: once, 0: until ended), loop plan | None, V2V settings)."""

    def __init__(self, parent, routes, route_info, autos, climate, drive_side="left", history=None, climates=None,
                 setups_file=None):
        super().__init__(parent)
        self.history = history
        self.setups_file = setups_file
        self.climates = climates or []
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE)
        self.setWindowTitle("Collision testing")
        self.setSizeGripEnabled(True)
        self.route_info, self.autos = route_info, autos
        # the setup scrolls (a small screen); Cancel / Start stay at the bottom, always in view
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 12); outer.setSpacing(8)
        self._body = QWidget(); self._body.setObjectName("setupBody")
        self._body.setStyleSheet("QWidget#setupBody { background: transparent; }")
        lay = QVBoxLayout(self._body); lay.setContentsMargins(16, 14, 16, 4); lay.setSpacing(10)
        self._scroll = QScrollArea(); self._scroll.setWidgetResizable(True); self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setWidget(self._body)
        outer.addWidget(self._scroll, 1)
        t = QLabel("New collision test"); t.setObjectName("title"); lay.addWidget(t)
        sub = QLabel("Autonomous vehicles (AVs) drive a saved route one behind the other. Each brakes only on what its own "
                     "camera / LiDAR / radar detect, with its own TTC.")
        sub.setObjectName("muted"); sub.setWordWrap(True); lay.addWidget(sub)
        # saved setups: the whole setup (route, loops + plan, AVs, V2V, publish) kept by name -- quick re-use
        if self.setups_file:
            sc = QFrame(); sc.setObjectName("pane")
            sl = QHBoxLayout(sc); sl.setContentsMargins(12, 8, 12, 8); sl.setSpacing(8)
            h = QLabel("Saved setups"); h.setObjectName("section"); sl.addWidget(h)
            self.setup_box = QComboBox(); self.setup_box.setMinimumWidth(260)
            self.setup_box.setToolTip("Load a saved setup: route, loops and their plan, the AVs (speed, gap, "
                                      "sensors), hold time, V2V and publish settings.\n'Last test' is the setup of "
                                      "the last test you started (kept automatically).")
            self.setup_box.activated.connect(self._setup_picked)
            sl.addWidget(self.setup_box, 1)
            b = QPushButton("Save as ..."); b.setToolTip("Keep this setup under a name, to load it again next time")
            ic = _qicon("fa5s.save", "#A7F3D0")
            if ic is not None:
                b.setIcon(ic)
            b.clicked.connect(self._setup_save)
            sl.addWidget(b)
            self.setup_del = QPushButton("Delete"); self.setup_del.setToolTip("Delete the chosen saved setup")
            self.setup_del.clicked.connect(self._setup_delete)
            sl.addWidget(self.setup_del)
            self.setup_note = QLabel(); self.setup_note.setObjectName("muted"); self.setup_note.setWordWrap(True)
            self.setup_note.setVisible(False)
            lay.addWidget(sc)
            lay.addWidget(self.setup_note)
        # route
        rc = QFrame(); rc.setObjectName("pane")
        rl = QGridLayout(rc); rl.setContentsMargins(12, 10, 12, 10); rl.setHorizontalSpacing(10); rl.setVerticalSpacing(6)
        h = QLabel("Route"); h.setObjectName("section"); rl.addWidget(h, 0, 0)
        self.route = QComboBox(); self.route.addItems(list(routes)); self.route.setMinimumWidth(260)
        rl.addWidget(self.route, 0, 1)
        self.side = QComboBox()
        self.side.addItem("Keep left", "left"); self.side.addItem("Keep right", "right")
        self.side.setCurrentIndex(0 if drive_side == "left" else 1)
        self.side.setToolTip("On a two-way route (out and back on the same road) the AVs drive in this lane, so "
                             "AVs coming the other way pass instead of stopping for each other")
        rl.addWidget(self.side, 0, 2)
        self.rinfo = QLabel(); self.rinfo.setObjectName("muted"); self.rinfo.setWordWrap(True)
        rl.addWidget(self.rinfo, 1, 1, 1, 2)
        h = QLabel("Loops"); h.setObjectName("section"); rl.addWidget(h, 2, 0)
        lh = QHBoxLayout(); lh.setSpacing(8)
        self.loop_cb = QCheckBox("Loop the test")
        self.loop_cb.setToolTip("Off: the AVs drive the route once. On: again and again -- the window shows which "
                                "loop is running; the results summary comes when the last loop is done")
        lh.addWidget(self.loop_cb)
        self.loops = QSpinBox(); self.loops.setRange(0, 999); self.loops.setValue(3)
        self.loops.setSuffix(" loops"); self.loops.setSpecialValueText("until I end it")
        self.loops.setToolTip("How many loops (0: until you end the test)")
        self.loops.setEnabled(False)
        lh.addWidget(self.loops)
        self.plan_btn = QPushButton("Plan the loops ...")
        ic = _qicon("fa5s.list-ol", "#E9D5FF")
        if ic is not None:
            self.plan_btn.setIcon(ic)
        self.plan_btn.setToolTip("Different settings for each loop: the climate, and per AV its top speed, sensors "
                                 "(e.g. radar OFF in loop 3) and stop & go")
        self.plan_btn.setEnabled(False)
        self.plan_btn.clicked.connect(self._plan)
        lh.addWidget(self.plan_btn)
        self.loop_info = QLabel(); self.loop_info.setObjectName("muted"); self.loop_info.setWordWrap(True)
        lh.addWidget(self.loop_info, 1)
        rl.addLayout(lh, 2, 1, 1, 2)
        self.plan_info = QLabel(); self.plan_info.setWordWrap(True); self.plan_info.setVisible(False)
        self.plan_info.setStyleSheet("color: #E9D5FF; font-size: 11px;")
        rl.addWidget(self.plan_info, 3, 1, 1, 2)
        rl.setColumnStretch(1, 1)
        lay.addWidget(rc)
        self._route_loop = False
        self.plan_ = None
        self.loop_cb.toggled.connect(lambda on: (self.loops.setEnabled(on), self._loop_text()))
        self.loops.valueChanged.connect(lambda *_a: self._loop_text())
        self.route.currentTextChanged.connect(self._route_changed)
        # AVs
        tc = QFrame(); tc.setObjectName("pane")
        tl = QVBoxLayout(tc); tl.setContentsMargins(12, 10, 12, 10); tl.setSpacing(6)
        th = QHBoxLayout()
        h = QLabel("Autonomous vehicles (AVs)"); h.setObjectName("section"); th.addWidget(h)
        th.addStretch()
        self.minus = QToolButton(); self.minus.setObjectName("follow"); self.minus.setText("−")
        self.count = QLabel("3"); self.count.setObjectName("section"); self.count.setFixedWidth(22)
        self.count.setAlignment(Qt.AlignCenter)
        self.plus = QToolButton(); self.plus.setObjectName("follow"); self.plus.setText("+")
        self.minus.clicked.connect(lambda: self._set_count(len(self.rows) - 1))
        self.plus.clicked.connect(lambda: self._set_count(len(self.rows) + 1))
        for w in (self.minus, self.count, self.plus):
            th.addWidget(w)
        tl.addLayout(th)
        self.rows_box = QVBoxLayout(); self.rows_box.setSpacing(5)
        tl.addLayout(self.rows_box)
        lay.addWidget(tc)
        self.rows = []
        # weather + hold
        wc = QHBoxLayout(); wc.setSpacing(10)
        cl = QLabel(climate); cl.setObjectName("chip"); cl.setWordWrap(True)
        cl.setToolTip("The climate is set with the Climate drop-down above the map (also during the test)")
        wc.addWidget(cl, 1)
        hl = QLabel("On a collision, hold"); hl.setObjectName("muted"); wc.addWidget(hl)
        self.hold = QDoubleSpinBox(); self.hold.setRange(0, 120); self.hold.setValue(10); self.hold.setSuffix(" s")
        self.hold.setDecimals(0)
        self.hold.setToolTip("After a collision the AVs involved stand still this long (to look at the details)")
        wc.addWidget(self.hold)
        self.near_miss = QCheckBox("Show near misses in 3D")
        self.near_miss.setChecked(False)
        self.near_miss.setToolTip("Off (default): the 3D view shows only collisions and collisions prevented by V2V.\n"
                                  "On: also a beacon for each near miss (time to collision below the critical TTC).")
        wc.addWidget(self.near_miss)
        lay.addLayout(wc)
        # V2V (the AVs with V2V ON; India: PC5 is the coming direct link, V2N works on today's 4G / 5G)
        import v2v as v2v_mod
        vc = QFrame(); vc.setObjectName("pane")
        vg = QGridLayout(vc); vg.setContentsMargins(12, 8, 12, 8); vg.setHorizontalSpacing(8); vg.setVerticalSpacing(5)
        vh = QLabel("V2V"); vh.setObjectName("section"); vh.setStyleSheet(f"color: {SENSOR_COL['V2V']};")
        vh.setToolTip("Vehicle-to-vehicle messages (only in this test): each AV with V2V ON sends its state 10x a "
                      "second and a brake alert at once when it brakes hard; it gets those of the connected vehicles "
                      "ahead -- fog does not stop them. Switch V2V per AV above (and per loop in the loop plan).")
        vg.addWidget(vh, 0, 0)
        self.v_link = QComboBox()
        for k, d in v2v_mod.LINKS.items():
            self.v_link.addItem(f"{d['label']} · ~{d['delay_ms']:.0f} ms", k)
        self.v_link.setToolTip("Direct C-V2X (PC5): vehicle to vehicle, ~20 ms, ~450 m, buildings block it (needs the "
                               "5.9 GHz band -- not yet assigned in India).\nCellular 4G/5G (V2N): through the "
                               "operator's network, ~90 ms (40 - 200), works today, not blocked by buildings.")
        vg.addWidget(self.v_link, 0, 1, 1, 2)
        self.v_gnss = QComboBox()
        for k, (lab, _s) in v2v_mod.GNSS.items():
            self.v_gnss.addItem(lab, k)
        self.v_gnss.setToolTip("How exactly each vehicle knows its own position (what it sends): NavIC / GPS ~2.5 m, "
                               "GAGAN ~1.2 m, RTK ~0.1 m -- a large error can put the vehicle ahead in the wrong lane")
        vg.addWidget(self.v_gnss, 0, 3)
        self.v_mode = QComboBox()
        for k, lab in v2v_mod.MODES.items():
            self.v_mode.addItem(lab, k)
        vg.addWidget(self.v_mode, 0, 4)
        ll = QLabel("Loss"); ll.setObjectName("muted"); vg.addWidget(ll, 1, 1, Qt.AlignRight)
        self.v_loss = QSpinBox(); self.v_loss.setRange(0, 50); self.v_loss.setSuffix(" %")
        self.v_loss.setValue(int(v2v_mod.DEFAULTS["loss_pct"]))
        self.v_loss.setToolTip("Messages lost on top of the link's own loss (congestion, interference)")
        vg.addWidget(self.v_loss, 1, 2)
        self.v_block = QCheckBox("Buildings block the direct link"); self.v_block.setChecked(True)
        self.v_block.setToolTip("Direct link: a building between the two vehicles (OpenStreetMap buildings) -- much "
                                "more loss and ~150 m range there")
        vg.addWidget(self.v_block, 1, 3)
        cl2 = QHBoxLayout(); cl2.setSpacing(6)
        cl2.addWidget(QLabel("Scene vehicles connected"))
        self.v_conn = QSpinBox(); self.v_conn.setRange(0, 100); self.v_conn.setSingleStep(10); self.v_conn.setSuffix(" %")
        self.v_conn.setToolTip("The share of the scene's vehicles (cars / trucks / buses) that also send V2V "
                               "(India: mixed traffic, few connected). Pedestrians / obstacles never.")
        cl2.addWidget(self.v_conn)
        vg.addLayout(cl2, 1, 4)
        cl3 = QHBoxLayout(); cl3.setSpacing(6)
        cl3.addWidget(QLabel("Heavy traffic: extra connected vehicles nearby"))
        self.v_bg = QSpinBox(); self.v_bg.setRange(0, 1000); self.v_bg.setSingleStep(50)
        self.v_bg.setSpecialValueText("none")
        self.v_bg.setToolTip("Vehicles that only load the radio channel (not drawn, not simulated one by one): they "
                             "are in range of every AV and send 10 messages a second.\nDirect link: the channel "
                             "gets busy (CBR) -> congestion control slows every sender (10 -> 5 -> 2 a second) and "
                             "more messages collide (loss).\nE.g. 100 vehicles: 20 % busy, no effect; 200: 40 %, "
                             "+5 % loss; 300: 60 %, +15 % loss; 600: senders slow to 5 a second to keep it at 60 %.")
        cl3.addWidget(self.v_bg)
        self.v_bg_info = QLabel(); self.v_bg_info.setObjectName("muted"); cl3.addWidget(self.v_bg_info, 1)
        vg.addLayout(cl3, 2, 1, 1, 4)

        def _bg_text(*_a):
            ld = v2v_mod.load_of(self.v_bg.value() + 2, self.v_link.currentData())
            if self.v_link.currentData() != "pc5":
                self.v_bg_info.setText(f"cellular: no shared channel · ~+{ld['extra_delay_ms']:.0f} ms delay")
            else:
                self.v_bg_info.setText(f"channel busy ~{ld['cbr'] * 100:.0f} %"
                                       + (f" (wanted {ld['cbr_demand'] * 100:.0f} %)" if ld['rate_hz'] < 9.95 else "")
                                       + f" · {ld['rate_hz']:.1f} messages / s each · +{ld['extra_loss'] * 100:.0f} % loss")
        self.v_bg.valueChanged.connect(_bg_text)
        self.v_link.currentIndexChanged.connect(_bg_text)
        _bg_text()
        vg.setColumnStretch(4, 1)
        self.v_link.currentIndexChanged.connect(
            lambda *_a: self.v_block.setEnabled(v2v_mod.LINKS[self.v_link.currentData()]["blocking"]))
        lay.addWidget(vc)
        # publish to hardware (MQTT): the chosen AVs' live state, a topic per AV (hw_publish.py)
        import hw_publish
        self.pub = dict(hw_publish.settings(), on=False)
        pc = QFrame(); pc.setObjectName("pane")
        pl = QHBoxLayout(pc); pl.setContentsMargins(12, 8, 12, 8); pl.setSpacing(10)
        ph = QLabel("Publish"); ph.setObjectName("section"); ph.setStyleSheet("color: #22D3EE;")
        pl.addWidget(ph)
        self.pub_btn = QPushButton("Publish data to hardware (MQTT) ...")
        ic = _qicon("fa5s.broadcast-tower", "#22D3EE")
        if ic is not None:
            self.pub_btn.setIcon(ic)
        self.pub_btn.setToolTip("While the test runs: each chosen AV's speed, position (lat, lon, heading), brake "
                                "state ... as an MQTT message on its own topic -- to drive model vehicles (ESP32)")
        self.pub_btn.clicked.connect(self._publish_setup)
        pl.addWidget(self.pub_btn)
        self.pub_info = QLabel(); self.pub_info.setObjectName("muted"); self.pub_info.setWordWrap(True)
        pl.addWidget(self.pub_info, 1)
        lay.addWidget(pc)
        self._pub_text()
        bb = QHBoxLayout()
        if self.history is not None:
            hb = QPushButton("Collision history")
            ic = _qicon("fa5s.history", "#E5E7EB")
            if ic is not None:
                hb.setIcon(ic)
            hb.setToolTip("Re-check the collisions of earlier tests in this yard: where, what, why")
            hb.clicked.connect(lambda: self.history())
            bb.addWidget(hb)
        bb.addStretch()
        c = QPushButton("Cancel"); c.clicked.connect(self.reject); bb.addWidget(c)
        s = QPushButton("▶  Start the test"); s.setObjectName("accent"); s.setDefault(True); s.clicked.connect(self.accept)
        bb.addWidget(s)
        bb.setContentsMargins(16, 0, 16, 0)
        outer.addLayout(bb)
        self._set_count(3)
        self._route_changed(self.route.currentText())
        if self.setups_file:
            self._fill_setups()
        self._built = True
        self._fit_size()

    def _fit_size(self):
        """As big as the setup needs, but within the screen (the rest scrolls): Start always visible."""
        from PyQt5.QtWidgets import QApplication
        self._body.adjustSize()
        hint = self._body.sizeHint()
        scr = (self.windowHandle().screen() if self.windowHandle() is not None else None) or \
            QApplication.primaryScreen()
        g = scr.availableGeometry()
        w = min(max(hint.width() + 24, 760), g.width() - 30)
        h = min(hint.height() + 64, g.height() - 50)          # (+ the button bar; - the title bar)
        self.resize(w, h)
        if self.isVisible():
            self._keep_on_screen()

    def _keep_on_screen(self):
        from PyQt5.QtWidgets import QApplication
        scr = (self.windowHandle().screen() if self.windowHandle() is not None else None) or \
            QApplication.primaryScreen()
        g = scr.availableGeometry()
        fg = self.frameGeometry()
        x = min(max(fg.x(), g.left()), g.right() - fg.width() + 1)
        y = min(max(fg.y(), g.top()), g.bottom() - fg.height() + 1)
        if (x, y) != (fg.x(), fg.y()):
            self.move(x, y)

    def showEvent(self, e):
        super().showEvent(e)
        from PyQt5.QtCore import QTimer
        QTimer.singleShot(0, self._keep_on_screen)            # (centred on the main window: may reach off screen)

    # ---- saved setups ----
    def _fill_setups(self, select=None):
        s = load_setups(self.setups_file)
        names = ([LAST_SETUP] if LAST_SETUP in s else []) + sorted((k for k in s if k != LAST_SETUP), key=str.lower)
        self.setup_box.blockSignals(True)
        self.setup_box.clear()
        self.setup_box.addItem("-- choose a saved setup to load --" if names else "-- no saved setups yet --", None)
        for k in names:
            v = s[k]
            self.setup_box.addItem(f"{k}   ·   {v.get('route', '?')}, {len(v.get('trucks') or [])} AVs"
                                   + (f", {v.get('loops')} loops" if v.get("loop") else "")
                                   + (f"   ({v['saved']})" if v.get("saved") else ""), k)
        i = self.setup_box.findData(select) if select else 0
        self.setup_box.setCurrentIndex(max(0, i))
        self.setup_box.blockSignals(False)
        self.setup_del.setEnabled(bool(self.setup_box.currentData()))

    def _setup_picked(self, *_a):
        name = self.setup_box.currentData()
        self.setup_del.setEnabled(bool(name))
        if not name:
            return
        st = load_setups(self.setups_file).get(name)
        if st:
            self.apply_config(st, name)

    def _setup_save(self):
        from PyQt5.QtWidgets import QInputDialog, QMessageBox
        cur = self.setup_box.currentData()
        name, ok = QInputDialog.getText(self, "Save the setup", "Name of this setup:",
                                        text=cur if cur and cur != LAST_SETUP else self.route.currentText())
        name = (name or "").strip()
        if not ok or not name:
            return
        if name == LAST_SETUP:
            QMessageBox.information(self, "Save the setup", f"'{LAST_SETUP}' is kept automatically -- please use "
                                                            "another name.")
            return
        if name in load_setups(self.setups_file) and QMessageBox.question(
                self, "Save the setup", f"Replace the saved setup '{name}'?") != QMessageBox.Yes:
            return
        try:
            save_setup(self.setups_file, name, self.config())
        except OSError as e:
            QMessageBox.warning(self, "Save the setup", f"Could not save:\n{e}")
            return
        self._fill_setups(select=name)
        self._note(f"Saved as '{name}'.")

    def _setup_delete(self):
        from PyQt5.QtWidgets import QMessageBox
        name = self.setup_box.currentData()
        if not name or QMessageBox.question(self, "Delete the setup", f"Delete the saved setup '{name}'?") \
                != QMessageBox.Yes:
            return
        try:
            delete_setup(self.setups_file, name)
        except OSError as e:
            QMessageBox.warning(self, "Delete the setup", f"Could not delete:\n{e}")
            return
        self._fill_setups()
        self._note(f"'{name}' deleted.")

    def _note(self, text, warn=False):
        self.setup_note.setText(text)
        self.setup_note.setStyleSheet("color: #FCD34D;" if warn else "")
        self.setup_note.setVisible(bool(text))

    def config(self):
        """The whole setup (saved setups): route, side, loops, plan, AVs, hold, V2V, publish (no password)."""
        pub = {k: v for k, v in (self.pub or {}).items() if k not in ("password", "on")}
        return {"route": self.route.currentText(), "side": self.side.currentData(),
                "loop": self.loop_cb.isChecked(), "loops": self.loops.value(), "plan": self.plan_,
                "trucks": [{"which": r.which.currentData(), "which_label": r.which.currentText(),
                            "kmh": r.kmh.value(), "gap": r.gap.value(),
                            "sensors": sorted(k for k, b in r.sw.items() if b.isChecked())} for r in self.rows],
                "hold": self.hold.value(), "near_miss": self.near_miss.isChecked(), "v2v": self.v2v_values(),
                "publish": pub}

    def apply_config(self, c, name=""):
        """A saved setup into the dialog (a route / AV that no longer exists: noted, the rest loaded)."""
        miss = []
        i = self.route.findText(str(c.get("route") or ""))
        if i >= 0:
            self.route.setCurrentIndex(i)
        elif c.get("route"):
            miss.append(f"route '{c['route']}' no longer exists")
        i = self.side.findData(c.get("side"))
        if i >= 0:
            self.side.setCurrentIndex(i)
        trucks = list(c.get("trucks") or [])
        if trucks:
            self._set_count(len(trucks))
        for r, t in zip(self.rows, trucks):
            vid = t.get("which")
            j = r.which.findData(vid) if vid else -1
            if vid and j < 0:
                miss.append(f"'{t.get('which_label') or vid}' is not in the yard (a new test AV instead)")
            r.which.setCurrentIndex(j if j >= 0 else r.which.count() - 1)
            r.kmh.setValue(float(t.get("kmh", r.kmh.value())))
            r.gap.setValue(float(t.get("gap", r.gap.value())))
            sens = set(t.get("sensors") or [])
            for k, b in r.sw.items():
                b.setChecked(k in sens)
        self.loops.setValue(int(c.get("loops", self.loops.value())))
        self.loop_cb.setChecked(bool(c.get("loop")))
        self.plan_ = c.get("plan") or None
        self.hold.setValue(float(c.get("hold", self.hold.value())))
        self.near_miss.setChecked(bool(c.get("near_miss", False)))
        v = c.get("v2v") or {}
        for box, key in ((self.v_link, "link"), (self.v_gnss, "gnss"), (self.v_mode, "mode")):
            j = box.findData(v.get(key))
            if j >= 0:
                box.setCurrentIndex(j)
        for box, key in ((self.v_loss, "loss_pct"), (self.v_conn, "connected_pct"), (self.v_bg, "bg_vehicles")):
            if v.get(key) is not None:
                box.setValue(int(v[key]))
        if v.get("block") is not None:
            self.v_block.setChecked(bool(v["block"]))
        if c.get("publish"):
            self.pub = dict(self.pub or {}, **c["publish"], on=False)
        self._loop_text()
        self._pub_text()
        self._note((f"Loaded '{name}'." if name else "Loaded.") + (" Note: " + "; ".join(miss) if miss else ""),
                   warn=bool(miss))

    def _route_changed(self, name):
        res = self.route_info(name) if name else ("", False)
        text, two_way = res[0], res[1]
        self._route_loop = bool(len(res) > 2 and res[2])
        self.rinfo.setText(text)
        self.side.setEnabled(bool(two_way))
        self._loop_text()

    def _base(self):
        return [(r.which.currentText(), r.kmh.value(), sorted(r.values()[3])) for r in self.rows]

    def _plan(self):
        n = self.loops.value()
        d = LoopPlanDialog(self, n, self._base(), self.climates, self.plan_)
        if d.exec_() == QDialog.Accepted:
            self.plan_ = d.plan()
        self._loop_text()

    def _loop_text(self):
        n = self.loops.value()
        looping = self.loop_cb.isChecked()
        self.plan_btn.setEnabled(looping and n >= 1)
        self.plan_btn.setToolTip("Different settings for each loop: the climate, and per AV its top speed, sensors "
                                 "(e.g. radar OFF in loop 3) and stop & go" if n else
                                 "Set a number of loops to plan them (not with 'until I end it')")
        has = bool(self.plan_) and looping and n >= 1
        self.plan_info.setVisible(has)
        if has:
            self.plan_info.setText("Plan: " + plan_text(self.plan_[:n], [(b[1],) for b in self._base()]))
            self.plan_btn.setText(f"Plan ({min(n, PLAN_MAX)} loops) ...")
        else:
            self.plan_btn.setText("Plan the loops ...")
        if not self.loop_cb.isChecked():
            t = ("Single run: once round the loop" if self._route_loop else "Single run: once to the route's end")
        elif self._route_loop:
            t = "Round the loop " + ("until you end the test" if n == 0 else f"{n} times")
        else:
            t = ("The route ends elsewhere: at its end all AVs start again from its start -- "
                 + ("until you end the test" if n == 0 else f"{n} runs"))
        self.loop_info.setText(t + ". The results summary shows when it finishes (and on End test).")

    def _set_count(self, n):
        n = max(1, min(6, n))
        while len(self.rows) < n:
            k = len(self.rows)
            r = _SetupRow(k, self.autos, f"New autonomous vehicle (test only): AV {k + 1}")
            r.which.setCurrentIndex(k if k < len(self.autos) else len(self.autos))
            r.kmh.setValue(min(60, 15 + 5 * k))
            self.rows_box.addWidget(r)
            self.rows.append(r)
        while len(self.rows) > n:
            r = self.rows.pop()
            r.setParent(None); r.deleteLater()
        self.count.setText(str(n))
        self.minus.setEnabled(n > 1); self.plus.setEnabled(n < 6)
        if hasattr(self, "pub_info"):
            self._pub_text()
        if getattr(self, "_built", False):
            self._fit_size()

    def values(self):
        looping = self.loop_cb.isChecked()
        n = self.loops.value() if looping else 1
        plan = None
        if looping and n >= 1 and self.plan_:                  # (the AVs changed since: the plan follows them)
            base = self._base()
            plan = []
            for lp in self.plan_[:min(n, PLAN_MAX)]:
                tr = list(lp.get("trucks") or [])[:len(base)]
                tr += [{"kmh": b[1], "sensors": list(b[2]), "sg": None} for b in base[len(tr):]]
                plan.append(dict(lp, trucks=tr))
        return (self.route.currentText(), self.side.currentData(), [r.values() for r in self.rows],
                self.hold.value(), n, plan, self.v2v_values())

    def _publish_setup(self):
        import hw_publish
        trucks = [(k + 1, r.which.currentText()) for k, r in enumerate(self.rows)]
        d = hw_publish.make_dialog(self, trucks, self.pub)
        if d.exec_() == QDialog.Accepted:
            self.pub = d.values()
            hw_publish.save_settings(self.pub)
        self._pub_text()

    def _pub_text(self):
        import hw_publish
        p = self.pub or {}
        n = len(self.rows) if hasattr(self, "rows") else 99
        tr = [t for t in (p.get("trucks") or []) if t <= n]
        where = (f"{', '.join(f'AV {t}' for t in tr)} → {', '.join(hw_publish.topic_of(p, t) for t in tr)} · "
                 f"{p['host']}:{p['port']} · {p['rate_hz']} Hz") if tr else ""
        if p.get("on") and tr:
            self.pub_info.setText(f"<span style='color:#22D3EE; font-weight:700'>STARTS WITH THE TEST</span> · {where}")
        elif tr:
            self.pub_info.setText(f"<b>OFF</b> -- start it in the test window (📡 MQTT) when needed · {where}")
        else:
            self.pub_info.setText("OFF -- set the broker and AVs here, start it in the test window (📡 MQTT)")
        self.pub_info.setTextFormat(Qt.RichText)

    def publish_values(self):
        """The publish-to-hardware settings (hw_publish; "on": start publishing at once with the test -- else it
        is started with the test window's MQTT button)."""
        p = dict(self.pub or {})
        p["trucks"] = [t for t in (p.get("trucks") or []) if 1 <= t <= len(self.rows)]
        p["on"] = bool(p.get("on") and p["trucks"])
        return p

    def v2v_values(self):
        """The V2V settings (v2v.DEFAULTS keys)."""
        return {"link": self.v_link.currentData(), "loss_pct": self.v_loss.value(), "block": self.v_block.isChecked(),
                "gnss": self.v_gnss.currentData(), "mode": self.v_mode.currentData(),
                "connected_pct": self.v_conn.value(), "bg_vehicles": self.v_bg.value()}


class CollisionTestWindow(QDialog):
    """AVs = [(id, role, name)]; callbacks: follow2d(id), follow3d(id), speed(id, kmh), stopgo(id),
    stopgo_off(id), sensor(id, name, on), details(id | None), shown(set of sensors), camera(index), cont(), pause(),
    restart(), end(), minimize(), results().
    update_view(d): d = {status, status_col, lap, lap_tip, finished, climate, note, cards: {id: card dict}, f2d, f3d,
    collisions, held, paused, log: [(t, text)], picked, details: DetailsPane dict | None}."""

    def __init__(self, parent, title, trucks, callbacks, route=""):
        super().__init__(parent)
        self.cb = dict(callbacks)
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE)
        self.setWindowTitle(title)
        self.setModal(False)
        self.setSizeGripEnabled(True)
        lay = QVBoxLayout(self); lay.setContentsMargins(14, 12, 14, 12); lay.setSpacing(10)
        top = QHBoxLayout(); top.setSpacing(10)
        # (the long texts shorten with '…' on a small screen -- the window never gets wider than the screen)
        t = ElideLabel("Collision testing", 60); t.setObjectName("title"); top.addWidget(t)
        if route:
            r = ElideLabel(f"route · {route}", 60); r.setObjectName("route"); top.addWidget(r)
        self.pill = ElideLabel("", 80); self.pill.setObjectName("pill"); top.addWidget(self.pill)
        self.lap = QLabel(); self.lap.setObjectName("lap"); self.lap.setVisible(False); top.addWidget(self.lap)
        self.mode = QLabel(); self.mode.setVisible(False); top.addWidget(self.mode)   # (sensor set-up)
        self.pub = QLabel(); self.pub.setVisible(False); top.addWidget(self.pub)      # (publish to hardware)
        top.addStretch()
        self.climate = ElideLabel("", 60); self.climate.setObjectName("chip"); top.addWidget(self.climate)
        self.docked = False
        self.dock_btn = QToolButton(); self.dock_btn.setObjectName("follow")
        self.dock_btn.setCursor(Qt.PointingHandCursor)
        self.dock_btn.clicked.connect(lambda: self.cb["dock"]() if "dock" in self.cb else None)
        self._dock_look(False)
        top.addWidget(self.dock_btn)
        mn = QToolButton(); mn.setObjectName("follow"); mn.setText("–")
        mn.setToolTip("Minimize to the bottom bar (the test goes on)")
        mn.clicked.connect(lambda: self.cb["minimize"]())
        top.addWidget(mn)
        self.max_btn = QToolButton(); self.max_btn.setObjectName("follow"); self.max_btn.setText("□")
        self.max_btn.setToolTip("Maximize: the whole screen (again: back to its size)")
        self.max_btn.clicked.connect(self.toggle_max)
        top.addWidget(self.max_btn)
        lay.addLayout(top)
        self.add_max_hint()
        self.focus = False                                     # (the details on the whole height: cards hidden)
        # progress: the current loop (looping) and the whole test -- how far, how long so far, about how long left
        from PyQt5.QtWidgets import QProgressBar
        pr = QHBoxLayout(); pr.setSpacing(14)
        self.prog = {}
        for key, col in (("loop", "#A855F7"), ("total", "#22C55E")):
            box = QVBoxLayout(); box.setSpacing(2)
            lab = QLabel(); lab.setObjectName("small")
            bar = QProgressBar(); bar.setRange(0, 1000); bar.setTextVisible(False); bar.setFixedHeight(8)
            bar.setStyleSheet(f"QProgressBar {{ background: #1F2937; border: none; border-radius: 4px; }} "
                              f"QProgressBar::chunk {{ background: {col}; border-radius: 4px; }}")
            box.addWidget(lab); box.addWidget(bar)
            w_ = QWidget(); w_.setLayout(box); box.setContentsMargins(0, 0, 0, 0)
            w_.setVisible(False)
            pr.addWidget(w_, 1)
            self.prog[key] = (w_, lab, bar)
        self.prog["loop"][0].setToolTip("The current loop: how far the front AV is through it, the time in it and "
                                        "about how long it still takes (pauses not counted)")
        self.prog["total"][0].setToolTip("The whole test: how far the last AV is through all the loops (the test "
                                         "ends when it is done), the running time and about how long is left")
        lay.addLayout(pr)
        self.note = QLabel(); self.note.setObjectName("muted"); self.note.setWordWrap(True); lay.addWidget(self.note)
        # the cards + the details scroll together (a small screen: nothing is out of reach); header / footer stay
        middle = QWidget(); middle.setObjectName("cardsHolder")
        middle.setStyleSheet("QWidget#cardsHolder { background: #0B1220; }")
        mv = QVBoxLayout(middle); mv.setContentsMargins(0, 0, 4, 0); mv.setSpacing(10)
        holder = QWidget(); holder.setObjectName("cardsHolder")
        holder.setStyleSheet("QWidget#cardsHolder { background: #0B1220; }")
        row = QHBoxLayout(holder); row.setContentsMargins(0, 0, 0, 0); row.setSpacing(10)
        self.cards = {}
        for vid, role, name in trucks:
            c = AVCard(vid, role, name, self.cb)
            row.addWidget(c, 0, Qt.AlignTop)
            self.cards[vid] = c
        row.addStretch(1)
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(holder)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sc.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.viewport().setStyleSheet("background: #0B1220;")
        self.cards_area = sc
        mv.addWidget(sc)
        self.cb["layout"] = self._details_layout
        self.cb["focus"] = lambda: self.set_focus_details(not self.focus)
        self.details = DetailsPane(self.cb)
        mv.addWidget(self.details, 1)
        self.details.setVisible(False)
        outer = QScrollArea(); outer.setWidgetResizable(True); outer.setWidget(middle)
        # (normally everything fits; a very small window: it scrolls sideways instead of cutting off the right side)
        outer.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        outer.viewport().setStyleSheet("background: #0B1220;")
        self.outer = outer
        lay.addWidget(outer, 1)
        self.log = QListWidget(); self.log.setWordWrap(True); self.log.setVisible(False)
        self.log.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.log.setMinimumHeight(120)
        self.log.setMaximumHeight(200)
        lay.addWidget(self.log)
        bar = QHBoxLayout(); bar.setSpacing(8)
        self.coll = QLabel(); self.coll.setStyleSheet("font-size: 13px;"); bar.addWidget(self.coll)
        self.log_btn = QToolButton(); self.log_btn.setObjectName("follow"); self.log_btn.setText("Log ▸")
        self.log_btn.setCheckable(True); self.log_btn.toggled.connect(self._toggle_log)
        bar.addWidget(self.log_btn)
        self.coll_btn = QToolButton(); self.coll_btn.setObjectName("follow"); self.coll_btn.setText("Collisions ▸")
        ic = _qicon("fa5s.map-marker-alt", "#F87171")
        if ic is not None:
            self.coll_btn.setIcon(ic); self.coll_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.coll_btn.setToolTip("Re-check the collisions of this test: where on the map, what it hit, speeds, what "
                                 "each sensor saw (or why not), the reason and a bird's-eye snapshot of that moment")
        self.coll_btn.clicked.connect(lambda: self.cb["collisions"]() if "collisions" in self.cb else None)
        bar.addWidget(self.coll_btn)
        self.save_btn = QToolButton(); self.save_btn.setObjectName("follow"); self.save_btn.setText("Prevented by V2V ▸")
        self.save_btn.setStyleSheet(f"color: {SENSOR_COL['V2V']};")
        self.save_btn.setToolTip("The collisions V2V prevented so far: all of them in a list, each one's proof (what "
                                 "V2V knew, what each sensor did and why, the impact speed without V2V)")
        self.save_btn.clicked.connect(lambda: self.cb["v2v_saves"]() if "v2v_saves" in self.cb else None)
        self.save_btn.setVisible(False)
        bar.addWidget(self.save_btn)
        self.res_btn = QToolButton(); self.res_btn.setObjectName("follow"); self.res_btn.setText("Results")
        ic = _qicon("fa5s.clipboard-check", "#A7F3D0")
        if ic is not None:
            self.res_btn.setIcon(ic); self.res_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.res_btn.setToolTip("The results summary so far: loops, distance, collisions and why, each AV "
                                "(it also shows when the test finishes / on End test, and is kept in Reports)")
        self.res_btn.clicked.connect(lambda: self.cb["results"]() if "results" in self.cb else None)
        bar.addWidget(self.res_btn)
        # publish to hardware (MQTT): OFF by default -- start / stop here, ⚙ the broker / AVs / topics
        self.mqtt_btn = QPushButton()
        self.mqtt_btn.clicked.connect(lambda: self.cb["mqtt"]() if "mqtt" in self.cb else None)
        bar.addWidget(self.mqtt_btn)
        self.mqtt_cfg = QToolButton(); self.mqtt_cfg.setObjectName("follow"); self.mqtt_cfg.setText("⚙")
        self.mqtt_cfg.setToolTip("MQTT publishing settings: broker (also free public test brokers), topic prefix, "
                                 "rate and which AVs (running: started again with the new settings)")
        self.mqtt_cfg.clicked.connect(lambda: self.cb["mqtt_settings"]() if "mqtt_settings" in self.cb else None)
        bar.addWidget(self.mqtt_cfg)
        self._mqtt_look(False)
        bar.addStretch()
        self.cont = QPushButton("Continue now"); self.cont.setObjectName("accent"); self.cont.setVisible(False)
        self.cont.setToolTip("End the collision hold"); self.cont.clicked.connect(lambda: self.cb["cont"]())
        bar.addWidget(self.cont)
        self.pause_btn = QPushButton("⏸ Pause"); self.pause_btn.setToolTip("All AVs stand still -- again to go on")
        self.pause_btn.clicked.connect(lambda: self.cb["pause"]())
        bar.addWidget(self.pause_btn)
        self.skip_btn = QPushButton("⏭ Skip loop")
        self.skip_btn.setToolTip("Quick test: end the current loop now -- all AVs go on at the start of the next "
                                 "loop (its plan settings: climate, speeds, sensors). In the last loop: the test "
                                 "finishes (results summary).")
        self.skip_btn.clicked.connect(lambda: self.cb["skip"]() if "skip" in self.cb else None)
        self.skip_btn.setVisible(False)
        bar.addWidget(self.skip_btn)
        b = QPushButton("↻ Restart"); b.setToolTip("Again from the start of the route (counts and log cleared)")
        b.clicked.connect(lambda: self.cb["restart"]())
        bar.addWidget(b)
        self.restart_btn = b
        b = QPushButton("■ End test"); b.setObjectName("danger"); b.clicked.connect(lambda: self.cb["end"]())
        b.setToolTip("End the test: the results summary shows, the map is put back as before the test")
        bar.addWidget(b)
        self.end_btn = b
        # (the footer never makes the window wider than the screen: short labels when the full ones do not fit)
        self.footer = QWidget(); self.footer.setLayout(bar); bar.setContentsMargins(0, 0, 0, 0)
        self.footer.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self._compact = False
        self._coll_html = ("", "")
        self._paused = False
        # (full text, compact text) of the footer buttons -- compact: the icon / a short word, the tooltip says it
        self._ftext = {self.coll_btn: ("Collisions ▸", "▸"), self.save_btn: ("Prevented by V2V ▸", "V2V ▸"),
                       self.res_btn: ("Results", ""), self.skip_btn: ("⏭ Skip loop", "⏭ Skip"),
                       self.restart_btn: ("↻ Restart", "↻"), self.end_btn: ("■ End test", "■ End")}
        lay.addWidget(self.footer)
        n = len(trucks)
        self._n = n
        self._fit(None)

    def _toggle_log(self, on):
        self.log.setVisible(on)
        self.log_btn.setText("Log ▾" if on else "Log ▸")

    def _footer_texts(self, compact):
        for w_, (full, short) in self._ftext.items():
            w_.setText(short if compact else full)
        self.pause_btn.setText(("▶" if self._paused else "⏸") if compact else
                               ("▶ Resume" if self._paused else "⏸ Pause"))
        on = bool(getattr(self, "_mqtt_on", False))
        self.mqtt_btn.setText(("📡 ON ■" if on else "📡 OFF ▶") if compact else
                              ("📡 MQTT: ON  ■ Stop" if on else "📡 MQTT: OFF  ▶ Start"))
        self.coll.setText(self._coll_html[1 if compact else 0])

    def _fit_footer(self):
        """Full labels when they fit in the footer's width, else the compact ones."""
        if not hasattr(self, "footer"):
            return
        self._footer_texts(False)
        need = self.footer.layout().sizeHint().width()
        compact = need > self.footer.width() + 2
        if compact:
            self._footer_texts(True)
        self._compact = compact

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.details.fit_width(self.width() - 30)
        self._fit_footer()

    def _mqtt_look(self, on):
        """The MQTT button: OFF (grey, 'start') / ON (cyan, 'stop')."""
        if getattr(self, "_mqtt_on", None) == on:
            return
        self._mqtt_on = on
        self.mqtt_btn.setText(("📡 ON ■" if on else "📡 OFF ▶") if getattr(self, "_compact", False) else
                              ("📡 MQTT: ON  ■ Stop" if on else "📡 MQTT: OFF  ▶ Start"))
        self.mqtt_btn.setToolTip(
            "Publishing the chosen AVs' state to the hardware (speed, position, heading, brake ...) -- click to "
            "STOP (each AV gets a last 'ended' message: speed 0, brake on)" if on else
            "Publish the chosen AVs' state over MQTT to the hardware (ESP32 ...) -- click to START (⚙: broker, "
            "AVs, topics)")
        self.mqtt_btn.setStyleSheet(
            "QPushButton { background: #155E75; color: #ECFEFF; border: 1px solid #22D3EE; border-radius: 6px; "
            "padding: 5px 12px; font-weight: 700; }" if on else
            "QPushButton { background: #1F2937; color: #94A3B8; border: 1px solid #334155; border-radius: 6px; "
            "padding: 5px 12px; }")

    def add_max_hint(self):
        """The title bar's maximize button (a window of its own; set again after floating from the main panel)."""
        if not self.docked:
            self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.max_btn.setVisible(not self.docked)

    def toggle_max(self):
        if self.docked:
            return
        if self.isMaximized():
            self.showNormal()
            self._fit(self.details.isVisible())
        else:
            self.showMaximized()

    def set_focus_details(self, on):
        """Larger details: the AV cards hidden, the detection details get the whole height (again: back)."""
        self.focus = bool(on)
        self.cards_area.setVisible(not self.focus)
        self.details.focus_btn.setText("⤡ Show the cards" if self.focus else "⤢ Larger details")
        self._fit(self.details.isVisible())

    def _screen_rect(self):
        from PyQt5.QtWidgets import QApplication
        scr = (self.screen() if hasattr(self, "screen") else None) or QApplication.primaryScreen()
        return scr.availableGeometry() if scr else None

    def _cards_height(self):
        for c in self.cards.values():
            c.layout().activate()
            c.adjustSize()
        hint = self.cards_area.widget().sizeHint()
        h = max([c.sizeHint().height() for c in self.cards.values()] or [hint.height()])
        bar = self.cards_area.horizontalScrollBar().sizeHint().height() if hint.width() > self.cards_area.width() else 0
        return h + 4 + bar

    def _det_min(self, h):
        """The details' height: at least what their contents need (else the tiles were squeezed and their text
        overlapped) -- the window's middle scrolls when the screen is smaller. 0: closed."""
        if h:
            h = max(h, self.details.layout().minimumSize().height())
        self.details.setMinimumHeight(h)
        return h

    def _fit(self, details_shown):
        """Size the window to its content -- never larger than the screen (a laptop: the cards turn compact while
        the details are shown, and the middle scrolls); the footer buttons always stay on screen. Maximized: only the
        parts' heights (the details take the rest)."""
        if not details_shown and self.focus:                            # (details closed: the cards come back)
            self.focus = False
            self.cards_area.setVisible(True)
            self.details.focus_btn.setText("⤢ Larger details")
        scr = self._screen_rect()
        max_w = (scr.width() - 16) if scr else 1500
        max_h = (scr.height() - 36) if scr else 1000                  # (the title bar)
        small = max_h < 1000 or self.docked
        for c in self.cards.values():
            c.set_compact(bool(details_shown) and small)
        if self.docked:                                                 # (in the main window: its splitter sizes it)
            self.layout().activate()
            ch = 0 if self.focus else self._cards_height()
            if not self.focus:
                self.cards_area.setFixedHeight(ch)
            self._det_min((430 if self.focus else 330) if details_shown else 0)
            if "dock_height" in self.cb:
                self.cb["dock_height"](ch + 160 + (max(560 if self.focus else 330, self.details.minimumHeight())
                                                   if details_shown else 0))
            return
        self.layout().activate()
        ch = 0 if self.focus else self._cards_height()
        if not self.focus:
            self.cards_area.setFixedHeight(ch)
        chrome = 160                                                    # header + progress + footer + margins
        if self.isMaximized():                                          # (the window stays as large as the screen;
            avail = self.height() - chrome - ch - 10                    #  the details fill what is left)
            self._det_min(max(430 if small else 560, avail) if details_shown else 0)
            return
        if details_shown:
            det = self._det_min((max_h - chrome - 10) if self.focus else (430 if small else 560))
            want_h, want_w = ch + det + chrome, max(1180, 40 + self._n * 310)
        else:
            self._det_min(0)
            want_h, want_w = ch + chrome, max(980, 40 + self._n * 310)
        w, h = min(max_w, want_w), min(max_h, want_h)
        self.resize(max(self.width() if details_shown else 0, w), h)
        if scr:                                                         # keep it on the screen
            fg = self.frameGeometry()
            x = min(max(scr.left(), fg.left()), scr.right() - fg.width())
            y = min(max(scr.top(), fg.top()), scr.bottom() - fg.height())
            if (x, y) != (fg.left(), fg.top()):
                self.move(x, y)

    def _details_layout(self, shown):
        self._fit(shown)

    def set_docked(self, on):
        """In the main window (True) or a window of its own (False): only the button / sizing change here -- the
        main window moves it (see MapWindow._ctest_dock)."""
        self.docked = bool(on)
        self.setSizeGripEnabled(not on)
        self._dock_look(on)
        self.add_max_hint()
        self._fit(self.details.isVisible())

    def _dock_look(self, docked):
        """The header's dock button: an icon (fit into the main panel / float as a window)."""
        icon = _qicon("mdi.dock-window" if docked else "mdi.dock-bottom", "#E5E7EB")
        if icon is not None:
            self.dock_btn.setIcon(icon); self.dock_btn.setText("")
        else:
            self.dock_btn.setText("⬒" if docked else "⬓")
        self.dock_btn.setToolTip("Float window: this panel as a window of its own again" if docked else
                                 "Fit to main panel: place this panel at the bottom of the main window (above the "
                                 "bottom bar) -- the map / 2D / 3D view shrinks to make room, so you see both at once. "
                                 "Drag the divider to resize; click again to float it as a window.")

    def keyPressEvent(self, ev):
        if self.docked and ev.key() == Qt.Key_Escape:                  # (Esc in the main window must not end the test)
            ev.ignore()
            return
        super().keyPressEvent(ev)

    def update_view(self, d):
        _badge(self.pill, d["status"], d["status_col"])
        self.lap.setText(d.get("lap") or ""); self.lap.setVisible(bool(d.get("lap")))
        self.lap.setToolTip(d.get("lap_tip") or "")
        if d.get("mode") is not None:
            real = d["mode"] == "real"
            if not self.mode.isVisible():
                self.mode.setVisible(True)
                _badge(self.mode, "REAL-WORLD sensors" if real else "simulated sensors", GREEN if real else "#60A5FA")
                self.mode.setToolTip(("Real-world: the camera picture, the LiDAR point cloud and radar echoes are "
                                      "processed by the app (tracks C1 / L1 / R1 …)\n\n" + (d.get("mode_tip") or ""))
                                     if real else "Simulated: each sensor is a model on the scene's objects")
        self._mqtt_look(bool(d.get("pub_on")))
        self.pub.setVisible(bool(d.get("pub")))
        if d.get("pub"):
            _badge(self.pub, d["pub"][0], d["pub"][1])
            self.pub.setToolTip(d.get("pub_tip") or "")
        self.pause_btn.setEnabled(not d.get("finished"))
        if self.skip_btn.isVisibleTo(self) != bool(d.get("can_skip")):
            self.skip_btn.setVisible(bool(d.get("can_skip")))
            self._fit_footer()
        self.skip_btn.setEnabled(not d.get("finished") and not d.get("paused"))
        pg = d.get("progress") or {}
        for key, (w_, lab, bar) in self.prog.items():
            v = pg.get(key)
            w_.setVisible(v is not None)
            if v is None:
                continue
            frac, text = v
            lab.setText(text)
            bar.setRange(0, 0 if frac is None else 1000)          # (until ended: a moving bar)
            if frac is not None:
                bar.setValue(int(round(frac * 1000)))
        self.climate.setText(d["climate"])
        self.note.setText(d.get("note") or ""); self.note.setVisible(bool(d.get("note")))
        for vid, cd in (d.get("cards") or {}).items():
            if vid in self.cards:
                self.cards[vid].update_view(cd, d.get("f2d"), d.get("f3d"), d.get("picked") == vid)
        if d.get("details"):
            self.details.update_view(d["details"])
        n = d["collisions"]
        sv = d.get("v2v_saves")
        num = lambda v, c: f"<span style='font-size:18px;font-weight:800;color:{c}'>{v}</span>"   # noqa: E731
        full = (num(n, RED if n else GREEN) + f" <span style='color:{GREY}'>collision{'s' if n != 1 else ''} in this "
                "test</span>" + (f" &nbsp;{num(sv, SENSOR_COL['V2V'])} <span style='color:{GREY}'>prevented by "
                                 "V2V</span>" if sv is not None else ""))
        short = (num(n, RED if n else GREEN) + f" <span style='color:{GREY}'>coll.</span>"
                 + (f" {num(sv, SENSOR_COL['V2V'])} <span style='color:{GREY}'>by V2V</span>" if sv is not None else ""))
        if (full, short) != self._coll_html or bool(d.get("paused")) != self._paused:
            self._coll_html, self._paused = (full, short), bool(d.get("paused"))
            self.coll.setToolTip(f"{n} collision(s) in this test" + (f", {sv} prevented by V2V" if sv is not None
                                                                      else ""))
            self._fit_footer()
        if self.save_btn.isVisibleTo(self) != (sv is not None):
            self.save_btn.setVisible(sv is not None)
            self._fit_footer()
        self.save_btn.setEnabled(bool(sv))
        if self.cont.isVisibleTo(self) != bool(d.get("held")):
            self.cont.setVisible(bool(d.get("held")))
            self._fit_footer()
        log = d.get("log") or []
        if self.log.count() > len(log):
            self.log.clear()
        while self.log.count() < len(log):
            t, text = log[self.log.count()]
            self.log.addItem(f"{t:5.1f} s   {text}")
            self.log.scrollToBottom()

    def camera_pixmap(self, jpeg_bytes):
        pm = QPixmap()
        pm.loadFromData(jpeg_bytes, "JPG")
        return pm


KIND_COL = {"detected too late": AMBER, "not detected": RED, "sensors off": RED, "hit by the other": PURPLE}
# why a collision happened (MapWindow._ctest_verify): the main cause and each factor checked
# Sensors switched off are the test's set-up (on purpose): never the cause. The cause is what the sensors that were ON
# could not do -- the climate, the other vehicle, or their range / field of view for the speed; only with every sensor
# off: "no sensor on". How to avoid it says which switched-off sensor would have seen it in time, a safe speed, a gap.
CAUSES = (("climate", "Climate", "#38BDF8"), ("obstacle", "Obstacle / vehicle", "#FBBF24"),
          ("limits", "Sensor range / speed", "#C084FC"), ("setup", "No sensor on (test set-up)", "#94A3B8"))
CAUSE_NAME = {k: n for k, n, _c in CAUSES}
CAUSE_COL = {k: c for k, _n, c in CAUSES}
A_FULL, STOP_GAP = 6.0, 3.0                  # (follow_test: full brake m/s² on a dry road, the gap it stops at)


def classify(r):
    """A collision record -> {cause, short, verify: [{key, yes, text}], avoid: [text]} from its own facts (sensors
    on, what each saw or why not, each sensor's range here / in clear weather, the distance it needed to stop, the
    grip, the other's speed). {} when the record has too few facts (an early version)."""
    rng = r.get("ranges") or {}
    if r.get("need_m") is None or not rng:
        return {}
    S = ("LiDAR", "camera", "radar")
    on = [s for s in S if s in (r.get("sensors") or [])]
    off = [s for s in S if s not in on]
    seen = r.get("seen_by") or {}
    missed = [s for s in on if s not in seen]
    why = dict(r.get("why_all") or r.get("why") or {})
    kind, hit = r.get("kind") or "", r.get("hit") or "it"
    other = float(r.get("other_kmh") or 0)
    need, need_dry = float(r["need_m"]), float(r.get("need_dry_m") or r["need_m"])
    v = float(r.get("approach_kmh") or r.get("speed_kmh") or 0) / 3.6
    grip = float(r.get("grip") or 1.0)
    clim = r.get("climate") or "this climate"
    R = {s: (float(rng[s][0]), float(rng[s][1])) for s in S if s in rng}
    geom = lambda s: "field of view" in why.get(s, "") or "hidden behind" in why.get(s, "")      # noqa: E731
    rt = lambda ss, k=0: ", ".join(f"{s} ~{R[s][k]:.0f} m" for s in ss if s in R)               # noqa: E731
    on_txt = " + ".join(on) or "no sensor"
    off_note = f" ({' / '.join(off)} off for this test)" if off and on else ""
    # climate
    unchanged = grip >= 0.99 and all(abs(a - b) < 0.5 for a, b in R.values())
    late = [s for s in on if s in missed or kind == "detected too late"]
    cut = [s for s in late if s in R and R[s][1] >= need_dry and R[s][0] < need and not geom(s)
           and R[s][0] < R[s][1] - 0.5]
    wx = [s for s in missed if s not in cut and not unchanged and not geom(s) and (
        "absorbs" in why.get(s, "") or "attenuation" in why.get(s, "")
        or (s == "camera" and "beyond the camera's range" in why.get(s, "") and s in R and R[s][0] < R[s][1] - 0.5))]
    d_first = r.get("first_seen_m")
    slip = grip < 0.95 and d_first is not None and need_dry <= float(d_first) + STOP_GAP < need
    if unchanged:
        cl = (False, f"no effect -- {clim}: the sensors reach as far as in clear weather, full road grip")
    elif cut or wx or slip:
        parts = []
        if cut:
            parts.append(f"{clim} cut the {' / '.join(cut)} to {rt(cut)} (clear weather {rt(cut, 1)}) -- less than the "
                         f"{need:.0f} m needed to stop")
        parts += [f"the {s} missed it because of the weather: {why.get(s, '')}" for s in wx]
        if slip:
            parts.append(f"wet / slippery road (grip {grip:.0%}): {need:.0f} m needed to stop, seen at {float(d_first):.0f}"
                         f" m -- on a dry road {need_dry:.0f} m was enough")
        cl = (True, "; ".join(parts))
    else:
        cl = (False, f"{clim} shortened the ranges / grip, but that was not why")
    # the other obstacle / vehicle
    ob = []
    if kind == "hit by the other":
        ob.append(f"{hit} moved into the AV ({other:.0f} km/h) while it almost stood")
    elif other > 3.0:
        ob.append(f"{hit} was moving ({other:.0f} km/h): crossing / cutting into the lane"
                  + (" closer than the AV could stop" if kind == "detected too late" else ""))
    hidden = [s for s in missed if "hidden behind" in why.get(s, "")]
    if hidden:
        ob.append(f"hidden behind another object for the {' / '.join(hidden)}")
    obst = (bool(ob), "; ".join(ob) if ob else f"{hit} stood / drove normally in the lane ({other:.0f} km/h)")
    # the switched-on sensors' range / field of view for this speed
    fov = [s for s in missed if "field of view" in why.get(s, "")]
    short_r = bool(on) and all(s in R and R[s][1] < need_dry for s in on)
    if not on:
        lim = (False, "no sensor was on")
    elif fov or short_r:
        parts = []
        if fov:
            parts.append(f"outside the {' / '.join(fov)}'s field of view (a bend / from the side)")
        if short_r:
            parts.append(f"at {v * 3.6:.0f} km/h it needs ~{need_dry:.0f} m to stop even on a dry road; {on_txt} reach "
                         f"only {rt(on, 1)} in clear weather")
        lim = (True, "; ".join(parts))
    else:
        lim = (False, f"{on_txt} reach {rt(on, 1)} in clear weather: enough for {v * 3.6:.0f} km/h ({need_dry:.0f} m)")
    if kind == "hit by the other":
        cause = "obstacle"
    elif not on:
        cause = "setup"
    elif cl[0]:
        cause = "climate"
    elif obst[0]:
        cause = "obstacle"
    else:
        cause = "limits"
        if not lim[0]:
            lim = (True, f"{kind or 'not detected'} although in range -- "
                         + "; ".join(f"{s}: {why.get(s, '')}" for s in (missed or on)))
    # the short reason: what the sensors that were ON could not do (the switched-off ones only noted)
    if kind == "hit by the other":
        short = f"{hit} drove into the standing AV"
    elif not on:
        short = f"No sensor on (test set-up) -- nothing could detect {hit}"
    elif cause == "climate":
        short = (f"{clim}: {' + '.join(cut + wx)} could not see {hit} in time" if cut or wx else
                 f"{clim}: wet road -- the stop was too long ({need:.0f} m needed)") + off_note
    elif cause == "obstacle":
        short = (f"{hit} hidden behind another object" if hidden and other <= 3.0 else
                 f"{hit} cut in / crossed at {other:.0f} km/h -- too close to stop") + off_note
    elif fov:
        short = f"{hit} outside the {' / '.join(fov)} field of view (bend / side){off_note}"
    elif short_r:
        short = f"Too fast for {on_txt}: {v * 3.6:.0f} km/h needs {need_dry:.0f} m, they see {rt(on, 1)}{off_note}"
    else:
        short = (f"{on_txt} {'saw' if kind == 'detected too late' else 'did not see'} {hit}"
                 f"{' too late' if kind == 'detected too late' else ''} at {v * 3.6:.0f} km/h{off_note}")
    # how to avoid it (the "pre-step")
    avoid = []
    would = [s for s in off if s in R and R[s][0] >= need and not geom(s)]
    if would and kind != "hit by the other":                 # (standing, hit by the other: no sensor would help)
        avoid.append(f"With the {' / '.join(would)} on (off for this test): {rt(would)} here -- more than the "
                     f"{need:.0f} m needed to stop, it would have been detected in time")
    a = A_FULL * grip
    usable = [R[s][0] for s in on if s in R and not geom(s)]
    best = max(usable) if usable else 0.0
    if kind != "hit by the other" and on and best < need:
        vs = math.sqrt(max(0.0, 2.0 * a * (best - STOP_GAP))) * 3.6
        if vs >= 3:
            avoid.append(f"At most ~{vs:.0f} km/h here (instead of {v * 3.6:.0f}): then it stops within the ~{best:.0f} m "
                         f"its {on_txt} see in {clim}")
    if kind == "detected too late" and d_first is not None and other > 3.0:
        vs = math.sqrt(max(0.0, 2.0 * a * max(0.0, float(d_first) - STOP_GAP))) * 3.6
        avoid.append(f"Slower where vehicles cut in / cross: at ~{vs:.0f} km/h it stops in the {float(d_first):.0f} m "
                     "where it saw it")
    oi = r.get("other_info") or {}
    if oi.get("test_truck") and str(oi.get("type", "")).startswith("rear-end") and kind == "detected too late":
        avoid.append(f"A larger gap to the AV ahead: at least ~{need:.0f} m at {v * 3.6:.0f} km/h in {clim}")
    if hidden:
        avoid.append("The LiDAR / radar see past what hides it from the camera"
                     + (f" -- the {' / '.join(s for s in ('LiDAR', 'radar') if s in off)} were off for this test"
                        if any(s in off for s in ("LiDAR", "radar")) else ""))
    if fov:
        avoid.append("Slower in bends: the camera / radar look straight ahead (the LiDAR sees all round)")
    if kind == "hit by the other":
        avoid.append("Nothing the AV could do while standing -- the other one must give way "
                     "(scene setting \"obstacles_give_way\")")
    if not on and R:
        ok = [s for s in S if s in R and R[s][0] >= need]
        avoid.append(f"Any of these on: {rt(ok)} -- more than the {need:.0f} m needed" if ok else
                     f"No sensor reaches the {need:.0f} m needed here -- slower")
    # V2V (collision testing): was the other connected, did V2V know it in time, alerts, losses
    vv = r.get("v2v") or {}
    v2v_line = None
    if vv and kind != "hit by the other":
        al, lost = vv.get("alert_s"), vv.get("alert_lost_s")
        # (how far ahead V2V knew it when it mattered: when it started braking, else since it was in the lane)
        fg = vv.get("brake_gap") if vv.get("brake_gap") is not None else vv.get("first_gap")
        when = vv.get("brake_s") if vv.get("brake_gap") is not None else vv.get("first_s")
        vv = dict(vv, first_gap=fg, first_s=when)
        stv = vv.get("stats") or {}
        if not vv.get("connected"):
            v2v_line = f"{hit} is not connected -- it sends no V2V messages (only the sensors can find it)"
        elif not vv.get("on"):
            v2v_line = (f"V2V was OFF on this AV; {hit} is connected"
                        + (f": its messages put it {fg:.0f} m ahead in the lane" if fg is not None else ""))
            if fg is not None and fg >= need:
                avoid.insert(0, f"With V2V on: {hit}'s messages showed it {fg:.0f} m ahead -- more than the "
                                f"{need:.0f} m needed to stop")
        else:
            parts = [f"V2V knew {hit} {fg:.0f} m ahead "
                     + (f"when it started braking ({float(vv.get('first_s') or 0):.1f} s before)"
                        if r.get("v2v", {}).get("brake_gap") is not None else
                        f"({float(vv.get('first_s') or 0):.1f} s before)") if fg is not None
                     else f"no V2V message placed {hit} in its lane (lost / out of range / GNSS position error)"]
            if al is not None:
                parts.append(f"its brake alert arrived {al:.1f} s before")
            if lost is not None:
                parts.append(f"a brake alert was LOST {lost:.1f} s before")
            if not vv.get("brake_mode"):
                parts.append("V2V only warns -- the AV brakes on its sensors")
            v2v_line = "; ".join(parts)
            if not vv.get("brake_mode") and fg is not None and fg >= need:
                avoid.insert(0, f"Let V2V brake (setup: V2V reaction): it knew {hit} {fg:.0f} m ahead, {need:.0f} m "
                                "were needed")
            elif fg is not None and fg < need:
                avoid.append(f"V2V knew it only {fg:.0f} m ahead (it came into the lane / was heard late): slower "
                             "here, or a better position fix (GAGAN / RTK)")
            if float(stv.get("loss_pct") or 0) >= 20:
                avoid.append(f"{stv['loss_pct']:.0f} % of the V2V messages to this AV were lost: the direct link "
                             "(PC5) / fewer buildings in the way")
    verify = [{"key": "climate", "yes": cl[0], "text": cl[1]}, {"key": "obstacle", "yes": obst[0], "text": obst[1]},
              {"key": "limits", "yes": lim[0], "text": lim[1]}]
    if v2v_line:
        verify.append({"key": "v2v", "yes": False, "info": True, "title": "V2V", "text": v2v_line})
    if off:
        verify.append({"key": "setup", "yes": not on, "info": True,
                       "text": f"{' / '.join(off)} switched off for this test -- a test setting, not counted as the cause"
                               + (f"; with it on it would have seen it in time ({rt(would)})" if would else
                                  "; it would not have seen it in time either")})
    return {"cause": cause, "short": short, "verify": verify, "avoid": avoid}


def _cls(r):
    c = r.get("_cls")
    if c is None:
        try:
            c = classify(r)
        except Exception:
            c = {}
        r["_cls"] = c
    return c


def rec_cause(r):
    """A collision record's main cause key (re-checked from its facts; the earliest records: from their kind)."""
    c = _cls(r).get("cause")
    if c:
        return c
    if r.get("cause") in CAUSE_NAME:
        return r["cause"]
    return {"sensors off": "setup", "hit by the other": "obstacle"}.get(r.get("kind"))


def rec_short(r):
    """A collision's short reason (one line; the earliest records: the first sentence of the detailed one)."""
    s = _cls(r).get("short") or r.get("short")
    if s:
        return s
    t = str(r.get("reason") or "")
    return (t.split(" -- ")[0].split(": ")[0].rstrip(".") if t else str(r.get("kind") or ""))


def avoid_html(r):
    return "<br>".join(f"→ {x}" for x in (_cls(r).get("avoid") or r.get("avoid") or []))


def other_html(r):
    """The vehicle / obstacle the AV collided with, in a few lines."""
    o = r.get("other_info") or {}
    if not o:
        return (f"<b>{r.get('hit')}</b> ({r.get('hit_kind') or 'object'}) · {r.get('other_kmh', 0):g} km/h"
                f"<br><span style='color:{GREY}'>No more details with this collision (an earlier version).</span>")
    g = lambda k, d="--": o.get(k) if o.get(k) is not None else d                    # noqa: E731
    lines = [f"<b style='font-size:13px'>{o.get('label')}</b> · {o.get('kind')}"
             + (f" · <b>test AV {o['truck_no']}</b>" if o.get("test_truck") and o.get("truck_no") else
                " · test AV" if o.get("test_truck") else " · moving obstacle of the scene" if o.get("scene_object")
                else ""),
             f"Size {g('length_m')} × {g('width_m')} m · "
             + (f"<b>{g('speed_kmh', 0):g} km/h</b>" if o.get("moving") and (o.get("speed_kmh") or 0) > 0.5 else
                "<b>standing still</b>")
             + (f" · heading {g('heading_deg')}° ({g('rel_heading_deg'):+g}° to the AV)"
                if o.get("rel_heading_deg") is not None else "")]
    imp = (f"Impact: the AV's <b>{o.get('on_truck', '?')}</b>"
           + (f" on its <b>{o['on_other']}</b>" if o.get("on_other") else "")
           + (f" -- <span style='color:{AMBER}'>{o['type']}</span>" if o.get("type") else ""))
    lines.append(imp)
    if o.get("test_truck"):
        lines.append(f"Its sensors: {' + '.join(o.get('sensors') or []) or 'all OFF'} · top {g('top_kmh')} km/h"
                     + (" · stop & go on" if o.get("stop_and_go") else "") + f" · it was: <i>{g('state')}</i>")
    if o.get("scene_object"):
        lines.append("It was giving way to the test AVs" if o.get("giving_way") else
                     "It was not giving way (driving its own path)")
    return "<br>".join(lines)


def verify_html(r):
    """The check of the factors of a collision as HTML lines (✔ it played a part / ✘ it did not)."""
    v = _cls(r).get("verify") or [x for x in r.get("verify") or [] if x.get("key") != "sensor"]
    if not v:
        return f"<span style='color:{GREY}'>No verification saved with this collision (an earlier version).</span>"
    main = rec_cause(r)
    out = []
    for f in v:
        k = f.get("key")
        if f.get("info"):                                     # (the test's set-up / V2V: noted, not a cause)
            col = SENSOR_COL["V2V"] if f.get("key") == "v2v" else GREY
            out.append(f"<span style='color:{col}'>ℹ <b>{f.get('title') or 'Test set-up'}</b> -- "
                       f"{f.get('text', '')}</span>")
            continue
        col = CAUSE_COL.get(k, "#E5E7EB") if f.get("yes") else GREY
        mark = "✔" if f.get("yes") else "✘"
        name = CAUSE_NAME.get(k, k)
        star = " <b>(main cause)</b>" if k == main else ""
        out.append(f"<span style='color:{col}'>{mark} <b>{name}</b>{star}</span> -- "
                   f"<span style='color:#CBD5E1'>{f.get('text', '')}</span>")
    return "<br>".join(out)


class CollisionHistoryDialog(QDialog):
    """Re-check collisions: a list (newest first) and, for the one picked, its reason, the facts, what each sensor
    saw (or why not), the bird's-eye snapshot of that moment and the AV's last log lines; its place on the map.
    records: a list of collision dicts (the running test's own list -- it refreshes -- or the saved history).
    callbacks: show(rec), show_all(recs), hide_all(), clear() | None. select: the record to pick first."""

    COLS = ["#", "When", "Loop", "AV", "Hit", "km/h", "Cause", "Reason (short)"]

    def __init__(self, parent, title, records, callbacks, select=None):
        super().__init__(parent)
        from PyQt5.QtCore import QTimer
        self.cb, self.records, self._select = callbacks, records, select
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE)
        self.setWindowTitle(title)
        self.setModal(False)
        self.setSizeGripEnabled(True)
        lay = QVBoxLayout(self); lay.setContentsMargins(14, 12, 14, 12); lay.setSpacing(8)
        top = QHBoxLayout()
        t = QLabel(title); t.setObjectName("title"); top.addWidget(t)
        self.count = QLabel(); self.count.setObjectName("muted"); top.addWidget(self.count)
        top.addStretch()
        lay.addLayout(top)
        sp = QSplitter(Qt.Horizontal)
        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(len(self.COLS) - 1, QHeaderView.Stretch)
        self.table.setStyleSheet("QTableWidget { background: #0A0F1C; color: #E5E7EB; gridline-color: #1F2937; "
                                 "border: 1px solid #1F2937; border-radius: 8px; } QHeaderView::section { "
                                 "background: #111827; color: #94A3B8; border: none; padding: 4px; }"
                                 "QTableWidget::item:selected { background: #1D4ED8; }")
        self.table.itemSelectionChanged.connect(self._picked)
        self.table.cellDoubleClicked.connect(lambda *_a: self._show())
        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(6, 0, 6, 0); rl.setSpacing(6)
        self.reason = QLabel("Pick a collision on the left"); self.reason.setWordWrap(True)
        self.reason.setStyleSheet("font-size: 13px; font-weight: 600; color: #F1F5F9; background: #111827; "
                                  "border: 1px solid #1F2937; border-radius: 8px; padding: 8px;")
        rl.addWidget(self.reason)
        # the key facts at a glance
        fr = QHBoxLayout(); fr.setSpacing(6)
        self.fact = {}
        for key, title, tip in (("speed", "SPEED", "Its speed at the collision (and before it braked)"),
                                ("need", "NEEDED TO STOP", "The distance it needed to stop from its speed before it "
                                                           "braked (this climate's grip; dry road in brackets)"),
                                ("climate", "CLIMATE", "The climate at the collision and the road's grip"),
                                ("other", "THE OTHER", "What it hit and how fast that moved"),
                                ("where", "WHERE", "The loop and the distance along the route")):
            f = QFrame(); f.setObjectName("tile"); f.setToolTip(tip)
            fl = QVBoxLayout(f); fl.setContentsMargins(8, 4, 8, 4); fl.setSpacing(0)
            a = QLabel(title); a.setObjectName("role"); fl.addWidget(a)
            b = QLabel("--"); b.setStyleSheet("font-size: 14px; font-weight: 800; color: #F1F5F9;")
            b.setWordWrap(True); fl.addWidget(b)
            fr.addWidget(f, 1)
            self.fact[key] = b
        rl.addLayout(fr)
        # the vehicle / obstacle it collided with
        oh = QLabel("The other vehicle / obstacle"); oh.setObjectName("section"); rl.addWidget(oh)
        self.other = QLabel(); self.other.setWordWrap(True); self.other.setTextFormat(Qt.RichText)
        self.other.setObjectName("small")
        self.other.setStyleSheet("background: #111827; border: 1px solid #1F2937; border-radius: 8px; padding: 6px;")
        rl.addWidget(self.other)
        # each sensor at that moment
        sh = QLabel("The sensors at the collision"); sh.setObjectName("section"); rl.addWidget(sh)
        tr = QHBoxLayout(); tr.setSpacing(6)
        self.stiles = {}
        for key, text in (("camera", "Camera"), ("LiDAR", "LiDAR"), ("radar", "Radar")):
            t = SensorTile(key, text); t.setMinimumHeight(118); tr.addWidget(t, 1); self.stiles[key] = t
        rl.addLayout(tr)
        self.sensors = QLabel(); self.sensors.setWordWrap(True); self.sensors.setTextFormat(Qt.RichText)
        self.sensors.setObjectName("small")
        rl.addWidget(self.sensors)
        self.facts = QLabel(); self.facts.setWordWrap(True); self.facts.setTextFormat(Qt.RichText)
        self.facts.setObjectName("small")
        self.facts.setTextInteractionFlags(Qt.TextSelectableByMouse)
        vh = QLabel("Verification -- what caused it"); vh.setObjectName("section"); rl.addWidget(vh)
        self.verify = QLabel(); self.verify.setWordWrap(True); self.verify.setTextFormat(Qt.RichText)
        self.verify.setObjectName("small")
        self.verify.setStyleSheet("background: #0F172A; border: 1px solid #1F2937; border-radius: 8px; padding: 6px;")
        self.verify.setToolTip("Each factor checked (sensors switched off for the test are only noted -- not a cause): "
                               "a switched-off sensor that would have seen it in "
                               "time; the climate cutting a sensor's range / the road's grip below what was needed; "
                               "the other obstacle / vehicle (crossing, cutting in, hidden behind another, moving into "
                               "the AV); the sensors' range / field of view for this speed even in clear weather")
        rl.addWidget(self.verify)
        tabs = QTabWidget(); tabs.setMinimumHeight(300)
        # the accident scene in 3D: both vehicles from outside (side / above / from the other one)
        sw = QWidget(); sl = QVBoxLayout(sw); sl.setContentsMargins(4, 4, 4, 4); sl.setSpacing(4)
        sb = QHBoxLayout(); sb.setSpacing(6)
        self.scene_btns = {}
        for name, text in (("side", "Side"), ("above", "From above"), ("other", "From the other one")):
            b = QPushButton(text); b.setObjectName("mini"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton#mini { padding: 4px 10px; } QPushButton#mini:checked { background: #1D4ED8; "
                            "color: #FFFFFF; border-color: #3B82F6; }")
            b.clicked.connect(lambda _c=False, n=name: self._scene_view(n))
            sb.addWidget(b)
            self.scene_btns[name] = b
        sb.addStretch()
        self.scene_title = QLabel(); self.scene_title.setObjectName("muted"); sb.addWidget(self.scene_title)
        sl.addLayout(sb)
        self.scene = CameraShot(); self.scene.setMinimumHeight(200); sl.addWidget(self.scene, 1)
        tabs.addTab(sw, "Accident scene (3D)")
        cw = QWidget(); cl = QVBoxLayout(cw); cl.setContentsMargins(4, 4, 4, 4); cl.setSpacing(4)
        self.cam = CameraShot(); self.cam.setMinimumHeight(200); cl.addWidget(self.cam, 1)
        self.cam_calc = QLabel(); self.cam_calc.setObjectName("small"); self.cam_calc.setWordWrap(True)
        self.cam_calc.setTextFormat(Qt.RichText); cl.addWidget(self.cam_calc)
        tabs.addTab(cw, "AV camera (detection)")
        self.view = SensorView(); self.view.setMinimumSize(260, 240)
        tabs.addTab(self.view, "Bird's-eye (all sensors)")
        self.otable = QTableWidget(0, 6)
        self.otable.setHorizontalHeaderLabels(["Object", "Real gap", "LiDAR", "Camera", "Radar", "Lane"])
        self.otable.verticalHeader().setVisible(False)
        self.otable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.otable.setStyleSheet("QTableWidget { background: #0A0F1C; color: #E5E7EB; gridline-color: #1F2937; "
                                  "border: none; } QHeaderView::section { background: #111827; color: #94A3B8; "
                                  "border: none; padding: 4px; }")
        oh = self.otable.horizontalHeader()
        oh.setSectionResizeMode(QHeaderView.ResizeToContents); oh.setStretchLastSection(True)
        tabs.addTab(self.otable, "What each sensor measured")
        self.log = QListWidget(); self.log.setWordWrap(True)
        tabs.addTab(self.log, "AV log")
        fw = QScrollArea(); fw.setWidgetResizable(True); fw.setWidget(self.facts)
        tabs.addTab(fw, "All facts")
        self.tabs = tabs
        rl.addStretch(1)
        # left: the list over the pictures (camera / bird's-eye ...); right: the reason, facts, sensors, verification
        left = QSplitter(Qt.Vertical); left.setHandleWidth(8)
        left.addWidget(self.table)
        left.addWidget(tabs)
        left.setStretchFactor(0, 1); left.setStretchFactor(1, 4)
        left.setSizes([130, 520])
        sp.insertWidget(0, left)
        right.setObjectName("collRight")
        right.setStyleSheet("QWidget#collRight { background: #0B1220; }")
        rs = QScrollArea(); rs.setWidgetResizable(True); rs.setWidget(right)        # (a small screen: it scrolls)
        rs.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        rs.viewport().setStyleSheet("background: #0B1220;")
        sp.addWidget(rs)
        sp.setSizes([600, 600])
        lay.addWidget(sp, 1)
        bar = QHBoxLayout(); bar.setSpacing(8)
        self.show_btn = QPushButton("Show on map"); self.show_btn.setObjectName("accent")
        self.show_btn.setToolTip("Zoom the map to where it happened (red numbered marker; yellow: the other one)")
        self.show_btn.clicked.connect(self._show); bar.addWidget(self.show_btn)
        b = QPushButton("Show all on map"); b.clicked.connect(lambda: self.cb["show_all"](list(self.records)))
        bar.addWidget(b)
        b = QPushButton("Hide markers"); b.clicked.connect(lambda: self.cb["hide_all"]()); bar.addWidget(b)
        bar.addStretch()
        if self.cb.get("clear"):
            b = QPushButton("Clear history"); b.setObjectName("danger"); b.clicked.connect(self._clear)
            bar.addWidget(b)
        b = QPushButton("Close"); b.clicked.connect(self.close); bar.addWidget(b)
        lay.addLayout(bar)
        self._n = -1
        self._refresh()
        self.timer = QTimer(self); self.timer.timeout.connect(self._refresh); self.timer.start(1000)
        from PyQt5.QtWidgets import QApplication
        scr = QApplication.primaryScreen()
        g = scr.availableGeometry() if scr else None
        self.resize(min(1240, (g.width() - 30) if g else 1240), min(820, (g.height() - 50) if g else 820))

    def _rows(self):
        return list(reversed(self.records))

    def _refresh(self):
        cur = self._current() if self._n >= 0 else None
        if cur is not None and (bool(cur.get("camera")), bool(cur.get("scene"))) != getattr(self, "_had_cam", None):
            self._picked()                                       # (its camera / scene images came a moment later)
        if len(self.records) == self._n:
            return
        self._n = len(self.records)
        rows = self._rows()
        self.count.setText(f"{len(rows)} collision{'s' if len(rows) != 1 else ''}")
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            cause = rec_cause(r)
            vals = [str(r.get("n", "")), str(r.get("time", ""))[5:], str(r.get("lap") or ""), str(r.get("truck", "")),
                    str(r.get("hit", "")), f"{r.get('speed_kmh', 0):g}", CAUSE_NAME.get(cause, "--"), rec_short(r)]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if j == 6:
                    it.setForeground(QColor(CAUSE_COL.get(cause, GREY)))
                elif j == 7:
                    it.setForeground(QColor(KIND_COL.get(r.get("kind"), "#E5E7EB")))
                it.setToolTip(r.get("reason", ""))
                self.table.setItem(i, j, it)
        if self._select is not None and self._select in rows:
            self.table.selectRow(rows.index(self._select))
            self._select = None
        elif rows and not self.table.selectedItems():
            self.table.selectRow(0)

    def _current(self):
        i = self.table.currentRow()
        rows = self._rows()
        return rows[i] if 0 <= i < len(rows) else None

    def _picked(self):
        r = self._current()
        if not r:
            return
        col = KIND_COL.get(r.get("kind"), "#E5E7EB")
        cause = rec_cause(r)
        ccol = CAUSE_COL.get(cause, col)
        self.reason.setText(
            f"<span style='font-size:15px; font-weight:800; color:{ccol}'>{rec_short(r)}</span><br>"
            f"<span style='color:{ccol}'>{CAUSE_NAME.get(cause, '').upper() or '--'}</span>"
            f" <span style='color:{GREY}'>·</span> <span style='color:{col}'>{(r.get('kind') or '').upper()}</span>"
            + (f"<br><span style='font-size:12px; color:#86EFAC'><b>How to avoid it:</b><br>{avoid_html(r)}</span>"
               if avoid_html(r) else "")
            + f"<br><span style='font-size:12px; font-weight:400; color:#CBD5E1'>Details: {r.get('reason', '')}</span>")
        ttc = r.get("min_ttc")
        self.facts.setText(
            f"<b>{r.get('truck')}</b> (AV {r.get('truck_no') or '?'}) × <b>{r.get('hit')}</b> ({r.get('hit_kind')})"
            f" · {r.get('time')} · {r.get('t')} s into the test<br>"
            f"route <b>{r.get('route')}</b> at {r.get('s')} m · {r.get('lat', 0):.6f}, {r.get('lng', 0):.6f} · "
            f"heading {r.get('heading')}°<br>"
            f"speed <b>{r.get('speed_kmh')} km/h</b> · the other {r.get('other_kmh')} km/h · needed "
            f"{r.get('stop_dist_m')} m to stop · lowest TTC {'--' if ttc is None else f'{ttc:.1f} s'}<br>"
            f"climate <b>{r.get('climate')}</b> · road grip {float(r.get('grip') or 1):.0%} · yard {r.get('yard')}")
        # the facts at a glance
        ap = r.get("approach_kmh")
        self.fact["speed"].setText(f"{r.get('speed_kmh', 0):g} km/h" + (f"<br><span style='font-size:11px; "
                                   f"font-weight:400; color:{GREY}'>{ap:g} km/h before braking</span>"
                                   if ap and ap > r.get("speed_kmh", 0) + 0.5 else ""))
        self.fact["need"].setText("--" if r.get("need_m") is None else
                                  f"{r['need_m']:.0f} m <span style='font-size:11px; font-weight:400; "
                                  f"color:{GREY}'>(dry {r.get('need_dry_m', 0):.0f} m)</span>")
        self.fact["climate"].setText(f"{r.get('climate') or '?'} <span style='font-size:11px; font-weight:400; "
                                     f"color:{GREY}'>grip {float(r.get('grip') or 1):.0%}</span>")
        self.fact["other"].setText(f"{r.get('hit')} <span style='font-size:11px; font-weight:400; color:{GREY}'>"
                                   f"{r.get('hit_kind') or ''} · {r.get('other_kmh', 0):g} km/h</span>")
        self.fact["where"].setText(f"loop {r.get('lap') or '?'} <span style='font-size:11px; font-weight:400; "
                                   f"color:{GREY}'>{r.get('s')} m · {r.get('t')} s</span>")
        # each sensor: OFF / detected (distance) / NOT detected (why), its range here and in clear weather
        on = set(r.get("sensors") or [])
        rng = r.get("ranges") or {}
        seen = r.get("seen_by") or {}
        for key, name in SENSORS:
            rr = rng.get(key)
            rtxt = (f"Range here ~{rr[0]:.0f} m" + (f" (clear weather ~{rr[1]:.0f} m)" if rr[1] > rr[0] * 1.05 else "")
                    if rr else "")
            if key in seen:
                self.stiles[key].show_result(True, (float(seen[key]), rtxt, None), "")
            else:
                why = (r.get("why") or {}).get(key, "")
                self.stiles[key].show_result(key in on, None, (why + (". " + rtxt if rtxt else "")).strip(". "))
                if key not in on:
                    self.stiles[key].info.setText("Switched off for this test (not counted as the cause)"
                                                  + (f" -- {rtxt}" if rtxt else ""))
        vv = r.get("v2v") or {}
        v2v_txt = ""
        if vv:
            stv = vv.get("stats") or {}
            v2v_txt = (f"<br><span style='color:{SENSOR_COL['V2V']}'>● V2V {'ON' if vv.get('on') else 'OFF'}"
                       + (" (warns only)" if vv.get("on") and not vv.get("brake_mode") else "") + "</span>"
                       + f" <span style='color:{GREY}'>· {r.get('hit')} "
                       + ("connected" if vv.get("connected") else "NOT connected")
                       + (f" · known {vv['brake_gap']:.0f} m ahead when it braked" if vv.get("brake_gap") is not None
                          else f" · known {vv['first_gap']:.0f} m ahead" if vv.get("first_gap") is not None else "")
                       + (f" · brake alert {vv['alert_s']:.1f} s before" if vv.get("alert_s") is not None else "")
                       + (f" · alert LOST {vv['alert_lost_s']:.1f} s before" if vv.get("alert_lost_s") is not None else "")
                       + (f" · {stv.get('loss_pct', 0):g} % lost, ~{stv['delay_ms']:.0f} ms" if stv.get("delay_ms") else "")
                       + f" · {vv.get('label', '')}</span>")
        self.sensors.setText(
            (f"<span style='color:{GREY}'>To stop in time from {ap or r.get('speed_kmh')} km/h it had to detect it "
             f"~{r['need_m']:.0f} m ahead.</span>" if r.get("need_m") is not None else "") + v2v_txt)
        self.verify.setText(verify_html(r))
        # the camera at the collision
        cam = r.get("camera") or {}
        self._had_cam = (bool(cam), bool(r.get("scene")))
        self._scene_rec = r
        self.other.setText(other_html(r))
        self._scene_view(getattr(self, "_scene_name", "side"))
        pix = None
        if cam.get("file"):
            pm = QPixmap(cam["file"])
            pix = None if pm.isNull() else pm
        if pix is not None:
            ov = dict(cam.get("overlay") or {})
            ov.setdefault("w", pix.width()); ov.setdefault("h", pix.height())
            self.cam.set_shot(pix, ov)
            c = cam.get("calc") or {}
            rows = "".join(f"<tr><td style='color:#94A3B8; padding-right:10px'>{n}</td><td>{f_}</td>"
                           f"<td style='padding-left:10px'><b>{v}</b></td></tr>" for n, f_, v in c.get("lines") or [])
            self.cam_calc.setText(f"<b>{cam.get('label', 'camera')}</b> · {c.get('title', '')}"
                                  + (f"<table cellspacing='0' cellpadding='1'>{rows}</table>" if rows else "")
                                  + (f"<span style='color:{GREY}'>{c.get('note', '')}</span>" if c.get("note") else ""))
        else:
            self.cam.set_shot(None, {"banner": "No camera image with this collision (recorded before the image was "
                                               "kept, or the camera page could not render it)."})
            self.cam_calc.setText("")
        # the bird's-eye view of that moment (its start view: close around the collision), what each sensor measured
        self.view.set_data(r.get("view"), reset=True)
        rows = r.get("table") or []
        self.otable.setRowCount(len(rows))
        for i, row in enumerate(rows):
            cells = [(row.get("obj", ""), "#E5E7EB"), (row.get("real", ""), "#CBD5E1")] + \
                [tuple(row.get(k) or ("", GREY)) for k in ("LiDAR", "camera", "radar", "lane")]
            for j, (text, colr) in enumerate(cells):
                it = QTableWidgetItem(str(text)); it.setForeground(QColor(colr))
                if j == 0 and row.get("bold"):
                    f_ = it.font(); f_.setBold(True); it.setFont(f_)
                self.otable.setItem(i, j, it)
        self.tabs.setTabText(self.tabs.indexOf(self.otable), f"What each sensor measured ({len(rows)})")
        self.log.clear()
        for t, text in r.get("log") or []:
            self.log.addItem(f"{t:6.1f} s   {text}")

    def _scene_view(self, name):
        """The accident scene's view (side / above / from the other one): both vehicles boxed and named."""
        self._scene_name = name
        r = getattr(self, "_scene_rec", None) or {}
        views = {v.get("name"): v for v in r.get("scene") or []}
        for n, b in self.scene_btns.items():
            b.setChecked(n == name)
            b.setEnabled(n in views)
        v = views.get(name) or (next(iter(views.values())) if views else None)
        if v is None:
            self.scene.set_shot(None, {"banner": "No 3D accident scene with this collision (recorded before it was "
                                                 "kept, or the camera page could not render it)."})
            self.scene_title.setText("")
            return
        if v.get("name") != name:
            self.scene_btns[v["name"]].setChecked(True); self._scene_name = v["name"]
        pm = QPixmap(v.get("file") or "")
        if pm.isNull():
            self.scene.set_shot(None, {"banner": "The scene image is not there any more."})
            return
        oi = r.get("other_info") or {}
        boxes = []
        for b in v.get("boxes") or []:
            truck = b.get("role") == "truck"
            boxes.append(dict(b, col="#3B82F6" if truck else RED,
                              lines=[(f"TEST AV · {r.get('truck')}" if truck else f"HIT · {b.get('label')}"),
                                     (f"{r.get('speed_kmh', 0):g} km/h" if truck else
                                      f"{oi.get('kind', '')} · {oi.get('speed_kmh', r.get('other_kmh', 0)):g} km/h")]))
        self.scene.set_shot(pm, {"w": v.get("w") or pm.width(), "h": v.get("h") or pm.height(), "boxes": boxes,
                                 "caption": f"{v.get('title', '')} · {r.get('climate') or ''} · {r.get('time', '')}"})
        self.scene_title.setText(v.get("title", ""))

    def _show(self):
        r = self._current()
        if r:
            self.cb["show"](r)

    def _clear(self):
        from PyQt5.QtWidgets import QMessageBox
        if QMessageBox.question(self, "Clear history", "Delete all saved collisions of this yard?") \
                != QMessageBox.Yes:
            return
        self.cb["clear"]()
        del self.records[:]
        self._n = -1
        self._refresh()
        self.reason.setText("No collisions saved"); self.facts.setText(""); self.sensors.setText("")
        self.verify.setText(""); self.cam.set_shot(None, None); self.otable.setRowCount(0)
        self.other.setText(""); self._scene_rec = None; self._scene_view("side")
        self.view.set_data(None); self.log.clear()

    def closeEvent(self, e):
        self.timer.stop()
        super().closeEvent(e)


SAVE_COLS = ["#", "Loop", "AV", "Other", "km/h", "V2V knew it at", "Sensors saw it at", "Needed to stop",
             "Without V2V", "Closest gap", "Why the sensors failed"]


def save_row(s):
    """One collision prevented by V2V as a table row (SAVE_COLS)."""
    return [str(s.get("n", "")), str(s.get("lap") or ""), str(s.get("truck", "")), str(s.get("other", "")),
            f"{s.get('speed_kmh', 0):g}", f"{s.get('v2v_gap', 0):.0f} m" + (" · brake alert" if s.get("brake_alert") else ""),
            "never" if s.get("sensor_gap") is None else f"{s['sensor_gap']:.0f} m ({' + '.join(s.get('sensor_by') or [])})",
            f"{s.get('need_m', 0):.0f} m", f"~{s.get('impact_kmh', 0):.0f} km/h impact",
            "--" if s.get("min_gap") is None else f"{s['min_gap']:.1f} m",
            "; ".join(f"{k}: {(s.get('why') or {}).get(k, '')}" for k, _n in SENSORS
                      if k not in (s.get("sensor_by") or []))]


def save_table(saves):
    """All the collisions prevented by V2V: a table (V2V green, the sensors / without-V2V red, closest gap green)."""
    t = QTableWidget(len(saves), len(SAVE_COLS))
    t.setHorizontalHeaderLabels(SAVE_COLS)
    t.verticalHeader().setVisible(False)
    t.setEditTriggers(QTableWidget.NoEditTriggers)
    t.setSelectionBehavior(QTableWidget.SelectRows); t.setSelectionMode(QTableWidget.SingleSelection)
    t.setStyleSheet("QTableWidget { background: #0A0F1C; color: #E5E7EB; border: none; gridline-color: #1F2937; } "
                    "QHeaderView::section { background: #111827; color: #94A3B8; border: none; padding: 4px; } "
                    "QTableWidget::item:selected { background: #1D4ED8; }")
    for i, s in enumerate(saves):
        for j, v in enumerate(save_row(s)):
            it = QTableWidgetItem(v); it.setToolTip(v)
            if j in (5, 9):
                it.setForeground(QColor(SENSOR_COL["V2V"] if j == 5 else GREEN))
            elif j in (6, 8):
                it.setForeground(QColor(RED))
            t.setItem(i, j, it)
    t.resizeColumnsToContents()
    t.setColumnWidth(10, min(520, max(220, t.columnWidth(10))))
    t.horizontalHeader().setStretchLastSection(True)
    return t


class V2VSavesDialog(QDialog):
    """All the collisions PREVENTED by V2V of a test (like the collisions window): the table of all of them on top,
    the selected one's proof below (◀ Prev / Next ▶ to go through them one by one).
    saves: MapWindow._v2v_episode's records; show_map(rec) | None; select: the index shown first."""

    def __init__(self, parent, saves, show_map=None, select=0, title="Collisions prevented by V2V"):
        super().__init__(parent)
        self.saves, self.show_map = list(saves or []), show_map
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE)
        self.setWindowTitle(title)
        self.setModal(False)
        self.setSizeGripEnabled(True)
        G = SENSOR_COL["V2V"]
        lay = QVBoxLayout(self); lay.setContentsMargins(12, 10, 12, 10); lay.setSpacing(6)
        top = QHBoxLayout()
        n = len(self.saves)
        h = QLabel(f"<span style='font-size:16px; font-weight:800; color:{G}'>{n}</span> <span style='font-size:14px; "
                   f"font-weight:700'>collision{'s' if n != 1 else ''} prevented by V2V</span> <span style='color:{GREY}'>"
                   "-- each one: a vehicle the AV knew only from V2V; its sensors saw it too late or never</span>")
        h.setTextFormat(Qt.RichText); top.addWidget(h, 1)
        self.pos = QLabel(); self.pos.setObjectName("lap"); top.addWidget(self.pos)
        self.prev_b = QPushButton("◀ Prev"); self.prev_b.clicked.connect(lambda: self.select(self.cur - 1))
        self.next_b = QPushButton("Next ▶"); self.next_b.clicked.connect(lambda: self.select(self.cur + 1))
        top.addWidget(self.prev_b); top.addWidget(self.next_b)
        lay.addLayout(top)
        sp = QSplitter(Qt.Vertical); sp.setHandleWidth(8)
        self.table = save_table(self.saves)
        self.table.setToolTip("Click a row: its proof below")
        self.table.currentCellChanged.connect(lambda r, _c, _pr, _pc: self.select(r) if r != self.cur else None)
        sp.addWidget(self.table)
        self.view = V2VSaveView(show_map)
        sp.addWidget(self.view)
        sp.setStretchFactor(0, 1); sp.setStretchFactor(1, 3)
        lay.addWidget(sp, 1)
        bb = QHBoxLayout(); bb.addStretch()
        c = QPushButton("Close"); c.clicked.connect(self.close); bb.addWidget(c)
        lay.addLayout(bb)
        from PyQt5.QtWidgets import QApplication
        scr = QApplication.primaryScreen()
        g = scr.availableGeometry() if scr else None
        self.resize(min(1240, (g.width() - 40) if g else 1240), min(900, (g.height() - 60) if g else 900))
        sp.setSizes([170, 700])
        self.cur = -1
        self.select(max(0, min(int(select or 0), n - 1)) if n else -1)

    def select(self, i):
        if not self.saves or i < 0 or i >= len(self.saves):
            return
        self.cur = i
        self.table.blockSignals(True); self.table.selectRow(i); self.table.blockSignals(False)
        self.table.scrollToItem(self.table.item(i, 0))
        self.view.set_rec(self.saves[i])
        self.pos.setText(f"{i + 1} / {len(self.saves)}")
        self.prev_b.setEnabled(i > 0); self.next_b.setEnabled(i < len(self.saves) - 1)


class V2VSaveView(QWidget):
    """One collision PREVENTED by V2V -- the proof: what V2V told the AV and when, what each sensor did (saw it
    only at ... / never: why), the distance it needed to stop, the impact speed without V2V, the bird's-eye view at
    that moment. set_rec(MapWindow._v2v_episode's record); show_map(rec) | None."""

    def __init__(self, show_map=None):
        super().__init__()
        self.show_map = show_map
        self.box = QHBoxLayout(self); self.box.setContentsMargins(0, 0, 0, 0)
        self.inner = None

    def set_rec(self, rec):
        if self.inner is not None:
            self.box.removeWidget(self.inner); self.inner.deleteLater()
        self.inner = QWidget()
        self.box.addWidget(self.inner)
        self._build(self.inner, rec, self.show_map)

    def _build(self, host, rec, show_map):
        G = SENSOR_COL["V2V"]
        lay = QHBoxLayout(host); lay.setContentsMargins(4, 4, 4, 4); lay.setSpacing(12)
        left = QVBoxLayout(); left.setSpacing(8)
        head = QLabel(f"<span style='font-size:16px; font-weight:800; color:{G}'>COLLISION PREVENTED BY V2V</span><br>"
                      f"<span style='font-size:13px; color:#F1F5F9'>{rec.get('short', '')}</span>")
        head.setWordWrap(True); head.setTextFormat(Qt.RichText)
        head.setStyleSheet(f"background: #052e1c; border: 1px solid {G}; border-radius: 8px; padding: 8px;")
        left.addWidget(head)
        tiles = QHBoxLayout(); tiles.setSpacing(6)
        sg = rec.get("sensor_gap")
        for title, val, col in (
                ("V2V KNEW IT AT", f"{rec.get('v2v_gap', 0):.0f} m", G),
                ("SENSORS SAW IT AT", "never" if sg is None else f"{sg:.0f} m", RED),
                ("NEEDED TO STOP", f"{rec.get('need_m', 0):.0f} m", "#F1F5F9"),
                ("WITHOUT V2V", f"~{rec.get('impact_kmh', 0):.0f} km/h impact", RED),
                ("WITH V2V", f"stopped {rec['min_gap']:.1f} m short" if rec.get("min_gap") is not None else "no contact",
                 GREEN)):
            f = QFrame(); f.setObjectName("tile")
            fl = QVBoxLayout(f); fl.setContentsMargins(8, 4, 8, 4); fl.setSpacing(0)
            a = QLabel(title); a.setObjectName("role"); fl.addWidget(a)
            b = QLabel(val); b.setStyleSheet(f"font-size: 15px; font-weight: 800; color: {col};"); b.setWordWrap(True)
            fl.addWidget(b)
            tiles.addWidget(f, 1)
        left.addLayout(tiles)

        def sec(t):
            x = QLabel(t); x.setObjectName("section"); left.addWidget(x)

        def para(html):
            x = QLabel(html); x.setWordWrap(True); x.setTextFormat(Qt.RichText); x.setObjectName("small")
            x.setStyleSheet("background: #111827; border: 1px solid #1F2937; border-radius: 8px; padding: 6px;")
            left.addWidget(x)
        sec("What V2V did")
        para(f"<b>{rec.get('other')}</b> ({rec.get('other_kmh', 0):g} km/h) sent its state"
             + (" and a <b style='color:#FCA5A5'>BRAKE ALERT</b>" if rec.get("brake_alert") else "")
             + f". {rec.get('truck')} at <b>{rec.get('speed_kmh', 0):g} km/h</b> knew it <b style='color:{G}'>"
             f"{rec.get('v2v_gap', 0):.0f} m ahead</b> (message {rec.get('age_ms', 0)} ms old, radio delay "
             f"{rec.get('delay_ms', 0)} ms) and braked on it -- up to {rec.get('max_dec', 0):g} m/s²"
             + (f", lowest TTC {rec['min_ttc']:.1f} s" if rec.get("min_ttc") is not None else "")
             + (f", closest gap <b>{rec['min_gap']:.1f} m</b>." if rec.get("min_gap") is not None else "."))
        para(f"<span style='color:{GREY}'>{rec.get('v2v_label', '')} · climate {rec.get('climate', '')} · loop "
             f"{rec.get('lap') or '?'} · {rec.get('time', '')} ({rec.get('t')} s into the test)</span>")
        sec("What the sensors did (why they failed)")
        lines = []
        rng = rec.get("ranges") or {}
        for key, name in SENSORS:
            r_ = rng.get(key) or [None, None]
            rtxt = (f" · range here ~{r_[0]:.0f} m" + (f" (clear weather ~{r_[1]:.0f} m)" if r_[1] and r_[0] and
                                                         r_[1] > r_[0] * 1.05 else "")) if r_[0] else ""
            if key not in (rec.get("sensors_on") or []):
                lines.append(f"<span style='color:{GREY}'>● {name}: OFF (switched off for this test){rtxt}</span>")
            elif key in (rec.get("sensor_by") or []):
                lines.append(f"<span style='color:{SENSOR_COL[key]}'>● {name}: saw it only at {sg:.0f} m, "
                             f"{rec.get('sensor_s_later', 0):g} s after V2V</span><span style='color:{GREY}'>{rtxt}"
                             f"</span> -- {rec.get('need_m', 0):.0f} m were needed")
            else:
                lines.append(f"<span style='color:{RED}'>● {name}: did NOT see it</span> -- "
                             f"{(rec.get('why') or {}).get(key, '')}<span style='color:{GREY}'>{rtxt}</span>")
        para("<br>".join(lines))
        sec("Without V2V")
        para(f"Nothing beyond its sensors' reach would be known: it drives on at its top speed "
             f"<b>{rec.get('top_kmh', rec.get('speed_kmh', 0)):g} km/h</b> (closing in at "
             f"{rec.get('closing_kmh', rec.get('speed_kmh', 0)):g} km/h). Its sensors would find {rec.get('other')} only "
             + (f"at {sg:.0f} m" if sg is not None else "at their range in this climate")
             + f" -- less than the <b>{rec.get('need_m', 0):.0f} m</b> it needs to stop from there (0.5 s from the "
             f"first sight to full braking + this climate's road grip + {3:g} m to stop short). Braking from that "
             f"point: an impact at about "
             f"<b style='color:{RED}'>{rec.get('impact_kmh', 0):.0f} km/h</b>. With V2V it slowed down early and "
             "stopped short.")
        left.addStretch(1)
        if show_map:
            bb = QHBoxLayout()
            b = QPushButton("Show on map"); b.setObjectName("accent"); b.clicked.connect(lambda: show_map(rec))
            bb.addWidget(b); bb.addStretch()
            left.addLayout(bb)
        lw = QWidget(); lw.setLayout(left); lw.setObjectName("saveproof")
        lw.setStyleSheet("QWidget#saveproof { background: #0B1220; }")
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(lw); sc.setFrameShape(QFrame.NoFrame)
        sc.viewport().setStyleSheet("background: #0B1220;")
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        lay.addWidget(sc, 3)
        rv = QVBoxLayout()
        cap = QLabel("Bird's-eye at that moment (green dot: known by V2V)"); cap.setObjectName("section")
        rv.addWidget(cap)
        self.bird = SensorView(); self.bird.setMinimumSize(320, 340)
        self.bird.set_data(rec.get("view"), reset=True)
        rv.addWidget(self.bird, 1)
        lay.addLayout(rv, 2)


def _dur(s):
    s = int(round(float(s or 0)))
    return f"{s // 3600} h {s % 3600 // 60:02d} min" if s >= 3600 else f"{s // 60} min {s % 60:02d} s" if s >= 60 \
        else f"{s} s"


def loops_text(rep):
    """'2 / 3 loops', '5 loops (until ended)', 'single run'."""
    planned, done = int(rep.get("loops_planned") or 1), int(rep.get("loops_done") or 0)
    if planned == 1:
        return "single run" + ("" if done >= 1 else " (not finished)")
    if planned == 0:
        return f"{done} loop{'s' if done != 1 else ''} (until ended)"
    return f"{done} / {planned} loops"


class CollisionReportDialog(QDialog):
    """The results summary of a collision test: shown when it finishes and on End test, kept in Reports (opened
    again from there). The collision count (and each cause) opens the collisions with their reason and the check of
    the sensors: sensor failure, climate, the other obstacle / vehicle, or the sensors' range for the speed.
    report: MapWindow._ctest_report(); callbacks: collisions(recs, title, select=None), folder() | None."""

    def __init__(self, parent, report, callbacks):
        super().__init__(parent)
        self.rep, self.cb = report, callbacks
        rep = report
        recs = rep.get("collisions") or []
        self.recs = recs
        self.setObjectName("collisionTest")
        self.setStyleSheet(STYLE + EXTRA_STYLE + """
            QPushButton#tilebtn { background: #111827; border: 1px solid #1F2937; border-radius: 10px;
                                  padding: 6px 10px; text-align: left; }
            QPushButton#tilebtn:hover { border-color: #3B82F6; background: #172554; }
            QPushButton#cause { border-radius: 9px; padding: 4px 12px; font-weight: 700; }""")
        self.setWindowTitle(f"Collision test results -- {rep.get('route', '')}")
        self.setModal(False)
        self.setSizeGripEnabled(True)
        lay = QVBoxLayout(self); lay.setContentsMargins(16, 12, 16, 12); lay.setSpacing(8)
        top = QHBoxLayout(); top.setSpacing(10)
        t = QLabel("Collision test results"); t.setObjectName("title"); top.addWidget(t)
        r = QLabel(f"route · {rep.get('route', '')}"); r.setObjectName("route"); top.addWidget(r)
        pill = QLabel(); pill.setObjectName("pill")
        n = len(recs)
        _badge(pill, "PASS · no collisions" if not n else f"FAIL · {n} collision{'s' if n != 1 else ''}",
               GREEN if not n else RED)
        top.addWidget(pill)
        lp = QLabel(loops_text(rep)); lp.setObjectName("lap"); top.addWidget(lp)
        top.addStretch()
        lay.addLayout(top)
        how = {"finished": "finished", "ended": "ended by the user", "app closed": "ended (application closed)",
               "running": "still running"}.get(rep.get("ended_by"), rep.get("ended_by") or "")
        clim = rep.get("climates") or []
        sub = QLabel(
            f"Yard <b>{rep.get('yard', '')}</b>" + (f" · project <b>{rep['project']}</b>" if rep.get("project") else "")
            + f" · started <b>{rep.get('started', '')}</b> → ended <b>{rep.get('ended', '')}</b> ({how})"
            + f" · {_dur(rep.get('duration_s'))}"
            + (f" · saved <b>{rep['saved']}</b>" if rep.get("saved") else "")
            + (f" · by {rep['user']}" if rep.get("user") else "")
            + f"<br>route {rep.get('route_m', 0):.0f} m"
            + (" (a loop)" if rep.get("loop_route") else "") + f" · keep {rep.get('drive_side', '')}"
            + f" · climate: <b>{' → '.join(clim) if clim else '?'}</b>"
            + (" · sensors: <b style='color:#34D399'>real-world processing</b>"
               + ("<br><span style='color:#94A3B8'>" + " · ".join(
                   f"{k}: {v.get('used')}" + ("" if v.get("integrated", True) else f" (chosen {v.get('chosen')}: not "
                                                                                   "integrated)")
                   for k, v in (rep.get("sensor_methods") or {}).items()) + "</span>" if rep.get("sensor_methods") else "")
               if rep.get("sensor_mode") == "real"
               else " · sensors: simulated" if rep.get("sensor_mode") == "sim" else "")
            + (f"<br><span style='color:{SENSOR_COL['V2V']}'>V2V: {rep['v2v'].get('label', '')}</span>"
               if rep.get("v2v") else "")
            + (f"<br><span style='color:#E9D5FF'>Loop plan: "
               f"{plan_text(rep['plan'], [(t.get('top_kmh_start') or 0,) for t in rep.get('trucks') or []])}</span>"
               if rep.get("plan") else ""))
        sub.setObjectName("muted"); sub.setTextFormat(Qt.RichText); sub.setWordWrap(True)
        lay.addWidget(sub)
        # tiles
        trucks = rep.get("trucks") or []
        tiles = QHBoxLayout(); tiles.setSpacing(8)
        dist = sum(float(x.get("dist_m") or 0) for x in trucks)
        ttcs = [x.get("min_ttc") for x in trucks if x.get("min_ttc") is not None]
        fulls = sum(int(x.get("full_brakes") or 0) for x in trucks)
        for title, val, col, tip in (
                ("Loops", loops_text(rep).replace(" loops", "").replace(" loop", ""), "#E9D5FF",
                 "Loops done / planned"),
                ("Driven", f"{dist / 1000:.2f} km", "#E5E7EB", "All AVs together"),
                ("Duration", _dur(rep.get("duration_s")), "#E5E7EB", ""),
                ("Full brakes", str(fulls), AMBER if fulls else GREEN, "Emergency brakings of all AVs"),
                ("Lowest TTC", "--" if not ttcs else f"{min(ttcs):.1f} s",
                 RED if ttcs and min(ttcs) < 1.5 else AMBER if ttcs and min(ttcs) < 3 else GREEN,
                 "The lowest time to collision any AV perceived")):
            f = QFrame(); f.setObjectName("tile")
            fl = QVBoxLayout(f); fl.setContentsMargins(10, 6, 10, 6); fl.setSpacing(0)
            a = QLabel(title.upper()); a.setObjectName("role"); fl.addWidget(a)
            b = QLabel(val); b.setObjectName("tileval"); b.setStyleSheet(f"color: {col};"); fl.addWidget(b)
            f.setToolTip(tip)
            tiles.addWidget(f, 1)
        cb = QPushButton(); cb.setObjectName("tilebtn"); cb.setCursor(Qt.PointingHandCursor)
        bl = QVBoxLayout(cb); bl.setContentsMargins(10, 6, 10, 6); bl.setSpacing(0)
        a = QLabel("COLLISIONS  ▸" if n else "COLLISIONS"); a.setObjectName("role")
        b = QLabel(str(n)); b.setObjectName("tileval"); b.setStyleSheet(f"color: {RED if n else GREEN};")
        for x in (a, b):
            x.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            bl.addWidget(x)
        cb.setMinimumHeight(a.sizeHint().height() + b.sizeHint().height() + 14)
        cb.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        if n:
            cb.setStyleSheet(f"QPushButton#tilebtn {{ border-color: {RED}; }}")
        cb.setToolTip("Open the collisions: each one's reason, what every sensor saw (or why not), the check of "
                      "sensor failure / climate / obstacle or vehicle, the bird's-eye snapshot and its place on the map")
        cb.setEnabled(bool(n))
        cb.clicked.connect(lambda: self._open(recs, "all"))
        tiles.addWidget(cb, 1)
        self.saves = list(rep.get("v2v_saves") or [])
        if rep.get("v2v") or self.saves:                      # (V2V in this test: the collisions it prevented)
            ns = len(self.saves)
            vb = QPushButton(); vb.setObjectName("tilebtn"); vb.setCursor(Qt.PointingHandCursor)
            vl = QVBoxLayout(vb); vl.setContentsMargins(10, 6, 10, 6); vl.setSpacing(0)
            a = QLabel("V2V PREVENTED ▸" if ns else "V2V PREVENTED"); a.setObjectName("role")
            b = QLabel(str(ns)); b.setObjectName("tileval"); b.setStyleSheet(f"color: {SENSOR_COL['V2V']};")
            for x in (a, b):
                x.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                vl.addWidget(x)
            vb.setMinimumHeight(a.sizeHint().height() + b.sizeHint().height() + 14)
            vb.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            vb.setStyleSheet(f"QPushButton#tilebtn {{ border-color: {SENSOR_COL['V2V']}; }}" if ns else "")
            vb.setToolTip("Collisions V2V prevented: the AV braked on a vehicle it knew only from V2V, its sensors "
                          "saw it too late or never -- each with the proof (what V2V knew, what each sensor did and "
                          "why, the impact speed without V2V)")
            vb.setEnabled(bool(ns))
            vb.clicked.connect(lambda: self._open_save(0))
            tiles.addWidget(vb, 1)
        lay.addLayout(tiles)
        # the causes
        cr = QHBoxLayout(); cr.setSpacing(8)
        cl = QLabel("Why:"); cl.setObjectName("section"); cr.addWidget(cl)
        counts = {}
        for x in recs:
            counts[rec_cause(x)] = counts.get(rec_cause(x), 0) + 1
        for key, name, col in CAUSES:
            k = counts.get(key, 0)
            b = QPushButton(f"{name}  {k}"); b.setObjectName("cause"); b.setCursor(Qt.PointingHandCursor)
            c = QColor(col)
            b.setStyleSheet(f"QPushButton#cause {{ background: rgba({c.red()},{c.green()},{c.blue()},"
                            f"{0.18 if k else 0.05}); color: {col if k else GREY}; border: 1px solid "
                            f"rgba({c.red()},{c.green()},{c.blue()},{0.6 if k else 0.2}); }}")
            b.setEnabled(bool(k))
            b.setToolTip(f"The collisions whose main cause is: {name}")
            b.clicked.connect(lambda _c=False, kk=key, nn=name: self._open([x for x in recs if rec_cause(x) == kk], nn))
            cr.addWidget(b)
        other = counts.get(None, 0)
        if other:
            o = QLabel(f"not classified: {other}"); o.setObjectName("muted"); cr.addWidget(o)
        cr.addStretch()
        lay.addLayout(cr)
        # tables
        tabs = QTabWidget()
        ttab = self._table(
            ["#", "AV", "Top speed", "Gap", "Sensors (start → end)", "Loops", "Driven", "Avg", "Brakes",
             "Full", "TTC warn / crit", "Lowest TTC", "Collisions", "V2V"],
            [[str(x.get("no", "")), str(x.get("name", "")), f"{x.get('top_kmh', 0):g} km/h", f"{x.get('gap_m', 0):g} m",
              self._sens(x), str(x.get("loops", "")), f"{float(x.get('dist_m') or 0):.0f} m",
              f"{float(x.get('avg_kmh') or 0):.1f} km/h", str(x.get("brakes", 0)), str(x.get("full_brakes", 0)),
              f"{x.get('ttc_warnings', 0)} / {x.get('ttc_critical', 0)}",
              "--" if x.get("min_ttc") is None else f"{x['min_ttc']:.1f} s", str(x.get("collisions", 0)),
              self._v2v_cell(x)]
             for x in trucks], red_col=12)
        ttab.setToolTip("Double-click an AV: its collisions only (reason, sensors, camera, 3D scene)")
        ttab.cellDoubleClicked.connect(lambda row, _c: self._av_collisions(trucks[row]) if row < len(trucks)
                                       else None)
        tabs.addTab(ttab, "AVs")
        loops = rep.get("loops") or []
        lw = QWidget(); lv = QVBoxLayout(lw); lv.setContentsMargins(0, 6, 0, 0); lv.setSpacing(6)
        if loops:
            lv.addWidget(self._loop_summary(loops, recs, rep))
        lv.addWidget(self._loop_tree(loops, recs, rep), 1)
        tabs.insertTab(0, lw, f"Loops ({len(loops)})")
        tabs.setCurrentIndex(0 if len(loops) > 1 else 1)
        self.ctab = self._table(
            ["#", "Loop", "AV", "Hit", "km/h", "Cause", "Reason (short)", "Details"],
            [[str(c.get("n", "")), str(c.get("lap") or ""), str(c.get("truck", "")), str(c.get("hit", "")),
              f"{c.get('speed_kmh', 0):g}", CAUSE_NAME.get(rec_cause(c), "--"), rec_short(c), str(c.get("reason", ""))]
             for c in recs], cause_col=5)
        self.ctab.setToolTip("Double-click: open this collision's details")
        self.ctab.cellDoubleClicked.connect(lambda row, _c: self._open(recs, "all", recs[row]) if row < len(recs)
                                            else None)
        tabs.addTab(self.ctab, f"Collisions ({n})")
        if rep.get("v2v") or self.saves:
            self.stab = save_table(self.saves)
            self.stab.setToolTip("Double-click: the proof -- what V2V knew, what each sensor did and why, the impact "
                                 "speed without V2V, the bird's-eye view at that moment")
            self.stab.cellDoubleClicked.connect(lambda row, _c: self._open_save(row))
            self._save_tab = tabs.addTab(self.stab, f"Prevented by V2V ({len(self.saves)})")
            if self.saves and not recs:
                tabs.setCurrentIndex(self._save_tab)
        self.tabs_ = tabs
        lay.addWidget(tabs, 1)
        bar = QHBoxLayout(); bar.setSpacing(8)
        if rep.get("dir"):
            s = QLabel("Kept in Reports → Collision tests"); s.setObjectName("muted"); s.setToolTip(rep["dir"])
            bar.addWidget(s)
        elif self.cb.get("save"):
            s = QLabel("Not saved (you chose not to save this test's results)"); s.setObjectName("muted")
            bar.addWidget(s)
            b = QPushButton("💾 Save to Reports"); b.setObjectName("accent")
            b.setToolTip("Keep these results in Reports → Collision tests (with the collisions' camera images)")
            b.clicked.connect(lambda: (self.close(), self.cb["save"]()))
            bar.addWidget(b)
        bar.addStretch()
        if self.cb.get("folder") and rep.get("dir"):
            b = QPushButton("Open folder"); b.clicked.connect(lambda: self.cb["folder"]()); bar.addWidget(b)
        b = QPushButton("Collision details ▸"); b.setObjectName("accent"); b.setEnabled(bool(n))
        b.clicked.connect(lambda: self._open(recs, "all")); bar.addWidget(b)
        b = QPushButton("Close"); b.clicked.connect(self.close); bar.addWidget(b)
        lay.addLayout(bar)
        from PyQt5.QtWidgets import QApplication
        scr = QApplication.primaryScreen()
        g = scr.availableGeometry() if scr else None
        self.resize(min(1380, (g.width() - 40) if g else 1150), min(760, (g.height() - 60) if g else 620))

    def _loop_summary(self, loops, recs, rep):
        """The quick view above the loops table: a card per loop -- PASS / FAIL, its climate, and each AV's
        result, collisions and collisions prevented by V2V (click a count: those records)."""
        saves = getattr(self, "saves", None) or []
        show_v2v = bool(rep.get("v2v") or saves)
        G = SENSOR_COL["V2V"]
        row = QWidget(); rl = QHBoxLayout(row); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(10)

        def chip(text, col, bold=True):
            c = QColor(col)
            x = QLabel(text); x.setAlignment(Qt.AlignCenter)
            x.setStyleSheet(f"background: rgba({c.red()},{c.green()},{c.blue()},0.16); color: {col}; border: 1px solid "
                            f"rgba({c.red()},{c.green()},{c.blue()},0.55); border-radius: 8px; padding: 1px 8px; "
                            f"font-size: 11px; font-weight: {800 if bold else 600};")
            return x

        def count_btn(n, col, word, cb):
            b = QPushButton(str(n)); b.setCursor(Qt.PointingHandCursor if n else Qt.ArrowCursor)
            b.setFlat(True); b.setEnabled(bool(n))
            b.setToolTip(f"{n} {word}" + (" -- click: the details" if n else ""))
            b.setStyleSheet(f"QPushButton {{ background: transparent; border: none; padding: 0 2px; "
                            f"color: {col if n else '#64748B'}; font-weight: {800 if n else 500}; font-size: 13px; }} "
                            f"QPushButton:hover {{ text-decoration: underline; }}")
            if n:
                b.clicked.connect(cb)
            return b

        for e in loops:
            k = e.get("loop")
            tr = e.get("trucks") or []
            nc = e.get("collisions") if e.get("collisions") is not None else sum(1 for c in recs if c.get("lap") == k)
            ns = sum(1 for s in saves if s.get("lap") == k)
            done = e.get("t1") is not None
            col = RED if nc else GREEN if done else AMBER
            card = QFrame(); card.setObjectName("loopcard")
            c = QColor(col)
            card.setStyleSheet(f"QFrame#loopcard {{ background: #0F172A; border: 1px solid rgba({c.red()},{c.green()},"
                               f"{c.blue()},0.55); border-top: 4px solid {col}; border-radius: 10px; }}")
            cl = QVBoxLayout(card); cl.setContentsMargins(12, 8, 12, 10); cl.setSpacing(5)
            hl = QHBoxLayout(); hl.setSpacing(8)
            t_ = QLabel(f"Loop {k}"); t_.setStyleSheet("font-size: 15px; font-weight: 800; color: #F1F5F9;")
            hl.addWidget(t_)
            hl.addWidget(chip("FAIL" if nc else "PASS" if done else "RUNNING", col))
            hl.addStretch()
            if show_v2v and ns:
                hl.addWidget(chip(f"{ns} by V2V", G))
            cl.addLayout(hl)
            sub = QLabel(f"{e.get('climate') or ''}"); sub.setStyleSheet(f"color: {GREY}; font-size: 11px;")
            sub.setToolTip(e.get("settings") or ""); cl.addWidget(sub)
            line = QFrame(); line.setFixedHeight(1); line.setStyleSheet("background: #1F2937;"); cl.addWidget(line)
            g = QGridLayout(); g.setHorizontalSpacing(10); g.setVerticalSpacing(3)
            for j, hd in enumerate(["AV", "RESULT", "COLLISIONS"] + (["PREVENTED\nBY V2V"] if show_v2v else [])):
                x = QLabel(hd); x.setStyleSheet("color: #64748B; font-size: 9px; font-weight: 800; letter-spacing: 1px;")
                g.addWidget(x, 0, j, alignment=Qt.AlignLeft if j == 0 else Qt.AlignCenter)
            for i, t in enumerate(tr, start=1):
                n = int(t.get("collisions") or 0)
                nm = QLabel(f"<b>AV {t.get('no')}</b> <span style='color:{GREY}'>· {t.get('name')}</span>")
                nm.setTextFormat(Qt.RichText); nm.setStyleSheet("font-size: 12px; color: #E5E7EB;")
                nm.setMinimumWidth(nm.sizeHint().width())
                nm.setToolTip(f"{t.get('kmh', 0):g} km/h · " + " + ".join(
                    x for x in (t.get("sensors") or []) if x) + (" · stop & go" if t.get("sg") else ""))
                g.addWidget(nm, i, 0)
                g.addWidget(chip("FAIL" if n else "PASS" if t.get("done", True) else "…", RED if n else GREEN), i, 1,
                            alignment=Qt.AlignCenter)
                g.addWidget(count_btn(n, RED, "collision" + ("s" if n != 1 else ""),
                                      lambda _c=False, tt=t, kk=k: self._av_collisions(tt, kk)), i, 2,
                            alignment=Qt.AlignCenter)
                if show_v2v:
                    nv = sum(1 for s in saves if s.get("lap") == k and s.get("truck") == t.get("name"))
                    v_on = "V2V" in (t.get("sensors") or [])
                    if nv or v_on:
                        g.addWidget(count_btn(nv, G, "prevented by V2V",
                                              lambda _c=False, kk=k, tt=t: self._saves_of(kk, tt)), i, 3,
                                    alignment=Qt.AlignCenter)
                    else:
                        x = QLabel("off"); x.setStyleSheet("color: #475569; font-size: 11px;")
                        x.setToolTip("V2V was off for this AV in this loop")
                        g.addWidget(x, i, 3, alignment=Qt.AlignCenter)
            g.setColumnStretch(0, 1)
            cl.addLayout(g)
            if not tr:
                x = QLabel(f"{nc} collision{'s' if nc != 1 else ''}"); x.setStyleSheet(f"color: {col};")
                cl.addWidget(x)
            cl.addStretch(1)
            card.setMinimumWidth(card.sizeHint().width())
            rl.addWidget(card)
        rl.addStretch(1)
        sc = QScrollArea(); sc.setWidget(row); sc.setWidgetResizable(True); sc.setFrameShape(QFrame.NoFrame)
        sc.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sc.setStyleSheet("QScrollArea { background: transparent; } QScrollBar:horizontal { background: #0B1220; "
                         "height: 10px; border: none; } QScrollBar::handle:horizontal { background: #334155; "
                         "border-radius: 5px; min-width: 40px; } QScrollBar::add-line, QScrollBar::sub-line "
                         "{ width: 0; } QScrollBar::add-page, QScrollBar::sub-page { background: none; }")
        sc.viewport().setStyleSheet("background: transparent;")
        row.setStyleSheet("background: transparent;")
        h = row.sizeHint().height()
        sc.setFixedHeight(h + (16 if row.sizeHint().width() > 1100 else 4))
        return sc

    def _saves_of(self, loop, t):
        sel = [s for s in self.saves if s.get("lap") == loop and (not t or s.get("truck") == t.get("name"))]
        if not sel:
            return
        what = f"loop {loop}" + (f" · AV {t.get('no')} · {t.get('name')}" if t else "")
        d = V2VSavesDialog(self, sel, self.cb.get("show_save"), title=f"Collisions prevented by V2V -- {what}")
        d.setAttribute(Qt.WA_DeleteOnClose, True)
        d.show()

    def _loop_tree(self, loops, recs, rep):
        """Each loop: its result, climate, settings, duration, km, brakings, TTC, collisions -- expanded: each AV
        in that loop. Double-click a loop: its collisions."""
        from PyQt5.QtWidgets import QTreeWidget, QTreeWidgetItem
        cols = ["Loop / AV", "Result", "Climate", "Settings", "Duration", "Driven", "Avg", "Full brakes",
                "TTC warn / crit", "Lowest TTC", "Collisions", "Prevented by V2V"]
        saves = getattr(self, "saves", None) or []
        tw = QTreeWidget(); tw.setColumnCount(len(cols)); tw.setHeaderLabels(cols)
        tw.setStyleSheet("QTreeWidget { background: #0A0F1C; color: #E5E7EB; border: 1px solid #1F2937; "
                         "border-radius: 8px; } QHeaderView::section { background: #111827; color: #94A3B8; "
                         "border: none; padding: 5px; font-weight: 700; } QTreeWidget::item:selected { background: #1D4ED8; }")
        tw.setToolTip("Double-click a loop: its collisions (reason, sensors, camera, bird's-eye)")
        fin = lambda v: v is not None                                                   # noqa: E731
        sens = lambda s: (" + ".join(x for x, _n in SENSORS if x in (s or [])) or "all OFF") + (   # noqa: E731
            " + V2V" if "V2V" in (s or []) else "")
        for e in loops:
            k = e.get("loop")
            tr = e.get("trucks") or []
            nc = e.get("collisions") if fin(e.get("collisions")) else sum(1 for c in recs if c.get("lap") == k)
            dur = ((e.get("t1") if fin(e.get("t1")) else rep.get("duration_s") or 0) - (e.get("t0") or 0))
            ttcs = [t["min_ttc"] for t in tr if fin(t.get("min_ttc"))]
            vals = [f"Loop {k}", "PASS" if not nc else "FAIL", str(e.get("climate") or ""),
                    e.get("settings") or "as set", _dur(dur) + ("" if fin(e.get("t1")) else " (not finished)"),
                    f"{sum(float(t.get('dist_m') or 0) for t in tr) / 1000:.2f} km" if tr else "",
                    "", str(sum(int(t.get("full_brakes") or 0) for t in tr)) if tr else "",
                    (f"{sum(int(t.get('ttc_warnings') or 0) for t in tr)} / "
                     f"{sum(int(t.get('ttc_critical') or 0) for t in tr)}") if tr else "",
                    f"{min(ttcs):.1f} s" if ttcs else "--", str(nc),
                    str(sum(1 for s_ in saves if s_.get("lap") == k)) if saves else ""]
            top = QTreeWidgetItem(vals)
            if saves:
                top.setForeground(11, QColor(SENSOR_COL["V2V"]))
            top.setData(0, Qt.UserRole, k)
            f = top.font(0); f.setBold(True)
            for j in range(len(cols)):
                top.setFont(j, f)
            top.setForeground(1, QColor(RED if nc else GREEN)); top.setForeground(10, QColor(RED if nc else GREEN))
            for j in range(len(cols)):
                top.setBackground(j, QColor("#2A1215" if nc else "#0F2A1E"))
            top.setToolTip(3, e.get("settings") or "the setup's settings")
            for t in tr:
                st = f"{t.get('kmh', 0):g} km/h · {sens(t.get('sensors'))}" + (" · stop & go" if t.get("sg") else "")
                ch = QTreeWidgetItem([f"   AV {t.get('no')} · {t.get('name')}", "FAIL" if t.get("collisions") else
                                      "ok", str(t.get("climate") or ""), st, "" if t.get("done") else "(still in it)",
                                      f"{float(t.get('dist_m') or 0):.0f} m", f"{float(t.get('avg_kmh') or 0):.1f} km/h",
                                      str(t.get("full_brakes", 0)),
                                      f"{t.get('ttc_warnings', 0)} / {t.get('ttc_critical', 0)}",
                                      "--" if not fin(t.get("min_ttc")) else f"{t['min_ttc']:.1f} s",
                                      str(t.get("collisions", 0)),
                                      str(sum(1 for s_ in saves if s_.get("lap") == k and
                                              s_.get("truck") == t.get("name"))) if saves else ""])
                ch.setData(0, Qt.UserRole, k)
                ch.setData(0, Qt.UserRole + 1, t)                   # (double-click: this AV in this loop)
                ch.setForeground(1, QColor(RED if t.get("collisions") else GREEN))
                ch.setForeground(10, QColor(RED if t.get("collisions") else GREY))
                top.addChild(ch)
            tw.addTopLevelItem(top)
            top.setExpanded(len(loops) <= 6)
        for j in range(len(cols)):
            tw.resizeColumnToContents(j)
        tw.setColumnWidth(3, min(380, max(160, tw.columnWidth(3))))
        tw.setToolTip("Double-click a loop: its collisions -- an AV under it: that AV's in that loop")
        if saves:
            tw.setToolTip("Double-click a loop: its collisions -- an AV under it: that AV's in that loop -- the "
                          "'Prevented by V2V' column: those prevented by V2V")
        tw.itemDoubleClicked.connect(lambda it, c: self._tree_saves(it) if c == 11 and saves else
                                     self._av_collisions(it.data(0, Qt.UserRole + 1), it.data(0, Qt.UserRole))
                                     if it.data(0, Qt.UserRole + 1) else
                                     self._open([c for c in recs if c.get("lap") == it.data(0, Qt.UserRole)],
                                                f"loop {it.data(0, Qt.UserRole)}"))
        return tw

    def _tree_saves(self, it):
        """The collisions prevented by V2V in one loop (of one AV)."""
        k, t = it.data(0, Qt.UserRole), it.data(0, Qt.UserRole + 1)
        sel = [s for s in self.saves if s.get("lap") == k and (not t or s.get("truck") == t.get("name"))]
        what = f"loop {k}" + (f" · AV {t.get('no')} · {t.get('name')}" if t else "")
        if not sel:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.information(self, "Prevented by V2V", f"No collision prevented by V2V in {what}.")
            return
        self._saves_of(k, t)

    def _open_save(self, i):
        """The collisions prevented by V2V: all of them in a list, row i's proof shown (Prev / Next for the others)."""
        if not self.saves or i >= len(self.saves):
            return
        if getattr(self, "_save_tab", None) is not None:
            self.tabs_.setCurrentIndex(self._save_tab)
        d = V2VSavesDialog(self, self.saves, self.cb.get("show_save"), select=i,
                           title=f"Collisions prevented by V2V -- {self.rep.get('route', '')}")
        d.setAttribute(Qt.WA_DeleteOnClose, True)
        d.show()

    def _av_collisions(self, t, loop=None):
        """One AV's collisions (in one loop): the collisions list filtered to it."""
        if not t:
            return
        no, name = t.get("no"), str(t.get("name") or "")
        recs = [c for c in self.recs if (c.get("truck_no") == no if c.get("truck_no") else str(c.get("truck")) == name)
                and (loop is None or c.get("lap") == loop)]
        what = f"AV {no} · {name}" + (f" · loop {loop}" if loop is not None else "")
        if not recs:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.information(self, "Collisions", f"No collision of {what}.")
            return
        self._open(recs, what)

    @staticmethod
    def _sens(x):
        a = [s for s, _n in SENSORS if s in (x.get("sensors_start") or [])] + (["V2V"] if x.get("v2v_start") else [])
        b = [s for s, _n in SENSORS if s in (x.get("sensors_end") or [])] + (["V2V"] if x.get("v2v_end") else [])
        ta = " + ".join(a) or "none"
        return ta if a == b else f"{ta} → {' + '.join(b) or 'none'}"

    @staticmethod
    def _v2v_cell(x):
        v = x.get("v2v")
        if not v:
            return "–"
        return (f"{v.get('received', 0)} rx · {v.get('loss_pct', 0):g} % lost"
                + (f" · {v['delay_ms']:.0f} ms" if v.get("delay_ms") is not None else "")
                + f" · {v.get('alerts', 0)} alerts")

    def _table(self, cols, rows, red_col=None, cause_col=None):
        tb = QTableWidget(len(rows), len(cols))
        tb.setHorizontalHeaderLabels(cols)
        tb.verticalHeader().setVisible(False)
        tb.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tb.setSelectionBehavior(QAbstractItemView.SelectRows)
        hh = tb.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setStretchLastSection(True)
        tb.setStyleSheet("QTableWidget { background: #0A0F1C; color: #E5E7EB; gridline-color: #1F2937; border: none; }"
                         " QHeaderView::section { background: #111827; color: #94A3B8; border: none; padding: 4px; }"
                         " QTableWidget::item:selected { background: #1D4ED8; }")
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                it = QTableWidgetItem(v)
                if j == red_col:
                    it.setForeground(QColor(RED if v not in ("0", "") else GREEN))
                if j == cause_col:
                    key = next((k for k, nm, _c in CAUSES if nm == v), None)
                    it.setForeground(QColor(CAUSE_COL.get(key, GREY)))
                it.setToolTip(v)
                tb.setItem(i, j, it)
        return tb

    def _open(self, recs, what, select=None):
        if recs:
            title = f"Collisions -- {self.rep.get('route', '')}" + ("" if what == "all" else f" -- {what}")
            self.cb["collisions"](list(recs), title, select)
