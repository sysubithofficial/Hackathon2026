"""
scenarios.py  --  obstacle scenarios ("Scenarios" in the left menu).

A scenario is a named set of obstacles (cars, outer trucks, pedestrians; static or moving
along a path) stored per yard in sites/<yard>/data/scenarios.json:

    {"scenarios": [{"name": "Min", "default": true, "created": "...",
                    "obstacles": [<obstacle payload as in obstacles.json>, ...]}, ...]}

Choosing a scenario replaces the obstacles on the map with its obstacles; the obstacles on
the map can be saved as a new scenario. The default scenarios Min / Average / Max are made
once per yard from the yard's recorded truck routes (sites/<yard>/routes): moving obstacles
drive / walk along stretches of those routes and back (so they never jump), static ones
stand beside the lanes -- never inside a building.
"""
import json
import math
import os
import random
from datetime import datetime

# name -> (static, moving) obstacle counts of the default scenarios
DEFAULT_COUNTS = [("Min", 6, 6), ("Average", 12, 14), ("Max", 24, 30)]
GRID = 5                           # obstacles are spread over a GRID x GRID raster of the map
TYPES_MOVING = ["car", "pedestrian", "outer_truck", "car", "pedestrian", "car"]
TYPES_STATIC = ["car", "pedestrian", "outer_truck", "car"]
ID_PREFIX = {"car": "CAR", "outer_truck": "OTRK", "pedestrian": "PED", "van": "VAN", "bus": "BUS",
             "truck_trailer": "TT"}
SPEED_KMH = {"car": (10, 20), "outer_truck": (8, 15), "pedestrian": (3, 5)}
METRES_PER_DEG = 111320.0


# ------------------------------------------------------------------ storage
def load(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return [s for s in data.get("scenarios", []) if s.get("name")]
    except (OSError, ValueError):
        return []


def save(path, scenarios):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"scenarios": scenarios}, f, indent=2)
    os.replace(tmp, path)


def make(name, obstacles, default=False):
    return {"name": name, "default": bool(default), "created": datetime.now().isoformat(timespec="seconds"),
            "obstacles": [dict(o) for o in obstacles]}


def summary(scenario):
    obs = scenario.get("obstacles", [])
    moving = sum(1 for o in obs if o.get("mode") == "dynamic")
    return f"{len(obs) - moving} static, {moving} moving"


# ------------------------------------------------------------------ geometry
def _resample(points, step):
    """Route points [(lat, lon, ...)] -> points every `step` metres."""
    pts = [(float(p[0]), float(p[1])) for p in points]
    if len(pts) < 2:
        return pts
    out = [pts[0]]
    carry = 0.0
    for (a_lat, a_lon), (b_lat, b_lon) in zip(pts, pts[1:]):
        kx = METRES_PER_DEG * math.cos(math.radians(a_lat))
        dx, dy = (b_lon - a_lon) * kx, (b_lat - a_lat) * METRES_PER_DEG
        seg = math.hypot(dx, dy)
        if seg < 1e-6:
            continue
        d = step - carry
        while d <= seg:
            f = d / seg
            out.append((a_lat + (b_lat - a_lat) * f, a_lon + (b_lon - a_lon) * f))
            d += step
        carry = seg - (d - step)
    return out


def _offset(lat, lon, lat2, lon2, side_m):
    """Point `side_m` metres to the right (+) / left (-) of the direction lat,lon -> lat2,lon2."""
    kx = METRES_PER_DEG * math.cos(math.radians(lat))
    de, dn = (lon2 - lon) * kx, (lat2 - lat) * METRES_PER_DEG
    n = math.hypot(de, dn) or 1.0
    re_, rn = dn / n, -de / n                         # right-hand normal
    return lat + rn * side_m / METRES_PER_DEG, lon + re_ * side_m / kx


def _dist(lat1, lon1, lat2, lon2):
    kx = METRES_PER_DEG * math.cos(math.radians(lat1))
    return math.hypot((lon2 - lon1) * kx, (lat2 - lat1) * METRES_PER_DEG)


def _there_and_back(path):
    return path + path[-2::-1] if len(path) > 1 else path


# ------------------------------------------------------------------ default scenarios
DEFAULTS_VERSION = 5               # bump when the default scenarios change: they are rebuilt

# traffic scenarios (heavy-traffic testing): (name, vehicles) -- cars and outer trucks driving the yard's roads in
# their lane (right-hand side), there and back; queues form where they meet (they wait behind each other)
TRAFFIC_LEVELS = [("Traffic: light", 20), ("Traffic: medium", 50), ("Traffic: heavy", 100),
                  ("Traffic: very heavy", 160)]
TRAFFIC_SPEED_KMH = {"car": (20, 40), "outer_truck": (15, 30), "van": (20, 35), "bus": (15, 30),
                     "truck_trailer": (15, 28)}
# the mix of vehicles in traffic (repeating): half cars, then vans, outer trucks, buses, trucks with trailers
TRAFFIC_MIX = ["car", "car", "van", "car", "outer_truck", "car", "bus", "car", "truck_trailer", "van"]
TRAFFIC_STRETCH_M = 400            # each vehicle drives up to this much of one road, then back
TRAFFIC_MIN_GAP_M = 12             # start positions at least this far apart


class _Spread:
    """Lane points bucketed into a GRID x GRID raster over the map bounds; picks always come
    from the least-used cell, so obstacles spread over the whole map."""

    def __init__(self, lanes, bounds, taken, grid=GRID):
        (s, w), (n, e) = bounds
        self.lanes, self.cells, self.taken = lanes, {}, taken     # taken: picks shared in one scenario
        for li, lane in enumerate(lanes):
            for pi in range(0, len(lane), 4):
                lat, lon = lane[pi]
                if not (s <= lat <= n and w <= lon <= e):
                    continue
                cell = (min(grid - 1, int((lat - s) / (n - s) * grid)), min(grid - 1, int((lon - w) / (e - w) * grid)))
                self.cells.setdefault(cell, []).append((li, pi))
        self.use = {c: 0 for c in self.cells}

    def pick(self, rnd, min_sep=30.0):
        """A lane point in the least-used cell, at least min_sep metres from every earlier pick
        of the scenario (so obstacles do not start on top of each other)."""
        if not self.cells:
            return None
        for attempt in range(30):
            least = min(self.use.values())
            cell = rnd.choice(sorted(c for c, u in self.use.items() if u == least))
            li, pi = rnd.choice(self.cells[cell])
            lat, lon = self.lanes[li][pi]
            sep = min_sep if attempt < 20 else min_sep / 3
            if all(_dist(lat, lon, a, b) >= sep for a, b in self.taken):
                self.use[cell] += 1
                self.taken.append((lat, lon))
                return li, pi
            self.use[cell] += 0.25                            # crowded cell: prefer others next time
        return None


def build_traffic(roads, in_slot, bounds, seed=7):
    """The traffic scenarios from the roads [(polyline [(lat, lon)], width m)]: every vehicle drives a stretch of
    one road in its right-hand lane and comes back in the other lane, again and again."""
    rnd = random.Random(seed)
    (s, w), (n, e) = bounds
    inside = lambda lat, lon: s <= lat <= n and w <= lon <= e
    lanes = []
    for line, width in roads or []:
        pts = [p for p in _resample(line, 2.0) if inside(*p)]
        if len(pts) >= 15:
            lanes.append((pts, max(1.4, float(width or 6.0) / 4.0)))
    if not lanes:
        return []
    weights = [len(p) for p, _o in lanes]
    out = []
    for name, count in TRAFFIC_LEVELS:
        taken, obs = [], []
        for i in range(count):
            typ = TRAFFIC_MIX[i % len(TRAFFIC_MIX)]
            for _try in range(40):
                pts, off = rnd.choices(lanes, weights)[0]
                k = min(len(pts) - 1, int(TRAFFIC_STRETCH_M / 2.0))
                a = rnd.randint(0, max(0, len(pts) - 1 - k))
                seg = pts[a:a + k + 1]
                if rnd.random() < 0.5:
                    seg = seg[::-1]                           # both directions on every road
                if len(seg) < 8 or any(_dist(seg[0][0], seg[0][1], p, q) < TRAFFIC_MIN_GAP_M for p, q in taken):
                    continue

                def lane(points):                             # the right-hand lane of this direction
                    res = []
                    for j in range(len(points)):
                        p0, p1 = (points[j], points[j + 1]) if j < len(points) - 1 else (points[j - 1], points[j])
                        res.append(_offset(points[j][0], points[j][1], points[j][0] + p1[0] - p0[0],
                                           points[j][1] + p1[1] - p0[1], off))
                    return res
                there, back = lane(seg), lane(seg[::-1])
                loop = there[::4] + back[::4]                 # a point every ~8 m, round trip
                if sum(1 for p in loop if in_slot(*p)) > len(loop) // 5:
                    continue
                taken.append(seg[0])
                lo, hi = TRAFFIC_SPEED_KMH[typ]
                path = [{"lat": round(p[0], 8), "lon": round(p[1], 8)} for p in loop] + \
                       [{"lat": round(there[0][0], 8), "lon": round(there[0][1], 8)}]
                obs.append({"type": typ, "objectId": f"TRF-{ID_PREFIX[typ]}-{count}-{i + 1}", "mode": "dynamic",
                            "latitude": path[0]["lat"], "longitude": path[0]["lon"], "path": path,
                            "speed_kmh": round(rnd.uniform(lo, hi), 1)})
                break
        sc = make(f"{name} ({len(obs)} vehicles)", obs, default=True)
        sc["version"] = DEFAULTS_VERSION
        sc["traffic"] = True
        out.append(sc)
    return out


def build_defaults(routes, in_slot, bounds, roads=None, footways=None,
                   fallback_path=None, fallback_point=None, seed=84):
    """routes / roads / footways: polylines [[(lat, lon, ...), ...], ...] (recorded truck routes,
    OpenStreetMap service roads, footways); in_slot(lat, lon) -> bool; bounds = [[s, w], [n, e]].
    Without any lane, fallback_path() / fallback_point() (random open-area paths / points)."""
    rnd = random.Random(seed)
    (s, w), (n, e) = bounds
    inside = lambda lat, lon: s <= lat <= n and w <= lon <= e
    lanes = [r for r in (_resample(p, 2.0) for p in list(routes or []) + list(roads or [])) if len(r) >= 25]
    walks = [r for r in (_resample(p, 2.0) for p in footways or []) if len(r) >= 10]
    out = []
    for name, n_static, n_moving in DEFAULT_COUNTS:
        taken = []
        drive, stand = _Spread(lanes, bounds, taken), _Spread(lanes, bounds, taken)
        walk = _Spread(walks + lanes, bounds, taken)         # footways, or beside any lane
        tag = name[:3].upper()
        obs = []
        for i in range(n_moving):
            typ = TYPES_MOVING[i % len(TYPES_MOVING)]
            path = None
            if lanes:
                path = _moving_path(rnd, walk if typ == "pedestrian" else drive, typ, in_slot, inside,
                                    n_footways=len(walks) if typ == "pedestrian" else 0)
            if not path and fallback_path:
                path = [{"lat": p["lat"], "lon": p["lon"]} for p in fallback_path()]
            if not path:
                continue
            lo, hi = SPEED_KMH[typ]
            obs.append({"type": typ, "objectId": f"{ID_PREFIX[typ]}-{tag}-M{i + 1}", "mode": "dynamic",
                        "latitude": path[0]["lat"], "longitude": path[0]["lon"], "path": path,
                        "speed_kmh": round(rnd.uniform(lo, hi), 1)})
        for i in range(n_static):
            typ = TYPES_STATIC[i % len(TYPES_STATIC)]
            pt = _static_point(rnd, stand, in_slot, inside) if lanes else None
            if not pt and fallback_point:
                p = fallback_point()
                pt = (p["lat"], p["lon"])
            if not pt:
                continue
            obs.append({"type": typ, "objectId": f"{ID_PREFIX[typ]}-{tag}-S{i + 1}", "mode": "static",
                        "latitude": pt[0], "longitude": pt[1]})
        sc = make(name, obs, default=True)
        sc["version"] = DEFAULTS_VERSION
        out.append(sc)
    return out


def _moving_path(rnd, spread, typ, in_slot, inside, n_footways=0, tries=60):
    """A stretch of a lane around a picked point, there and back. Vehicles drive on the lane;
    pedestrians walk on a footway, or 3.5 m beside a lane."""
    for _ in range(tries):
        pick = spread.pick(rnd)
        if pick is None:
            return None
        li, pi = pick
        lane = spread.lanes[li]
        n = rnd.randint(15, 30) if typ == "pedestrian" else rnd.randint(50, 100)
        n = min(n, len(lane) - 1)
        s = max(0, min(pi - n // 2, len(lane) - 1 - n))
        seg = lane[s:s + n + 1]
        if typ == "pedestrian" and li >= n_footways:          # a vehicle lane: walk beside it
            side = rnd.choice((-3.5, 3.5))
            moved = []
            for k in range(len(seg)):
                a, b = (seg[k], seg[k + 1]) if k < len(seg) - 1 else (seg[k - 1], seg[k])   # lane direction
                moved.append(_offset(seg[k][0], seg[k][1], seg[k][0] + b[0] - a[0], seg[k][1] + b[1] - a[1], side))
            seg = moved
        seg = [p for p in seg if inside(*p)]                 # stay on the map
        if len(seg) < 6:
            continue
        pts = seg[::4] + ([seg[-1]] if (len(seg) - 1) % 4 else [])   # a point every ~8 m
        if sum(1 for p in pts if in_slot(*p)) > (0 if typ == "pedestrian" else len(pts) // 5):
            continue                                         # crosses parking / dock areas: try again
        return _there_and_back([{"lat": round(a, 8), "lon": round(b, 8)} for a, b in pts])
    return None


def _static_point(rnd, spread, in_slot, inside, tries=80):
    """Beside a lane (4-6 m off its centre), on the map, not inside a slot."""
    for _ in range(tries):
        pick = spread.pick(rnd)
        if pick is None:
            return None
        li, pi = pick
        lane = spread.lanes[li]
        k = min(pi, len(lane) - 2)
        lat, lon = _offset(lane[k][0], lane[k][1], lane[k + 1][0], lane[k + 1][1],
                           rnd.choice((-1, 1)) * rnd.uniform(4.0, 6.0))
        if inside(lat, lon) and not in_slot(lat, lon):
            return round(lat, 8), round(lon, 8)
    return None