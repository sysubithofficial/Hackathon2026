"""Paths along the yard's OpenStreetMap roads (osm_surroundings.json "roads"): from a source to a destination
(through optional via points), and back to the source the same way or by other roads.

    r = RoadRouter(roads)                       # roads: [{kind, name, oneway, width, line: [[lat, lon], ...]}]
    res = r.plan([src, via..., dst], back="different", side="left")    # back: None / "same" / "different"
    res = {"points": [(lat, lon)], "out_m", "back_m", "shared_m", "roads": [(name, m)], "back_roads", "notes",
           "against_m", "side"}

- Every point is snapped onto a drivable road. Near a divided road (two one-way carriageways) both carriageways
  are tried -- the one from which the way is legal is taken (a click on a highway can land on the other half).
- One-way roads are driven their way only. When the map leaves no legal way (a carriageway cut at the edge of the
  downloaded area), driving against one costs AGAINST_PENALTY times its length: only where it cannot be avoided;
  res["against_m"] says how much (the notes too).
- side ("left": India, UK, Japan ...; "right": US, Europe ...): on a two-way road the path is in that lane -- moved
  off the centre line by a quarter of the road's width (1.5 - 2.5 m); one-way carriageways are drawn at their
  centre already. side=None: on the centre lines.
- "different": the way back avoids the roads of the way out (DIFFERENT_PENALTY x) where another road exists
  (shared_m says how much is still shared).
"""
import heapq
import math

DRIVE = {"motorway", "trunk", "primary", "secondary", "tertiary", "unclassified", "residential", "service",
         "living_street", "motorway_link", "trunk_link", "primary_link", "secondary_link", "tertiary_link", "road"}
DIFFERENT_PENALTY = 12.0
AGAINST_PENALTY = 40.0
SNAP_MAX_M = 80.0
SNAP_ALT_M = 15.0                  # other roads this much farther than the nearest are tried too (divided roads)
LANE_MIN_M, LANE_MAX_M, LANE_DEFAULT_M = 1.5, 2.5, 1.75


def dist(a, b):
    kx = 111320.0 * math.cos(math.radians((a[0] + b[0]) / 2))
    return math.hypot((b[1] - a[1]) * kx, (b[0] - a[0]) * 111320.0)


def heading(a, b):
    return math.degrees(math.atan2((b[1] - a[1]) * math.cos(math.radians(a[0])), b[0] - a[0])) % 360.0


class RoadRouter:
    def __init__(self, roads):
        self.pos, self.adj, self.name = {}, {}, {}          # vertex -> (lat, lon); u -> [(v, m, legal)]
        self.edge = {}                                      # (u, v) -> {"ow": oneway, "w": width m}
        self.segs = []                                      # (u, v, oneway, road index) for snapping
        n = 0
        key_of = {}

        def vid(p):
            nonlocal n
            k = (round(p[0] * 2e5), round(p[1] * 2e5))     # (~5 cm: shared OSM nodes join the roads)
            if k not in key_of:
                key_of[k] = n
                self.pos[n] = (float(p[0]), float(p[1]))
                n += 1
            return key_of[k]
        for ri, r in enumerate(roads or []):
            if r.get("kind") not in DRIVE or len(r.get("line") or []) < 2:
                continue
            try:
                ow = int(r.get("oneway") or 0)
            except (TypeError, ValueError):
                ow = 1 if str(r.get("oneway")).lower() in ("yes", "true") else 0
            try:
                w = float(r.get("width") or 0)
            except (TypeError, ValueError):
                w = 0.0
            pts = [vid(p) for p in r["line"]]
            for a, b in zip(pts, pts[1:]):
                if a != b:
                    self._edge(a, b, ow, r.get("name") or r.get("kind"), w, ri)
        self._n = n

    def _edge(self, a, b, ow, name, w=0.0, ri=-1):
        m = dist(self.pos[a], self.pos[b])
        self.adj.setdefault(a, []).append((b, m, ow >= 0))   # (oneway 1: a -> b only; -1: b -> a only)
        self.adj.setdefault(b, []).append((a, m, ow <= 0))
        self.name[(a, b)] = self.name[(b, a)] = name
        self.edge[(a, b)] = self.edge[(b, a)] = {"ow": ow, "w": w}
        self.segs.append((a, b, ow, ri))

    def __len__(self):
        return len(self.segs)

    def _near(self, p):
        """The segments near a point: [(metres off, segment index, t along it)], nearest first."""
        lat, lon = p
        kx = 111320.0 * math.cos(math.radians(lat))
        out = []
        for i, (a, b, ow, ri) in enumerate(self.segs):
            A, B = self.pos[a], self.pos[b]
            ax, ay = (A[1] - lon) * kx, (A[0] - lat) * 111320.0
            bx, by = (B[1] - lon) * kx, (B[0] - lat) * 111320.0
            if min(abs(ax), abs(bx)) > SNAP_MAX_M + 400 and ax * bx > 0:
                continue
            dx, dy = bx - ax, by - ay
            L2 = dx * dx + dy * dy
            t = 0.0 if L2 <= 0 else max(0.0, min(1.0, -(ax * dx + ay * dy) / L2))
            out.append((math.hypot(ax + t * dx, ay + t * dy), i, t))
        out.sort()
        return out

    def _split(self, i, t):
        a, b, ow, ri = self.segs[i]
        if t <= 0.02:
            return a
        if t >= 0.98:
            return b
        A, B = self.pos[a], self.pos[b]
        c = self._n
        self._n += 1
        self.pos[c] = (A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t)
        e = self.edge.get((a, b), {"ow": ow, "w": 0.0})
        nm = self.name.get((a, b))
        self._edge(a, c, ow, nm, e["w"], ri)             # (the old edge stays: the snapped vertex joins it)
        self._edge(c, b, ow, nm, e["w"], ri)
        return c

    def snap(self, p):
        """A point onto the nearest road (the road split there) -> (vertex, metres off) | (None, metres)."""
        near = self._near(p)
        if not near or near[0][0] > SNAP_MAX_M:
            return None, (near[0][0] if near else None)
        d, i, t = near[0]
        return self._split(i, t), d

    def candidates(self, p, alt=None, n=4):
        """A point onto the roads near it: the nearest, and other roads up to `alt` (SNAP_ALT_M) farther (the
        other carriageway of a divided road) -> [(vertex, metres off)] | raises ValueError."""
        alt = SNAP_ALT_M if alt is None else alt
        near = self._near(p)
        if not near or near[0][0] > SNAP_MAX_M:
            raise ValueError(f"{round(near[0][0]) if near else '?'} m from the nearest road (at most {SNAP_MAX_M:.0f} m)")
        out, roads = [], set()
        for d, i, t in near:
            if d > min(SNAP_MAX_M, near[0][0] + alt) or len(out) >= n:
                break
            ri = self.segs[i][3]
            if ri in roads:
                continue
            roads.add(ri)
            out.append((self._split(i, t), d))
        return out

    def _path(self, s, g, avoid=None, against=False):
        """Dijkstra s -> g: one-way roads their way only (against: allowed at AGAINST_PENALTY x). -> (vertices,
        cost) | (None, inf)."""
        dd, prev, pq = {s: 0.0}, {}, [(0.0, s)]
        while pq:
            c, u = heapq.heappop(pq)
            if u == g:
                break
            if c > dd.get(u, 1e18):
                continue
            for v, m, ok in self.adj.get(u, []):
                if not ok and not against:
                    continue
                w = m * (DIFFERENT_PENALTY if avoid and ((u, v) in avoid or (v, u) in avoid) else 1.0)
                if not ok:
                    w *= AGAINST_PENALTY
                if c + w < dd.get(v, 1e18):
                    dd[v], prev[v] = c + w, u
                    heapq.heappush(pq, (c + w, v))
        if g not in dd:
            return None, math.inf
        out = [g]
        while out[-1] != s:
            out.append(prev[out[-1]])
        return out[::-1], dd[g]

    def _legal(self, u, v):
        return any(x == v and ok for x, m, ok in self.adj.get(u, []))

    def _best_leg(self, starts, goals, avoid=None, allow_against=True):
        """The best leg from any start candidate to any goal candidate: legal if there is one (the nearest
        snaps preferred: their metres off count double) -> (vertices, legal)."""
        best = None
        for s, ds in starts:
            for g, dg in goals:
                p, c = self._path(s, g, avoid)
                if p is not None:
                    c += 2.0 * (ds + dg)
                    if best is None or c < best[0]:
                        best = (c, p, True)
        if best is not None:
            return best[1], True
        if not allow_against:
            return None, False
        for s, ds in starts[:1]:                          # (no legal way at all: as little against as possible)
            for g, dg in goals[:1]:
                p, c = self._path(s, g, avoid, against=True)
                if p is not None:
                    return p, False
        return None, False

    def _roads(self, verts):
        out = []
        for a, b in zip(verts, verts[1:]):
            n = self.name.get((a, b)) or "road"
            m = dist(self.pos[a], self.pos[b])
            if out and out[-1][0] == n:
                out[-1][1] += m
            else:
                out.append([n, m])
        return [(n, round(m)) for n, m in out if m >= 1]

    def _against_m(self, verts):
        """Metres driven against one-way roads (a U-turn across to the other carriageway is not a road: not counted)."""
        return sum(dist(self.pos[a], self.pos[b]) for a, b in zip(verts, verts[1:])
                   if (a, b) in self.edge and not self._legal(a, b))

    def _lane_points(self, verts, side):
        """The vertices as points, in the drive-side lane of two-way roads (one-way carriageways: as they are)."""
        if not side or len(verts) < 2:
            return [self.pos[v] for v in verts]
        sgn = 1.0 if side == "left" else -1.0              # (+: to the left of the way it drives)
        lat0 = self.pos[verts[0]][0]
        kx = 111320.0 * math.cos(math.radians(lat0))
        xy = [((self.pos[v][1]) * kx, self.pos[v][0] * 111320.0) for v in verts]
        offs = []
        for a, b in zip(verts, verts[1:]):
            e = self.edge.get((a, b)) or {"ow": 0, "w": 0.0}
            if e["ow"] != 0:
                offs.append(0.0)
            else:
                w = e["w"]
                offs.append(sgn * (min(LANE_MAX_M, max(LANE_MIN_M, w / 4.0)) if w > 0 else LANE_DEFAULT_M))
        out = []
        for i in range(len(xy)):
            # the vertex moved along the mean normal of its two segments (by each one's offset)
            segs = [j for j in (i - 1, i) if 0 <= j < len(offs)]
            nx = ny = 0.0
            for j in segs:
                dx, dy = xy[j + 1][0] - xy[j][0], xy[j + 1][1] - xy[j][1]
                L = math.hypot(dx, dy) or 1.0
                nx += -dy / L * offs[j]
                ny += dx / L * offs[j]
            nx, ny = nx / len(segs), ny / len(segs)
            out.append(((xy[i][1] + ny) / 111320.0, (xy[i][0] + nx) / kx))
        # (a sharp turn / U-turn: a point that would go backwards is dropped)
        res = [out[0]]
        for i in range(1, len(out)):
            if i + 1 < len(out):
                a, b, c = res[-1], out[i], out[i + 1]
                if dist(a, b) < 0.3:
                    continue
            res.append(out[i])
        return res

    def plan(self, stops, back=None, side=None):
        """stops = [(lat, lon) source, via ..., destination]; back: None / "same" / "different"; side: the drive
        side ("left" / "right") or None -> the route."""
        notes = []
        if len(stops) < 2:
            raise ValueError("a source and a destination are needed")
        cands = []
        for i, p in enumerate(stops):
            what = "the source" if i == 0 else "the destination" if i == len(stops) - 1 else f"via point {i}"
            try:
                c = self.candidates(p)
            except ValueError as e:
                raise ValueError(f"{what} is {e}")
            if c[0][1] > 15:
                notes.append(f"{what} moved {c[0][1]:.0f} m onto the road")
            cands.append(c)
        out, prev, legal_all = None, cands[0], True
        for k in range(1, len(cands)):
            p, legal = self._best_leg(prev, cands[k], allow_against=False)
            if p is None:                                 # (no legal way to the nearest roads: every road within
                wide_prev = self.candidates(stops[0], alt=SNAP_MAX_M, n=8) if k == 1 else prev    # SNAP_MAX_M -- the
                wide_goal = self.candidates(stops[k], alt=SNAP_MAX_M, n=8)                        # other carriageway)
                p, legal = self._best_leg(wide_prev, wide_goal, allow_against=False)
                if p is not None:
                    for what, q, v in (("source", stops[0], p[0]), ("destination" if k == len(cands) - 1 else
                                                                    f"via point {k}", stops[k], p[-1])):
                        m = dist(q, self.pos[v])
                        if m > 15:
                            notes.append(f"{what} moved {m:.0f} m to the road driven this way (the carriageway the "
                                         "traffic takes in this direction)")
            if p is None:
                p, legal = self._best_leg(prev, cands[k])
            if p is None:
                raise ValueError("the roads do not connect these points (no way between them on the map's roads)")
            legal_all &= legal
            out = p if out is None else out + p[1:]
            prev = [(p[-1], 0.0)]
        res_back = []
        if back:
            same_rev = out[::-1]
            if back == "same" and self._against_m(same_rev) < 1.0:
                res_back = same_rev                              # (the same roads back, legal both ways)
            else:
                if back == "same":
                    notes.append("one-way roads on the way out: back by the nearest legal way")
                avoid = set(zip(out, out[1:])) if back == "different" else None
                p, legal = self._best_leg([(out[-1], 0.0)], [(out[0], 0.0)], avoid=avoid, allow_against=False)
                if p is None:                                    # (a dead end in the map's roads: turn round onto
                    starts = [(out[-1], 0.0)] + self.candidates(stops[-1], alt=SNAP_MAX_M, n=8)   # the other
                    goals = [(out[0], 0.0)] + self.candidates(stops[0], alt=SNAP_MAX_M, n=8)       # carriageway)
                    p, legal = self._best_leg(starts, goals, avoid=avoid, allow_against=False)
                    if p is not None and p[0] != out[-1]:
                        notes.append(f"turns round at the destination onto the other carriageway "
                                     f"({dist(self.pos[out[-1]], self.pos[p[0]]):.0f} m across: a U-turn -- the "
                                     "map's roads end there)")
                if p is None:
                    p, legal = self._best_leg([(out[-1], 0.0)], [(out[0], 0.0)], avoid=avoid)
                if p is None:
                    raise ValueError("no way back to the source on the map's roads")
                legal_all &= legal
                res_back = p if p[0] == out[-1] else [out[-1]] + p
                if res_back[-1] != out[0]:
                    res_back = res_back + [out[0]]
        full = out + res_back[1:]
        against = self._against_m(full)
        if against >= 1.0:
            notes.append(f"{against:.0f} m against a one-way road: no legal way there on the map's roads (the "
                         "downloaded area cuts that carriageway?) -- check it, or move the point")
        pts = self._lane_points(full, side)
        out_m = sum(dist(self.pos[a], self.pos[b]) for a, b in zip(out, out[1:]))
        back_m = sum(dist(self.pos[a], self.pos[b]) for a, b in zip(res_back, res_back[1:]))
        used = set(zip(out, out[1:])) | set(zip(out[1:], out))
        shared = sum(dist(self.pos[a], self.pos[b]) for a, b in zip(res_back, res_back[1:]) if (a, b) in used) \
            if back == "different" else (back_m if back == "same" else 0.0)
        return {"points": pts, "out_m": out_m, "back_m": back_m, "shared_m": shared, "roads": self._roads(out),
                "back_roads": self._roads(res_back) if res_back else [], "notes": notes, "back": back,
                "against_m": against, "side": side, "n_out": len(out),
                "src": self.pos[out[0]], "dst": self.pos[out[-1]]}


def densify(points, step_m=0.85):
    """Points every step_m along the polyline, each with its heading -> [(lat, lon, heading)]."""
    if len(points) < 2:
        return [(points[0][0], points[0][1], 0.0)] if points else []
    dense = [tuple(points[0])]
    for a, b in zip(points, points[1:]):
        n = max(1, int(dist(a, b) / step_m))
        for i in range(1, n + 1):
            dense.append((a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n))
    out, h = [], 0.0
    for i, p in enumerate(dense):
        if i + 1 < len(dense) and dist(p, dense[i + 1]) > 1e-3:
            h = heading(p, dense[i + 1])
        out.append((p[0], p[1], h))
    return out
