"""Ground height (terrain) around a yard, for the 3D view: hills / slopes instead of a flat plane.

Source: the open "Terrain Tiles" on AWS (Registry of Open Data, free, no key, no account) -- elevation
tiles in the "terrarium" PNG encoding (height = R * 256 + G + B / 256 - 32768 m), made from SRTM,
GMTED, ETOPO and national elevation models (about 30 m detail outside the USA / Europe).
Downloaded once together with the surroundings ("Update 3D", a yard chosen on the map) and kept in
the yard's osm_surroundings.json ("terrain"), so the 3D view works offline afterwards.

download(bbox) -> {"bbox": [[s, w], [n, e]], "nx", "ny", "step_m", "h": [heights in decimetres, row by row
from the north-west corner], "min_m", "max_m", "source", "attribution"}.
"""
import math
import urllib.request
from datetime import datetime

TILE_URL = "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"
ATTRIBUTION = ("Terrain: Mapzen Terrain Tiles on AWS Open Data (SRTM, GMTED2010, ETOPO1 and others; "
               "SRTM courtesy of NASA / USGS)")
MARGIN_M = 300                    # beyond the surroundings: the 3D view's ground reaches further than the OSM data
STEP_M = 10.0                     # grid spacing (the source has ~30 m detail: 10 m is smooth enough)
MAX_TILES = 64                    # a very large area: a coarser zoom level instead
MAX_POINTS = 160000               # (~400 x 400)


def _tile_xy(lat, lon, z):
    n = 2 ** z
    x = (lon + 180.0) / 360.0 * n
    y = (1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n
    return x, y


def _fetch_tile(z, x, y, timeout=25):
    from PyQt5.QtGui import QImage
    req = urllib.request.Request(TILE_URL.format(z=z, x=x, y=y), headers={"User-Agent": "yard-simulation/1.0"})
    data = urllib.request.urlopen(req, timeout=timeout).read()
    img = QImage.fromData(data)
    if img.isNull() or img.width() != 256:
        raise RuntimeError(f"terrain tile {z}/{x}/{y}: not a PNG tile")
    img = img.convertToFormat(QImage.Format_RGB32)
    ptr = img.constBits(); ptr.setsize(img.byteCount())
    raw = bytes(ptr)                               # BGRA per pixel (little endian RGB32)
    out = [0.0] * (256 * 256)
    bpl = img.bytesPerLine()
    for py in range(256):
        row = py * bpl
        for px in range(256):
            o = row + px * 4
            out[py * 256 + px] = raw[o + 2] * 256.0 + raw[o + 1] + raw[o] / 256.0 - 32768.0
    return out


def _blur(h, nx, ny, passes=2):
    """3 x 3 box blur: smooths the source's 1 m steps and the bumps of single buildings / tree tops."""
    for _ in range(passes):
        out = [0.0] * len(h)
        for j in range(ny):
            j0, j1 = max(0, j - 1), min(ny - 1, j + 1)
            for i in range(nx):
                i0, i1 = max(0, i - 1), min(nx - 1, i + 1)
                s = 0.0; c = 0
                for jj in range(j0, j1 + 1):
                    b = jj * nx
                    for ii in range(i0, i1 + 1):
                        s += h[b + ii]; c += 1
                out[j * nx + i] = s / c
        h = out
    return h


def download(bbox, progress=None, margin_m=MARGIN_M, step_m=STEP_M):
    """bbox = [[south, west], [north, east]] (the surroundings' box). Raises on network errors."""
    (s, w), (n, e) = bbox
    k = 111320.0 * max(0.2, math.cos(math.radians((s + n) / 2)))
    s, n = s - margin_m / 111320.0, n + margin_m / 111320.0
    w, e = w - margin_m / k, e + margin_m / k
    width_m, height_m = (e - w) * k, (n - s) * 111320.0
    step = max(step_m, math.sqrt(width_m * height_m / MAX_POINTS))
    nx, ny = max(2, int(round(width_m / step)) + 1), max(2, int(round(height_m / step)) + 1)
    z = 15
    while z > 8:
        x0, y0 = _tile_xy(n, w, z); x1, y1 = _tile_xy(s, e, z)
        if (int(x1) - int(x0) + 1) * (int(y1) - int(y0) + 1) <= MAX_TILES:
            break
        z -= 1
    x0, y0 = _tile_xy(n, w, z); x1, y1 = _tile_xy(s, e, z)
    tiles = {}
    want = [(tx, ty) for ty in range(int(y0), int(y1) + 1) for tx in range(int(x0), int(x1) + 1)]
    for i, (tx, ty) in enumerate(want):
        if progress:
            progress(f"Downloading the ground height ... tile {i + 1} of {len(want)}")
        tiles[(tx, ty)] = _fetch_tile(z, tx, ty)

    def px(gx, gy):                                # one source pixel (clamped to the downloaded tiles)
        gx = min(max(gx, int(x0) * 256), (int(x1) + 1) * 256 - 1)
        gy = min(max(gy, int(y0) * 256), (int(y1) + 1) * 256 - 1)
        return tiles[(gx >> 8, gy >> 8)][(gy & 255) * 256 + (gx & 255)]

    h = []
    for j in range(ny):
        lat = n - (n - s) * j / (ny - 1)
        for i in range(nx):
            lon = w + (e - w) * i / (nx - 1)
            fx, fy = _tile_xy(lat, lon, z)
            fx, fy = fx * 256 - 0.5, fy * 256 - 0.5          # pixel centres
            ix, iy = int(math.floor(fx)), int(math.floor(fy))
            tx, ty = fx - ix, fy - iy
            a = px(ix, iy) * (1 - tx) + px(ix + 1, iy) * tx
            b = px(ix, iy + 1) * (1 - tx) + px(ix + 1, iy + 1) * tx
            h.append(a * (1 - ty) + b * ty)
    h = _blur(h, nx, ny)
    return {"bbox": [[s, w], [n, e]], "nx": nx, "ny": ny, "step_m": round(step, 2),
            "h": [int(round(v * 10)) for v in h], "min_m": round(min(h), 1), "max_m": round(max(h), 1),
            "zoom": z, "fetched_at": datetime.now().isoformat(timespec="seconds"),
            "source": "AWS Terrain Tiles (terrarium)", "attribution": ATTRIBUTION}


def summary(t):
    if not t:
        return "flat (no ground height)"
    return f"ground height {t.get('min_m')} .. {t.get('max_m')} m ({round(t['max_m'] - t['min_m'])} m difference)"
