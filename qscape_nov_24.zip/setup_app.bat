@echo off
rem Q-SCAPE -- one-time set-up on Windows (no Git Bash needed): .venv in this folder + its packages.
rem Same as setup_app.sh. Company network that inspects HTTPS: set PIP_CERT=C:\path\company_root.pem first.
cd /d "%~dp0"
set PYTHONNOUSERSITE=1
set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" (echo ERROR: Python 3.8 - 3.12 not found ^(python.org^). & pause & exit /b 1)
echo == 1/3  Python ==
%PY% -c "import sys; print(' ', sys.executable, sys.version.split()[0]); sys.exit(0 if (3, 8) <= sys.version_info[:2] <= (3, 12) else 1)" || (echo ERROR: needs Python 3.8 - 3.12 & pause & exit /b 1)
echo == 2/3  .venv and packages ==
if exist .venv rmdir /s /q .venv
%PY% -m venv .venv || (echo ERROR: could not create .venv & pause & exit /b 1)
.venv\Scripts\python.exe -m pip install --upgrade pip >nul 2>nul
.venv\Scripts\python.exe -m pip install --prefer-binary -r requirements.txt || (echo ERROR: pip could not install requirements.txt ^(internet / proxy? PIP_CERT^) & pause & exit /b 1)
echo == 3/3  check ==
.venv\Scripts\python.exe -c "import PyQt5.QtWebEngineWidgets, PyQt5.QtWebChannel, folium, qtawesome, numpy, pandas, paho.mqtt.client; print('  ok  all packages')" || (echo ERROR: a package is missing & pause & exit /b 1)
echo.
echo Ready. Start Q-SCAPE with run_app.bat (or: bash run_app.sh in Git Bash).
pause
