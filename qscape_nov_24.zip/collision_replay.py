"""Collision test replay: a saved collision test played back exactly as it was shown -- nothing is detected again.

Recording (a test started with "Save this test for replay?" Yes): MapWindow feeds a Recorder with
  * the positions of every vehicle (the 2D map / 3D view payload: objects, planned routes, collisions / near misses),
  * the collision-test window's view (status, cards, counters, progress, log) ~3 times a second,
  * each truck's detection details (sensor tiles, TTC, bird's-eye view, objects table, V2V messages),
  * the camera images of the truck whose details were open (with their detection boxes and distance working).
When the test ends it is saved as replay.json.gz in the test's report folder (Reports -> Collision tests).

Playing (Reports -> a collision test -> Replay): ReplayPlayer opens the same collision-test window (cards, detection
details, camera, log), puts the recorded vehicles on the 2D map (the live ones dimmed) and in the 3D view, and adds a
replay bar: play / pause, speed 0.25x .. 8x, a timeline to seek, previous / next collision (or near miss).
"""
import base64
import bisect
import copy
import gzip
import json
import os
import time
from collections import deque

from PyQt5.QtCore import Qt, QTimer, QObject
from PyQt5.QtWidgets import (QWidget, QHBoxLayout, QLabel, QPushButton, QComboBox, QSlider, QToolButton)

REPLAY_FILE = "replay.json.gz"
MAX_FRAMES = 40000                   # positions kept (~3 h at 4 Hz)
MAX_WIN = 40000                      # window views kept (~3.5 h at 3 Hz)
DETAILS_EVERY_S = 0.6                # the AVs whose details are closed: their details this often
CAMERA_EVERY_S = 0.9                 # camera images kept at most this often (per AV)


def jsonable(x):
    """sets -> sorted lists, tuples -> lists, anything else unknown -> str (json-safe)."""
    if isinstance(x, dict):
        return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, deque)):
        return [jsonable(v) for v in x]
    if isinstance(x, (set, frozenset)):
        return sorted((jsonable(v) for v in x), key=str)
    if x is None or isinstance(x, (bool, int, str)):
        return x
    if isinstance(x, float):
        return x if x == x and abs(x) != float("inf") else None
    try:
        return float(x)                                   # (numpy numbers)
    except (TypeError, ValueError):
        return str(x)


class Recorder:
    """A running collision test's recording (see the module text)."""

    def __init__(self):
        self.frames = deque(maxlen=MAX_FRAMES)
        self.win = deque(maxlen=MAX_WIN)
        self.det = deque(maxlen=MAX_WIN * 2)
        self.cams = []
        self._det_last = {}
        self._cam_last = {}

    # positions (the 2D map / 3D view payload of _send_yard3d_dynamic)
    def add_positions(self, payload):
        fr = self.frames
        if fr and payload["t"] - fr[-1]["t"] < 0.2 and not payload.get("events"):
            return
        fr.append(jsonable(payload))

    def need_details(self, now, members, picked):
        """The AVs whose detection details are recorded now (the open one each time, the others now and then)."""
        return [m for m in members if m == picked or now - self._det_last.get(str(m), 0.0) >= DETAILS_EVERY_S]

    # the window's view (_ctest_update) + details {AV id: details dict}
    def add_window(self, now, d, details):
        v = {k: val for k, val in d.items() if k not in ("log", "details", "f2d", "f3d", "picked")}
        v["log_n"] = len(d.get("log") or [])
        self.win.append({"t": round(now, 3), "d": jsonable(v)})
        for m, dd in (details or {}).items():
            if dd is not None:
                self.det.append({"t": round(now, 3), "id": str(m), "d": jsonable(dd)})
                self._det_last[str(m)] = now

    def add_camera(self, now, fid, jpeg_b64, overlay, calc):
        if not jpeg_b64 or now - self._cam_last.get(str(fid), 0.0) < CAMERA_EVERY_S:
            return
        self._cam_last[str(fid)] = now
        self.cams.append({"t": round(now, 3), "id": str(fid), "jpeg": jpeg_b64,
                          "overlay": jsonable(overlay), "calc": jsonable(calc)})

    def usable(self):
        return len(self.frames) >= 4 or len(self.win) >= 4

    def save(self, path, meta, log, route_line, dims):
        rec = {"version": 2, "meta": jsonable(meta), "route_line": jsonable(route_line), "dims": jsonable(dims),
               "log": jsonable(log), "frames": list(self.frames), "win": list(self.win), "det": list(self.det),
               "cams": self.cams}
        tmp = path + ".tmp"
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            json.dump(rec, f, separators=(",", ":"))
        os.replace(tmp, path)
        return path


def load(path):
    """A saved replay; the window's sets back as sets."""
    with gzip.open(path, "rt", encoding="utf-8") as f:
        rec = json.load(f)
    for w in rec.get("win") or []:
        for cd in ((w.get("d") or {}).get("cards") or {}).values():
            if isinstance(cd.get("sensors"), list):
                cd["sensors"] = set(cd["sensors"])
    for e in rec.get("det") or []:
        if isinstance((e.get("d") or {}).get("sensors_on"), list):
            e["d"]["sensors_on"] = set(e["d"]["sensors_on"])
    return rec


def has_replay(report_dir):
    return bool(report_dir) and os.path.exists(os.path.join(report_dir, REPLAY_FILE))


# ---- the 2D map (Leaflet): the recorded vehicles in a pane of their own, the live markers dimmed ----
REPLAY2D_JS = r"""
(function () {
  if (window.rp2d) return;
  var M = null, g = null, veh = {}, plans = [], evs = {}, route = null, dims = {}, EV = [], centred = false;
  function css() {
    if (document.getElementById('rp2dCss')) return;
    var s = document.createElement('style'); s.id = 'rp2dCss';
    s.textContent = '.rp2d-on .leaflet-marker-pane, .rp2d-on .leaflet-shadow-pane { opacity: .15; }' +
      '.rp2d-lbl { background: rgba(17,24,39,.88); color: #fde68a; border: 1px solid #f59e0b; border-radius: 6px;' +
      ' padding: 1px 6px; font: 600 11px Segoe UI, Arial; box-shadow: none; }' +
      '.rp2d-lbl:before { display: none; } .rp2d-ev { font: 600 11px Segoe UI, Arial; }';
    document.head.appendChild(s);
  }
  function ensure() {
    M = window.__rpMap; if (!M) return false;
    if (!M.getPane('rp2dPane')) { var p = M.createPane('rp2dPane'); p.style.zIndex = 645; }
    if (!g) g = L.layerGroup().addTo(M);
    return true;
  }
  function corners(lat, lng, h, Ln, W) {
    var r = h * Math.PI / 180, fx = Math.sin(r), fy = Math.cos(r), k = 111320, kc = k * Math.cos(lat * Math.PI / 180);
    return [[Ln / 2, W / 2], [Ln / 2, -W / 2], [-Ln / 2, -W / 2], [-Ln / 2, W / 2]].map(function (p) {
      var e = fx * p[0] + fy * p[1], n = fy * p[0] - fx * p[1]; return [lat + n / k, lng + e / kc]; });
  }
  function sizeOf(o) {
    if (o.size && o.size.l) return [o.size.l, o.size.w || 2];
    var d = dims[o.kind]; if (d) return d;
    if (o.cat === 'object') return ({ pedestrian: [0.7, 0.7], bus: [12, 2.55], van: [5.2, 2.0], outer_truck: [8, 2.5],
                                      truck_trailer: [16.5, 2.6] })[o.type] || [4.5, 1.8];
    if ((o.kind || '').indexOf('trailer') === 0) return [16.2, 2.6];
    return [5, 2.5];
  }
  function colOf(o) {
    if (o.cat === 'route' || o.cat === 'truck') return o.lidar ? '#f59e0b' : '#a3e635';
    if (o.cat === 'trailer') return '#60a5fa';
    return o.type === 'pedestrian' ? '#f472b6' : '#e5e7eb';
  }
  window.rp2d = {
    init: function (routeLine, dimsIn, events) {
      if (!ensure()) return false;
      if (g) g.clearLayers();
      veh = {}; plans = []; evs = {}; centred = false;
      css(); dims = dimsIn || {}; EV = events || [];
      M.getContainer().classList.add('rp2d-on');
      if (routeLine && routeLine.length > 1) {
        route = L.polyline(routeLine, { pane: 'rp2dPane', color: '#a855f7', weight: 5, opacity: 0.45, dashArray: '8 8' }).addTo(g);
      }
      return true;
    },
    show: function (objs, pl, t, followId) {
      if (!ensure()) return;
      var seen = {};
      (objs || []).forEach(function (o) {
        var key = o.cat + ':' + o.id, sz = sizeOf(o), c = corners(o.lat, o.lng, o.h || 0, sz[0], sz[1]), v = veh[key];
        seen[key] = true;
        if (!v) {                                               // its real outline + a dot (seen at any zoom) with the name
          var col = colOf(o), main = o.cat === 'route' || o.cat === 'truck' || (o.cat === 'object' && o.lidar);
          v = veh[key] = {
            poly: L.polygon(c, { pane: 'rp2dPane', color: '#111827', weight: 1, fillColor: col, fillOpacity: 0.92 }).addTo(g),
            dot: L.circleMarker([o.lat, o.lng], { pane: 'rp2dPane', radius: main ? 6 : 4, color: '#111827', weight: 1.5,
                                                  fillColor: col, fillOpacity: 1 }).addTo(g) };
          if (main) v.dot.bindTooltip(String(o.label || o.id), { permanent: true, direction: 'top', className: 'rp2d-lbl', offset: [0, -6] });
          else v.dot.bindTooltip(String(o.label || o.id));
        } else { v.poly.setLatLngs(c); v.dot.setLatLng([o.lat, o.lng]); }
        if (followId != null && String(o.id) === String(followId)) M.panTo([o.lat, o.lng], { animate: false });
      });
      Object.keys(veh).forEach(function (k) { if (!seen[k]) { g.removeLayer(veh[k].poly); g.removeLayer(veh[k].dot); delete veh[k]; } });
      var tr = (objs || []).filter(function (o) { return o.cat === 'route'; });
      if (tr.length && followId == null) {                      // the test's trucks: close at first, then kept in view
        var la = tr.reduce(function (s, o) { return s + o.lat; }, 0) / tr.length,
            ln = tr.reduce(function (s, o) { return s + o.lng; }, 0) / tr.length;
        if (!centred) { centred = true; M.setView([la, ln], Math.max(M.getZoom(), 18), { animate: false }); }
        else if (!M.getBounds().pad(-0.2).contains([la, ln])) M.panTo([la, ln], { animate: true, duration: 0.4 });
      }
      plans.forEach(function (p) { g.removeLayer(p); }); plans = [];
      Object.keys(pl || {}).forEach(function (id) {
        var P = pl[id]; if (!P || P.length < 2) return;
        var top = Math.max(15, P.reduce(function (m, p) { return Math.max(m, p[2]); }, 0));
        var cOf = function (k) { var f = k / top; return f < 0.15 ? '#ef4444' : f < 0.6 ? '#f59e0b' : '#22c55e'; };
        var seg = [[P[0][0], P[0][1]]], col = cOf(P[0][2]);
        for (var i = 1; i < P.length; i++) {
          seg.push([P[i][0], P[i][1]]); var c2 = cOf(P[i][2]);
          if (c2 !== col || i === P.length - 1) {
            plans.push(L.polyline(seg, { pane: 'rp2dPane', color: col, weight: 4, opacity: 0.85 }).addTo(g));
            seg = [[P[i][0], P[i][1]]]; col = c2;
          }
        }
      });
      EV.forEach(function (e, i) {                              // collisions / near misses up to this moment
        var on = e.t <= t + 0.05, m = evs[i];
        if (on && !m) {
          m = evs[i] = L.circleMarker([e.lat, e.lng], { pane: 'rp2dPane', radius: 10, weight: 3,
            color: e.kind === 'collision' ? '#ef4444' : e.kind === 'v2v_save' ? '#10b981' : '#f59e0b',
            fillOpacity: 0.25 }).addTo(g);
          m.bindTooltip(e.text, { className: 'rp2d-ev' });
        } else if (!on && m) { g.removeLayer(m); delete evs[i]; }
      });
    },
    clear: function () {
      if (g) g.clearLayers();
      veh = {}; plans = []; evs = {}; route = null; EV = []; centred = false;
      if (M) M.getContainer().classList.remove('rp2d-on');
    }
  };
})();
"""


def _mmss(s):
    s = max(0, int(round(s)))
    return f"{s // 60}:{s % 60:02d}"


class ReplayPlayer(QObject):
    """A saved collision test played in the collision-test window + the 2D map + the 3D view (see the module text).
    mw: the MapWindow; rec: load(); rep: the test's report (report.json, "dir" set)."""

    SPEEDS = (0.25, 0.5, 1.0, 2.0, 4.0, 8.0)

    def __init__(self, mw, rec, rep):
        super().__init__(mw)
        import collision_panel
        self.mw, self.rec, self.rep = mw, rec, rep
        meta = rec.get("meta") or {}
        self.frames = rec.get("frames") or []
        self.win = rec.get("win") or []
        self.log = [tuple(x) for x in (rec.get("log") or [])]
        self.events = sorted([e for f in self.frames for e in (f.get("events") or [])], key=lambda e: e["t"])
        self.f_t = [f["t"] for f in self.frames]
        self.w_t = [w["t"] for w in self.win]
        self.det = {}
        for e in rec.get("det") or []:
            self.det.setdefault(e["id"], []).append(e)
        self.det_t = {k: [e["t"] for e in v] for k, v in self.det.items()}
        self.cams = {}
        for c in rec.get("cams") or []:
            self.cams.setdefault(c["id"], []).append(c)
        self.cam_t = {k: [c["t"] for c in v] for k, v in self.cams.items()}
        ts = self.f_t + self.w_t
        self.t0, self.t1 = (min(ts), max(ts)) if ts else (0.0, 1.0)
        # the climate of each moment (recorded per frame; an older replay: the test's first climate) -- applied while
        # it plays, the app's own climate back when it closes
        self.climate_before = (getattr(mw, "climate", None) or {}).get("id")
        cur = meta.get("climate0") or self._climate_id(meta.get("climates") or rep.get("climates") or [])
        self.f_clim = []
        for f in self.frames:
            cur = f.get("climate") or cur
            self.f_clim.append(cur)
        self._clim = None
        self.t, self.playing, self.speed = 0.0, True, 1.0
        self.picked, self.f2d, self.f3d = None, None, None
        self._wi, self._fi, self._ck, self._pk, self._3d = -2, -2, None, None, False
        self._last = time.time()
        trucks = [tuple(x) for x in (meta.get("trucks") or [])]
        self.ids = {str(x[0]): x[0] for x in trucks}
        title = f"Collision test REPLAY -- {meta.get('route') or rep.get('route') or ''}"
        self.title = title
        cb = {
            "camera": lambda i: None, "shown": lambda s: None, "speed": lambda vid, kmh: None,
            "stopgo": lambda vid: None, "stopgo_off": lambda vid: None, "sensor": lambda vid, n, on: None,
            "follow2d": self._follow2d, "follow3d": self._follow3d, "details": self._pick,
            "cont": self._after_hold, "pause": self.toggle, "skip": lambda: self.jump(1),
            "restart": lambda: (self.seek(0.0), self._play(True)), "end": self.close,
            "minimize": lambda: mw.minimize_to_tray(self.w, title),
            "collisions": self._collisions, "v2v_saves": self._v2v_saves,
            "results": lambda: mw.show_collision_report(dict(self.rep)),
            "dock": lambda: self._dock(None),
            "dock_height": lambda h: mw._panel_dock_height(self.w, h),
        }
        self._store = {}                                   # (its floating geometry while fitted to the main panel)
        self.w = w = collision_panel.CollisionTestWindow(mw, title, trucks, route=meta.get("route") or "", callbacks=cb)
        w.setAttribute(Qt.WA_DeleteOnClose, True)
        w.finished.connect(lambda *_a: self.close())
        w.details.set_cameras(meta.get("cams") or ["camera"], 0)
        for c in w.cards.values():                         # (a replay: the AVs' controls only show what was set)
            for b in [c.spin, c.sg, c.off] + list(c.sw.values()):
                b.setEnabled(False)
        for b in (w.mqtt_btn, w.mqtt_cfg):
            b.setVisible(False)
        w._ftext[w.skip_btn] = ("⏭ Next collision", "⏭")
        w._ftext[w.restart_btn] = ("↻ From the start", "↻")
        w._ftext[w.end_btn] = ("■ Close replay", "■")
        w.skip_btn.setToolTip("Jump to 4 s before the next collision / near miss")
        w.restart_btn.setToolTip("Play the test again from its start")
        w.end_btn.setToolTip("Close the replay (the map and the 3D view show the live yard again)")
        w.pause_btn.setToolTip("Play / pause the replay (Space)")
        w.cont.setText("Skip the hold ▶")
        w.cont.setToolTip("Jump to where the AVs drive on after the collision hold")
        w.layout().insertWidget(1, self._bar())
        mw.make_minimizable(w, title)
        if getattr(mw, "_ctest_docked_pref", False):      # (like the live test: fitted to the main panel last time)
            self._dock(True)
        else:
            w.show()
            w._fit(False)
        # the 2D map
        self._js2d(REPLAY2D_JS + f"window.rp2d.init({json.dumps(rec.get('route_line') or [])}, "
                                 f"{json.dumps(rec.get('dims') or {})}, {json.dumps(self.events)});")
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(100)
        self._apply(force=True)

    # ---- the replay bar (above the progress row) ----
    def _bar(self):
        bar = QWidget()
        bar.setObjectName("rpBar")
        bar.setStyleSheet("QWidget#rpBar { background: #1C1917; border: 1px solid #F59E0B; border-radius: 8px; }"
                          "QPushButton, QToolButton, QComboBox { padding: 3px 9px; }")
        h = QHBoxLayout(bar)
        h.setContentsMargins(8, 5, 8, 5)
        h.setSpacing(6)
        badge = QLabel("REPLAY")
        badge.setStyleSheet("background: #F59E0B; color: #111827; font-weight: 800; border-radius: 5px; "
                            "padding: 2px 8px;")
        badge.setToolTip("A saved collision test played back as it was recorded -- nothing is detected again")
        h.addWidget(badge)
        meta = self.rec.get("meta") or {}
        info = QLabel(f"{meta.get('started') or ''}")
        info.setStyleSheet("color: #FDE68A;")
        h.addWidget(info)
        self.prev_b = QToolButton(); self.prev_b.setText("|◀"); self.prev_b.setToolTip("Previous collision / near miss")
        self.prev_b.clicked.connect(lambda: self.jump(-1)); h.addWidget(self.prev_b)
        self.play_b = QPushButton("⏸"); self.play_b.setToolTip("Play / pause (Space)"); self.play_b.setFixedWidth(44)
        self.play_b.clicked.connect(self.toggle); h.addWidget(self.play_b)
        self.next_b = QToolButton(); self.next_b.setText("▶|"); self.next_b.setToolTip("Next collision / near miss")
        self.next_b.clicked.connect(lambda: self.jump(1)); h.addWidget(self.next_b)
        self.speed_c = QComboBox()
        for s in self.SPEEDS:
            self.speed_c.addItem(f"{s:g}x", s)
        self.speed_c.setCurrentIndex(self.SPEEDS.index(1.0))
        self.speed_c.setToolTip("Replay speed")
        self.speed_c.currentIndexChanged.connect(lambda i: setattr(self, "speed", float(self.speed_c.itemData(i))))
        h.addWidget(self.speed_c)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, max(1, int((self.t1 - self.t0) * 10)))
        self.slider.setToolTip("Drag to any moment of the test")
        self.slider.sliderMoved.connect(lambda v: self.seek(v / 10.0))
        self.slider.sliderPressed.connect(lambda: self._play(False))
        h.addWidget(self.slider, 1)
        self.time_l = QLabel("0:00 / " + _mmss(self.t1 - self.t0))
        self.time_l.setStyleSheet("color: #E5E7EB; font-family: Consolas, monospace;")
        h.addWidget(self.time_l)
        nc = sum(1 for e in self.events if e.get("kind") == "collision")
        nv = sum(1 for e in self.events if e.get("kind") == "v2v_save")         # (collisions prevented by V2V)
        nn = len(self.events) - nc - nv
        ev = QLabel(f"<span style='color:#F87171'>● {nc} collision{'s' if nc != 1 else ''}</span>  "
                    f"<span style='color:#FBBF24'>● {nn} near miss{'es' if nn != 1 else ''}</span>"
                    + (f"  <span style='color:#34D399'>● {nv} prevented by V2V</span>" if nv else ""))
        ev.setToolTip("\n".join(f"{_mmss(e['t'] - self.t0)}  {e.get('text', '')}" for e in self.events) or
                      "No collision / near miss in this test")
        h.addWidget(ev)
        self.prev_b.setEnabled(bool(self.events)); self.next_b.setEnabled(bool(self.events))
        self.w.keyPressEvent = self._key
        return bar

    def _key(self, ev):
        if ev.key() == Qt.Key_Space:
            self.toggle()
        elif ev.key() == Qt.Key_PageDown:
            self.jump(1)
        elif ev.key() == Qt.Key_PageUp:
            self.jump(-1)
        elif ev.key() == Qt.Key_Escape:
            self.close()

    # ---- control ----
    def _play(self, on):
        self.playing = bool(on)
        if self.playing and self.t >= self.t1 - self.t0 - 0.05:
            self.t = 0.0
        self._last = time.time()
        self.play_b.setText("⏸" if self.playing else "▶")
        self._apply(force=True)

    def _dock(self, on):
        """'Fit to main panel' (as in the live test): the replay window at the bottom of the main window."""
        try:
            self.mw._panel_dock(self.w, self._store, on)
        except RuntimeError:
            pass

    def toggle(self):
        self._play(not self.playing)

    def seek(self, t):
        self.t = max(0.0, min(self.t1 - self.t0, float(t)))
        self._apply()

    def jump(self, direction):
        """4 s before the next / previous collision or near miss (paused there)."""
        now = self.t0 + self.t
        if direction > 0:
            ev = next((e for e in self.events if e["t"] - 4.0 > now + 0.5), None)
        else:
            ev = next((e for e in reversed(self.events) if e["t"] - 4.0 < now - 0.5), None)
        if ev is None:
            return
        self._play(False)
        self.seek(ev["t"] - 4.0 - self.t0)
        self._js3d(f"window.yard3dFocus && window.yard3dFocus({ev['lat']}, {ev['lng']}, 70, 38);")

    def _after_hold(self):
        """'Skip the hold': the first moment after now where no AV is held any more."""
        i = bisect.bisect_right(self.w_t, self.t0 + self.t)
        for k in range(i, len(self.win)):
            if not (self.win[k].get("d") or {}).get("held"):
                self.seek(self.win[k]["t"] - self.t0)
                return

    def _pick(self, vid):
        if vid is not None and str(vid) == str(self.picked):
            vid = None
        self.picked = self.ids.get(str(vid)) if vid is not None else None
        w = self.w
        name = next((c.findChild(QLabel, "tname").text() for k, c in w.cards.items() if str(k) == str(self.picked)), None)
        w.details.set_av(name if self.picked is not None else None)
        w.details.set_camera(None, None, None)
        self._ck = None
        self._apply(force=True)

    def _follow2d(self, vid):
        self.f2d = None if str(self.f2d) == str(vid) else self.ids.get(str(vid), vid)
        self._apply(force=True)

    def _follow3d(self, vid):
        self.f3d = None if str(self.f3d) == str(vid) else self.ids.get(str(vid), vid)
        self._js3d(f"window.yard3dFollow && window.yard3dFollow({json.dumps(str(self.f3d))});" if self.f3d is not None
                   else "window.yard3dUnfollow && window.yard3dUnfollow();")
        self._apply(force=True)

    def _abs_records(self, recs):
        d = self.rep.get("dir") or ""
        out = []
        for r in recs or []:
            r = copy.deepcopy(r)
            for it in ([r.get("camera")] if r.get("camera") else []) + list(r.get("scene") or []):
                if isinstance(it, dict) and it.get("file") and not os.path.isabs(it["file"]):
                    it["file"] = os.path.join(d, it["file"])
            out.append(r)
        return out

    def _collisions(self):
        self.mw.open_collision_history(self._abs_records(self.rep.get("collisions")),
                                       f"Collisions -- {self.rep.get('route', '')} (replay)")

    def _v2v_saves(self):
        self.mw.open_v2v_saves(self.rep.get("v2v_saves") or [],
                               f"Collisions prevented by V2V -- {self.rep.get('route', '')} (replay)")

    @staticmethod
    def _climate_id(labels):
        """The climate id of the first of the report's climate labels (older replays recorded only those)."""
        try:
            import site_config as cfg
            first = labels[0] if labels else None
            return next((c["id"] for c in cfg.CLIMATES if first in (c.get("label"), c.get("id"))), None)
        except Exception:
            return None

    def _show_climate(self, cid):
        """The test's climate at this moment: the app's (map, 3D view, combo box) -- while a live collision test runs,
        only the 3D view's (the live test keeps its own)."""
        if not cid or cid == self._clim:
            return
        self._clim = cid
        mw = self.mw
        if getattr(mw, "collision_tests", None):
            import site_config as cfg
            c = next((c for c in cfg.CLIMATES if c["id"] == cid), None)
            if c is not None:
                self._js3d(f"window.setClimate && window.setClimate({json.dumps(c)});")
        elif hasattr(mw, "set_climate"):
            mw.set_climate(cid)

    def _restore_climate(self):
        """The app's own climate back (the replay finished or closed). Played again / sought back: the test's
        climate is shown again (_clim cleared)."""
        try:
            mw = self.mw
            if self._clim and self.climate_before:
                if getattr(mw, "collision_tests", None):
                    self._js3d(f"window.setClimate && window.setClimate({json.dumps(mw.climate)});")
                elif self.climate_before != self._clim:
                    mw.set_climate(self.climate_before)
            self._clim = None
        except Exception:
            pass

    # ---- the pages ----
    def _js2d(self, js):
        mw = self.mw
        if getattr(mw, "map_var_name", None):
            mw.browser.page().runJavaScript(f"window.__rpMap = {mw.map_var_name};" + js)

    def _js3d(self, js):
        v = getattr(self.mw, "yard3d_view", None)
        if v is not None and getattr(self.mw, "_yard3d_loaded", False):
            v.page().runJavaScript(js)

    def _tick(self):
        now = time.time()
        dt, self._last = now - self._last, now
        if self.playing:
            self.t += min(0.5, dt) * self.speed
            if self.t >= self.t1 - self.t0:
                self.t = self.t1 - self.t0
                self._play(False)
                self._restore_climate()                    # (finished: the app's own climate back)
                return
        self._apply()

    def _apply(self, force=False):
        T = self.t0 + self.t
        w = self.w
        # the window (its view of that moment, the open AV's details)
        wi = bisect.bisect_right(self.w_t, T) - 1
        if wi >= 0 and (force or wi != self._wi):
            self._wi = wi
            d = dict(self.win[wi]["d"])
            d["log"] = self.log[:int(d.pop("log_n", 0) or 0)]
            d["cards"] = {self.ids.get(k, k): v for k, v in (d.get("cards") or {}).items()}
            d["picked"], d["f2d"], d["f3d"] = self.picked, self.f2d, self.f3d
            d["paused"], d["can_skip"], d["pub"], d["pub_on"] = not self.playing, bool(self.events), None, False
            d["finished"] = False
            d["details"] = self._details_at(T)
            if d.get("held"):
                d["note"] = "Held after a collision (replay): look at the cards and the detection details -- " \
                            "'Skip the hold' jumps to where they drive on"
            w.update_view(d)
        # the open AV's camera image of that moment
        if self.picked is not None:
            c = self._camera_at(T)
            key = (c or {}).get("t")
            if key != self._ck or self._pk != self.picked:
                self._ck, self._pk = key, self.picked
                if c is None:
                    w.details.set_camera(None, {"banner": "camera: no image recorded for this AV at this moment "
                                                          "(images are kept of the AV whose details were open)"}, None)
                else:
                    pix = w.camera_pixmap(base64.b64decode(c["jpeg"]))
                    w.details.set_camera(pix, c.get("overlay"), c.get("calc"))
        # the 2D map + the 3D view
        fi = bisect.bisect_right(self.f_t, T) - 1
        if fi >= 0 and (force or fi != self._fi):
            self._fi = fi
            f = self.frames[fi]
            self._show_climate(self.f_clim[fi])
            self._js2d(f"window.rp2d && window.rp2d.show({json.dumps(f.get('objects') or [])}, "
                       f"{json.dumps(f.get('plans') or {})}, {T}, {json.dumps(None if self.f2d is None else str(self.f2d))});")
            v = getattr(self.mw, "yard3d_view", None)
            if v is not None and v.isVisible() and getattr(self.mw, "_yard3d_loaded", False):
                if not self._3d:
                    self._3d = True
                    v.page().runJavaScript("window.loadReplay && window.loadReplay(" + json.dumps(
                        {"meta": self.rec.get("meta") or {}, "frames": self.frames}, separators=(",", ":"))
                        + ", {external: true});")
                v.page().runJavaScript(f"window.replayAt && window.replayAt({T});")
        # the bar
        if not self.slider.isSliderDown():
            self.slider.blockSignals(True)
            self.slider.setValue(int(self.t * 10))
            self.slider.blockSignals(False)
        self.time_l.setText(f"{_mmss(self.t)} / {_mmss(self.t1 - self.t0)}")

    def _details_at(self, T):
        if self.picked is None:
            return None
        k = str(self.picked)
        i = bisect.bisect_right(self.det_t.get(k, []), T) - 1
        return self.det[k][i]["d"] if i >= 0 else None

    def _camera_at(self, T):
        k = str(self.picked)
        i = bisect.bisect_right(self.cam_t.get(k, []), T) - 1
        if i < 0 or T - self.cams[k][i]["t"] > 6.0:
            return None
        return self.cams[k][i]

    def close(self):
        if getattr(self, "_closed", False):
            return
        self._closed = True
        self.timer.stop()
        self._js2d("window.rp2d && window.rp2d.clear();")
        self._js3d("window.replayClose && window.replayClose();")
        self._restore_climate()
        try:
            w = self.w
            docked = getattr(w, "docked", False)
            if w.isVisible():
                w.close()
            if docked:                                     # (fitted to the main panel: out of it, the map gets the room)
                w.hide()
                w.setParent(None)
                w.deleteLater()
        except RuntimeError:
            pass
        if getattr(self.mw, "_replay_player", None) is self:
            self.mw._replay_player = None
