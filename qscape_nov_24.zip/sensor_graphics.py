"""Simple pictures of the sensors for people who are not engineers.

draw_icon(p, key, rect, colour): a small icon of camera / LiDAR / radar / V2V (the collision test cards' status
strip and the diagrams). Diagram(kind): a picture per topic of the "how it works" window -- a top view of the road
with the truck, what each sensor does and what it gives (camera field of view + range in fog, LiDAR rays and
points, radar waves + echo + speed, V2V messages through fog, fusion, TTC scale, the climate's effect ...).
The diagrams are schematic (not to scale); their numbers come from the models where it matters (climate chart).
"""
import math

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from PyQt5.QtWidgets import QSizePolicy, QWidget

try:                                                   # (the app's sensor colours: cards, bird's-eye, details)
    from follow_panel import SENSOR_COL as _SC
    COL = dict(_SC)
except Exception:
    COL = {"camera": "#FBBF24", "LiDAR": "#22D3EE", "radar": "#C084FC", "V2V": "#34D399"}
BG, ROAD, LINE, TXT, MUTED = "#0B1220", "#1E293B", "#475569", "#E5E7EB", "#94A3B8"
GREEN, AMBER, RED, OURS, OTHER = "#34D399", "#FBBF24", "#F87171", "#2563EB", "#64748B"


def _c(c, a=None):
    q = QColor(c)
    if a is not None:
        q.setAlphaF(a)
    return q


def draw_icon(p, key, r, col, width=1.6):
    """A small icon (camera / LiDAR / radar / V2V) in rect r."""
    p.save()
    pen = QPen(_c(col), width); pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    cx, cy = x + w / 2, y + h / 2
    s = min(w, h)
    if key == "camera":
        body = QRectF(cx - s * 0.45, cy - s * 0.25, s * 0.9, s * 0.6)
        p.drawRoundedRect(body, s * 0.1, s * 0.1)
        p.drawRect(QRectF(cx - s * 0.18, cy - s * 0.37, s * 0.3, s * 0.12))
        p.drawEllipse(QPointF(cx, cy + s * 0.05), s * 0.17, s * 0.17)
    elif key == "LiDAR":
        p.setBrush(_c(col)); p.drawEllipse(QPointF(cx, cy), s * 0.12, s * 0.12); p.setBrush(Qt.NoBrush)
        for k in range(8):
            a = k * math.pi / 4
            p.drawLine(QPointF(cx + math.cos(a) * s * 0.25, cy + math.sin(a) * s * 0.25),
                       QPointF(cx + math.cos(a) * s * 0.45, cy + math.sin(a) * s * 0.45))
    elif key == "radar":
        p.setBrush(_c(col)); p.drawEllipse(QPointF(x + s * 0.18, cy), s * 0.1, s * 0.1); p.setBrush(Qt.NoBrush)
        for k, rr in enumerate((0.28, 0.5, 0.72)):
            p.drawArc(QRectF(x + s * 0.18 - rr * s, cy - rr * s, 2 * rr * s, 2 * rr * s), -40 * 16, 80 * 16)
    elif key == "V2V":
        p.drawLine(QPointF(cx, cy - s * 0.05), QPointF(cx, cy + s * 0.45))
        p.setBrush(_c(col)); p.drawEllipse(QPointF(cx, cy - s * 0.08), s * 0.08, s * 0.08); p.setBrush(Qt.NoBrush)
        for rr in (0.22, 0.4):
            p.drawArc(QRectF(cx - rr * s, cy - s * 0.08 - rr * s, 2 * rr * s, 2 * rr * s), 30 * 16, 120 * 16)
    p.restore()


# ------------------------------------------------------------------ drawing helpers (logical 800-wide canvas)
def _text(p, x, y, t, col=TXT, size=12, bold=False, align=Qt.AlignLeft, w=300):
    f = QFont(); f.setPixelSize(size); f.setBold(bold); p.setFont(f); p.setPen(_c(col))
    if align == Qt.AlignCenter:
        p.drawText(QRectF(x - w / 2, y - size, w, size * 5), Qt.AlignHCenter | Qt.AlignTop | Qt.TextWordWrap, t)
    elif align == Qt.AlignRight:
        p.drawText(QRectF(x - w, y - size, w, size * 5), Qt.AlignRight | Qt.AlignTop | Qt.TextWordWrap, t)
    else:
        p.drawText(QRectF(x, y - size, w, size * 3.6), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, t)


def _vehicle(p, r, col, label="", outline=None, dashed=False, cab=True):
    """A vehicle from the top (truck with a cab when cab)."""
    p.save()
    pen = QPen(_c(outline or col), 2, Qt.DashLine if dashed else Qt.SolidLine)
    p.setPen(pen); p.setBrush(_c(col, 0.35 if dashed else 0.9))
    p.drawRoundedRect(r, 4, 4)
    if cab and r.width() > 60:
        p.setBrush(_c("#FFFFFF", 0.18)); p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(r.right() - r.width() * 0.22, r.y() + 3, r.width() * 0.2, r.height() - 6), 3, 3)
    p.restore()
    if label:
        _text(p, r.center().x(), r.center().y() - 6, label, "#FFFFFF", 11, True, Qt.AlignCenter, r.width() + 40)


def _arrow(p, a, b, col=TXT, w=2.0, head=9, dashed=False, both=False):
    p.save()
    p.setPen(QPen(_c(col), w, Qt.DashLine if dashed else Qt.SolidLine)); p.drawLine(a, b)
    p.setBrush(_c(col)); p.setPen(Qt.NoPen)

    def tip(t, f):
        ang = math.atan2(t.y() - f.y(), t.x() - f.x())
        p.drawPolygon(QPolygonF([t, QPointF(t.x() - head * math.cos(ang - 0.4), t.y() - head * math.sin(ang - 0.4)),
                                 QPointF(t.x() - head * math.cos(ang + 0.4), t.y() - head * math.sin(ang + 0.4))]))
    tip(b, a)
    if both:
        tip(a, b)
    p.restore()


def _mark(p, x, y, ok, r=11):
    """A ✓ (green) / ✕ (red) in a circle."""
    p.save()
    col = GREEN if ok is True else RED if ok is False else MUTED
    p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawEllipse(QPointF(x, y), r, r)
    p.setPen(QPen(_c("#0B1220"), 2.6, Qt.SolidLine, Qt.RoundCap))
    if ok is True:
        p.drawPolyline(QPolygonF([QPointF(x - r * 0.45, y), QPointF(x - r * 0.1, y + r * 0.4),
                                  QPointF(x + r * 0.5, y - r * 0.4)]))
    else:
        p.drawLine(QPointF(x - r * 0.4, y - r * 0.4), QPointF(x + r * 0.4, y + r * 0.4))
        p.drawLine(QPointF(x - r * 0.4, y + r * 0.4), QPointF(x + r * 0.4, y - r * 0.4))
    p.restore()


def _road(p, y0, y1, x0=0, x1=800, lanes=2):
    p.save()
    p.setPen(Qt.NoPen); p.setBrush(_c(ROAD)); p.drawRect(QRectF(x0, y0, x1 - x0, y1 - y0))
    p.setPen(QPen(_c(LINE), 2)); p.drawLine(QPointF(x0, y0), QPointF(x1, y0)); p.drawLine(QPointF(x0, y1), QPointF(x1, y1))
    pen = QPen(_c(LINE), 2, Qt.DashLine); p.setPen(pen)
    for k in range(1, lanes):
        yy = y0 + (y1 - y0) * k / lanes
        p.drawLine(QPointF(x0, yy), QPointF(x1, yy))
    p.restore()


def _fog(p, rect, n=70, seed=3, a=0.16):
    import random
    rnd = random.Random(seed)
    p.save(); p.setPen(Qt.NoPen); p.setClipRect(rect)
    for _ in range(n):
        r = rnd.uniform(6, 22)
        p.setBrush(_c("#E2E8F0", a * rnd.uniform(0.5, 1.0)))
        p.drawEllipse(QPointF(rnd.uniform(rect.left(), rect.right()), rnd.uniform(rect.top(), rect.bottom())), r, r)
    p.restore()


def _dim(p, x0, x1, y, label, col="#FDE68A"):
    """A distance dimension line with arrows both ways and its label."""
    _arrow(p, QPointF(x0, y), QPointF(x1, y), col, 1.6, 7, both=True)
    p.save(); p.setPen(QPen(_c(col), 1, Qt.DotLine))
    p.drawLine(QPointF(x0, y - 14), QPointF(x0, y + 6)); p.drawLine(QPointF(x1, y - 14), QPointF(x1, y + 6))
    p.restore()
    _text(p, (x0 + x1) / 2, y + 6, label, col, 12, True, Qt.AlignCenter, 260)


def _chip(p, x, y, t, col, size=11):
    f = QFont(); f.setPixelSize(size); f.setBold(True); p.setFont(f)
    w = p.fontMetrics().horizontalAdvance(t) + 14
    p.save(); p.setPen(QPen(_c(col), 1.2)); p.setBrush(_c(col, 0.15))
    p.drawRoundedRect(QRectF(x, y, w, size + 10), 8, 8); p.restore()
    p.setPen(_c(col)); p.drawText(QRectF(x, y, w, size + 10), Qt.AlignCenter, t)
    return w


# ------------------------------------------------------------------ the diagrams
def _d_flow(p):
    steps = [("1", "The scene moves", "trucks, vehicles ahead,\nobstacles, stop & go", "#E9D5FF"),
             ("2", "Sensors look", "camera · LiDAR · radar\n+ V2V messages", COL["camera"]),
             ("3", "Pick the target", "nearest vehicle in its\nlane (fusion)", "#F472B6"),
             ("4", "Truck decides", "follow · brake ·\nFULL BRAKE (AEB)", RED),
             ("5", "Check the truth", "real bodies touch?\n→ COLLISION + reason", "#FCA5A5")]
    x = 10
    for i, (n, t, s, col) in enumerate(steps):
        r = QRectF(x, 40, 140, 130)
        p.setPen(QPen(_c(col), 2)); p.setBrush(_c(col, 0.10)); p.drawRoundedRect(r, 12, 12)
        p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawEllipse(QPointF(x + 24, 66), 14, 14)
        f = QFont(); f.setPixelSize(14); f.setBold(True); p.setFont(f); p.setPen(_c("#0B1220"))
        p.drawText(QRectF(x + 10, 52, 28, 28), Qt.AlignCenter, n)
        _text(p, x + 44, 61, t, col, 13, True, w=96)
        _text(p, x + 10, 104, s, TXT, 11, w=124)
        if i < len(steps) - 1:
            _arrow(p, QPointF(x + 142, 105), QPointF(x + 158, 105), MUTED, 2, 8)
        x += 158
    _text(p, 400, 196, "Repeated many times a second for every truck — the truck only knows what its sensors tell it.",
          MUTED, 12, False, Qt.AlignCenter, 780)


def _d_camera(p):
    _road(p, 60, 200)
    ox, oy = 110, 165
    _fog(p, QRectF(450, 62, 350, 136), 60)
    # field of view (cone) clipped to the road
    p.save(); p.setClipRect(QRectF(0, 60, 800, 140))
    path = QPainterPath(QPointF(ox, oy))
    path.lineTo(ox + 700, oy - 700); path.lineTo(ox + 700, oy + 700); path.closeSubpath()
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"], 0.13)); p.drawPath(path)
    p.setPen(QPen(_c(COL["camera"], 0.5), 1)); p.drawLine(QPointF(ox, oy), QPointF(ox + 160, oy - 160))
    p.drawLine(QPointF(ox, oy), QPointF(ox + 160, oy + 160))
    p.setBrush(Qt.NoBrush)
    p.setPen(QPen(_c(COL["camera"], 0.45), 1.5, Qt.DashLine))
    p.drawArc(QRectF(ox - 620, oy - 620, 1240, 1240), -45 * 16, 90 * 16)       # clear weather: 80 m
    p.setPen(QPen(_c(COL["camera"]), 2.5))
    p.drawArc(QRectF(ox - 330, oy - 330, 660, 660), -45 * 16, 90 * 16)         # fog: 60 m
    p.restore()
    _vehicle(p, QRectF(20, 148, 90, 34), OURS, "our truck")
    draw_icon(p, "camera", QRectF(100, 130, 18, 18), COL["camera"])
    _vehicle(p, QRectF(250, 150, 140, 30), OTHER, "Truck_auto_1")
    _mark(p, 320, 138, True)
    _text(p, 320, 112, "SEEN · 'truck' 65 %", GREEN, 12, True, Qt.AlignCenter, 200)
    _vehicle(p, QRectF(400, 150, 50, 30), OTHER, "", dashed=True, cab=False)
    _mark(p, 425, 138, False)
    _text(p, 380, 205, "hidden behind it", RED, 11, w=150)
    _vehicle(p, QRectF(560, 80, 70, 28), OTHER, "", cab=False)
    _mark(p, 595, 70, False)
    _text(p, 640, 92, "beyond the fog\nrange → NOT seen", RED, 11, True, w=160)
    _dim(p, 110, 250, 226, "gap 28 m")
    _text(p, 448, 46, "fog range 60 m", COL["camera"], 12, True, Qt.AlignCenter, 160)
    _text(p, 700, 46, "clear day 80 m", MUTED, 11, False, Qt.AlignCenter, 160)
    _text(p, 10, 20, "Top view: the camera sees inside its 90° view and up to its range — fog shortens the range.",
          MUTED, 12, w=780)


def _d_lidar(p):
    for row, (cy, title, fog) in enumerate(((80, "Clear weather", False), (205, "Whiteout fog", True))):
        _road(p, cy - 45, cy + 45, lanes=1)
        _text(p, 8, cy - 58, title, AMBER if not fog else RED, 12, True, w=200)
        if fog:
            _fog(p, QRectF(118, cy - 44, 430, 88), 55, seed=7 + row, a=0.2)
        _vehicle(p, QRectF(20, cy - 16, 90, 32), OURS, "our truck")
        lx, ly = 104, cy - 12
        p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"])); p.drawEllipse(QPointF(lx, ly), 5, 5)
        _vehicle(p, QRectF(330, cy - 18, 200, 36), OTHER, "Truck_auto_1")
        hits = 0
        for k in range(11):
            ty = cy - 30 + k * 6
            if fog:
                end = lx + 40 + (k * 37) % 120
                g = QPen(_c(COL["LiDAR"], 0.5), 1.2, Qt.DotLine); p.setPen(g)
                p.drawLine(QPointF(lx, ly), QPointF(end, ly + (ty - ly) * (end - lx) / (330 - lx)))
                p.setPen(Qt.NoPen); p.setBrush(_c("#CBD5E1", 0.7))
                p.drawEllipse(QPointF(lx + 18 + (k * 13) % 40, ly + (k % 5 - 2) * 4), 2.2, 2.2)
            else:
                p.setPen(QPen(_c(COL["LiDAR"], 0.7), 1.2)); p.drawLine(QPointF(lx, ly), QPointF(330, ty))
                if cy - 18 <= ty <= cy + 18:
                    p.setPen(Qt.NoPen); p.setBrush(_c("#FDE68A")); p.drawEllipse(QPointF(330, ty), 3.2, 3.2)
                    hits += 1
        if not fog:
            _dim(p, 110, 330, cy + 30, "gap 12.3 m (nearest point)")
            _mark(p, 560, cy, True)
            _text(p, 578, cy - 8, "many points → DETECTED", GREEN, 12, True, w=220)
        else:
            _mark(p, 560, cy, False)
            _text(p, 578, cy - 14, "0 points (need 4)\n→ NOT detected", RED, 12, True, w=220)
            _text(p, 130, cy + 30, "fog: rays die out · grey dots = false points near the sensor", MUTED, 11, w=420)


def _d_radar(p):
    _road(p, 50, 200, x1=590)
    cy = 125
    _fog(p, QRectF(150, 52, 260, 146), 50, seed=11, a=0.14)
    _vehicle(p, QRectF(20, cy - 17, 90, 34), OURS, "our truck")
    p.save(); p.setClipRect(QRectF(0, 52, 588, 146)); p.setBrush(Qt.NoBrush)
    for k, rr in enumerate((40, 90, 140, 190, 240, 290)):
        p.setPen(QPen(_c(COL["radar"], 0.85 - k * 0.11), 2.2))
        p.drawArc(QRectF(112 - rr, cy - rr, 2 * rr, 2 * rr), -28 * 16, 56 * 16)
    p.restore()
    _vehicle(p, QRectF(420, cy - 17, 150, 34), OTHER, "Truck_auto_1")
    for k, rr in enumerate((25, 55, 85)):
        p.setPen(QPen(_c("#F0ABFC", 0.8 - k * 0.2), 1.8, Qt.DashLine))
        p.drawArc(QRectF(420 - rr, cy - rr, 2 * rr, 2 * rr), 150 * 16, 60 * 16)
    _text(p, 250, 34, "radio waves pass through the fog", COL["radar"], 12, True, Qt.AlignCenter, 300)
    _text(p, 345, 172, "echo comes back", "#F0ABFC", 11, False, Qt.AlignCenter, 160)
    _arrow(p, QPointF(30, 92), QPointF(100, 92), TXT, 2.2); _text(p, 30, 78, "40 km/h", TXT, 12, True, w=120)
    _arrow(p, QPointF(440, 92), QPointF(490, 92), TXT, 2.2); _text(p, 440, 78, "20 km/h", TXT, 12, True, w=120)
    _text(p, 290, 222, "Doppler: closing at 20 km/h — known at once", "#FDE68A", 12, True, Qt.AlignCenter, 420)
    # echo strength
    x0, y0 = 610, 70
    _text(p, x0, y0 - 14, "Echo strength", MUTED, 11, True, w=180)
    for i, (n, v, col) in enumerate((("truck", 1.0, GREEN), ("car", 0.6, GREEN), ("parked car", 0.35, AMBER),
                                     ("pedestrian", 0.18, RED))):
        y = y0 + 8 + i * 30
        _text(p, x0, y + 2, n, TXT, 11, w=90)
        p.setPen(Qt.NoPen); p.setBrush(_c("#1F2937")); p.drawRoundedRect(QRectF(x0 + 80, y - 6, 100, 12), 4, 4)
        p.setBrush(_c(col)); p.drawRoundedRect(QRectF(x0 + 80, y - 6, 100 * v, 12), 4, 4)
    _text(p, x0, y0 + 132, "weak echo = seen later / flickers", MUTED, 10, w=190)


def _d_v2v(p):
    _road(p, 110, 210)
    cy = 160
    _fog(p, QRectF(200, 112, 330, 96), 80, seed=5, a=0.26)
    _vehicle(p, QRectF(20, cy - 17, 90, 34), OURS, "our truck")
    _vehicle(p, QRectF(580, cy - 17, 150, 34), OTHER, "Truck_auto_1")
    p.setPen(Qt.NoPen); p.setBrush(_c(RED)); p.drawRect(QRectF(576, cy - 15, 5, 8)); p.drawRect(QRectF(576, cy + 7, 5, 8))
    # sensors stop in the fog
    p.setPen(QPen(_c(COL["camera"], 0.7), 2, Qt.DashLine)); p.drawLine(QPointF(112, cy), QPointF(230, cy))
    _mark(p, 240, cy, False, 9)
    _text(p, 120, cy + 34, "sensors: blocked by fog", RED, 11, True, w=200)
    # radio
    p.setBrush(Qt.NoBrush)
    for k, rr in enumerate((30, 60, 90)):
        p.setPen(QPen(_c(COL["V2V"], 0.9 - k * 0.2), 2))
        p.drawArc(QRectF(655 - rr, cy - 20 - rr, 2 * rr, 2 * rr), 60 * 16, 60 * 16)
    _arrow(p, QPointF(600, 80), QPointF(130, 112), COL["V2V"], 2.4, 11)
    bub = QRectF(240, 30, 300, 46)
    p.setPen(QPen(_c(COL["V2V"]), 1.6)); p.setBrush(_c(COL["V2V"], 0.14)); p.drawRoundedRect(bub, 10, 10)
    _text(p, 390, 40, "“Truck_auto_1 · 0 km/h · BRAKING!”", "#F1F5F9", 13, True, Qt.AlignCenter, 300)
    _text(p, 390, 60, "arrives in ~20 ms, 10 times a second", COL["V2V"], 11, False, Qt.AlignCenter, 300)
    # GPS
    p.setPen(QPen(_c(MUTED), 1.5)); p.setBrush(_c("#334155")); p.drawRect(QRectF(735, 18, 22, 12))
    p.drawLine(QPointF(728, 24), QPointF(764, 24))
    p.setPen(QPen(_c(MUTED), 1, Qt.DotLine)); p.drawLine(QPointF(746, 30), QPointF(670, cy - 18))
    p.setPen(QPen(_c(AMBER), 1.4, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(655, cy), 40, 26)
    _text(p, 700, 48, "GPS position\n± 2.5 m", AMBER, 11, True, w=110)
    _text(p, 10, 236, "Our truck knows it and brakes — even though no sensor can see through the fog.", MUTED, 12,
          w=780)


def _d_fusion(p):
    rows = [("LiDAR", "12.4 m", True), ("camera", "nothing (fog)", None), ("radar", "12.6 m · −3 m/s", True),
            ("V2V", "13.5 m", True)]
    for i, (k, t, ok) in enumerate(rows):
        y = 30 + i * 46
        r = QRectF(10, y, 230, 36)
        p.setPen(QPen(_c(COL[k]), 1.5)); p.setBrush(_c(COL[k], 0.10)); p.drawRoundedRect(r, 8, 8)
        draw_icon(p, k, QRectF(18, y + 7, 22, 22), COL[k])
        _text(p, 48, y + 12, f"{k}: {t}", TXT if ok else MUTED, 12, True, w=190)
        _arrow(p, QPointF(242, y + 18), QPointF(320, 120), _c(COL[k], 0.8 if ok else 0.25).name(), 1.6, 7)
    y = 30 + 4 * 46
    _text(p, 14, y + 12, "radar: parked car 4 m to the left", MUTED, 11, w=240)
    _mark(p, 250, y + 16, False, 8)
    _text(p, 14, y + 30, "→ outside our lane, ignored", RED, 11, w=240)
    box = QRectF(322, 70, 200, 100)
    p.setPen(QPen(_c("#F472B6"), 2)); p.setBrush(_c("#F472B6", 0.12)); p.drawRoundedRect(box, 12, 12)
    _text(p, 422, 86, "FUSION", "#F472B6", 14, True, Qt.AlignCenter, 190)
    _text(p, 422, 110, "1. in our lane?\n2. take the NEAREST", TXT, 12, False, Qt.AlignCenter, 190)
    _arrow(p, QPointF(524, 120), QPointF(580, 120), "#F472B6", 2.4, 10)
    t = QRectF(582, 62, 208, 116)
    p.setPen(QPen(_c(GREEN), 2)); p.setBrush(_c(GREEN, 0.12)); p.drawRoundedRect(t, 12, 12)
    _text(p, 686, 78, "TARGET", GREEN, 14, True, Qt.AlignCenter, 200)
    _text(p, 686, 102, "Truck_auto_1\n12.4 m ahead\nspeed 8.1 m/s (radar)", TXT, 12, False, Qt.AlignCenter, 200)


def _d_brake(p, ttc_warn=3.0, ttc_crit=1.5):
    _road(p, 30, 90, lanes=1)
    _vehicle(p, QRectF(30, 44, 90, 32), OURS, "our truck")
    _arrow(p, QPointF(40, 30 - 2), QPointF(110, 28), TXT, 2); _text(p, 40, 14, "40 km/h = 11.1 m/s", TXT, 11, True, w=200)
    _vehicle(p, QRectF(470, 44, 150, 32), OTHER, "stopped truck")
    _dim(p, 120, 470, 104, "25 m")
    _text(p, 640, 50, "TTC = 25 ÷ 11.1\n= 2.2 s", "#FDE68A", 14, True, w=160)
    x0, x1, y = 40, 760, 170
    span = 6.0
    X = lambda t: x0 + (x1 - x0) * min(span, t) / span       # noqa: E731
    for a, b, col, lab in ((0, ttc_crit, RED, "FULL BRAKE (AEB)"), (ttc_crit, ttc_warn, AMBER, "warning · brake"),
                           (ttc_warn, span, GREEN, "follow / drive on")):
        p.setPen(Qt.NoPen); p.setBrush(_c(col, 0.8)); p.drawRect(QRectF(X(a), y, X(b) - X(a), 22))
        _text(p, (X(a) + X(b)) / 2, y + 16, lab, "#0B1220", 12, True, Qt.AlignCenter, X(b) - X(a))
    for t in (0, ttc_crit, ttc_warn, span):
        _text(p, X(t), y + 36, f"{t:g} s" if t < span else "6 s +", MUTED, 11, False, Qt.AlignCenter, 60)
    m = X(2.2)
    p.setBrush(_c("#FFFFFF")); p.setPen(Qt.NoPen)
    p.drawPolygon(QPolygonF([QPointF(m, y - 2), QPointF(m - 8, y - 14), QPointF(m + 8, y - 14)]))
    _text(p, m, y - 34, "2.2 s → brake", "#FFFFFF", 12, True, Qt.AlignCenter, 140)
    _text(p, 40, 238, "Time to collision (TTC) = how many seconds until it would hit, if nothing changes.", MUTED, 12,
          w=740)


def _d_climate(p, rows):
    """rows: [(climate, camera %, LiDAR %, radar %)] of the clear-weather range."""
    _text(p, 10, 16, "How far each sensor sees — % of its clear-weather range", MUTED, 12, True, w=600)
    lx = 520
    for i, k in enumerate(("camera", "LiDAR", "radar")):
        p.setPen(Qt.NoPen); p.setBrush(_c(COL[k])); p.drawRoundedRect(QRectF(lx + i * 85, 8, 12, 10), 2, 2)
        _text(p, lx + i * 85 + 18, 18, k, TXT, 11, w=70)
    y = 50
    bw = 520
    for name, *vals in rows:
        _text(p, 10, y + 10, name, TXT, 12, w=150)
        for j, (k, v) in enumerate(zip(("camera", "LiDAR", "radar"), vals)):
            yy = y + j * 9
            p.setPen(Qt.NoPen); p.setBrush(_c("#1F2937")); p.drawRect(QRectF(170, yy, bw, 7))
            p.setBrush(_c(COL[k])); p.drawRect(QRectF(170, yy, bw * max(0.0, min(1.0, v)), 7))
        _text(p, 170 + bw + 8, y + 10, " · ".join(f"{v:.0%}" for v in vals), MUTED, 10, w=120)
        y += 36
    _text(p, 10, y + 6, "V2V: radio — not affected by fog (only a little by heavy rain).", COL["V2V"], 11, True, w=700)


def _d_collision(p):
    _road(p, 40, 120, lanes=1)
    _vehicle(p, QRectF(150, 62, 110, 36), OURS, "our truck")
    _vehicle(p, QRectF(262, 62, 160, 36), OTHER, "Truck_auto_1")
    star = QPolygonF()
    for k in range(16):
        r = 22 if k % 2 == 0 else 10
        a = k * math.pi / 8
        star.append(QPointF(261 + r * math.cos(a), 80 + r * math.sin(a)))
    p.setPen(QPen(_c("#FDE68A"), 1.5)); p.setBrush(_c(RED)); p.drawPolygon(star)
    _text(p, 470, 74, "the real bodies touch\n→ COLLISION (recorded with every\nsensor's view, camera, 3D scene)",
          "#FCA5A5", 12, True, w=320)
    _text(p, 10, 150, "The reason is worked out from the facts:", MUTED, 12, True, w=500)
    x = 10
    for t, col in (("climate (fog / rain cut the range)", "#7DD3FC"), ("hidden / small obstacle", AMBER),
                   ("seen too late for its speed", "#FB923C"), ("test setup", MUTED)):
        x += _chip(p, x, 168, t, col) + 8
    _text(p, 10, 222, "Sensors switched off on purpose are not blamed — they are suggested as a way to avoid it.",
          MUTED, 11, w=780)


# ------------------------------------------------------------------ data flow (what our app receives / does / sends)
_CH = 5.9        # ~px per character at 11 px


def _th(t, w):
    """Height (px) of 11 px text wrapped to w."""
    from PyQt5.QtCore import QRect
    from PyQt5.QtGui import QFontMetrics
    f = QFont(); f.setPixelSize(11)
    return max(15, QFontMetrics(f).boundingRect(QRect(0, 0, int(w), 2000), Qt.TextWordWrap, t).height() + 2)


def _box_lines(lines, bw):
    """(height in units of 15 px) of the box's lines."""
    return sum(_th(t, bw - 24) for t in lines) / 15.0


def _flow_layout(spec):
    """spec: [{"title": str | None, "boxes": [(title, who, [lines], colour, dashed)], "arrows": [label, ...]}]
    -> (rows with geometry, total height)."""
    y, out = 6, []
    for row in spec:
        n = len(row["boxes"])
        gap = 58
        bw = (800 - 12 - gap * (n - 1)) / n
        th = 20 if row.get("title") else 0
        h = 46 + 15 * max(_box_lines(b[2], bw) for b in row["boxes"])
        out.append((row, y + th, bw, gap, h))
        y += th + h + 14
    return out, y


def _d_dataflow(p, spec):
    rows, _H = _flow_layout(spec)
    for row, y, bw, gap, h in rows:
        if row.get("title"):
            _text(p, 6, y - 6, row["title"], row.get("title_col", MUTED), 12, True, w=780)
        for i, (title, who, lines, col, dashed) in enumerate(row["boxes"]):
            x = 6 + i * (bw + gap)
            r = QRectF(x, y, bw, h)
            p.setPen(QPen(_c(col), 1.8, Qt.DashLine if dashed else Qt.SolidLine))
            p.setBrush(_c(col, 0.08)); p.drawRoundedRect(r, 10, 10)
            p.setPen(Qt.NoPen); p.setBrush(_c(col, 0.22))
            p.drawRoundedRect(QRectF(x, y, bw, 38), 10, 10); p.drawRect(QRectF(x, y + 28, bw, 10))
            _text(p, x + 10, y + 15, title, col, 12, True, w=bw - 16)
            fw = QFont(); fw.setPixelSize(10); p.setFont(fw); p.setPen(_c(MUTED))
            p.drawText(QRectF(x + 10, y + 21, bw - 16, 14), Qt.AlignLeft | Qt.AlignVCenter,
                       p.fontMetrics().elidedText(who, Qt.ElideRight, int(bw - 16)))
            f = QFont(); f.setPixelSize(11); p.setFont(f); p.setPen(_c(TXT))
            ty = y + 44
            for t in lines:
                th = _th(t, bw - 24)
                p.setFont(f)
                p.setPen(_c(col)); p.drawText(QRectF(x + 8, ty, 10, 15), Qt.AlignLeft | Qt.AlignTop, "•")
                p.setPen(_c(TXT))
                p.drawText(QRectF(x + 18, ty, bw - 24, th), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, t)
                ty += th
            if i < len(row["boxes"]) - 1:
                ay = y + h / 2
                _arrow(p, QPointF(x + bw + 4, ay), QPointF(x + bw + gap - 4, ay), MUTED, 2, 9)
                lab = (row.get("arrows") or [])[i] if i < len(row.get("arrows") or []) else ""
                if lab:
                    _text(p, x + bw + gap / 2, ay - 22, lab, "#FDE68A", 10, True, Qt.AlignCenter, gap + 10)


def flow_height(spec):
    return _flow_layout(spec)[1]


HEIGHTS = {"flow": 210, "camera": 245, "lidar": 265, "radar": 240, "v2v": 250, "fusion": 250, "brake": 250,
           "climate": None, "collision": 240}


class Diagram(QWidget):
    """A picture of one topic, drawn on an 800-wide logical canvas scaled to the widget."""

    def __init__(self, kind, data=None):
        super().__init__()
        self.kind, self.data = kind, data
        self.H = int(math.ceil(flow_height(data) if kind == "dataflow" else
                               HEIGHTS.get(kind) or (70 + 36 * len(data or []))))
        self.setMinimumHeight(int(self.H * 0.55))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setFixedHeight(self.H)

    def resizeEvent(self, e):
        self.setFixedHeight(int(self.H * min(1.0, max(0.55, self.width() / 800.0))))
        super().resizeEvent(e)

    def paintEvent(self, _e):
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), _c("#0A0F1C"))
            s = min(self.width() / 800.0, self.height() / float(self.H))
            p.translate((self.width() - 800 * s) / 2, (self.height() - self.H * s) / 2)
            p.scale(s, s)
            fn = {"flow": _d_flow, "camera": _d_camera, "lidar": _d_lidar, "radar": _d_radar, "v2v": _d_v2v,
                  "fusion": _d_fusion, "brake": _d_brake, "collision": _d_collision}.get(self.kind)
            if self.kind == "climate":
                _d_climate(p, self.data or [])
            elif self.kind == "dataflow":
                _d_dataflow(p, self.data or [])
            elif self.kind == "brake" and self.data:
                _d_brake(p, *self.data)
            elif fn:
                fn(p)
        except Exception:
            import sys
            sys.excepthook(*sys.exc_info())
        finally:
            p.end()
