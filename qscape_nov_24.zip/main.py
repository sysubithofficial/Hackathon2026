"""Q-SCAPE -- Quest Simulation & Collision Analysis Platform Environment.

Start:  python main.py

No sign-in (one feature: collision testing). Choose / create a site from the map, then the main window
(shipyard.MapWindow): the 2D map and 3D view of the site, its AVs (autonomous vehicles), obstacles, routes and
scenarios, and Collision Testing (top bar).
"""

import json
import os
import sys

from PyQt5.QtWidgets import QApplication
from PyQt5 import QtWebEngineWidgets  # noqa: F401 -- before the QApplication (the app itself is imported later)

from screen_utils import enable_high_dpi, install_wheel_guard

APP_NAME = "Q-SCAPE"                 # (= shipyard.APP_NAME; the app is imported only after the sign-in)
ROOT = os.path.dirname(os.path.abspath(__file__))


def _all_sites():
    """sites/ folders with a map parameter file (= site_config.available_sites, without loading a site)."""
    from config_loader import find_cc_files
    out, sd = [], os.path.join(ROOT, "sites")
    for name in sorted(os.listdir(sd)) if os.path.isdir(sd) else []:
        sub = os.path.join(sd, name, "cc_config")
        if os.path.isdir(os.path.join(sd, name)) and find_cc_files(sub if os.path.isdir(sub) else os.path.join(sd, name)):
            out.append(name)
    return out


def _pick_site_for_user(auth):
    """The site loaded for the signed-in user (only one they may see: auth.can_see_site). None: they have none yet."""
    try:
        with open(os.path.join(ROOT, "config", "app_settings.json"), encoding="utf-8") as f:
            active = json.load(f).get("active_site")
    except (OSError, ValueError):
        active = None
    sites = _all_sites()
    wanted = os.environ.get("YARD_SITE")
    if wanted in sites and auth.can_see_site(wanted):
        return wanted
    return auth.choose_site(sites, active)


def _first_site(app):
    """A user without any site: they create their first one from the map, then the app starts with it."""
    from PyQt5.QtWidgets import QMessageBox, QDialog
    import auth
    QMessageBox.information(None, APP_NAME, "You have no site yet.\n\nCreate your first site from the map: search a "
                                            "place, draw its outline, then Create.")
    import yard_from_map
    import site_config as cfg
    dlg = yard_from_map.ChooseYardDialog(None)
    if dlg.exec_() != QDialog.Accepted or not dlg.site_id:
        return None
    cfg.set_active_site(dlg.site_id)
    return dlg.site_id


def main():
    import crash_guard
    crash_guard.install()   # a Python error in a Qt callback is logged (logs/app_errors.log), not a crash
    crash_guard.use_angle()   # Windows: Direct3D (ANGLE) instead of the graphics driver's OpenGL (driver crashes)
    enable_high_dpi()   # must run before QApplication is created
    app = QApplication(sys.argv)
    install_wheel_guard(app)   # the wheel over a drop-down / number box scrolls the page (unless it was clicked)

    # no sign-in: Q-SCAPE has one feature (collision testing) -- it runs as the local user with full access
    import auth
    auth.install_neutral_ui(app)
    auth.set_current(dict(auth.LOCAL_USER))

    # the site: one this user may see (administrators: any) -- chosen before the app (site_config) loads one
    site = _pick_site_for_user(auth)
    if site is None:
        site = _first_site(app)
        if site is None:
            sys.exit(0)
        auth.handoff()                                   # (site_config already loaded another site: start again)
        from PyQt5.QtCore import QProcess
        QProcess.startDetached(sys.executable, sys.argv[:] or [os.path.join(ROOT, "main.py")], ROOT)
        sys.exit(0)
    os.environ["YARD_SITE"] = site
    import site_config as cfg
    os.environ.pop("YARD_SITE", None)                    # (not inherited by a restarted copy: it picks again)
    auth.remember_site(cfg.ACTIVE_SITE)
    import log_filter
    log_filter.install()   # the terminal: errors / warnings only ("log": "all" in the app settings = everything)

    from shipyard import MapWindow, load_app_stylesheet
    window = MapWindow()
    # the dark / gold theme on the main window's own widget tree (its dialogs and the sign-in keep their own look)
    window.setStyleSheet(load_app_stylesheet())
    window.showMaximized()

    code = app.exec_()
    crash_guard.shutdown_qt(app)   # web views deleted while Qt runs (they crashed the app on exit)
    sys.exit(code)


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
