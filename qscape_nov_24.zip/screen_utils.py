"""
Screen-size helpers shared by the shipyard map and the packet filter.

The UI was first laid out on a large monitor. These helpers keep every
window inside the screen it is shown on (laptop 1366x768, 1920x1080 at
125/150 % scaling, 4K, ...) instead of using fixed pixel sizes.
"""

from PyQt5.QtCore import QEvent, QObject, Qt
from PyQt5.QtWidgets import (QAbstractScrollArea, QAbstractSlider, QAbstractSpinBox, QApplication, QComboBox, QFrame,
                             QScrollArea, QScrollBar, QVBoxLayout, QWidget)


def enable_high_dpi():
    """Must be called BEFORE QApplication is created.

    Without this, Qt5 on Windows draws widgets in physical pixels while
    fonts follow the Windows scale setting, so on 125 % / 150 % screens
    text and fixed-size widgets no longer match.
    """
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    # Use the exact Windows scale (1.25, 1.5) instead of rounding 1.5 up to 2x,
    # which would make everything far too big on 1080p laptops at 150 %.
    if hasattr(QApplication, "setHighDpiScaleFactorRoundingPolicy"):
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)


def available_geometry(widget=None):
    """Usable area (taskbar excluded) of the screen the widget is on."""
    screen = None
    if widget is not None and widget.windowHandle() is not None:
        screen = widget.windowHandle().screen()
    if screen is None:
        screen = QApplication.primaryScreen()
    return screen.availableGeometry()


def _value_widget(w):
    """The drop-down / number box / slider a widget is (or is part of: a number box's text field, an editable
    drop-down's text field) -- else None. Scroll bars are not."""
    for x in (w, w.parentWidget() if w is not None else None):
        if isinstance(x, (QComboBox, QAbstractSpinBox)) or \
                (isinstance(x, QAbstractSlider) and not isinstance(x, QScrollBar)):
            return x
    return None


class _WheelGuard(QObject):
    """Scrolling a page must never change what is chosen in it: the mouse wheel over a drop-down, a number box
    (also its text field, also after it was clicked) or a slider scrolls the page (the scroll area it is in)
    instead. Values change with the arrows / typing / the keyboard, a drop-down in its open list (that list is a
    window of its own and gets the wheel itself)."""

    def eventFilter(self, obj, ev):
        if ev.type() != QEvent.Wheel or not obj.isWidgetType() or obj.isWindow():
            return False                                  # (a drop-down's open list is a window of its own)
        vw = _value_widget(obj)
        if vw is None:
            return False
        p = vw.parentWidget()
        while p is not None and not isinstance(p, QAbstractScrollArea):
            p = p.parentWidget()
        if p is not None:
            QApplication.sendEvent(p.viewport(), ev)      # (the page scrolls)
        return True                                       # (never to the drop-down / number box / slider itself)


_GUARD = None


def install_wheel_guard(app):
    """Once, after QApplication is created (main.py / shipyard.py)."""
    global _GUARD
    if _GUARD is None:
        _GUARD = _WheelGuard(app)
        app.installEventFilter(_GUARD)
    return _GUARD


def make_scrollable(window):
    """The window's contents in a scroll area (both ways): a window whose layout needs more room than the
    screen has can then be made smaller -- it scrolls instead of reaching past the screen's edge."""
    lay = window.layout()
    if lay is None or getattr(window, "_scrollable", False):
        return
    inner = QWidget()
    inner.setObjectName("fitInner")
    inner.setLayout(lay)                                  # (the layout and its widgets move into it)
    sc = QScrollArea(window)
    sc.setObjectName("fitScroll")
    sc.setWidgetResizable(True)
    sc.setFrameShape(QFrame.NoFrame)
    sc.setStyleSheet("QScrollArea#fitScroll, QWidget#fitInner { background: transparent; }")
    sc.setWidget(inner)
    outer = QVBoxLayout(window)
    outer.setContentsMargins(0, 0, 0, 0)
    outer.addWidget(sc)
    window._scrollable = True


def fit_to_screen(window, width, height, fraction=0.9, align="center"):
    """Resize `window` to width x height, shrunk so it fits within `fraction`
    of the usable screen area, and place it fully on screen. If its layout needs
    more room than that, its contents scroll (make_scrollable).

    align: "center", "left" or "right".
    """
    area = available_geometry(window)
    w = min(width, int(area.width() * fraction))
    h = min(height, int(area.height() * fraction))
    hint = window.minimumSizeHint()
    if window.layout() is not None and (hint.width() > w or hint.height() > h):
        make_scrollable(window)
    w = max(w, window.minimumWidth())
    h = max(h, window.minimumHeight())
    window.resize(w, h)

    # resize() sets the client area; the OS title bar/border comes on top.
    frame_w = window.frameGeometry().width() - window.geometry().width()
    frame_h = window.frameGeometry().height() - window.geometry().height()
    full_w, full_h = w + max(frame_w, 0), h + max(frame_h, 0)

    if align == "left":
        x = area.left()
    elif align == "right":
        x = area.right() - full_w + 1
    else:
        x = area.left() + (area.width() - full_w) // 2
    y = area.top() + (area.height() - full_h) // 2
    window.move(max(x, area.left()), max(y, area.top()))
