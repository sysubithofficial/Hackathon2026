"""Q-SCAPE functional test (opens the app's window for ~2 minutes): 2 AVs drive the same route one behind the other
in dense fog (LiDAR + camera, radar off). After ~25 s AV 1 (front) brakes hard to a stop.
  nov2v   AV 2 has no V2V -> expect a collision (~55 km/h)
  v2v     both AVs send / use V2V -> AV 2 brakes on AV 1's brake alert: no collision, 1 'V2V prevented' record
  replay  opens the newest saved collision test replay (Reports -> Collision tests -> Replay) and plays it a little
Each run is saved with its replay (Reports -> Collision tests).
Usage: python tests/av_runs.py nov2v|v2v|replay [gap_m] [decel]   (from the qscape folder or anywhere)"""
import glob, json, os, sys, time, traceback
PK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODE = sys.argv[1] if len(sys.argv) > 1 else "nov2v"
GAP = float(sys.argv[2]) if len(sys.argv) > 2 else 30.0
DECEL = float(sys.argv[3]) if len(sys.argv) > 3 else 7.0
os.chdir(PK); sys.path.insert(0, PK)
import main as M
import crash_guard
crash_guard.install(); crash_guard.use_angle()
from screen_utils import enable_high_dpi
enable_high_dpi()
from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5 import QtWebEngineWidgets  # noqa
app = QApplication(sys.argv)
import auth
auth.install_neutral_ui(app)
if not auth.has_users():
    auth.add_user("admin", "secret1", "Admin", role="admin")
u, _ = auth.check("admin", "secret1"); auth.set_current(u)
os.environ["YARD_SITE"] = M._pick_site_for_user(auth)
import site_config as cfg
os.environ.pop("YARD_SITE", None)
for n in ("warning", "critical", "information"):
    setattr(QMessageBox, n, staticmethod(lambda *a, **k: QMessageBox.Ok))
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.No)
import shipyard as sy


def pump(s):
    a = time.time()
    while time.time() - a < s:
        app.processEvents(); time.sleep(0.004)


mw = sy.MapWindow(); mw.setStyleSheet(sy.load_app_stylesheet()); mw.resize(1600, 900); mw.show()
pump(20)
try:
    if MODE == "replay":
        reps = sorted(glob.glob(os.path.join(mw.collision_reports_dir(), "*", "replay.json.gz")), key=os.path.getmtime)
        if not reps:
            raise SystemExit("no saved replay -- run nov2v or v2v first")
        d = os.path.dirname(reps[-1])
        print("opening replay:", d, flush=True)
        mw.open_collision_replay(d)
        pump(12)
        pl = getattr(mw, "_replay_player", None)
        print("replay player:", type(pl).__name__ if pl is not None else None, flush=True)
        if pl is not None:
            for k in ("t", "dur", "duration", "playing"):
                if hasattr(pl, k):
                    print(f"  {k} = {getattr(pl, k)}", flush=True)
    else:
        while mw.unknown_list.count():                       # (no other traffic: only the two AVs on the route)
            it = mw.unknown_list.item(0)
            mw.delete_unknown_object(it.data(sy.Qt.UserRole) or {}, it, save=False)
        for vid in list(mw.path_replays):                    # (nothing else driving)
            try:
                mw.stop_path_replay(vid); mw.remove_marker(vid)
            except Exception:
                pass
        lst = mw.av_list                                     # (the site's own AVs off the map, in memory only)
        for i in range(lst.count()):
            it = lst.item(i)
            p = dict(it.data(sy.Qt.UserRole) or {})
            vid = p.get("avId")
            if vid and p.get("latitude") is not None:
                try:
                    mw.remove_marker(vid)
                except Exception:
                    pass
                p["latitude"] = p["longitude"] = None
                it.setData(sy.Qt.UserRole, p)
        mw._fobj_cache = None
        pump(1)
        print("objects near the route after clearing:", [o[1] for o in mw._follow_objects("none")][:12], flush=True)
        mw.climate_combo.setCurrentIndex(mw.climate_combo.findData(os.environ.get("AV_CLIMATE", "whiteout_fog")))
        pump(1)
        mw.set_map_view("3d"); pump(14)
        mw._view3d_actions["optReplay"].setChecked(True); pump(1)
        route = "Quest_Main_Entrance" if "Quest_Main_Entrance" in sy.SAVED_PATHS else list(sy.SAVED_PATHS)[0]
        sens = {"LiDAR", "camera"} | ({"V2V"} if MODE == "v2v" else set())
        temp = [mw._ctest_new_av("CT1"), mw._ctest_new_av("CT2")]
        KMH = float(os.environ.get("AV_KMH", "60"))
        members = [(temp[0], KMH, GAP, sens), (temp[1], KMH, GAP, sens)]
        mw.start_collision_test(route, members, 10.0, temp=temp,
                                v2v={"link": "pc5", "loss_pct": 5, "gnss": "navic", "mode": "brake", "connected_pct": 100},
                                replay=True, save=True)
        pump(3)
        cid = next(iter(mw.collision_tests)); ct = mw.collision_tests[cid]
        f1, f2 = mw.follow_tests[temp[0]], mw.follow_tests[temp[1]]
        print("route", route, "| AVs", temp, "| sensors", sorted(sens), "| gap", GAP, flush=True)
        t0 = time.time()
        while time.time() - t0 < 50:
            pump(1)
            if time.time() - t0 > 22 and f1["ctl"].v > KMH / 3.6 * 0.9 and f2["ctl"].v > KMH / 3.6 * 0.9:
                break
        print(f"before the stop: AV1 {f1['ctl'].v * 3.6:.0f} km/h, AV2 {f2['ctl'].v * 3.6:.0f} km/h, "
              f"true gap {f2.get('true_gap') or 0:.1f} m", flush=True)
        f1["ctl"].stop_and_go(time.time() - f1["t0"], DECEL, 25.0)
        t1 = time.time()
        while time.time() - t1 < 22:
            pump(0.5)
            if ct.get("v2v_saves") or ct.get("collisions"):
                pump(3)
                break
        pump(4)
        saves, cols = ct.get("v2v_saves") or [], ct.get("collisions") or []
        out = {"mode": MODE, "gap": GAP, "decel": DECEL,
               "saves": [{k: v for k, v in s.items() if isinstance(v, (str, int, float, bool, type(None), list))}
                         for s in saves],
               "collisions": [{k: v for k, v in c.items() if isinstance(v, (str, int, float, bool, type(None)))}
                              for c in cols]}
        print(json.dumps(out, indent=1, default=str)[:3500], flush=True)
        for nm, f in (("AV1", f1), ("AV2", f2)):
            print(nm, "log:", [f"{t:5.1f} {x}" for t, x in f["ctl"].log][-12:], flush=True)
        mw.end_collision_test(cid, quiet=True); pump(4)
        print("report dir:", ct.get("report_dir"), flush=True)
        print(f"SUMMARY {MODE}: {len(cols)} collision(s)"
              + (f" at {cols[0].get('speed_kmh')} km/h" if cols else "") + f", {len(saves)} V2V save(s)", flush=True)
except Exception:
    traceback.print_exc()
log = os.path.join(PK, "logs", "app_errors.log")
print("app_errors.log:", open(log, encoding="utf-8", errors="replace").read()[-1200:] if os.path.exists(log) else "none")
sys.stdout.flush()
os._exit(0)
