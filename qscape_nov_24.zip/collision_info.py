"""How collision testing works: an info window (main window, the ⓘ next to the Collision Testing button).

Each topic -- the test flow, camera, LiDAR, radar, V2V, sensor fusion, braking / TTC, climate, collisions and their
reasons -- with its purpose, how it works in this simulation, the calculation step by step with an example (how the
object's name and distance are found), what it gives and its limitations. The sensor topics have a "Method"
drop-down: the method in use (integrated) and other known methods (e.g. YOLO for the camera), each with how it
detects, a comparison with the method in use, what integrating it would need and how complex that is. Choosing a
not-integrated method changes nothing: the tests keep using the integrated one (the window says so).
The numbers of the examples are computed with the models themselves (follow_test / v2v), so they stay true.
"""
import math

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QListWidget,
                             QListWidgetItem, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem, QVBoxLayout,
                             QWidget)

import follow_test as ft
import v2v

GREEN, AMBER, RED, GREY, BLUE = "#34D399", "#FBBF24", "#F87171", "#94A3B8", "#60A5FA"
COL = {"camera": "#FBBF24", "lidar": "#22D3EE", "radar": "#C084FC", "v2v": "#34D399", "real": "#34D399", "fusion": "#F472B6",
       "brake": "#F87171", "climate": "#7DD3FC", "flow": "#E9D5FF", "collision": "#FCA5A5"}
CPLX = {"Low": GREEN, "Medium": AMBER, "High": "#FB923C", "Very high": RED}

STYLE = """
QDialog#ctInfo { background: #0B1220; }
QDialog#ctInfo QLabel { color: #E5E7EB; }
QListWidget#topics { background: #0F172A; border: 1px solid #1F2937; border-radius: 10px; color: #CBD5E1;
                     font-size: 13px; padding: 4px; outline: none; }
QListWidget#topics::item { padding: 9px 8px; border-radius: 7px; }
QListWidget#topics::item:selected { background: #1E3A8A; color: white; }
QListWidget#topics::item:hover { background: #172554; }
QFrame#card { background: #111827; border: 1px solid #1F2937; border-radius: 10px; }
QLabel#h1 { font-size: 20px; font-weight: 800; }
QLabel#cap { color: #94A3B8; font-size: 10px; font-weight: 800; letter-spacing: 1px; }
QLabel#body { color: #E5E7EB; font-size: 12px; }
QComboBox { background: #0F172A; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px; padding: 5px 8px;
            min-height: 22px; }
QComboBox QAbstractItemView { background: #0F172A; color: #E5E7EB; selection-background-color: #1D4ED8; }
QPushButton { background: #1F2937; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px; padding: 6px 14px; }
QPushButton:hover { background: #273449; }
QTableWidget { background: #0A0F1C; color: #E5E7EB; border: none; gridline-color: #1F2937; font-size: 12px; }
QHeaderView::section { background: #111827; color: #94A3B8; border: none; padding: 4px; }
QScrollArea { border: none; background: #0B1220; }
QScrollBar:vertical { background: #0B1220; width: 10px; border: none; }
QScrollBar::handle:vertical { background: #334155; border-radius: 5px; min-height: 40px; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: none; }
"""

# climates of the examples (config/climates.json when there, else these values)
_FALLBACK = {
    "clear": {"label": "Clear sky", "visibility_m": 4500, "day": True, "lidar": {"extinction_per_m": 0.0}},
    "fog": {"label": "Fog", "visibility_m": 120, "day": True, "lidar": {"extinction_per_m": 0.025}},
    "dense_fog": {"label": "Dense fog", "visibility_m": 40, "day": True, "lidar": {"extinction_per_m": 0.075}},
    "whiteout_fog": {"label": "Whiteout fog", "visibility_m": 12, "day": True, "lidar": {"extinction_per_m": 0.22}},
    "heavy_rain": {"label": "Heavy rain", "visibility_m": 350, "day": True, "precip": {"type": "rain", "rate": 1.0},
                   "lidar": {"extinction_per_m": 0.012}},
    "night": {"label": "Night", "visibility_m": 1500, "day": False, "lidar": {"extinction_per_m": 0.0}},
}


def _clim(cid):
    try:
        import site_config as cfg
        for c in cfg.CLIMATES or []:
            if c.get("id") == cid:
                return c
    except Exception:
        pass
    return _FALLBACK[cid]


def _steps(items):
    """Numbered calculation steps (html)."""
    return "".join(f"<p style='margin:3px 0'><b style='color:#93C5FD'>{i}.</b> {s}</p>" for i, s in
                   enumerate(items, 1))


def _bul(items, col="#CBD5E1"):
    return "".join(f"<p style='margin:2px 0'><span style='color:{col}'>●</span> {s}</p>" for s in items)


def _lim(real, sim):
    return (f"<b style='color:#FCA5A5'>The sensor (real world)</b>{_bul(real, RED)}"
            f"<b style='color:#FDE68A'>This simulation (simplified)</b>{_bul(sim, AMBER)}")


# ------------------------------------------------------------------ examples, computed with the models
def _camera_example():
    fog, dfog, night, clear = _clim("fog"), _clim("dense_fog"), _clim("night"), _clim("clear")
    ego_l, L, W, x, y = 7.0, 16.5, 2.5, 40.0, 0.8
    gap = x - ego_l / 2 - L / 2
    ang = math.degrees(math.atan2(y, x))
    r_fog = ft.camera_range(fog)
    conf = max(0.25, min(0.99, 1.0 - 0.75 * gap / max(1.0, r_fog)))
    r_d, r_n, r_c = ft.camera_range(dfog), ft.camera_range(night), ft.camera_range(clear)
    ped = r_fog * min(1.0, 0.4 + 0.6 * min(1.0, 0.6 / 2.5))
    half = ft.FRONT_CAMERA["hfov_deg"] / 2
    van = math.degrees(math.atan2(1.0, 15.0)); car = math.degrees(math.atan2(0.9, 30.0))
    return _steps([
        "<b>Example:</b> our AV (7 m long) drives at 40 km/h; <b>Truck_auto_1</b> (16.5 m with its trailer, "
        "2.5 m wide) is ahead. Every object in the scene is known by its id / label, its map position, length, "
        "width and kind.",
        "<b>Into the AV's frame</b>: east / north metres of the object from our AV, turned by our heading: "
        "forward x = e·sin(h) + n·cos(h), left y = −e·cos(h) + n·sin(h) → "
        f"<b>x = {x:g} m, y = {y:g} m</b> (centre to centre).",
        f"<b>Distance (gap)</b>, bumper to bumper: x − own length/2 − its length/2 = {x:g} − {ego_l / 2:g} − "
        f"{L / 2:g} = <b>{gap:.2f} m</b>.",
        f"<b>In the field of view?</b> angle = atan(y / x) = {ang:.1f}° — inside ±{half:g}° → yes.",
        f"<b>Range in this climate</b> ({fog.get('label')}, visibility {fog.get('visibility_m')} m): "
        f"min({ft.FRONT_CAMERA['max_range_m']:g}, {ft.FRONT_CAMERA['visibility_share']:g} × "
        f"{fog.get('visibility_m')}) = <b>{r_fog:.0f} m</b>; a 2.5 m wide object gets the full range. "
        f"{gap:.1f} m &lt; {r_fog:.0f} m → <b>seen</b>.",
        f"<b>Hidden?</b> Its angular width ±atan(1.25 / {x:g}) is compared with the nearer objects: covered "
        f"≥ {ft.OCCLUDED_SHARE:.0%} → not seen. (A car 0.9 m half-wide at 30 m spans ±{car:.1f}°; a van 1 m "
        f"half-wide at 15 m in front spans ±{van:.1f}° → fully covered → the car is hidden.)",
        f"<b>Type and confidence</b>: conf = 1 − 0.75 × gap / range = 1 − 0.75 × {gap:.1f} / {r_fog:.0f} = "
        f"<b>{conf:.2f}</b> → ≥ 0.5, so the type <b>'truck'</b> is given (below 0.5 only 'object').",
        "<b>Name</b>: the detection carries the object's id / label from the scene → <b>'Truck_auto_1'</b>.",
        f"<b>Result</b>: Truck_auto_1 · truck · {gap:.1f} m · conf {conf:.2f} · sensor camera. The same truck in "
        f"<b>{dfog.get('label')}</b> ({dfog.get('visibility_m')} m): range {r_d:.0f} m → <b>not seen</b>; at "
        f"<b>night</b>: {r_n:.0f} m (clear day {r_c:.0f} m); a <b>pedestrian</b> (0.6 m wide) in {fog.get('label')}: "
        f"only from {ped:.0f} m."])


def _lidar_example():
    wf, fog = _clim("whiteout_fog"), _clim("fog")
    ext = float((wf.get("lidar") or {}).get("extinction_per_m") or 0.22)
    ext_f = float((fog.get("lidar") or {}).get("extinction_per_m") or 0.025)
    p12 = math.exp(-2 * ext * 12); p8 = math.exp(-2 * ext * 8); pf = math.exp(-2 * ext_f * 12)
    rng = ft.lidar_range(wf)
    return _steps([
        "<b>Example:</b> our AV (7 m long, 2.5 m wide); the LiDAR scans its full pattern of rays (its channels × "
        "horizontal steps); the detections are taken a few times a second (~4 Hz in the test).",
        "<b>Each ray</b> is traced through the 3D scene: the nearest surface it meets — ground, a building, the "
        "box of a vehicle / obstacle — gives the distance r along the ray; the point = sensor position + r × ray "
        "direction, with range noise added.",
        "<b>Name</b>: a ray that hits a vehicle's 3D box belongs to that vehicle → its point is counted under "
        "<b>'Truck_auto_1'</b>. E.g. 60 rays land on the back of its trailer.",
        "<b>Distance (gap)</b> of each point in the AV's frame (forward f, left l): "
        "gap = √(max(0, |l| − half width)² + max(0, |f| − half length)²). A point at f = 15.8 m, l = 0.4 m: "
        "max(0, 0.4 − 1.25) = 0, max(0, 15.8 − 3.5) = 12.3 → <b>gap 12.3 m</b>. The object's gap is its "
        "<b>nearest</b> point's.",
        "<b>Detection</b>: an object with at least <b>4 points</b> (config/lidar.json) is detected: "
        "Truck_auto_1 · 60 points · 12.3 m · sensor LiDAR (no type, no speed).",
        f"<b>Climate</b>: each return survives with probability e^(−2 × extinction × r). {fog.get('label')} "
        f"(extinction {ext_f:g}/m) at 12 m: e^(−2×{ext_f:g}×12) = {pf:.0%} → ~{60 * pf:.0f} of 60 points → "
        f"detected. <b>{wf.get('label')}</b> ({ext:g}/m): at 12 m {p12:.2%} → ~{60 * p12:.1f} points → "
        f"<b>not detected</b>; at 8 m {p8:.1%} → ~{60 * p8:.1f}. Fog also adds false points close to the sensor "
        "(they belong to no object, so they are not detections).",
        f"<b>Range used for the reports</b>: where ~2 % of the returns are left: ln(50) / (2 × extinction) = "
        f"ln 50 / (2 × {ext:g}) = <b>{rng:.1f} m</b> (at most 15 m)."])


def _radar_example():
    clear, rain = _clim("clear"), _clim("heavy_rain")
    m_c = ft.radar_margin_db(60.0, 20.0, clear); p_c = ft.radar_pd(m_c)
    loss = ft.radar_losses_db(rain, 60.0); m_r = ft.radar_margin_db(60.0, 20.0, rain); p_r = ft.radar_pd(m_r)
    m_p = ft.radar_margin_db(30.0, -5.0, clear); p_p = ft.radar_pd(m_p)
    m_s = ft.radar_margin_db(50.0, 10.0, clear, static=True); p_s = ft.radar_pd(m_s)
    R = ft.FRONT_RADAR
    return _steps([
        f"<b>Example:</b> our AV at 40 km/h (11.1 m/s); <b>Truck_auto_1</b> (a truck, radar cross-section "
        f"~20 dBsm) 60 m ahead at 20 km/h (5.6 m/s), inside the ±{R['hfov_deg'] / 2:g}° beam.",
        f"<b>Signal margin</b> (dB over the detection threshold): (RCS − {R['ref_rcs_dbsm']:g}) − "
        f"40·log10(r / {R['max_range_m']:g}) − weather losses = (20 − 20) − 40·log10(60/120) − 0 = "
        f"<b>{m_c:+.1f} dB</b>.",
        f"<b>Detection probability</b> per scan: Pd = 1 / (1 + e^(−margin / {R['pd_slope_db']:g})) = "
        f"<b>{p_c:.1%}</b>. Each scan draws: detected or missed.",
        f"<b>Tracker</b>: confirmed after {R['confirm']} hits in the last {R['window']} scans; when missed it is "
        f"kept ('coasting') {R['coast_s']:g} s.",
        "<b>Distance</b>: the true gap + range noise (σ grows as the margin falls: 0.08 m × (1 + 10^(−margin/10))). "
        "<b>Name</b>: the object the track belongs to (Truck_auto_1).",
        "<b>Speed (Doppler)</b>: v_rel = its speed × cos(heading difference) − our speed = 5.6 − 11.1 = "
        "<b>−5.6 m/s</b> (closing at 20 km/h) — known at once, no need to watch the gap change.",
        f"<b>Weather</b>: {rain.get('label')} costs {loss:.1f} dB at 60 m (rain attenuation ITU-R P.838 + "
        f"backscatter + wet radome) → margin {m_r:+.1f} dB → Pd {p_r:.0%}. Fog costs almost nothing.",
        f"<b>Weak targets</b>: a pedestrian (−5 dBsm) at 30 m: margin {m_p:+.1f} dB → Pd {p_p:.0%} (it flickers); "
        f"a parked car (10 dBsm, never moved: −{R['clutter_static_db']:g} dB) at 50 m: {m_s:+.1f} dB → "
        f"Pd {p_s:.0%}."])


def _v2v_example():
    L = v2v.LINKS["pc5"]
    tol = ft.CORRIDOR_HALF_M + 1.5 * 2.5
    gap = 30.0 - 3.5 - 8.25
    v_al = max(0.0, 5.0 + (-5.0) * v2v.ANTICIPATE_S)
    return _steps([
        f"<b>Example:</b> <b>Truck_auto_1</b> (16.5 m) brakes hard (−5 m/s²) from 18 km/h (5 m/s); it sends a "
        f"<b>BRAKE ALERT</b> at once (harder than {v2v.BRAKE_ALERT:g} m/s²) besides its {v2v.RATE_HZ:g} Hz state "
        "messages: id + label, GNSS position, speed, heading, acceleration, length, brake flag.",
        "<b>Position</b>: its true position + its GNSS error (NavIC / GPS ~2.5 m, slowly drifting).",
        f"<b>The radio (PC5)</b>: delay {L['delay_ms']:g} ± {L['jitter_ms']:g} ms; delivered within "
        f"{L['range_m']:g} m in line of sight ({L['nlos_range_m']:g} m when a building blocks the line, +60 % loss "
        "there), lost with the base loss + the loss set in the setup. Say it arrives after 24 ms.",
        "<b>Name</b>: the message carries the sender's id / label → <b>'Truck_auto_1'</b> (known even when no "
        "sensor sees it).",
        "<b>Where along our route</b>: the reported position is placed on our route ahead: x = 30.0 m along it, "
        f"2.9 m beside it. In our lane? |2.9| ≤ corridor {ft.CORRIDOR_HALF_M:g} + 1.5 × GNSS 2.5 = {tol:.2f} m and "
        "its heading within 35° of the route's → <b>yes</b> (more than 90° off: coming the other way, ignored).",
        f"<b>Distance (gap)</b> = x − our length/2 − its length/2 = 30.0 − 3.5 − 8.25 = <b>{gap:.2f} m</b>.",
        f"<b>Speed</b>: its reported speed along our road; on a brake alert we plan with the speed it brakes to "
        f"{v2v.ANTICIPATE_S:g} s later: 5 + (−5 × {v2v.ANTICIPATE_S:g}) = {v_al:g} m/s → our AV brakes now.",
        f"<b>Fresh?</b> a message older than its delay + {v2v.STALE_S * 1000:g} ms is dropped. Result: Truck_auto_1 · "
        f"{gap:.1f} m · BRAKING · 24 ms · sensor V2V."])


def _v2v_fields():
    ex = {"tx": "Truck_auto_1", "t": "12:04:31.250", "lat": "8.558421", "lon": "76.882541", "hd": "169",
          "v": "5.6 (20 km/h)", "a": "−4.8", "brake": "YES", "L": "16.5", "alert": "BRAKE ALERT"}
    rows = "".join(f"<tr><td style='padding-right:10px'><b>{nm}</b></td><td style='color:#34D399; padding-right:6px'>"
                   f"{ex.get(k, '')}</td><td style='color:#94A3B8; padding-right:10px'>{unit}</td>"
                   f"<td style='color:#CBD5E1'>{mean}</td></tr>" for k, nm, unit, mean in v2v.MSG_FIELDS)
    return (f"<table cellspacing='0' cellpadding='1'>{rows}</table>"
            f"<span style='color:#94A3B8'>Size on the air ~{v2v.MSG_BYTES} bytes (a brake alert ~{v2v.ALERT_BYTES}) "
            "with the security signature + certificate (real standards: SAE J2735 BSM / ETSI CAM; brake alert: "
            "EEBL / DENM). <b>Not</b> in the message: the distance to me, whether it is in my lane, a picture — the "
            "receiver works those out. The receiver adds: the message's <b>age</b> (now − time stamp) and, in this "
            "test, the radio delay. In this simulation the message is plain data (no encoding, no signing).</span>")


def _v2v_txrx():
    L = v2v.LINKS
    return _steps([
        f"<b>Who sends</b>: every connected vehicle — the test AVs with V2V ON, and the share of the scene's "
        "vehicles set as connected. Pedestrians, cones, old vehicles send nothing.",
        f"<b>When</b>: a <b>state</b> message every {1000 / v2v.RATE_HZ:g} ms ({v2v.RATE_HZ:g} a second, slower in "
        f"heavy traffic), and a <b>BRAKE ALERT</b> at once when it brakes harder than {v2v.BRAKE_ALERT:g} m/s², stops "
        "after a collision or stop &amp; go starts.",
        "<b>To whom</b>: a <b>broadcast</b> — nobody is addressed; every vehicle in radio range gets it (also those "
        "behind, beside, coming the other way). Each receiver decides itself what matters to it.",
        f"<b>The radio</b>: direct C-V2X (PC5) ~{L['pc5']['delay_ms']:g} ms, ~{L['pc5']['range_m']:g} m, "
        f"~{L['pc5']['nlos_range_m']:g} m behind buildings; cellular (V2N) ~{L['v2n']['delay_ms']:g} ms through the "
        "operator's network. Per message and receiver: delivered (after its delay) or lost.",
        "<b>The receiver keeps</b> only the <b>latest</b> message of every sender; older than its delay + "
        f"{v2v.STALE_S * 1000:g} ms = not used (the sender may be gone / out of range).",
        "<b>It checks each one</b>: placed on its own route → ahead? in its lane (± GNSS error)? going its way? "
        "→ <b>used</b> (a detection 'V2V' with distance and speed, brake mode) or <b>not used</b> and why "
        "(behind, other direction, beside its lane, too old).",
        "<b>See it live</b>: detection details → <b>V2V messages</b>: sends / receives counts, every message held now "
        "with its decision, one message field by field, the latest deliveries and lost brake alerts."])


def _v2v_traffic():
    rows = []
    for n in (10, 100, 200, 300, 600, 1000):
        ld = v2v.load_of(n, "pc5")
        rx = n * ld["rate_hz"] * (1 - 0.06 - ld["extra_loss"])
        rows.append(f"<tr><td style='padding-right:12px'><b>{n}</b></td>"
                    f"<td style='padding-right:12px'>{ld['cbr_demand'] * 100:.0f} %</td>"
                    f"<td style='padding-right:12px'>{ld['rate_hz']:.1f} / s</td>"
                    f"<td style='padding-right:12px'>{ld['cbr'] * 100:.0f} %</td>"
                    f"<td style='padding-right:12px'>+{ld['extra_loss'] * 100:.0f} %</td>"
                    f"<td style='padding-right:12px'>{rx:.0f} / s</td>"
                    f"<td>{100 * rx / v2v.VERIFY_PER_S:.0f} %</td></tr>")
    head = ("<tr style='color:#94A3B8'><td>vehicles in range</td><td>busy wanted</td><td>each sends</td>"
            "<td>busy (after control)</td><td>extra loss</td><td>to check</td><td>of ~2000 / s</td></tr>")
    return (
        "<b>One shared channel</b>: on the direct link all vehicles in range send on the same radio channel. Each "
        f"message occupies ~{v2v.AIRTIME_MS:g} ms of it → <b>channel busy ratio</b> (CBR) = vehicles × messages / s "
        f"× {v2v.AIRTIME_MS:g} ms. When it gets busy, messages <b>collide</b> (more loss, from ~"
        f"{v2v.CBR_LOSS_FROM * 100:.0f} % busy) and <b>congestion control</b> (ETSI DCC / SAE J3161) makes every "
        f"sender slower so the channel stays below ~{v2v.DCC_TARGET * 100:.0f} % — older positions, but still "
        "delivered. A brake alert is always sent at once."
        f"<table cellspacing='0' cellpadding='1' style='margin-top:4px'>{head}{''.join(rows)}</table>"
        "<b>The receiver's work</b>: every message must have its signature checked before it is trusted; a V2V "
        f"unit checks ~{v2v.VERIFY_PER_S} a second (security chip). Above that it checks only the relevant ones "
        "(ahead, close) — 'verify on demand'. <b>Cellular (V2N)</b>: no shared channel (the network schedules it): the "
        "rate stays, the delay grows a little.<br>"
        "<b>In this app</b>: the AVs and connected scene vehicles are simulated message by message; "
        "<i>setup → V2V → Heavy traffic: extra connected vehicles nearby</i> adds vehicles that only load the "
        "channel (busy %, slower sending, more loss) — so a heavy-traffic test does not slow the PC. The V2V "
        "messages tab shows the load and the app's own cost (ms per step; usually well under 1 ms).")


def _fusion_example():
    return _steps([
        "<b>Example</b> — what the sensors give at one moment (only those switched on):<br>"
        "&nbsp;&nbsp;LiDAR: Truck_auto_1 12.4 m (50 points) · radar: Truck_auto_1 12.6 m, v_rel −3.0 m/s · "
        "camera: nothing (fog) · V2V: Truck_auto_1 13.5 m (GNSS) · radar: a parked car 4.0 m to the left.",
        f"<b>Lane filter</b>: objects more than {ft.CORRIDOR_HALF_M:g} m beside our path ahead are dropped → the "
        "parked car goes.",
        "<b>Merge by object</b>: the same id from several sensors is one object; each sensor's own distance is "
        "kept (LiDAR 12.4, radar 12.6, V2V 13.5) and the <b>nearest</b> is used: 12.4 m.",
        "<b>Target</b>: the nearest object in the lane → Truck_auto_1, 12.4 m, seen by LiDAR + radar + V2V.",
        "<b>Its speed</b>: radar / V2V give it directly: v_lead = our speed + v_rel = 11.1 − 3.0 = 8.1 m/s. "
        "Camera / LiDAR only: from how the gap changes between two looks with the same sensors "
        "(smoothed 60 / 40).",
        f"<b>Hold</b>: a detection is used {ft.HOLD_S:g} s; with nothing for longer the target is lost and the "
        "AV speeds up again."])


def _brake_example():
    fog = _clim("fog")
    grip = ft.road_grip(fog)
    v = 40 / 3.6
    room = 25.0 - ft.STOP_GAP_M
    a_req = v * v / (2 * room)
    ttc1 = 25.0 / v
    ttc2 = 15.0 / v
    a_full = ft.A_FULL * grip
    stop = v * v / (2 * a_full)
    return _steps([
        f"<b>Example:</b> our AV at 40 km/h ({v:.1f} m/s); Truck_auto_1 stands 25 m ahead; {fog.get('label')} "
        f"(road grip {grip:.0%}).",
        f"<b>TTC</b> = gap / closing speed = 25 / {v:.1f} = <b>{ttc1:.2f} s</b> → below {ft.TTC_WARN_S:g} s: a "
        "<b>warning</b>.",
        f"<b>Needed deceleration</b> to stop {ft.STOP_GAP_M:g} m short: v² / (2 × (gap − {ft.STOP_GAP_M:g})) = "
        f"{v:.1f}² / (2 × {room:g}) = <b>{a_req:.2f} m/s²</b> → above {ft.A_COMFORT:g}: it brakes hard with "
        f"{a_req:.2f} × 1.15 = {a_req * 1.15:.2f} m/s² (at most the full brake).",
        f"<b>Seen later</b> — first at 15 m: TTC = 15 / {v:.1f} = <b>{ttc2:.2f} s</b> &lt; {ft.TTC_CRIT_S:g} s → "
        f"<b>AEB, full brake</b>: {ft.A_FULL:g} × grip {grip:.2f} = {a_full:.1f} m/s²; it needs {stop:.1f} m to stop "
        f"→ stops {15 - stop:.1f} m short.",
        f"<b>Seen at 10 m</b> (thick fog): it needs {stop:.1f} m but has 10 → <b>collision</b> at "
        f"~{math.sqrt(max(0.0, v * v - 2 * a_full * 10)) * 3.6:.0f} km/h (without the reaction time)."])


# ------------------------------------------------------------------ methods
def _M(name, ok, note, how="", compare=None, needs=None, cplx=None, effort="", real=False):
    return {"name": name, "ok": ok, "note": note, "how": how, "compare": compare or [], "needs": needs or [],
            "cplx": cplx, "effort": effort, "real": real}


def _R(name, note, how):
    """A method integrated in the REAL-WORLD set-up (top bar Sensors)."""
    return _M(name + "  [real-world set-up]", True, note, how, real=True)


# each option's set-up ("sim" / "real" / "both": which set-up's drop-down lists it) and its step-by-step picture deck
_TAGS = {
    "camera": [("sim", "camera"), ("real", "camera_real"), ("real", "yolo"), ("real", "depth"), ("both", "lane")],
    "lidar": [("sim", "lidar"), ("real", "lidar_real"), ("real", "pointpillars"), ("real", "dbscan")],
    "radar": [("sim", "radar"), ("real", "radar_real"), ("real", "radar_fft"), ("real", "radar_4d")],
    "v2v": [("both", "v2v"), ("both", "v2v_v2n"), ("both", "v2v_dsrc"), ("both", "v2v_std"), ("both", "v2v_rsu")],
    "fusion": [("sim", "fusion"), ("real", "fusion_real"), ("both", "kalman"), ("real", "early_fusion")],
    "brake": [("both", "brake"), ("both", "mpc"), ("both", "fcw")],
}


def _methods():
    """topic -> [method] with its set-up and picture deck (_TAGS)."""
    out = _methods_raw()
    for k, ms in out.items():
        for m, (setup, deck) in zip(ms, _TAGS.get(k, [])):
            m["setup"], m["deck"] = setup, deck
            m["short"] = m["name"].replace("  [real-world set-up]", "")
    return out


def _v2v_link():
    """The V2V link of the last collision test started ('Last test' setup), else the default (PC5)."""
    try:
        import os
        import site_config as cfg
        import collision_panel as cpn
        s = cpn.load_setups(os.path.join(cfg.SITE_DIR, "collision_setups.json")).get(cpn.LAST_SETUP) or {}
        link = ((s.get("v2v") or {}).get("link")) or v2v.DEFAULTS["link"]
        return link if link in v2v.LINKS else "pc5"
    except Exception:
        return "pc5"


def _methods_raw():
    """topic -> [method]: the first integrated one is what the tests use. compare: [(aspect, in use, this one)]."""
    return {
        "camera": [
            _M("Camera model: field of view + range in this climate", True,
               "In use: an object inside the camera's field of view and closer than its range in this climate is "
               "seen, with its type and a confidence.",
               "Geometry only (no picture is analysed): angle and distance of each scene object against the "
               "camera's field of view and its climate range; occlusion by angular width; type confidence from the "
               "distance."),
            _R("Picture processing: free space / ground contact",
               "The obstacles are found IN THE PICTURE: road / not-road per pixel column, the ground contact gives the "
               "distance, tracked over the pictures.",
               "Road colours learned from the bottom of the picture (fading to the haze colour far away); per column "
               "the lowest place where the road stops for good (≥ 0.8 m high) is an obstacle's ground contact; "
               "distance = camera height ÷ tan(angle below the horizon); neighbouring columns grouped; type from the "
               "width; confidence from the contrast; tracks C1 …. No machine learning — a classic monocular method."),
            _M("YOLO (v8 / v11) object detection on the 3D camera images", False,
               "A neural network finds the vehicles in the rendered camera picture.",
               "Each camera frame (e.g. 640 × 640 pixels) goes through the network: it outputs boxes (x, y, width, "
               "height in pixels) + a class (truck, car, person ...) + a confidence. The distance is NOT given: it "
               "is estimated from the box — the bottom edge projected onto the road with the camera's calibration "
               "(height, pitch, focal length), or from the box height and the known size of the class. The name is "
               "not given either: a tracker (ByteTrack / DeepSORT) keeps an id per object over the frames; to link "
               "it to the scene's name the box is matched with the projected scene boxes (IoU).",
               [("What is detected", "Every scene object in range (geometry)",
                 "What the network recognises in the picture"),
                ("Name", "From the scene (exact)", "Track id only; scene name by box matching"),
                ("Distance", "Exact geometry", "Estimated from the box (± 5–15 %, worse far away / on slopes)"),
                ("Climate", "Range = share of the visibility (a formula)",
                 "Depends on how the fog / rain / night looks in the rendered picture"),
                ("Misses / false alarms", "None inside the range", "Yes — like a real camera"),
                ("Compute", "Microseconds", "~10–40 ms per frame on a GPU, 80–300 ms on a CPU (per camera)"),
                ("Realism of the test", "Optimistic", "Closer to a real perception stack")],
               ["Frames from the 3D view at 5–10 Hz per camera per AV (the camera images exist already: "
                "frontCamShot) — moving them from the web page to Python is the main cost.",
                "A runtime: onnxruntime / PyTorch (+ CUDA for a GPU) and the model weights (yolov8n ≈ 6 MB).",
                "Licence check: Ultralytics YOLO is AGPL-3.0 — for in-house / closed use a commercial licence, or "
                "an Apache-licensed model (YOLOX, RT-DETR).",
                "Distance from the box: the camera calibration (intrinsics + mounting, Vehicles → cameras).",
                "A tracker for the ids, and box ↔ scene-object matching for the names in the reports.",
                "Running asynchronously (a worker thread / process) so the simulation does not stall; the detection "
                "time becomes part of the reaction delay.",
                "Render quality: flat 3D models and simple fog may be detected differently from real pictures "
                "(domain gap) — needs checking with recorded camera images (Validate)."],
               "High", "about 3–5 weeks for a working version (frames, model, distance, tracking, threading); "
                       "longer to make the rendered pictures realistic enough to trust the results"),
            _M("Depth estimation (stereo / monocular) for the distance", False,
               "The distance from two cameras or a depth network instead of the model's geometry.",
               "Stereo: the same point in the left and right picture is shifted by the disparity d pixels → "
               "distance = focal length × baseline / d. Monocular: a depth network (MiDaS, Depth-Anything) "
               "predicts a depth per pixel (relative, needs scaling).",
               [("Distance", "Exact geometry", "Stereo ± 1–5 % near, poor far away; mono: relative, needs scale"),
                ("Needs", "Nothing extra", "A second camera / a depth model + a detector for the objects"),
                ("Compute", "Microseconds", "20–100 ms per frame")],
               ["A detector first (e.g. YOLO) — depth only gives the distance of what was found.",
                "Stereo: a second rendered camera + matching (OpenCV SGBM); mono: a depth network + scaling.",
                "Calibration of both cameras."],
               "High", "about 2–4 weeks on top of a camera detector"),
            _M("Lane / road-marking detection", False, "Finding the lane from the picture.",
               "A network or classic edge + Hough-line detection finds the lane lines; the AV's lane decides "
               "which objects are 'ahead'.",
               [("Lane", "The route's path ± 2.2 m (known)", "Detected from the picture (can fail in rain / snow)")],
               ["Lane markings drawn in the 3D scene (not there today).", "A lane detector + the camera calibration."],
               "Medium", "about 1–2 weeks once markings are drawn")],
        "lidar": [
            _M("Simulated LiDAR scan + points per object", True,
               "In use: the 3D page shoots the LiDAR's rays; each point is counted on the object it hits; enough "
               "points = a detection.",
               "Ray casting against the 3D scene with the climate's extinction, noise and false returns; points are "
               "grouped by the object they hit (known from the scene); ≥ 4 points = detected; gap = nearest point."),
            _R("Point-cloud clustering (grid / Euclidean)",
               "The unlabelled points are grouped by the app itself: ground removal, weather filter, clustering, "
               "tracking.",
               "Points higher than 0.3 m (flat yard); within 12 m a point needs neighbours in its 0.2 m cell (fog / "
               "rain returns are sparse); touching 0.6 m cells form one cluster (≥ 5 points); the distance is the "
               "nearest point inside our driving corridor; tracks L1 …."),
            _M("PointPillars / CenterPoint 3D detection network", False,
               "A neural network on the point cloud gives 3D boxes with type.",
               "The point cloud is turned into a bird's-eye grid of pillars / voxels; the network outputs 3D boxes "
               "(centre x, y, z, length, width, height, yaw) + class + score. Distance = from the box to our AV. "
               "Names: a tracker id; scene names by matching the boxes with the scene objects.",
               [("Grouping of points", "Known from the scene (perfect)", "Learned (can merge / split objects)"),
                ("Type", "None", "Car / truck / pedestrian ..."),
                ("Sparse far objects", "≥ 4 points is enough", "Needs more points; misses small far objects"),
                ("Compute", "Counting", "~20–60 ms per scan on a GPU; slow on a CPU")],
               ["The point cloud from the 3D page to Python per scan (tens of thousands of points, ~10 Hz).",
                "A model trained on a LiDAR like ours (beam count / mounting differ from KITTI / nuScenes) — likely "
                "fine-tuning on simulated + recorded data.",
                "GPU runtime (PyTorch / TensorRT, OpenPCDet / mmdetection3d).",
                "A tracker + box ↔ scene matching for the names."],
               "Very high", "about 4–8 weeks, mostly the model / training and the GPU setup"),
            _M("DBSCAN / Euclidean clustering + 3D boxes", False,
               "Grouping the points without knowing the objects, then fitting boxes.",
               "Ground points are removed (height / RANSAC plane); the rest is clustered: points closer than ~0.5 m "
               "to each other form one object (DBSCAN); a box is fitted to each cluster; gap = its nearest point.",
               [("Grouping of points", "Known from the scene (perfect)",
                 "By distance — close objects merge, a trailer can split"),
                ("False objects", "Weather points are never objects", "Fog / rain points can form clusters"),
                ("Name", "From the scene", "Cluster → nearest scene object (matching)"),
                ("Compute", "Counting", "~5–20 ms per scan (scikit-learn / Open3D)")],
               ["The point cloud per scan to Python (or clustering inside the web page in JavaScript).",
                "Ground removal + clustering parameters tuned per climate.",
                "Cluster ↔ scene-object matching for the names in the reports."],
               "Medium", "about 1–2 weeks")],
        "radar": [
            _M("Physical 77 GHz radar model (radar equation + tracker)", True,
               "In use: signal-to-noise from the radar equation, detection probability per scan, weather losses, "
               "confirmation over scans; Doppler gives the speed.",
               "An object-level model: no echoes are simulated, the detection probability is computed per object "
               "and drawn every scan."),
            _R("Beam scan + CFAR + clustering",
               "Echo points per 1° beam with power and Doppler, thresholded, clustered and tracked — no names.",
               "Each beam is traced to the first object outline (a second echo under a high truck); its power from the "
               "radar equation with the weather loss and a random (Swerling) fluctuation; above the CFAR threshold "
               "(+4 dB for standing echoes) it is a point (range, angle, Doppler with noise); rain clutter adds false "
               "points; points within 2 m with the same Doppler form an object; tracks R1 … (3 of 4 scans). Not a "
               "full signal simulation (no FFT / range-Doppler map)."),
            _M("Raw radar point cloud + CFAR detection", False,
               "Detections from simulated radar echoes (range-Doppler map).",
               "Echoes of the scene (ray tracing at 77 GHz) form a range-Doppler(-angle) map; CFAR (constant false "
               "alarm rate) finds the peaks above the local noise; the peaks are clustered into objects.",
               [("Detection", "Probability per object (formula)", "Peaks in a simulated signal"),
                ("Ghosts / multipath", "None", "Yes — guard rails, under the truck, mirror targets"),
                ("Angle resolution", "Exact positions", "A few degrees — close objects merge"),
                ("Compute", "Microseconds", "Heavy: radar ray tracing per scan")],
               ["A radar ray tracer in the 3D page (materials' reflectivity at 77 GHz).",
                "Signal processing (FFT range / Doppler, CFAR, clustering) in Python / numpy.",
                "The radar's real parameters (chirps, antennas) to be meaningful."],
               "Very high", "about 6–10 weeks"),
            _M("4D imaging radar (height + many points)", False, "A high-resolution radar with elevation.",
               "Like a sparse LiDAR that works in fog: hundreds of points per scan with range, angle, height and "
               "Doppler; objects by clustering.",
               [("Points", "One detection per object", "Hundreds of points per scan"),
                ("Height", "None", "Yes — bridges / signs are not taken for obstacles")],
               ["A point-level radar model (as the raw radar above, with elevation).",
                "Clustering / a detector for radar points."],
               "Very high", "about 6–10 weeks")],
        "v2v": [
            _M("Direct C-V2X (PC5 sidelink)", True,
               "Integrated — choose it in the collision test setup (V2V settings): ~20 ms, ~450 m, buildings block.",
               "Messages straight between the vehicles; delay, range, building blocking and loss decided per "
               "message."),
            _M("Cellular 4G / 5G (V2N)", True,
               "Integrated — choose it in the collision test setup (V2V settings): ~90 ms, through the network.",
               "Messages through the operator's network: longer delay, no building blocking."),
            _M("DSRC / IEEE 802.11p", False, "The older Wi-Fi based V2V radio.",
               "Like PC5 (direct, 5.9 GHz, ~2–5 ms access delay, ~300 m), CSMA channel access: with many vehicles "
               "the channel gets busy and messages are lost (congestion).",
               [("Delay", "PC5 ~20 ms", "~2–10 ms"), ("Range", "~450 m", "~300 m"),
                ("Many vehicles", "No congestion modelled", "Losses grow with the channel load")],
               ["A link entry in v2v.LINKS (delay / range / loss) — simple.",
                "For realism: a channel-load model (more vehicles → more loss)."],
               "Low", "about 1–3 days (the parameters); a congestion model ~1 week"),
            _M("Standard messages: SAE J2735 BSM / ETSI CAM, DENM (ASN.1) + IEEE 1609.2 signing", False,
               "The simulation sends plain data — the safety logic is tested, not the encoding / security.",
               "Each message encoded in ASN.1 UPER (BSM ~40–300 bytes), signed with a certificate (1609.2) and "
               "verified by the receiver; invalid / unsigned messages are dropped.",
               [("Content", "Plain Python data", "Standard binary messages (interoperable)"),
                ("Security", "None", "Signing / verification, certificate handling (+ ~1–3 ms)"),
                ("Use", "The safety logic", "Testing real V2V software / units")],
               ["An ASN.1 library (asn1tools) + the J2735 / CAM schemas.",
                "1609.2 signing (cryptography) + test certificates.",
                "Only worth it to connect real V2V units / software (hardware in the loop)."],
               "Medium", "about 2–3 weeks"),
            _M("Roadside units (RSU, V2I)", False, "Not needed for collision testing.",
               "Fixed units at junctions / gates relay messages and send signal / hazard information.",
               [("Coverage", "Vehicle to vehicle only", "+ relays around corners, signal phases")],
               ["Placing RSUs on the map, an RSU link model, I2V messages (SPaT / MAP)."], "Medium",
               "about 2 weeks")],
        "fusion": [
            _M("Nearest object in the lane from any sensor (late fusion)", True,
               "In use: each sensor gives its objects; the nearest one in the AV's lane is the target.",
               "Objects are merged by their scene id; the nearest distance of any sensor is used."),
            _R("Tracking per sensor + matching by position",
               "Each sensor's measurements become tracks (alpha-beta filter, confirmed after M of N); tracks are "
               "matched to the real objects by position only to name them.",
               "Nearest-neighbour association within a gate, position + speed smoothed, coasting when missed; the "
               "nearest confirmed track in the lane is the target; unmatched tracks are 'unknown objects' and are "
               "braked for too."),
            _M("Kalman / multi-object tracking (EKF, IMM)", False, "Tracks with position + speed estimates per object.",
               "Each object is a track with a state (position, speed, acceleration) and its uncertainty; every "
               "measurement (LiDAR, radar, camera) updates it weighted by its accuracy (Kalman gain); the "
               "association of measurements to tracks by distance (Hungarian / JPDA), not by the scene id.",
               [("Association", "By scene id (perfect)", "By distance — can swap / lose objects"),
                ("Speed", "Radar / V2V, else gap change", "Estimated from all sensors, smoother"),
                ("Noise", "Nearest value wins", "Weighted by each sensor's accuracy")],
               ["A tracker module (filterpy / own EKF) between the sensors and the braking.",
                "Measurement noise per sensor and climate.", "Association without the scene id."],
               "Medium", "about 1–3 weeks"),
            _M("Early fusion (camera pixels + LiDAR points)", False, "Fusing the raw data before detection.",
               "LiDAR points projected into the camera picture (colour + depth per point) and one network detects "
               "on both.",
               [("Input", "Each sensor's objects", "Raw pictures + point clouds together")],
               ["Camera images + point clouds per frame in Python, the calibration between them, a fusion network "
                "(GPU)."], "Very high", "about 6+ weeks")],
        "brake": [
            _M("Gap keeping + needed deceleration + AEB on TTC", True,
               "In use: keeps the set gap, brakes as hard as needed to stop short, full brake when TTC is below "
               f"{ft.TTC_CRIT_S:g} s.",
               "A rule-based controller on the perceived target."),
            _M("Model predictive control (MPC)", False, "Optimising speed over the next seconds.",
               "Every step it plans the speed for the next ~5 s (comfort, gap, limits of braking / grip) and applies "
               "the first step.",
               [("Behaviour", "Rules (follow / brake / AEB)", "Smooth, plans ahead"),
                ("Compute", "Microseconds", "1–10 ms per step (an optimiser)")],
               ["An MPC solver (cvxpy / CasADi) + a vehicle model."], "Medium", "about 2 weeks"),
            _M("Driver warning only (FCW, no automatic brake)", False, "Only warnings, the driver brakes.",
               "A forward-collision warning at TTC below ~2.5 s; braking after a driver reaction time (~1.2 s).",
               [("Who brakes", "The AV automatically", "A modelled driver after a reaction time")],
               ["A driver model (reaction time, braking) in follow_test."], "Low", "about 2–4 days")],
    }


# ------------------------------------------------------------------ how OUR app does it: data in → calculation → out
SCENE, PY, WEB, OUT_C = "#94A3B8", "#93C5FD", "#F0ABFC", "#86EFAC"


def _flows():
    """topic -> (data-flow spec for sensor_graphics.Diagram('dataflow'), [key facts (html)])."""
    cam, rad = ft.FRONT_CAMERA, ft.FRONT_RADAR
    lk = v2v.LINKS["pc5"]
    return {
        "flow": ([
            {"boxes": [("MAP PAGE (the scene)", "Leaflet map, JavaScript",
                        ["all trucks, trailers, vehicles, obstacles", "positions, size, type, heading, speed",
                         "the climate chosen"], SCENE, False),
                       ("TEST LOOP (Python)", "every 100 ms, per AV",
                        ["camera + radar: calculated here", "LiDAR: asked from the 3D page", "V2V: messages here",
                         "fusion → braking → move the AV", "ground truth → collision?"], PY, False),
                       ("3D PAGES", "three.js, JavaScript",
                        ["LiDAR ray scan (every 250 ms)", "camera pictures (for showing)", "3D accident scene"],
                        WEB, False),
                       ("TEST WINDOW", "3 times a second",
                        ["cards, sensor icons, distances", "detection details", "collisions + results"], OUT_C, False)],
             "arrows": ["object list", "positions", "results"]}],
            ["The AV <b>never sees the 'truth'</b>: it brakes only on what its sensors' calculations give. The "
             "truth (real positions) is used only to judge: TTC real, collision yes / no.",
             "Everything happens on this PC — no real sensor data and no network; MQTT is not used by the test."]),
        "camera": ([
            {"title": "Simulated set-up: detection — what the AV brakes on (every 100 ms)", "title_col": OUT_C,
             "boxes": [("RECEIVES", "from the map page",
                        ["every object: id, name, position, length, width, type, heading, speed",
                         "our AV: position + heading on its route",
                         f"camera set-up: {cam['hfov_deg']:g}° view, {cam['max_range_m']:g} m, mounting",
                         "weather: visibility, day / night, rain / snow"], SCENE, False),
                       ("CALCULATES", "Python · follow_test.camera_detect",
                        ["each object into the AV's frame (x ahead, y left)",
                         "inside the view angle? closer than the range?", "hidden behind a nearer one?",
                         "type + confidence from the distance"], COL["camera"], False),
                       ("SENDS", "→ fusion (Follower.perceive)",
                        ["name = the object's scene id / label", "distance (gap, m)", "x / y position",
                         "type + confidence %", "sensor = camera"], OUT_C, False)],
             "arrows": ["object list", "detections"]},
            {"title": "Camera picture — ONLY for showing (Detection details, collision images)", "title_col": WEB,
             "boxes": [("3D CAMERA PAGE", "yard3d.html · frontCamShot (three.js)",
                        ["gets the positions + the camera mounting", "renders the picture with fog / rain / night",
                         "projects every object into it as a box (pixels)"], WEB, True),
                       ("RETURNS", "→ Python",
                        ["JPEG picture", "per object: box x0 y0 x1 y1, height (m), distance"], WEB, True),
                       ("DRAWN ON IT", "Python · Detection details",
                        ["green box = detected, red = missed + why",
                         "distance on the box = focal × height ÷ box height", "NOT used for braking"], WEB, True)],
             "arrows": ["shot", "boxes"]}],
            ["<b>Does the app find the vehicle's name / distance from the picture? In the Simulated set-up: no.</b> "
             "The name comes from the scene data (each object's id / label) and the distance from geometry "
             "(positions and lengths). <b>In the Real-world set-up: yes</b> — the picture is processed (see the topic "
             "<i>Real-world set-up</i>).",
             "The picture is rendered only so you can <b>see</b> what the camera would see; the boxes are drawn from "
             "the scene's 3D positions, and the distance written on a box is worked out from its size in the picture "
             "(focal length × real height ÷ box height in pixels) — to compare with the real distance."]),
        "lidar": ([
            {"boxes": [("PYTHON SENDS", "every 250 ms → 3D sensor page",
                        ["all positions (trucks, trailers, obstacles)",
                         f"lidarDetect(report range {ft.REPORT_RANGE_M:g} m)"], PY, False),
                       ("3D SENSOR PAGE", "yard3d.html · JavaScript (three.js)",
                        ["casts the AV's real LiDAR ray pattern", "each ray: nearest surface hit → a point",
                         "fog / rain: drops returns, adds noise + false points",
                         "counts the points on each object; ≥ 4 → detection"], COL["LiDAR"], False),
                       ("RETURNS", "→ Python",
                        ["per AV: id + name of each detected object", "points count",
                         "gap (nearest point), range", "x / y in the AV's frame, lat / lng"], WEB, False)],
             "arrows": ["runJavaScript", "result"]},
            {"boxes": [("PYTHON, every 100 ms", "_route_tick",
                        ["uses detections younger than 0.6 s", "places them along its route",
                         f"keeps those in its lane (±{ft.CORRIDOR_HALF_M:g} m)"], PY, False),
                       ("SENDS", "→ fusion (Follower.perceive)",
                        ["name, distance along the route", "points", "sensor = LiDAR"], OUT_C, False)],
             "arrows": ["lane filter"]}],
            ["<b>The LiDAR is the one sensor really simulated from the 3D scene:</b> rays are traced against the 3D "
             "models. The <b>name</b> is the object the rays hit (the 3D model belongs to that vehicle); the "
             "<b>distance</b> is its nearest point to our AV's body.",
             "In collision testing the detection result is used, not the full point cloud (the cloud is drawn in the "
             "3D / LiDAR views)."]),
        "radar": ([
            {"boxes": [("RECEIVES", "from the map page, every 100 ms",
                        ["every object: id, name, position, size, type, moving?, heading, speed",
                         "our AV: position, heading, speed", "weather: rain / snow rate, visibility"], SCENE, False),
                       ("CALCULATES", "Python · follow_test.radar_detect",
                        [f"in the {rad['hfov_deg']:g}° beam?", "signal margin = radar equation − weather (dB)",
                         "detection chance Pd → random draw this scan",
                         f"tracker: {rad['confirm']} of {rad['window']} scans; distance noise"], COL["radar"], False),
                       ("SENDS", "→ fusion (Follower.perceive)",
                        ["name (tracked object's id / label)", "distance (+ noise)", "relative speed (Doppler)",
                         "Pd, signal margin, coasting", "sensor = radar"], OUT_C, False)],
             "arrows": ["object list", "detections"]}],
            ["<b>No radio echoes are simulated</b>: the radar is a formula per object (how strong its echo would be "
             "at this distance in this weather), drawn as a chance every 100 ms. The name comes from the scene data.",
             "The speed is the object's real speed from the scene minus ours (what Doppler would measure)."]),
        "v2v": ([
            {"boxes": [("EACH SENDER", "v2v.Channel.step",
                        ["10× a second (slower in heavy traffic): id, name, GPS position (+ error), speed, heading, "
                         "acceleration, length, brake",
                         f"BRAKE ALERT at once (≤ −{v2v.BRAKE_ALERT:g} m/s² or stop)"], COL["V2V"], False),
                       ("THE RADIO", "Python · v2v.Channel",
                        ["per receiver: lost? (loss %, range, buildings, channel busy %)",
                         f"delivered after ~{lk['delay_ms']:g} ± {lk['jitter_ms']:g} ms (PC5)",
                         "kept in a queue until then"], PY, False),
                       ("EACH RECEIVER", "every 100 ms",
                        [f"fresh only: age ≤ delay + {v2v.STALE_S:g} s", "placed on its route; in our lane?",
                         "gap = x − our length/2 − its length/2"], COL["V2V"], False),
                       ("SENDS", "→ fusion",
                        ["name, distance, its speed", "brake yes / no, message age", "sensor = V2V"], OUT_C, False)],
             "arrows": ["message", "delivered", "V2V list"]}],
            ["<b>Messages are Python data</b> (no radio hardware, no network): the channel decides for every message "
             "and receiver whether and when it arrives.",
             "The <b>name</b> is written in the message; the <b>distance</b> comes from the GPS position the sender "
             "reports (with its GPS error), not from a sensor."]),
        "fusion": ([
            {"boxes": [("RECEIVES", "every 100 ms",
                        ["LiDAR list", "camera list", "radar list", "V2V list (if on, brake mode)",
                         "prediction (target lost in a bend)"], SCENE, False),
                       ("CALCULATES", "Python · Follower.perceive",
                        [f"drop objects outside the lane (±{ft.CORRIDOR_HALF_M:g} m)",
                         "merge by object id, keep each sensor's distance", "target = the nearest",
                         "its speed: radar / V2V, else from the gap change"], "#F472B6", False),
                       ("SENDS", "→ braking (Follower.step)",
                        ["target name + distance", "its speed", "which sensors see it + their distances"],
                         OUT_C, False)],
             "arrows": ["4 lists", "target"]}],
            ["The same vehicle from several sensors is matched by its <b>scene id</b> (a real car would match by "
             "position)."]),
        "real": ([
            {"title": "Camera (real-world)", "title_col": COL["camera"],
             "boxes": [("3D CAMERA PAGE", "every AV, in turn",
                        ["renders its camera picture (this climate)", "no object positions sent"], WEB, False),
                       ("PICTURE PROCESSING", "Python · real_camera.detect",
                        ["road colours → road / not road per pixel", "lowest obstacle per column = ground contact",
                         "distance = h_cam ÷ tan(angle)", "group columns, type from width"], COL["camera"], False),
                       ("TRACKER", "Python · real_sensors.Tracker",
                        ["confirmed after 2 of 3 pictures", "track id C1 …, speed from the gap change"], PY, False),
                       ("SENDS", "→ fusion", ["track, distance, type + confidence", "classified ones only"],
                        OUT_C, False)],
             "arrows": ["picture", "objects", "tracks"]},
            {"title": "LiDAR (real-world)", "title_col": COL["LiDAR"],
             "boxes": [("3D SENSOR PAGE", "every 250 ms",
                        ["ray-traced points (east, north, height)", "NOT what they hit"], WEB, False),
                       ("POINT PROCESSING", "Python · real_sensors.lidar_clusters",
                        ["ground removal, fog / rain filter", "clusters of touching 0.6 m cells (≥ 5 points)",
                         "nearest point in our corridor"], COL["LiDAR"], False),
                       ("TRACKER", "Python", ["2 of 3 scans", "track id L1 …"], PY, False),
                       ("SENDS", "→ fusion", ["track, distance, points"], OUT_C, False)],
             "arrows": ["cloud", "clusters", "tracks"]},
            {"title": "Radar (real-world)", "title_col": COL["radar"],
             "boxes": [("BEAM SCAN", "Python · real_sensors.radar_scan, every 100 ms",
                        ["1° beams → first outline hit", "echo power + fluctuation", "CFAR threshold → points",
                         "Doppler, rain clutter"], COL["radar"], False),
                       ("CLUSTERS", "Python · radar_clusters",
                        ["points within 2 m, same Doppler", "single weak standing echo dropped"], PY, False),
                       ("TRACKER", "Python", ["3 of 4 scans; standing: 0.8 s", "track id R1 …"], PY, False),
                       ("SENDS", "→ fusion", ["track, distance, relative speed"], OUT_C, False)],
             "arrows": ["points", "objects", "tracks"]}],
            ["<b>The difference to the simulated set-up:</b> no sensor is told what is in the scene — the camera "
             "looks at the picture, the LiDAR groups unlabelled points, the radar thresholds echoes. Names are added "
             "afterwards only for the reports (matching each track to the real object at its position).",
             "V2V, fusion (nearest in the lane) and braking work the same in both set-ups."]),
        "brake": ([
            {"boxes": [("RECEIVES", "every 100 ms",
                        ["target: distance, speed", "own speed, set gap, top speed", "road grip (climate)"],
                        SCENE, False),
                       ("CALCULATES", "Python · Follower.step",
                        ["TTC = distance ÷ closing speed", "needed deceleration", "follow / brake / AEB"],
                        COL_BRAKE, False),
                       ("SENDS", "→ the AV on the map",
                        ["new speed", "moves along the route: s + speed × 0.1 s", "new position → map + 3D pages"],
                        OUT_C, False)],
             "arrows": ["target", "speed"]},
            {"title": "Ground truth — only to judge, not to drive", "title_col": "#FCA5A5",
             "boxes": [("TRUE POSITIONS", "Python, every 100 ms",
                        ["real gap to the nearest object in the lane", "real TTC"], SCENE, True),
                       ("TOUCH?", "gap ≤ 0.2 m while moving",
                        ["COLLISION record: speeds, sensors, camera + 3D images, reason"], "#FCA5A5", True)],
             "arrows": ["check"]}],
            ["The AV brakes on the <b>perceived</b> target; the real positions are only used to count TTC / "
             "collisions."]),
    }


def _current_mode():
    """The sensor set-up in use (top bar 'Sensors')."""
    try:
        import site_config as cfg
        m = str(((cfg.APP_SETTINGS or {}).get("collision_sensors") or {}).get("mode", "sim"))
    except Exception:
        m = "sim"
    return m if m in ("sim", "real") else "sim"


def _flows_real():
    """The REAL-WORLD set-up's data flow per sensor topic (the 'real' topic's rows, one each)."""
    rows = _flows()["real"][0]
    by = {"camera": rows[0], "lidar": rows[1], "radar": rows[2]}
    out = {k: ([dict(v, title=None)], []) for k, v in by.items()}
    out["camera"][1].extend([
        "<b>Real-world set-up: the obstacles are found IN THE PICTURE.</b> The camera page renders each AV's "
        "picture (no object positions are sent); Python finds the road / not-road split and the ground contact; the "
        "distance comes from the camera's height and tilt.",
        "The name is not in the picture: the track C3 is matched to the real object at its position afterwards — "
        "only to name it in the cards and reports."])
    out["lidar"][1].append("<b>Real-world set-up:</b> the LiDAR page sends the measured points only — not what "
                           "they hit. Grouping, distance and tracking are done by the app, as a real LiDAR stack.")
    out["radar"][1].append("<b>Real-world set-up:</b> echoes per beam with power, fluctuation and a CFAR threshold — "
                           "objects come from clustering the detection points, not from the scene's list.")
    out["fusion"] = ([{"boxes": [
        ("RECEIVES", "every 100 ms", ["camera tracks C…", "LiDAR tracks L…", "radar tracks R…", "V2V messages"],
         SCENE, False),
        ("FUSION", "Python · _real_detect + Follower.perceive",
         ["each track at its measured position", "a standing camera-only one needs LiDAR / radar",
          "lane test: its edge vs our width + 0.3 m", "nearest in the lane = target"], "#F472B6", False),
        ("SENDS", "→ braking", ["target distance + speed", "which sensors / tracks see it"], OUT_C, False)],
        "arrows": ["tracks", "target"]}],
        ["Tracks are matched to the real objects by position only to name them; unmatched ones are 'unknown "
         "object' — and braked for if in the lane."])
    return out


def _quick_real():
    """The REAL-WORLD set-up's 'In short' of the sensor topics."""
    return {
        "camera": [
            ("PURPOSE", "The AV's <b>eyes</b> — here it really looks at the <b>picture</b> to find obstacles."),
            ("HOW IT WORKS", "Road colours learned from the bottom of the picture → each pixel column scanned upward "
                             "→ where the road ends for good (≥ 0.8 m high) an obstacle stands → columns grouped."),
            ("OUTPUTS", "Track id (C3) · <b>distance</b> · type from its width (truck / car / person) + confidence."),
            ("FORMULA", "Distance = camera height ÷ tan(angle below the horizon). <i>2.4 m ÷ tan(9.2°) = "
                        "<b>14.8 m</b></i>.<br>Confidence from the contrast to the road; below 50 % only 'object' "
                        "(not braked for)."),
            ("LIMITATIONS", "Fog / rain / night lower the contrast → missed · objects lower than ~0.8 m missed · the "
                            "distance gets coarser far away · ~1 picture / s per AV here.")],
        "lidar": [
            ("PURPOSE", "A <b>laser scanner</b> — here its raw points are grouped by the app, as on a real AV."),
            ("HOW IT WORKS", "Points (no labels) → ground + the map's buildings / poles removed → sparse fog / rain "
                             "points filtered → touching 0.6 m cells form an object."),
            ("OUTPUTS", "Track id (L4) · <b>distance</b> · number of points."),
            ("FORMULA", "Distance = the nearest point <b>inside our driving corridor</b> (our width + 0.3 m).<br>An "
                        "object needs ≥ 5 points; confirmed after 2 of 3 scans."),
            ("LIMITATIONS", "Whiteout fog: a wall of returns near the sensor · close objects may merge / a long one "
                            "split.")],
        "radar": [
            ("PURPOSE", "<b>Radio waves</b> — here as echo points per beam, thresholded and clustered."),
            ("HOW IT WORKS", "1° beams → first outline hit → echo power (radar equation, weather, random "
                             "fluctuation) → above the CFAR threshold = a point with range, angle, Doppler."),
            ("OUTPUTS", "Track id (R2) · <b>distance</b> · <b>speed</b> (Doppler)."),
            ("FORMULA", "Points within 2 m with the same speed = one object · 3 of 4 scans → confirmed · standing "
                        "echoes need 0.8 s (clutter)."),
            ("LIMITATIONS", "Rain clutter · a standing target is confirmed later · no full signal simulation (no "
                            "FFT).")],
        "fusion": [
            ("PURPOSE", "Puts the sensors' <b>tracks</b> together into one target."),
            ("HOW IT WORKS", "Tracks at their measured positions; a standing object only the camera sees needs LiDAR "
                             "or radar to agree; the nearest one in the lane is the target."),
            ("OUTPUTS", "Target distance + speed, which tracks see it."),
            ("FORMULA", "In the lane: its edge within our width + 0.3 m of the route."),
            ("LIMITATIONS", "Names only from matching to the real objects (reports) · phantoms in the lane are braked "
                            "for.")],
    }


COL_BRAKE = "#F87171"
COL.setdefault("V2V", "#34D399")
COL.setdefault("LiDAR", "#22D3EE")


# ------------------------------------------------------------------ the quick view (for a new person)
def _quick():
    """topic -> [(label, text)]: a few plain lines; the full details are behind 'Show full details'."""
    fog = _clim("fog")
    r_fog = ft.camera_range(fog)
    r_wf = ft.lidar_range(_clim("whiteout_fog"))
    v = 40 / 3.6
    return {
        "flow": [
            ("IDEA", "AVs drive a route one behind the other. Each AV brakes <b>only on what its own sensors "
                     "see</b> — like a real self-driving vehicle."),
            ("EACH MOMENT", "Sensors look → the nearest vehicle in its lane is the <b>target</b> → the AV keeps "
                            "its distance or brakes → if the real bodies touch, it is a <b>collision</b>."),
            ("YOU TEST", "Change the weather, the speed, stop &amp; go, or switch sensors off — and see when it "
                         "fails."),
            ("RESULT", "Per loop and AV: PASS / FAIL, collisions (with the reason), collisions prevented by V2V.")],
        "camera": [
            ("PURPOSE", "The AV's <b>eyes</b> — the only sensor that tells <b>what</b> the object is (truck, car, "
                        "person)."),
            ("HOW IT WORKS", f"It looks ahead in a {ft.FRONT_CAMERA['hfov_deg']:g}° wide view. A vehicle is seen when "
                             f"it is inside that view, <b>closer than the camera's range</b> and not hidden behind "
                             f"another vehicle."),
            ("OUTPUTS", "Name · <b>type</b> (truck / car / person) with a confidence % · <b>distance</b>."),
            ("FROM THE PICTURE?", "<b>Simulated set-up: no</b> — the name and distance come from the scene data, the "
                                  "picture is only for showing. <b>Real-world set-up: yes</b> — the obstacles are "
                                  "found in the picture itself (top bar <b>Sensors</b>)."),
            ("FORMULA", f"Range = <b>½ × visibility</b> (max {ft.FRONT_CAMERA['max_range_m']:g} m; × 0.45 at night). "
                        f"<i>Fog {fog.get('visibility_m')} m → {r_fog:.0f} m.</i><br>"
                        "Distance = how far ahead − ½ our length − ½ its length. <i>40 − 3.5 − 8.25 = <b>28 m</b></i>."
                        "<br>Confidence = 1 − 0.75 × distance ÷ range. <i>1 − 0.75 × 28 ÷ 60 = <b>65 %</b></i> "
                        "(below 50 %: only 'object')."),
            ("LIMITATIONS", "Fog, rain, snow and night shorten its range · cannot see through the vehicle ahead · "
                            "in this simulation no picture is analysed (no misses / false alarms) and the name comes "
                            "from the scene.")],
        "lidar": [
            ("PURPOSE", "A <b>laser scanner</b>: measures the distance very precisely (centimetres), day and night."),
            ("HOW IT WORKS", "It shoots thousands of laser rays. Each ray that hits a vehicle gives a <b>point</b>. "
                             "Enough points on one vehicle = detected."),
            ("OUTPUTS", "Name (the vehicle the points landed on) · <b>distance</b> · number of points. No type, no "
                        "speed."),
            ("FORMULA", "Detected when <b>points ≥ 4</b>.<br>Distance = to the <b>nearest point</b> on it. "
                        "<i>e.g. 12.3 m</i>.<br>In fog a ray comes back with probability e<sup>−2 × fog × distance"
                        f"</sup> → <i>whiteout fog: only within ~{r_wf:.0f} m</i>."),
            ("LIMITATIONS", "Fog, heavy rain, snow and dust kill the rays · short range on these AVs (~15 m) · "
                            "in this simulation points are grouped by the object they hit (no grouping mistakes).")],
        "radar": [
            ("PURPOSE", "<b>Radio waves</b>: sees far, <b>through fog</b>, and measures the <b>speed</b> at once."),
            ("HOW IT WORKS", "It sends radio waves; a vehicle reflects an <b>echo</b>. Strong echo = detected. The "
                             "echo's frequency shift (Doppler) tells the speed."),
            ("OUTPUTS", "Name (the tracked object) · <b>distance</b> · <b>speed</b> (closing / opening)."),
            ("FORMULA", f"Echo strength falls with distance⁴ → a truck is seen up to ~{ft.FRONT_RADAR['max_range_m']:g} m,"
                        " a person much closer.<br>Detected after <b>2 of 3</b> scans.<br>"
                        "Speed = its speed − ours. <i>20 − 40 km/h = closing at <b>20 km/h</b></i>."),
            ("LIMITATIONS", "Cannot tell the type · weak on people and standing objects · some loss in heavy rain / "
                            "snow · in this simulation no ghost echoes and exact positions.")],
        "v2v": [
            ("PURPOSE", "Vehicles <b>talk to each other</b>: “I am here, this fast, I am braking!” — known even when "
                        "no sensor can see it (fog, far away, behind another vehicle)."),
            ("HOW IT WORKS", "<b>① Send</b>: every connected vehicle broadcasts a small message <b>10 times a "
                             "second</b> (and a <b>BRAKE ALERT</b> at once when it brakes hard) — to everyone in "
                             "range, not to one receiver.<br><b>② Radio</b>: ~20 ms (direct) / ~90 ms (cellular); "
                             "some messages are lost; buildings block the direct link.<br><b>③ Receive</b>: our AV "
                             "keeps the <b>latest</b> message of every sender.<br><b>④ Check</b>: fresh? in my lane? "
                             "ahead? going my way?<br><b>⑤ Use</b>: its distance and speed → brake like on a sensor."),
            ("THE RADIO IN OUR APP", "<b>No real radio signal is sent</b> — no antenna, no network, no 5.9 GHz waves. "
                                     "Each message is a <b>data record</b> inside the PC; the <b>channel</b> (Python, "
                                     "v2v.Channel) decides for every message and receiver: <b>① close enough?</b> "
                                     "(~450 m, ~150 m behind buildings) · <b>② a building on the straight line?</b> (the "
                                     "map's building outlines) · <b>③ lost by chance?</b> (1 % + the setup's loss + "
                                     "rain + busy channel) · <b>④ when</b> (~20 ms later, waits in a queue). In real "
                                     "life the same message travels as radio waves; the app copies what matters for "
                                     "braking: reach, blocking, loss and delay. Steps 5–10 of the picture show it."),
            ("IN ONE MESSAGE", "<b>Sender id · time · latitude · longitude · heading · speed · acceleration · brake "
                               "flag · length · type</b> (state or BRAKE ALERT). ~300 bytes on the air with the "
                               "security signature. <i>e.g. Truck_auto_1 · 12:04:31.250 · 8.558421, 76.882541 · "
                               "169° · 5.6 m/s · −4.8 m/s² · brake YES · 16.5 m · BRAKE ALERT</i>. Not in it: the "
                               "distance (the receiver works it out), no camera picture."),
            ("HEAVY TRAFFIC", "All vehicles in range share one radio channel: 100 vehicles ≈ 20 % busy (fine), 300 ≈ "
                              "60 % → messages collide (more loss) and <b>congestion control</b> slows every sender "
                              "(10 → 5 → 2 a second). The receiver must also check every message's signature "
                              "(~2000 / s per unit). Try it: setup → V2V → <i>Heavy traffic: extra connected vehicles "
                              "nearby</i>."),
            ("OUTPUTS", "Name (in the message) · <b>distance</b> · its <b>speed</b> · braking yes / no · message age."),
            ("FORMULA", "Distance = its GPS position along our route − ½ our length − ½ its length. "
                        "<i>30 − 3.5 − 8.25 = <b>18 m</b></i> (GPS error ~2.5 m).<br>"
                        "Used only if fresh: age ≤ delay + 0.3 s (PC5 delay ~20 ms, range ~450 m)."),
            ("LIMITATIONS", "Only <b>connected</b> vehicles (not people / obstacles) · GPS error · lost or late "
                            "messages · buildings block the direct radio."),
            ("SEE IT LIVE", "Detection details → tab <b>V2V messages</b> (or click the V2V tile): the 5 steps, what "
                            "the AV <b>sends</b> and <b>receives</b> (delivered / lost, radio delay), the "
                            "<b>traffic</b> (vehicles in range, channel busy %, messages / s, the app's own cost), one "
                            "message <b>field by field</b>, and every message it holds now — <b>used</b> (in its lane "
                            "ahead) or why not.")],
        "fusion": [
            ("PURPOSE", "Puts all sensors together into <b>one target</b> to brake on."),
            ("HOW IT WORKS", f"Ignore objects outside our lane (±{ft.CORRIDOR_HALF_M:g} m); take the <b>nearest</b> "
                             "object any sensor sees."),
            ("OUTPUTS", "Target name · distance · its speed · which sensors see it."),
            ("FORMULA", "Target = nearest in lane. <i>LiDAR 12.4 m, radar 12.6 m, camera nothing → "
                        "<b>12.4 m</b></i>.<br>Speed: radar / V2V directly, else from how the distance changes."),
            ("LIMITATIONS", "The nearest value wins (no weighting by accuracy) · objects matched by their scene id.")],
        "brake": [
            ("PURPOSE", "Decides the AV's speed from the target: follow, brake, or full brake."),
            ("HOW IT WORKS", f"TTC below {ft.TTC_WARN_S:g} s: warning · brake as hard as needed to stop "
                             f"{ft.STOP_GAP_M:g} m short · TTC below {ft.TTC_CRIT_S:g} s: <b>full brake (AEB)</b>."),
            ("OUTPUTS", "Speed · braking level · TTC (perceived and real) · warnings."),
            ("FORMULA", f"TTC = distance ÷ closing speed. <i>25 m at 40 km/h → <b>{25 / v:.1f} s</b></i>.<br>"
                        f"Brake needed = speed² ÷ (2 × (distance − {ft.STOP_GAP_M:g} m)).<br>"
                        f"Full brake = {ft.A_FULL:g} m/s² × road grip (fog 90 %, heavy rain 70 %, snow 60 %)."),
            ("LIMITATIONS", "Brakes act at once (no delay) · no swerving · load does not change braking.")],
        "climate": [
            ("WHAT", "The weather changes how far each sensor sees."),
            ("FOG", "Camera and LiDAR lose most; radar and V2V almost not affected."),
            ("RAIN / SNOW", "Camera and LiDAR weaker, radar loses a little, the road is slippery."),
            ("NIGHT", "Camera range less than half.")],
        "real": [
            ("PURPOSE", "Test the <b>perception</b> too: each sensor finds the objects in its own measurements, as on a "
                        "real AV — so misses, wrong distances and phantom objects can happen. Choose it with the "
                        "top bar's <b>Sensors</b> button (applies to tests started after)."),
            ("CAMERA", "The rendered picture → road colours learned from the bottom → per pixel column: where the road "
                       "stops for good = an obstacle's ground contact → distance = camera height ÷ tan(angle below "
                       "the horizon) → grouped, type from the width → tracked (C1 …). Unclassified ones are not "
                       "braked for."),
            ("LiDAR", "Unlabelled point cloud → ground removal (height) → fog / rain points dropped (density filter) → "
                      "clustering (0.6 m cells) → the nearest point inside our driving corridor → tracked (L1 …)."),
            ("RADAR", "1° beams traced to the object outlines → echo power (radar equation, weather, random "
                      "fluctuation) → CFAR threshold → points with Doppler → clusters → tracked (R1 …); rain clutter "
                      "and standing echoes need longer to confirm."),
            ("NAMES", "A real sensor never knows names: each confirmed track is matched to the real object at its "
                      "position only to name it in the cards and reports; unmatched tracks show as <i>unknown "
                      "object L5</i> — and are braked for if in the lane."),
            ("LIMITATIONS", "Slower (every AV's camera picture is rendered: ~1 picture / s per AV on a PC without "
                            "3D acceleration) · at night the 3D scene has no headlights, so the camera sees little · "
                            "the camera misses objects lower than ~0.8 m · in whiteout fog the LiDAR sees a wall of "
                            "returns.")],
        "collision": [
            ("WHAT", "The real bodies of the AV and the other vehicle / obstacle touch."),
            ("REASON", "Climate · hidden / small obstacle · sensors saw it too late for the speed · test setup."),
            ("SENSORS OFF", "Switched off on purpose → not blamed; suggested as a way to avoid it."),
            ("WHERE", "Collisions ▸ in the test window, the results summary, Reports → Collision tests.")],
    }


# ------------------------------------------------------------------ topics
def _topics():
    """[(key, title, icon, [(caption, html)])] -- the numbers from the models."""
    cam, rad = ft.FRONT_CAMERA, ft.FRONT_RADAR
    lk = v2v.LINKS
    return [
        ("flow", "How a collision test works", "▶", [
            ("PURPOSE", "Check whether autonomous vehicles (AVs) on a route avoid hitting the vehicle / obstacle ahead -- "
                        "in clear weather, fog, rain, snow, at night -- when they brake <b>only on what their own "
                        "sensors (and V2V) tell them</b>."),
            ("EVERY MOMENT OF THE TEST",
             "1. The scene moves: the AVs, the vehicles ahead (stop &amp; go), obstacles.<br>"
             "2. Each sensor of each AV looks: <b>camera</b>, <b>LiDAR</b>, <b>radar</b> (only those switched "
             "on), and <b>V2V</b> messages arrive.<br>"
             "3. <b>Fusion</b>: the nearest object in the AV's lane is its target (distance, speed).<br>"
             "4. <b>Braking</b>: keep the gap, brake harder when closing in, full brake (AEB) when the time to "
             "collision is critical.<br>"
             "5. The <b>real</b> positions (ground truth) are checked: bodies touching = a <b>collision</b>, kept "
             "with every sensor's view, the camera shots, the 3D scene and the reason."),
            ("RESULTS", "Per loop and AV: collisions, full brakes, TTC warnings, the lowest TTC, collisions "
                        "prevented by V2V -- in the results summary and Reports → Collision tests.")]),
        ("real", "Real-world set-up", "🛰", [
            ("SIMULATED vs REAL-WORLD", "<b>Simulated</b> (default): each sensor is a model on the scene's objects — "
                                        "fast, repeatable, for testing the braking logic. <b>Real-world</b>: each "
                                        "sensor processes its own data (camera picture, LiDAR point cloud, radar "
                                        "echoes) and tracks what it finds — for testing perception: misses, wrong "
                                        "distances, phantom objects, late detections."),
            ("WHERE", "Top bar <b>Sensors: Simulated / Real-world</b> → choose a set-up (applies to tests started "
                      "after). The test window shows <b>REAL-WORLD sensors</b>; the results and reports record it."),
            ("DETECTION DETAILS", "Real-world: the camera image shows what the picture processing found (green, with "
                                  "its distance) and the true positions dashed grey; the tiles explain a miss from the "
                                  "sensor's own data (no cluster, no echo track, not found in the picture).")]),
        ("camera", "Camera", "📷", [
            ("PURPOSE", "Sees <b>what</b> the object is (truck, car, pedestrian ...) and where -- the only sensor "
                        "that tells the type. Weak in fog, rain, snow and at night."),
            ("HOW IT DETECTS (IN THIS SIMULATION)",
             f"Each AV's configured cameras (front: {cam['hfov_deg']:g}° wide, up to {cam['max_range_m']:g} m). "
             "An object is <b>seen</b> when it is inside the camera's field of view and closer than the camera's "
             f"range in this climate: <b>{cam['visibility_share']:.0%} of the visibility</b> (max "
             f"{cam['max_range_m']:g} m), × {cam['night']:g} at night (headlights only), minus up to "
             f"{cam['precip_loss']:.0%} in heavy rain / snow. Small objects (pedestrians) are seen closer. "
             f"An object hidden {ft.OCCLUDED_SHARE:.0%} behind a nearer one is <b>not seen</b> (occlusion)."),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _camera_example()),
            ("WHAT IT GIVES",
             "<b>Name</b>: the object's id / label in the scene. <b>Type</b> with a confidence (lower far away; "
             "below 50 % only 'object'). <b>Distance</b>: from the AV's front bumper to the object's back. "
             "No speed -- the speed comes from how the distance changes."),
            ("LIMITATIONS", _lim(
                ["No direct distance from one camera — it must be estimated (box size / road plane).",
                 "Fog, heavy rain, snow, night: the picture loses contrast — far objects are missed.",
                 "Glare / low sun, a dirty or wet lens, dark objects at night.",
                 "Needs a trained detector — it can miss objects or see false ones; unusual vehicles are harder.",
                 "Cannot see through the vehicle ahead (occlusion)."],
                ["No picture is analysed: in range = seen, out of range = not seen (no misses, no false alarms).",
                 "The range is a fixed share of the climate's visibility; glare / backlight do not shorten it.",
                 "The name comes from the scene (a real camera does not know names).",
                 "Occlusion by angular width only (not by height: a low car behind a tall truck is hidden too).",
                 "The confidence is a formula of the distance, not a network's score."])),
            ("CAMERA IMAGES", "The pictures in Detection details / the collision details are rendered by the 3D view "
                              "from the camera's real mounting (Vehicles → cameras), with the detections drawn in.")]),
        ("lidar", "LiDAR", "🔆", [
            ("PURPOSE", "Measures the <b>distance</b> very precisely (centimetres) and the shape, day and night. "
                        "Weak in fog / heavy rain / snow (the laser light is scattered)."),
            ("HOW IT DETECTS (IN THIS SIMULATION)",
             "The 3D page casts the AV's LiDAR rays (its configured LiDARs: channels, angles, range) against the "
             "3D scene. Each ray that hits a vehicle / obstacle gives a point; an object with <b>at least 4 points</b> "
             "(config/lidar.json \"detection\".min_points) is a detection. The climate's extinction removes rays, "
             "adds noise and false points (fog / rain / snow) -- in thick fog few rays come back. Occlusion and the "
             "blind zone close to the AV come from the scan itself."),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _lidar_example()),
            ("WHAT IT GIVES", "<b>Name</b>: the object the points landed on. <b>Distance</b>: from its nearest point. "
                              "The point count (more points = more sure). No type, no speed (from the change of "
                              "distance)."),
            ("LIMITATIONS", _lim(
                ["Fog, heavy rain, snow, dust: the laser is scattered — range drops sharply, false points near "
                 "the sensor.",
                 "Dark / wet / low-reflective surfaces return few points; far objects are sparse.",
                 "No colour or type by itself; needs clustering / a detector to make objects.",
                 "A short-range LiDAR (as on these AVs, ~15 m used) sees too late for high speeds.",
                 "Blind zone very close to the AV; occlusion by the vehicle ahead."],
                ["Points are grouped by the object they hit (known from the scene) — no clustering mistakes "
                 "(merged / split objects).",
                 "≥ 4 points = detected, a fixed rule; false weather points are never taken as objects.",
                 "The range in the reports is a formula (2 % returns, at most 15 m); the scan itself is ray-traced.",
                 "Intensity (reflectivity) is not used for the detection."])),
            ("RANGE", "The detection range used for the test is ~15 m in clear air (the configured short-range "
                      "LiDARs), shorter in fog: where only ~2 % of the returns are left.")]),
        ("radar", "Radar", "📡", [
            ("PURPOSE", "Long range and <b>hardly affected by fog</b>; measures the <b>speed</b> straight away "
                        "(Doppler). No type; standing objects and pedestrians are weaker."),
            ("HOW IT DETECTS (IN THIS SIMULATION)",
             f"A 77 GHz front radar, {rad['hfov_deg']:g}° wide, a truck detected half of the scans at "
             f"{rad['max_range_m']:g} m in clear air. Each scan: signal-to-noise from the radar equation (radar "
             "cross-section: truck ~20 dBsm, car ~10, pedestrian ~-5; minus 40·log(distance)), minus the weather "
             "(rain attenuation ITU-R P.838 + backscatter + wet radome, snow on the radome, spray behind a truck, "
             f"fog almost nothing), minus {rad['clutter_static_db']:g} dB for objects that never moved "
             f"(stationary filter). Detected with that probability; confirmed after {rad['confirm']} of "
             f"{rad['window']} scans, kept {rad['coast_s']:g} s when missed. It sees under / past the vehicle ahead "
             "(almost no occlusion)."),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _radar_example()),
            ("WHAT IT GIVES", "<b>Distance</b> (with noise growing as the signal falls), <b>relative speed</b> "
                              "(Doppler), signal margin / detection probability. Name: the object it tracks."),
            ("LIMITATIONS", _lim(
                ["Poor angular resolution: two objects side by side merge; lateral position is rough.",
                 "Standing objects are filtered with the road clutter (a stopped vehicle can be missed).",
                 "Pedestrians / small objects reflect little; ghost targets from guard rails / multipath.",
                 "No type; heavy rain / snow on the radome cuts the range; interference from other radars."],
                ["Object level: no echoes, no ghosts / multipath, no false alarms.",
                 "Positions exact apart from the range noise (no angular resolution limit).",
                 "One front radar; the stationary filter is a fixed −6 dB for objects never seen moving.",
                 "Name from the scene's object."])),
        ]),
        ("v2v", "V2V (vehicle-to-vehicle)", "📶", [
            ("PURPOSE", "Vehicles <b>tell</b> each other where they are, how fast, and when they brake -- beyond "
                        "the sensors' reach, through fog, around the vehicle in between. Only for collision testing "
                        "(no roadside units)."),
            ("HOW IT WORKS (IN THIS SIMULATION)",
             f"Each connected vehicle sends its state {v2v.RATE_HZ:g}× a second (position from its GNSS, speed, "
             f"heading, length, braking), and a <b>BRAKE ALERT</b> at once when it brakes harder than "
             f"{v2v.BRAKE_ALERT:g} m/s² or stops. The link decides per message: delivered or lost, and when -- "
             f"PC5 ~{lk['pc5']['delay_ms']:g} ms, ~{lk['pc5']['range_m']:g} m (~{lk['pc5']['nlos_range_m']:g} m "
             f"behind buildings); V2N ~{lk['v2n']['delay_ms']:g} ms. The position has the GNSS error (NavIC / GPS "
             "~2.5 m, GAGAN ~1.2 m, RTK ~0.1 m). A message older than its delay + "
             f"{v2v.STALE_S * 1000:g} ms is not used. The receiver keeps only vehicles in its own lane, going its "
             "way."),
            ("WHAT IS IN ONE MESSAGE", _v2v_fields()),
            ("SENDING AND RECEIVING", _v2v_txrx()),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _v2v_example()),
            ("HEAVY TRAFFIC: MANY VEHICLES NEARBY", _v2v_traffic()),
            ("WHAT IT GIVES", "<b>Name</b> (the sender's id), <b>distance</b> from the reported position, its "
                              "<b>speed</b> and braking. Mode: <i>brakes on it</i> (used like a sensor) or "
                              "<i>warns only</i>."),
            ("LIMITATIONS", _lim(
                ["Only <b>connected</b> vehicles are known — pedestrians, obstacles, old vehicles send nothing.",
                 "Position from GNSS: metres of error, worse between buildings / under bridges → wrong lane.",
                 "Delay and lost messages; buildings block the direct link.",
                 "Trust: a faulty or spoofed message (needs signing / misbehaviour detection).",
                 "In India the 5.9 GHz band is not yet assigned for PC5."],
                ["Plain messages (no ASN.1 encoding, no signing — the signature check is only counted).",
                 "Radio: line of sight / blocked by buildings, fixed delay ± jitter, loss rate — no fading; channel "
                 "congestion as a load formula (busy % → congestion control, extra loss), not per radio slot.",
                 "GNSS error as a slowly drifting offset (no multipath jumps)."])),
            ("PREVENTED BY V2V", "When the AV knew a stopping / braking vehicle <b>only</b> through V2V, did not "
                                 "collide, and its sensors saw it too late or never to stop without V2V, the test "
                                 "counts a collision <b>prevented by V2V</b> -- with the proof (what each sensor did, "
                                 "the impact speed without V2V).")]),
        ("fusion", "Sensor fusion & target", "🔗", [
            ("PURPOSE", "Combine what the sensors see into one target to brake on."),
            ("HOW IT WORKS",
             f"Objects within ±{ft.CORRIDOR_HALF_M:g} m of the AV's path ahead (its lane) count. From all "
             "switched-on sensors (and V2V in brake mode) the <b>nearest</b> object is the target; each sensor's own "
             f"distance is kept. A detection is used {ft.HOLD_S:g} s. The target's speed: radar / V2V directly, "
             "otherwise from the change of distance (only when the same sensors measure it). In a bend, a target "
             "that left every field of view is predicted along the road for a short while."),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _fusion_example()),
            ("LIMITATIONS", _lim(
                ["Real fusion must decide which detections are the same object (association) — mistakes swap or "
                 "duplicate objects."],
                ["Objects are merged by their scene id (perfect association).",
                 "The nearest distance wins — no weighting by each sensor's accuracy, no Kalman filter.",
                 "Only the nearest object in the lane is braked for (no cut-in prediction)."]))]),
        ("brake", "Braking, TTC & AEB", "🛑", [
            ("PURPOSE", "Decide the speed from the target: keep the gap, slow down, stop in time."),
            ("HOW IT WORKS",
             f"<b>TTC</b> (time to collision) = distance / closing speed. Warning below {ft.TTC_WARN_S:g} s, "
             f"<b>critical</b> below {ft.TTC_CRIT_S:g} s → <b>full brake (AEB)</b>. Otherwise the needed "
             f"deceleration to stop {ft.STOP_GAP_M:g} m short: above {ft.A_COMFORT:g} m/s² it brakes hard (up to the "
             f"full brake {ft.A_FULL:g} m/s² × the road grip), below that it follows with the set gap. Speeding up "
             f"{ft.ACCEL:g} m/s². No target: it drives on at its set speed."),
            ("CALCULATION STEP BY STEP (EXAMPLE)", _brake_example()),
            ("LIMITATIONS", _lim(
                ["Real brakes need time to build up pressure (~0.3–0.5 s); a loaded truck brakes weaker."],
                ["The braking acts at once (no actuator delay); one grip value per climate.",
                 "No swerving — braking only.", "Load / trailer mass do not change the braking."])),
            ("GROUND TRUTH", "Next to the perceived TTC the real one (true positions) is kept -- the difference "
                             "shows what the sensors missed.")]),
        ("climate", "Climate effects", "🌫", [
            ("PURPOSE", "The same test in different weather shows which sensor fails where."),
            ("WHAT THE CLIMATE CHANGES",
             "<b>Camera</b>: half the visibility, less at night and in rain / snow. <b>LiDAR</b>: the laser's "
             "extinction (fog, rain, snow) -- fewer points, noise. <b>Radar</b>: rain / snow attenuation + radome, "
             "fog almost nothing. <b>V2V</b>: not affected by fog, heavy rain adds a little loss. <b>Road grip</b>: "
             "the full brake is weaker -- fog ~90 %, heavy rain ~70 %, snow ~60 %."),
            ("EACH CLIMATE", "__CLIMATE_TABLE__")]),
        ("collision", "Collisions & their reasons", "💥", [
            ("WHAT IS A COLLISION", "The real bodies (AV and the other vehicle / obstacle) touch. The AV "
                                    "stops; the record keeps the speeds, every sensor's view, the camera shots, the "
                                    "3D accident scene and the AV's log."),
            ("THE REASON", "Worked out from the facts: <b>climate</b> (sensors on, but the weather cut their range), "
                           "<b>obstacle / vehicle</b> (hidden behind another, cut in, too small), <b>sensor range for "
                           "the speed</b> (seen, but too late to stop), or <b>test setup</b>. Sensors switched off on "
                           "purpose are not blamed -- they are suggested as a way to avoid it, when they would have "
                           "helped."),
            ("WHERE", "Collisions ▸ in the test window, the results summary (double-click a loop / AV), "
                      "Reports → Collision tests.")]),
    ]


class InfoDialog(QDialog):
    """The collision-testing info window: topics on the left, the selected one on the right."""
    TECH_ROWS = ("FORMULA",)          # ('In short' rows left out of the Overview: they are in the Technical overview)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ctInfo")
        self.setStyleSheet(STYLE)
        self.setWindowTitle("Collision testing -- how it works")
        self.setModal(False)
        self.setSizeGripEnabled(True)
        self.methods = _methods()
        self.choice = {}                                       # ((topic, set-up) -> index, kept while the app runs)
        self.topics = _topics()
        self.quick = _quick()
        self.flows = _flows()
        self.quick_r, self.flows_r = _quick_real(), _flows_real()
        self.full = False                                      # (the full details shown: kept across topics)
        self.step = {}                                         # (each topic's slide step)
        self.mode = _current_mode()                            # (the set-up shown: the chosen one by default)
        lay = QVBoxLayout(self); lay.setContentsMargins(14, 12, 14, 12); lay.setSpacing(10)
        hrow = QHBoxLayout()
        head = QLabel("<span style='font-size:18px; font-weight:800'>Collision testing -- how it works</span><br>"
                      f"<span style='color:{GREY}'>Pick a topic on the left, the <b>set-up</b>, the sensor "
                      "<b>option</b> and the <b>view</b> on the right. <b>Overview</b>: animated pictures step by step "
                      "(◀ Prev / Next ▶, ▶ Play) in plain words. <b>Technical overview</b>: how our app does it in code "
                      "— modules, logic, libraries, parameters, advantages and limitations.</span>")
        head.setTextFormat(Qt.RichText); head.setWordWrap(True)
        hrow.addWidget(head, 1)
        self.mode_cb = QComboBox()
        cur = _current_mode()
        for m, t in (("sim", "Simulated set-up"), ("real", "Real-world set-up")):
            self.mode_cb.addItem(f"{t}" + ("   — in use" if m == cur else ""), m)
        self.mode_cb.setCurrentIndex(self.mode_cb.findData(self.mode))
        self.mode_cb.setToolTip("Which sensor set-up the pictures and texts describe -- 'in use' is the one chosen "
                                "with the top bar's Sensors button")
        self.mode_cb.currentIndexChanged.connect(lambda _i: self._set_mode(self.mode_cb.currentData()))
        sel = QGridLayout(); sel.setHorizontalSpacing(8); sel.setVerticalSpacing(6)
        for r, t in enumerate(("Set-up", "Sensor option", "View")):
            x = QLabel(t); x.setStyleSheet(f"color: {GREY}; font-weight: 700;")
            sel.addWidget(x, r, 0)
        sel.addWidget(self.mode_cb, 0, 1)
        # the options of the topic's sensor in the set-up chosen above: the picked one's details + pictures below
        self.meth_cb = QComboBox(); self.meth_cb.setMinimumWidth(380)
        self.meth_cb.setToolTip("The options of this sensor in the set-up chosen above: '— in use' is what the tests "
                                "use; pick any to see how it works (✖ = not in our app yet: what adding it takes)")
        self.meth_cb.currentIndexChanged.connect(self._set_method)
        self.meth_cb.view().setMinimumWidth(640)             # (the open list: the full names)
        sel.addWidget(self.meth_cb, 1, 1)
        # the view: Overview (pictures + plain words) or Technical overview (code, logic, libraries, limits)
        self.view_cb = QComboBox()
        self.view_cb.addItem("Overview — animated pictures, plain words (for everyone)", "overview")
        self.view_cb.addItem("Technical overview — how our app does it in code: logic, libraries, limits", "tech")
        self.view_cb.setToolTip("Technical overview: the modules / functions, the algorithm (simplified code), the "
                                "libraries, parameters, timing, advantages and limitations -- for engineers / evaluators")
        self.view = "overview"
        self.view_cb.currentIndexChanged.connect(lambda _i: self._set_view(self.view_cb.currentData()))
        sel.addWidget(self.view_cb, 2, 1)
        hrow.addLayout(sel)
        lay.addLayout(hrow)
        body = QHBoxLayout(); body.setSpacing(12)
        self.list = QListWidget(); self.list.setObjectName("topics"); self.list.setFixedWidth(250)
        for key, title, icon, _s in self.topics:
            it = QListWidgetItem(f"{icon}   {title}")
            it.setForeground(QColor(COL.get(key, "#E5E7EB")))
            self.list.addItem(it)
        body.addWidget(self.list)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.viewport().setStyleSheet("background: #0B1220;")
        body.addWidget(self.scroll, 1)
        lay.addLayout(body, 1)
        bb = QHBoxLayout(); bb.addStretch()
        c = QPushButton("Close"); c.clicked.connect(self.close); bb.addWidget(c)
        lay.addLayout(bb)
        self.list.currentRowChanged.connect(self._show)
        self.list.setCurrentRow(0)
        from PyQt5.QtWidgets import QApplication
        scr = QApplication.primaryScreen()
        g = scr.availableGeometry() if scr else None
        self.resize(min(1180, (g.width() - 40) if g else 1180), min(860, (g.height() - 60) if g else 860))

    def show_topic(self, key):
        for i, t in enumerate(self.topics):
            if t[0] == key:
                self.list.setCurrentRow(i)

    def _set_mode(self, m):
        self.mode = m if m in ("sim", "real") else "sim"
        self._show(self.list.currentRow())

    def _set_view(self, v):
        self.view = "tech" if v == "tech" else "overview"
        self._show(self.list.currentRow())

    def _set_method(self, i):
        row = self.list.currentRow()
        if i < 0 or row < 0 or getattr(self, "_filling", False):
            return
        key = self.topics[row][0]
        if self._opts(key):
            self.choice[(key, self.mode)] = i
            self._show(row)

    # ---- the options of a topic in the set-up shown, and the one in use ----
    def _opts(self, key):
        """The options of the topic's sensor listed for the set-up shown (sim / real / both)."""
        return [m for m in self.methods.get(key, []) if m.get("setup", "both") in (self.mode, "both")]

    def _in_use(self, key):
        """Index (in _opts) of the option the tests use in the set-up shown."""
        opts = self._opts(key)
        if not opts:
            return 0
        if key == "v2v":
            link = _v2v_link()
            want = "PC5" if link == "pc5" else "Cellular"
            return next((i for i, m in enumerate(opts) if want in m["name"]), 0)
        if self.mode == "real":
            import sensor_mode as smod
            sk = {"camera": "camera", "lidar": "LiDAR", "radar": "radar", "fusion": "fusion"}.get(key)
            if sk in smod.REAL_METHODS:
                find = smod.effective(sk, smod.real_methods()[sk])[3]
                return next((i for i, m in enumerate(opts) if find.lower() in m["name"].lower()), 0)
            return next((i for i, m in enumerate(opts) if m.get("real")), next(
                (i for i, m in enumerate(opts) if m["ok"]), 0))
        return next((i for i, m in enumerate(opts) if m["ok"]), 0)

    def _chosen_not_integrated(self, key):
        """Index (in _opts) of a real-world option chosen in the Sensors dialog that is not integrated, else None."""
        if self.mode != "real":
            return None
        import sensor_mode as smod
        sk = {"camera": "camera", "lidar": "LiDAR", "radar": "radar", "fusion": "fusion"}.get(key)
        if sk not in smod.REAL_METHODS:
            return None
        o = smod.method(sk, smod.real_methods()[sk])
        if o[2]:
            return None
        return next((i for i, m in enumerate(self._opts(key)) if o[3].lower() in m["name"].lower()), None)

    def _selected(self, key):
        """The option picked in the drop-down (the one in use until another is picked), or None."""
        opts = self._opts(key)
        if not opts:
            return None
        ck = (key, self.mode)
        if ck not in self.choice or self.choice[ck] >= len(opts):
            self.choice[ck] = self._in_use(key)
        return opts[self.choice[ck]]

    def _fill_methods(self, key):
        """The sensor-option drop-down: the options of this topic's sensor in the set-up shown, '— in use' marked;
        a topic without options: one disabled line."""
        self._filling = True
        self.meth_cb.clear()
        opts = self._opts(key)
        if opts:
            use, chosen = self._in_use(key), self._chosen_not_integrated(key)
            for i, m in enumerate(opts):                   # (the status first: a long name may be cut at the end)
                tag = ("IN USE" if i == use else
                       "chosen in Sensors, NOT integrated" if i == chosen else
                       ("integrated (pick it in the test setup)" if key == "v2v" else "integrated")
                       if m["ok"] else "not in our app yet")
                self.meth_cb.addItem(("✔  " if m["ok"] else "✖  ") + tag + "  ·  " + m["short"])
                self.meth_cb.setItemData(i, m["short"] + "  —  " + tag, Qt.ToolTipRole)
                self.meth_cb.setItemData(i, QColor(GREEN if i == use else "#93C5FD" if m["ok"] else AMBER),
                                         Qt.ForegroundRole)
            self.meth_cb.setCurrentIndex(self.choice.get((key, self.mode), use))
            self.meth_cb.setEnabled(True)
        else:
            self.meth_cb.addItem("— no sensor options for this topic (pick Camera, LiDAR, Radar, V2V …)")
            self.meth_cb.setEnabled(False)
        self._filling = False

    def showEvent(self, e):
        """(Opened again: the set-up chosen meanwhile is shown.)"""
        cur = _current_mode()
        for i in range(self.mode_cb.count()):
            m = self.mode_cb.itemData(i)
            self.mode_cb.setItemText(i, f"{'Simulated' if m == 'sim' else 'Real-world'} set-up"
                                        + ("   — in use" if m == cur else ""))
        if cur != self.mode:
            self.mode_cb.setCurrentIndex(self.mode_cb.findData(cur))
        super().showEvent(e)

    def _show(self, row):
        if row < 0:
            return
        key, title, icon, secs = self.topics[row]
        col = COL.get(key, "#E5E7EB")
        page = QWidget(); page.setStyleSheet("background: #0B1220;")
        v = QVBoxLayout(page); v.setContentsMargins(2, 0, 6, 6); v.setSpacing(10)
        real = self.mode == "real"
        hrow = QHBoxLayout()
        h = QLabel(f"{icon}  {title}"); h.setObjectName("h1"); h.setStyleSheet(f"color: {col};")
        hrow.addWidget(h)
        if key in ("camera", "lidar", "radar", "fusion"):
            chip = QLabel(("REAL-WORLD set-up" + self._real_choice(key)) if real else "SIMULATED set-up")
            chip.setStyleSheet(f"color: {'#34D399' if real else '#60A5FA'}; border: 1px solid "
                               f"{'#34D399' if real else '#60A5FA'}; border-radius: 8px; padding: 2px 8px; "
                               "font-weight: 700; background: transparent;")
            hrow.addWidget(chip)
        hrow.addStretch()
        v.addLayout(hrow)
        sel = self._selected(key)                            # (the option picked: its pictures, flow, In short)
        self._fill_methods(key)
        if sel is not None:                                  # (the chosen sensor option: what it is, in use or not)
            v.addWidget(self._method_card(key, col))
        if self.view == "tech":                              # TECHNICAL OVERVIEW: code, logic, libraries, limits
            try:
                self._tech_page(v, key, col, sel, real)
            except Exception:
                import sys
                sys.excepthook(*sys.exc_info())
            v.addStretch(1)
            self.scroll.setWidget(page)
            self.scroll.verticalScrollBar().setValue(0)
            return
        # OVERVIEW (for everyone): the animated working-flow picture + the important points -- no box diagrams,
        # formulas or code (those are in the Technical overview)
        try:
            v.addWidget(self._slide_card(key, col, sel))
        except Exception:
            import sys
            sys.excepthook(*sys.exc_info())
        if sel is not None and not sel["ok"]:                # (an option not in our app: its own few lines)
            quick = [("WHAT IT IS", sel["note"]),
                     ("IN OUR TESTS", f"Not used — the tests use <b>{self._opts(key)[self._in_use(key)]['short']}</b>. "
                                      "The Technical overview shows what adding it would take.")]
        else:
            quick = self.quick_r.get(key) if real and key in self.quick_r else self.quick.get(key)
            quick = [(k, t) for k, t in (quick or []) if k not in self.TECH_ROWS]
        if quick:
            v.addWidget(self._quick_card(quick, col))
        hint = QLabel(f"<span style='color:{GREY}'>For the code, the logic, the libraries, the numbers and the "
                      "limitations: <b>View → Technical overview</b> (top right).</span>")
        hint.setTextFormat(Qt.RichText); hint.setWordWrap(True)
        v.addWidget(hint)
        v.addStretch(1)
        self.scroll.setWidget(page)
        self.scroll.verticalScrollBar().setValue(0)

    # ---- the technical overview ----
    def _tech_page(self, v, key, col, sel, real):
        """View 'Technical overview': how OUR app does it in code -- the pipeline (module · function), the core logic
        (simplified code), libraries, parameters, timing, advantages / limitations, how to check it in the app."""
        import html as _html
        import collision_tech as ct
        used = self._opts(key)[self._in_use(key)] if self._opts(key) else None
        tk = ("camera_real" if key == "camera" else "lidar_real" if key == "lidar" else "radar_real" if key == "radar"
              else "fusion_real" if key == "fusion" else key) if (real and sel is None) else key
        T = ct.for_option(tk, sel, used)
        if T is None:
            v.addWidget(self._card("TECHNICAL OVERVIEW", "No technical notes for this topic.", col))
            return

        def card(title, border=col):
            f = QFrame(); f.setObjectName("card")
            f.setStyleSheet(f"QFrame#card {{ background: #0F172A; border: 1px solid #1F2937; "
                            f"border-left: 3px solid {border}; }}")
            lay = QVBoxLayout(f); lay.setContentsMargins(12, 8, 12, 10); lay.setSpacing(6)
            a = QLabel(title); a.setObjectName("cap"); a.setStyleSheet(f"color: {border}; background: transparent;")
            lay.addWidget(a)
            v.addWidget(f)
            return lay

        def lab(lay, text, style="color: #E5E7EB; font-size: 12px;"):
            x = QLabel(text); x.setWordWrap(True); x.setTextFormat(Qt.RichText)
            x.setTextInteractionFlags(Qt.TextSelectableByMouse)
            x.setStyleSheet(style + " background: transparent;")
            lay.addWidget(x)
            return x
        import tech_graphics as tg
        mono = "font-family: Consolas, 'Courier New', monospace;"
        gen = bool(T.get("generic"))
        name = sel["short"] if sel else self.topics[self.list.currentRow()][1]
        import sensor_slides as ss
        base = sel["deck"] if sel else ({"real": "flow"}.get(key, key) if not real else
                                        {"camera": "camera_real", "lidar": "lidar_real", "radar": "radar_real",
                                         "fusion": "fusion_real", "real": "flow"}.get(key, key))
        easy = "easy_" + base if (not gen and "easy_" + base in ss.DECKS) else None

        def collapsible(title, widget):
            b = QPushButton("▸  " + title); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(f"QPushButton {{ background: transparent; color: {BLUE}; border: 1px dashed #334155; "
                            "border-radius: 8px; padding: 7px; font-weight: 700; text-align: left; } "
                            "QPushButton:hover { background: #172554; }")
            widget.setVisible(False)
            b.toggled.connect(lambda on: (widget.setVisible(on), b.setText(("▾  " if on else "▸  ") + title)))
            v.addWidget(b); v.addWidget(widget)
        if easy:
            # THE EASY WAY (for the evaluator): real world → our app → detection → real ↔ app → limits, in pictures
            v.addWidget(self._slide_card(key, col, sel, deck=easy))
            tip = QLabel(f"<span style='color:{GREY}'>◀ Prev / Next ▶ or ▶ Play · the band on top: "
                         "<b style='color:#7DD3FC'>real world</b> → <b style='color:#34D399'>our app</b> → "
                         "detection → real ↔ app → limits.  For developers: the sections below.</span>")
            tip.setTextFormat(Qt.RichText); tip.setWordWrap(True)
            v.addWidget(tip)
            tdeck = "tech_" + base
            if tdeck in ss.DECKS:
                collapsible("For developers: the code, step by step (code · picture · calculation)",
                            self._slide_card(key, col, sel, deck=tdeck))
            box = QWidget(); bl = QVBoxLayout(box); bl.setContentsMargins(0, 0, 0, 0); bl.setSpacing(8)
            x = QLabel(T["summary"]); x.setWordWrap(True); x.setTextFormat(Qt.RichText)
            x.setStyleSheet("color: #E5E7EB; font-size: 12px; background: transparent;")
            bl.addWidget(x)
            params = list(T.get("params") or [])
            if T.get("timing"):
                params.append(("Timing / computing cost", T["timing"].split(";")[0].split(" — ")[0],
                               "measured / by design"))
            if params:
                bl.addWidget(tg.number_tiles([(a, b if len(b) <= 60 else b[:57] + "…", c) for a, b, c in params],
                                             col))
            if T.get("libs"):
                bl.addWidget(tg.chips([(_html.escape(a), _html.escape(b)) for a, b in T["libs"]], "#93C5FD"))
            if T.get("verify"):
                bl.addWidget(tg.chips([(f"✔ Show it live {i + 1}", _html.escape(x_)) for i, x_ in
                                       enumerate(T["verify"])], AMBER, per_row=1))
            collapsible("Key numbers, libraries, how to show it live", box)
            if T.get("code"):
                x = QLabel("<pre style='margin:0'>" + _html.escape(T["code"]) + "</pre>")
                x.setTextFormat(Qt.RichText); x.setTextInteractionFlags(Qt.TextSelectableByMouse)
                x.setStyleSheet(f"background: #020617; color: #A7F3D0; border: 1px solid #1F2937; "
                                f"border-radius: 6px; padding: 8px; font-size: 12px; {mono}")
                collapsible("The core logic (simplified code)", x)
            return
        lay = card(f"TECHNICAL OVERVIEW — {name.upper()}", BLUE)
        lab(lay, T["summary"], "color: #F1F5F9; font-size: 13px;")
        # 1) THE PICTURE, step by step: code (top) · what it computes (middle, animated) · calculation (bottom)
        if gen and sel is not None:                          # (not in our app: the picture of how it would work)
            v.addWidget(self._slide_card(key, col, sel))
        else:
            tdeck = "tech_" + base
            if tdeck in ss.DECKS:
                v.addWidget(self._slide_card(key, col, sel, deck=tdeck))
        # (not in our app: what adding it needs, step by step)
        if gen and T.get("pipeline"):
            card("WHAT ADDING IT TO OUR APP NEEDS", AMBER).addWidget(
                tg.chips([(f"Step {i + 1}", _html.escape(w)) for i, (_s, _x, w) in enumerate(T["pipeline"])], AMBER,
                         per_row=1))
        # 3) key numbers
        params = list(T.get("params") or [])
        if T.get("timing"):
            params.append(("Timing / computing cost", T["timing"].split(";")[0].split(" — ")[0], "measured / by design"))
        if params:
            tiles = [(a, b, c) for a, b, c in params]
            tiles = [(a, b if len(b) <= 60 else b[:57] + "…", c) for a, b, c in tiles]
            card("KEY NUMBERS (value · what · where to change it)").addWidget(tg.number_tiles(tiles, col))
        # 4) advantages / limitations
        if (T.get("pros") or T.get("cons")) and not gen:     # (not in our app: the comparison table above has it)
            card("ADVANTAGES ✓  AND  LIMITATIONS ✕", GREEN).addWidget(
                tg.pros_cons(T.get("pros") or [], T.get("cons") or []))
        # 5) libraries / technology, how to check it
        if T.get("libs"):
            card("LIBRARIES & TECHNOLOGY", "#93C5FD").addWidget(
                tg.chips([(_html.escape(a), _html.escape(b)) for a, b in T["libs"]], "#93C5FD"))
        if T.get("verify"):
            card("SHOW IT LIVE IN THE APP", AMBER).addWidget(
                tg.chips([(f"✔ {i + 1}", _html.escape(x)) for i, x in enumerate(T["verify"])], AMBER, per_row=1))
        # 6) for reading later: the code and the detailed calculation (collapsed)
        if T.get("code"):
            x = QLabel("<pre style='margin:0'>" + _html.escape(T["code"]) + "</pre>")
            x.setTextFormat(Qt.RichText); x.setTextInteractionFlags(Qt.TextSelectableByMouse)
            x.setStyleSheet(f"background: #020617; color: #A7F3D0; border: 1px solid #1F2937; border-radius: 6px; "
                            f"padding: 8px; font-size: 12px; {mono}")
            collapsible("Show the core logic (simplified code)", x)
        flows = self.flows_r if real and key in self.flows_r else self.flows
        if key in flows and (sel is None or sel["ok"]) and not gen:
            collapsible("Data in → calculation → data out (diagram)", self._flow_card(key, col, flows[key]))
        if T.get("how"):
            x = QLabel(T["how"]); x.setWordWrap(True)
            x.setStyleSheet("color: #E5E7EB; font-size: 12px; background: #0F172A; padding: 8px; border-radius: 6px;")
            collapsible("How it would detect (text)", x)
        secs = self.topics[self.list.currentRow()][3]
        if secs and not gen:
            box = QWidget(); bl = QVBoxLayout(box); bl.setContentsMargins(0, 0, 0, 0); bl.setSpacing(8)
            for c_, h_ in secs:
                bl.addWidget(self._card(c_, h_, col))
            collapsible("Detailed calculation examples and notes", box)

    def _real_choice(self, key):
        """' · camera: YOLO (not integrated → picture processing)' of the chosen real-world mechanism."""
        import sensor_mode as smod
        sk = {"camera": "camera", "lidar": "LiDAR", "radar": "radar", "fusion": "fusion"}.get(key)
        if sk not in smod.REAL_METHODS:
            return ""
        mid = smod.real_methods()[sk]
        o = smod.method(sk, mid)
        return (f" · {o[1].split(' (')[0]}" if o[2] else
                f" · chosen {o[1].split(' (')[0]}: NOT integrated → {smod.effective(sk, mid)[1].split(' (')[0]}")

    def _slide_card(self, key, col, opt=None, deck=None):
        """The picture, step by step (◀ Prev / Next ▶ / ▶ Play), animated: of the option picked in the drop-down
        (else the topic's, for the set-up shown); deck: a given deck (the Technical overview's)."""
        import sensor_slides as ss
        data = opt
        deck = deck or ("climate" if key == "climate" else opt["deck"] if opt and opt.get("deck") in ss.DECKS else
                        ss.deck_for(key, self.mode))
        if deck is None:
            return QWidget()
        if key == "climate":
            data = []
            clear = (ft.camera_range(None), ft.lidar_range(None), ft.radar_range(None))
            for cid in ("clear", "night", "heavy_rain", "snow", "fog", "dense_fog", "whiteout_fog"):
                try:
                    c = _clim(cid)
                except KeyError:
                    continue
                data.append((str(c.get("label") or cid).split(" (")[0], ft.camera_range(c) / clear[0],
                             ft.lidar_range(c) / clear[1], ft.radar_range(c) / clear[2]))
        f = QFrame(); f.setObjectName("card")
        f.setStyleSheet("QFrame#card { background: #0A0F1C; border: 1px solid #1F2937; }")
        lay = QVBoxLayout(f); lay.setContentsMargins(8, 6, 8, 8); lay.setSpacing(4)
        slide = ss.Slide(deck, data)
        slide.go(self.step.get(deck, 1))
        top = QHBoxLayout(); top.setSpacing(8)
        cap = QLabel(); cap.setObjectName("cap"); cap.setStyleSheet(f"color: {col}; background: transparent;")
        top.addWidget(cap)
        text = QLabel(); text.setWordWrap(True); text.setTextFormat(Qt.RichText)
        text.setStyleSheet("color: #F1F5F9; font-size: 13px; font-weight: 700; background: transparent;")
        top.addWidget(text, 1)
        prev = QPushButton("◀ Prev"); nxt = QPushButton("Next ▶"); play = QPushButton("▶ Play")
        play.setCheckable(True)
        play.setToolTip("Go through all the steps by itself (one every 7 s)")
        for b in (prev, nxt, play):
            b.setCursor(Qt.PointingHandCursor)
            # (no keyboard focus: Next on the last step is disabled -- the focus jumped to the next widget below
            #  and the page scrolled to the bottom)
            b.setFocusPolicy(Qt.NoFocus)
            top.addWidget(b, 0, Qt.AlignTop)
        lay.addLayout(top)
        lay.addWidget(slide)
        dots = QLabel(); dots.setAlignment(Qt.AlignCenter); dots.setStyleSheet("background: transparent;")
        lay.addWidget(dots)
        from PyQt5.QtCore import QTimer
        auto = QTimer(f); auto.setInterval(7000)
        name = (opt or {}).get("short", "").split(" (")[0].split(":")[0]

        def refresh():
            k = slide.step
            self.step[deck] = k
            cap.setText((f"PICTURE{' · ' + name.upper() if name else ''} · STEP {k} / {slide.n}" if slide.n > 1 else
                         "PICTURE"))
            text.setText(slide.caption())
            prev.setEnabled(k > 1); nxt.setEnabled(k < slide.n)
            for b in (prev, nxt, play):
                b.setVisible(slide.n > 1)
            dots.setText(" ".join(f"<span style='color:{col if i + 1 == k else '#334155'}; font-size:16px'>●</span>"
                                  for i in range(slide.n)) if slide.n > 1 else "")
            dots.setTextFormat(Qt.RichText)

        def tick():
            if slide.step >= slide.n:
                play.setChecked(False)
                return
            slide.go(slide.step + 1); refresh()

        def toggle(on):
            play.setText("❚❚ Pause" if on else "▶ Play")
            if on:
                if slide.step >= slide.n:                    # (from the start again)
                    slide.go(1); refresh()
                auto.start()
            else:
                auto.stop()
        auto.timeout.connect(tick)
        play.toggled.connect(toggle)
        prev.clicked.connect(lambda: (slide.go(slide.step - 1), refresh(), auto.isActive() and auto.start()))
        nxt.clicked.connect(lambda: (slide.go(slide.step + 1), refresh(), auto.isActive() and auto.start()))
        refresh()
        return f

    def _flow_card(self, key, col, flow=None):
        """How OUR app does it: the data it receives, what it calculates, what it sends (+ the key facts)."""
        import sensor_graphics as sg
        spec, notes = flow or self.flows[key]
        f = QFrame(); f.setObjectName("card")
        f.setStyleSheet("QFrame#card { background: #0A0F1C; border: 1px solid #334155; }")
        lay = QVBoxLayout(f); lay.setContentsMargins(8, 6, 8, 8); lay.setSpacing(4)
        a = QLabel("IN OUR APP — DATA RECEIVED → CALCULATION → DATA SENT"); a.setObjectName("cap")
        a.setStyleSheet(f"color: {col}; background: transparent;")
        lay.addWidget(a)
        lay.addWidget(sg.Diagram("dataflow", spec))
        for n in notes:
            x = QLabel(f"<span style='color:{col}'>●</span> {n}"); x.setWordWrap(True); x.setTextFormat(Qt.RichText)
            x.setStyleSheet("color: #E5E7EB; font-size: 12px; background: transparent;")
            lay.addWidget(x)
        return f

    @staticmethod
    def _diagram(key, col):
        """The topic's picture in a card."""
        import sensor_graphics as sg
        data = None
        if key == "climate":
            data = []
            clear = (ft.camera_range(None), ft.lidar_range(None), ft.radar_range(None))
            for cid in ("clear", "night", "heavy_rain", "snow", "fog", "dense_fog", "whiteout_fog"):
                try:
                    c = _clim(cid)
                except KeyError:
                    continue
                data.append((str(c.get("label") or cid).split(" (")[0], ft.camera_range(c) / clear[0],
                             ft.lidar_range(c) / clear[1], ft.radar_range(c) / clear[2]))
        elif key == "brake":
            data = (ft.TTC_WARN_S, ft.TTC_CRIT_S)
        f = QFrame(); f.setObjectName("card")
        f.setStyleSheet(f"QFrame#card {{ background: #0A0F1C; border: 1px solid #1F2937; }}")
        lay = QVBoxLayout(f); lay.setContentsMargins(8, 6, 8, 8); lay.setSpacing(2)
        a = QLabel("PICTURE"); a.setObjectName("cap"); a.setStyleSheet(f"color: {col}; background: transparent;")
        lay.addWidget(a)
        lay.addWidget(sg.Diagram(key, data))
        return f

    @staticmethod
    def _quick_card(lines, col):
        """The quick view: label | one plain line."""
        f = QFrame(); f.setObjectName("card")
        c = QColor(col)
        f.setStyleSheet(f"QFrame#card {{ background: rgba({c.red()},{c.green()},{c.blue()},0.07); "
                        f"border: 1px solid rgba({c.red()},{c.green()},{c.blue()},0.5); }}")
        g = QGridLayout(f); g.setContentsMargins(14, 10, 14, 10); g.setHorizontalSpacing(14); g.setVerticalSpacing(7)
        a = QLabel("IN SHORT"); a.setObjectName("cap"); a.setStyleSheet(f"color: {col}; background: transparent;")
        g.addWidget(a, 0, 0, 1, 2)
        for i, (k, t) in enumerate(lines, 1):
            x = QLabel(k); x.setStyleSheet(f"color: {col}; font-size: 11px; font-weight: 800; background: transparent;"
                                           " padding-top: 2px;")
            x.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            g.addWidget(x, i, 0)
            y = QLabel(t); y.setWordWrap(True); y.setTextFormat(Qt.RichText)
            y.setStyleSheet("color: #F1F5F9; font-size: 13px; background: transparent;")
            g.addWidget(y, i, 1)
        g.setColumnStretch(1, 1)
        return f

    @staticmethod
    def _card(cap, html, col):
        f = QFrame(); f.setObjectName("card")
        f.setStyleSheet(f"QFrame#card {{ border-left: 3px solid {col}; }}")
        fl = QVBoxLayout(f); fl.setContentsMargins(12, 8, 12, 10); fl.setSpacing(4)
        a = QLabel(cap); a.setObjectName("cap"); fl.addWidget(a)
        if html == "__CLIMATE_TABLE__":
            fl.addWidget(_climate_table())
            return f
        b = QLabel(html); b.setObjectName("body"); b.setWordWrap(True); b.setTextFormat(Qt.RichText)
        b.setTextInteractionFlags(Qt.TextSelectableByMouse)
        fl.addWidget(b)
        return f

    def _method_card(self, key, col):
        f = QFrame(); f.setObjectName("card")
        f.setStyleSheet(f"QFrame#card {{ border: 1px solid {col}; }}")
        fl = QVBoxLayout(f); fl.setContentsMargins(12, 8, 12, 10); fl.setSpacing(6)
        opts = self._opts(key)
        m = self._selected(key)
        i = opts.index(m)
        use = self._in_use(key)
        setup = "Simulated" if self.mode == "sim" else "Real-world"
        a = QLabel(f"SELECTED OPTION ({i + 1} of {len(opts)} in the {setup} set-up)" +
                   (" — IN USE" if i == use else " — change it with the Sensor option drop-down at the top right"))
        a.setObjectName("cap"); fl.addWidget(a)
        n = QLabel(("✔  " if m["ok"] else "✖  ") + m["short"])
        n.setWordWrap(True)
        n.setStyleSheet(f"color: {GREEN if m['ok'] else AMBER}; font-size: 14px; font-weight: 800; "
                        "background: transparent;")
        fl.addWidget(n)
        fl.addWidget(self._method_detail(key, m))
        return f

    def _method_detail(self, key, m):
        used = self._opts(key)[self._in_use(key)]
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(6)

        def lab(html, style=""):
            x = QLabel(html); x.setWordWrap(True); x.setTextFormat(Qt.RichText); x.setObjectName("body")
            x.setTextInteractionFlags(Qt.TextSelectableByMouse)
            if style:
                x.setStyleSheet(style)
            v.addWidget(x)
            return x

        def cap(t):
            x = QLabel(t); x.setObjectName("cap"); v.addWidget(x)
        if m["ok"]:
            note = m["note"]
            for p in ("In use: ", "Integrated — "):
                note = note[len(p):] if note.startswith(p) else note
            head = ("INTEGRATED — IN USE" if m is used else
                    "INTEGRATED — choose it in the collision test setup (V2V settings)" if key == "v2v" else
                    "INTEGRATED — not used by the tests now")
            if m is used and m.get("real"):
                head += " in the Real-world set-up (top bar <i>Sensors</i>)"
            elif m is used and m.get("setup") == "sim":
                head += " in the Simulated set-up"
            elif m is used and key == "v2v":
                head += " (the link of the last test)"
            lab(f"<b style='color:{GREEN}'>{head}</b> — {note[:1].upper() + note[1:]}")
            return w
        lab(f"<b style='color:{AMBER}'>NOT IN OUR APP YET</b> — {m['note']}<br><span style='color:{GREY}'>Selecting "
            f"it changes nothing: the collision tests keep using <b>{used['short']}</b>. The picture below shows how "
            "it would work.</span>")
        if self.view != "tech":                              # (Overview: no technical details)
            return w
        if m["compare"]:
            cap(f"COMPARED WITH THE METHOD IN USE ({used['short']})")
            g = QGridLayout(); g.setHorizontalSpacing(0); g.setVerticalSpacing(0)
            for j, t in enumerate(("", "In use now", m["name"].split(" (")[0])):
                x = QLabel(t); x.setWordWrap(True)
                x.setStyleSheet("background: #1F2937; color: #94A3B8; font-size: 11px; font-weight: 800; "
                                "padding: 4px 8px;")
                g.addWidget(x, 0, j)
            for i, (asp, now, it) in enumerate(m["compare"], 1):
                bg = "#0F172A" if i % 2 else "#111827"
                for j, (t, c) in enumerate(((asp, "#E5E7EB"), (now, GREEN), (it, "#FDE68A"))):
                    x = QLabel(t); x.setWordWrap(True)
                    x.setStyleSheet(f"background: {bg}; color: {c}; font-size: 12px; padding: 4px 8px;"
                                    + (" font-weight: 700;" if j == 0 else ""))
                    g.addWidget(x, i, j)
            g.setColumnStretch(0, 2); g.setColumnStretch(1, 4); g.setColumnStretch(2, 5)
            v.addLayout(g)
        if m["cplx"]:
            cap("COMPLEXITY")
            c = QColor(CPLX.get(m["cplx"], AMBER))
            lab(f"<span style='background: rgba({c.red()},{c.green()},{c.blue()},0.18); color: {c.name()}; "
                f"font-weight: 800;'>&nbsp;{m['cplx'].upper()}&nbsp;</span> &nbsp;{m['effort']} "
                f"<span style='color:{GREY}'>(a rough estimate)</span>")
        return w


def _climate_table():
    """Each climate: camera / LiDAR / radar range and the road grip (from the models)."""
    try:
        import site_config as cfg
        clims = list(cfg.CLIMATES or [])
    except Exception:
        clims = []
    cols = ["Climate", "Visibility", "Camera", "LiDAR", "Radar", "Road grip"]
    t = QTableWidget(len(clims), len(cols)); t.setHorizontalHeaderLabels(cols)
    t.verticalHeader().setVisible(False); t.setEditTriggers(QTableWidget.NoEditTriggers)
    t.setSelectionMode(QTableWidget.NoSelection)
    clear = (ft.camera_range(None), ft.lidar_range(None), ft.radar_range(None))
    for i, c in enumerate(clims):
        vals = [str(c.get("label") or c.get("id")), f"{float(c.get('visibility_m') or 4500):.0f} m",
                ft.camera_range(c), ft.lidar_range(c), ft.radar_range(c), f"{ft.road_grip(c):.0%}"]
        for j, x in enumerate(vals):
            if j in (2, 3, 4):
                ok = x >= clear[j - 2] * 0.95
                it = QTableWidgetItem(f"~{x:.0f} m")
                it.setForeground(QColor(GREEN if ok else AMBER if x >= clear[j - 2] * 0.4 else RED))
            else:
                it = QTableWidgetItem(x)
            t.setItem(i, j, it)
    t.resizeColumnsToContents()
    t.horizontalHeader().setStretchLastSection(True)
    t.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    t.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    t.setFixedHeight(t.horizontalHeader().sizeHint().height() + sum(t.rowHeight(i) for i in range(t.rowCount())) + 4)
    return t
