"""The Follow test window (an AV following a manual one, braking on its LiDAR / camera / radar).

Small, resizable, dark: a status pill + the climate, two vehicle cards (speed, brake; their speed setting and
stop and go, changed while the test runs), the sensor switches (LiDAR / camera / radar on / off while it drives),
a distance bar (real gap, set gap, the stop zone, where the LiDAR / camera / radar put the vehicle ahead), the
sensors with their distance and error to the real one, TTC, the collision counter and a log that can be opened.
"Sensor view" opens a bird's-eye view of what each sensor covers and detects + a table of the detections (how
each sensor identifies the vehicles / obstacles). The app fills it with update_view(d).
(SensorView / DistanceBar are also used by the Collision testing windows, collision_panel.py.)
"""
import math

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from PyQt5.QtWidgets import (QAbstractItemView, QDialog, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout,
                             QHeaderView, QLabel, QListWidget, QPushButton, QSizePolicy, QTableWidget,
                             QTableWidgetItem, QToolButton, QVBoxLayout, QWidget)

RED, AMBER, GREEN, CYAN, GREY, TEXT = "#EF4444", "#F59E0B", "#22C55E", "#22D3EE", "#94A3B8", "#E5E7EB"
PURPLE = "#C084FC"                                                  # the radar
SENSOR_COL = {"LiDAR": CYAN, "camera": AMBER, "radar": PURPLE, "V2V": "#34D399"}   # (V2V: collision testing)

STYLE = """
QDialog#followPanel { background: #0B1220; }
QFrame#card { background: #111827; border: 1px solid #1F2937; border-radius: 10px; }
QLabel { color: #E5E7EB; background: transparent; }
QLabel#muted { color: #94A3B8; font-size: 11px; }
QLabel#big { font-size: 26px; font-weight: 700; }
QLabel#name { font-size: 12px; font-weight: 600; color: #CBD5E1; }
QLabel#pill { border-radius: 11px; padding: 3px 12px; font-weight: 700; font-size: 12px; }
QLabel#chip { border-radius: 9px; padding: 2px 9px; font-size: 11px; background: #1E293B; color: #CBD5E1; }
QLabel#badge { border-radius: 8px; padding: 2px 8px; font-size: 11px; font-weight: 700; }
QPushButton { background: #1E293B; color: #E5E7EB; border: 1px solid #334155; border-radius: 7px; padding: 5px 12px; }
QPushButton:hover { background: #273449; }
QPushButton#danger { background: #3F1D1D; border-color: #7F1D1D; }
QPushButton#accent { background: #14532D; border-color: #166534; }
QToolButton { color: #94A3B8; background: transparent; border: none; font-size: 11px; }
QToolButton#follow { color: #CBD5E1; background: #1E293B; border: 1px solid #334155; border-radius: 6px;
                     padding: 2px 7px; font-size: 11px; font-weight: 600; }
QToolButton#follow:hover { background: #273449; }
QToolButton#follow[on="true"] { color: #052E16; background: #22C55E; border-color: #16A34A; }
QDoubleSpinBox { background: #0F172A; color: #E5E7EB; border: 1px solid #334155; border-radius: 6px; padding: 2px 4px; }
QDoubleSpinBox:focus { border-color: #22C55E; }
QListWidget { background: #0F172A; color: #CBD5E1; border: 1px solid #1F2937; border-radius: 8px; font-size: 11px; }
QPushButton#sensor { border-radius: 7px; padding: 4px 8px; font-weight: 700; font-size: 11px; }
QTableWidget { background: #0F172A; color: #CBD5E1; border: 1px solid #1F2937; border-radius: 8px; font-size: 11px;
               gridline-color: #1F2937; }
QHeaderView::section { background: #111827; color: #94A3B8; border: none; padding: 3px; font-size: 11px; }
"""


class _SafePaint(QWidget):
    """A painting error is reported (crash_guard log) -- never ends the app (PyQt aborts on errors in paintEvent)."""

    def paintEvent(self, e):
        try:
            self._paint(e)
        except Exception:
            import sys
            sys.excepthook(*sys.exc_info())


class SensorView(_SafePaint):
    """Bird's-eye view of one AV's sensors: forward is up, the AV at the bottom. The LiDAR's
    range (cyan circle), the camera's (amber) and radar's (purple) fields of view as far as they reach in this
    climate, its lane, every object around (grey) with a coloured mark for each sensor that detects it; an object in
    its lane that no sensor detects is outlined red; d["hit"] (an object id): the object of a collision, marked.
    Mouse wheel: zoom (at the mouse), drag: move, double-click: back to the start view."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(False)
        self.d = None
        self.span0 = self.span = 45.0                               # metres shown ahead
        self.pan = QPointF(0, 0)                                    # (px) the view moved by dragging / zooming
        self._drag = None

    def set_data(self, d, reset=False):
        """reset: a new subject (another collision): the start view again (d["span"]: metres shown)."""
        self.d = d
        if reset:
            self.span0 = self.span = float((d or {}).get("span") or 45.0)
            self.pan = QPointF(0, 0)
        self.update()

    def _origin(self, k):
        """The AV's centre on the screen: at the bottom with its whole body (and a little behind it) in view."""
        L = float((self.d or {}).get("ego_L", 4.9))
        return QPointF(self.width() / 2.0, self.height() - max(26.0, (L / 2 + 2.0) * k)) + self.pan

    def _k(self):
        return (self.height() - 46) / self.span

    def wheelEvent(self, e):
        old_k = self._k()
        c_old = self._origin(old_k)
        m = QPointF(e.pos())
        self.span = max(6.0, min(160.0, self.span * (0.85 if e.angleDelta().y() > 0 else 1.18)))
        new_k = self._k()
        # (the point under the mouse stays under it)
        c_new_wo_pan = self._origin(new_k) - self.pan
        target = m - (m - c_old) * (new_k / old_k)
        self.pan = target - c_new_wo_pan
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = (QPointF(e.pos()), QPointF(self.pan))
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.pan = self._drag[1] + (QPointF(e.pos()) - self._drag[0])
            self.update()

    def mouseReleaseEvent(self, _e):
        self._drag = None
        self.unsetCursor()

    def mouseDoubleClickEvent(self, _e):
        self.span, self.pan = self.span0, QPointF(0, 0)
        self.update()

    def _paint(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor("#0A0F1C"))
        d = self.d
        if not d:
            p.setPen(QColor(GREY)); p.drawText(QRectF(0, 0, w, h), Qt.AlignCenter, "no data yet")
            p.end(); return
        k = self._k()                                                 # px per metre
        o0 = self._origin(k)
        cx, cy = o0.x(), o0.y()                                       # the AV's centre

        def S(x, y):                                                  # (forward, left) metres -> screen
            return QPointF(cx - y * k, cy - x * k)
        # range rings
        step = 2 if self.span <= 12 else 5 if self.span <= 30 else 10 if self.span <= 70 else 20 if self.span <= 120 \
            else 40
        f = QFont(); f.setPointSize(7); p.setFont(f)
        far = int(max(self.span * 2.5, 30))                           # (moved / zoomed: rings further out too)
        for r in range(step, far + 1, step):
            p.setPen(QPen(QColor("#1E293B"), 1))
            p.drawEllipse(S(0, 0), r * k, r * k)
            p.setPen(QColor("#475569")); p.drawText(S(r, 0) + QPointF(3, 10), f"{r} m")
        on = d.get("on") or set()
        # sensor coverage (as far as each reaches in this climate)
        for name, fov in (("radar", d.get("fov", {}).get("radar", 60)), ("camera", d.get("fov", {}).get("camera", 90))):
            r = (d.get("ranges") or {}).get(name)
            if not r:
                continue
            col = QColor(SENSOR_COL[name])
            path = QPainterPath(S(0, 0))
            for i in range(0, 25):
                a = math.radians(-fov / 2 + fov * i / 24)
                path.lineTo(S(r * math.cos(a), -r * math.sin(a)))
            path.closeSubpath()
            if name in on:
                col.setAlpha(28); p.setBrush(QBrush(col)); col.setAlpha(120)
                p.setPen(QPen(col, 1))
            else:
                p.setBrush(Qt.NoBrush); col.setAlpha(90); p.setPen(QPen(col, 1, Qt.DotLine))
            p.drawPath(path)
        r = (d.get("ranges") or {}).get("LiDAR")
        if r:
            col = QColor(CYAN)
            if "LiDAR" in on:
                col.setAlpha(22); p.setBrush(QBrush(col)); col.setAlpha(140); p.setPen(QPen(col, 1))
            else:
                p.setBrush(Qt.NoBrush); col.setAlpha(90); p.setPen(QPen(col, 1, Qt.DotLine))
            p.drawEllipse(S(0, 0), r * k, r * k)
        # its lane (the road ahead it drives along)
        lane = d.get("lane") or []
        if len(lane) > 1:
            pen = QPen(QColor(34, 197, 94, 45), max(2.0, 2 * d.get("lane_half", 2.2) * k))
            pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
            p.setPen(pen); p.setBrush(Qt.NoBrush)
            p.drawPolyline(QPolygonF([S(x, y) for x, y in lane]))
        # objects
        f.setPointSize(8); p.setFont(f)
        hit = str(d.get("hit")) if d.get("hit") is not None else None
        labels = []
        for o in d.get("objs") or []:
            x, y, L, W = o["x"], o["y"], o["L"], o["W"]
            sc = S(x, y)
            if sc.x() < -200 or sc.x() > w + 200 or sc.y() < -200 or sc.y() > h + 200:   # (off the screen)
                continue
            is_hit = hit is not None and str(o.get("id")) == hit
            p.save()
            p.translate(S(x, y))
            p.rotate(o.get("rel_h") or 0.0)
            det = [s for s in ("LiDAR", "camera", "radar", "V2V") if s in (o.get("det") or ())]
            body = QColor("#64748B") if o.get("kind") != "pedestrian" else QColor("#A3A3A3")
            body.setAlpha(200)
            missed = o.get("lane") and not det and x > 0
            p.setBrush(body)
            p.setPen(QPen(QColor(RED), 2) if missed else QPen(QColor("#94A3B8"), 1) if not o.get("target")
                     else QPen(QColor("#FFFFFF"), 2))
            p.drawRoundedRect(QRectF(-W / 2 * k, -L / 2 * k, max(3, W * k), max(3, L * k)), 2, 2)
            p.restore()
            c = sc
            if is_hit:                                                # the collision: a red ring + COLLISION
                p.setBrush(Qt.NoBrush)                                # (d["hit_col"] / ["hit_label"]: another mark)
                for rr, a in ((max(L, W) / 2 * k + 8, 220), (max(L, W) / 2 * k + 16, 110)):
                    col = QColor(d.get("hit_col") or RED); col.setAlpha(a)
                    p.setPen(QPen(col, 3)); p.drawEllipse(c, rr, rr)
            for i, s in enumerate(det):                               # a dot per sensor that detects it
                p.setPen(QPen(QColor("#0A0F1C"), 1)); p.setBrush(QColor(SENSOR_COL[s]))
                p.drawEllipse(c + QPointF(W / 2 * k + 7 + i * 10, -4), 4.5, 4.5)
            txt = f"{o['label']}" + (f" · {o['gap']:.1f} m" if o.get("gap") is not None and x > 0 else "")
            if is_hit:
                txt = (d.get("hit_label") or "COLLISION") + " · " + txt
            if missed:
                txt += " · NOT DETECTED"
            elif o.get("hidden"):
                txt += " · hidden (camera)"
            if det:
                txt += " · seen by " + " + ".join(det)
            labels.append((c + QPointF(W / 2 * k + 7, 8), txt,
                           (d.get("hit_col") or RED) if is_hit else RED if missed else "#E2E8F0",
                           bool(is_hit or missed or o.get("lane"))))
        # the AV itself
        L, W = d.get("ego_L", 4.9), 2.5
        p.setBrush(QColor("#2563EB")); p.setPen(QPen(QColor("#93C5FD"), 1.5))
        p.drawRoundedRect(QRectF(cx - W / 2 * k, cy - L / 2 * k, W * k, L * k), 2, 2)
        p.setPen(QColor("#DBEAFE")); p.drawText(QPointF(cx + W / 2 * k + 6, cy + 4), d.get("ego_label") or "this truck")
        # the labels last (on a dark plate, readable over everything); the important ones bold
        fm = None
        for pos, txt, col, strong in sorted(labels, key=lambda x: x[3]):
            f.setPointSize(9 if strong else 8); f.setBold(strong); p.setFont(f)
            fm = p.fontMetrics()
            over = pos.x() + fm.width(txt) + 6 - w
            if over > 0:                                              # (kept inside the view)
                pos = QPointF(max(4.0, pos.x() - over), pos.y() + fm.height() + 2)
            r = QRectF(pos.x() - 3, pos.y() - fm.ascent() - 2, fm.width(txt) + 6, fm.height() + 3)
            p.setPen(Qt.NoPen); p.setBrush(QColor(10, 15, 28, 200)); p.drawRoundedRect(r, 3, 3)
            p.setPen(QColor(col)); p.drawText(pos, txt)
        f.setBold(False)
        # legend: the sensors (top left), the marks (bottom), the controls (top right)
        f.setPointSize(8); p.setFont(f)
        fm = p.fontMetrics()
        p.setPen(Qt.NoPen); p.setBrush(QColor(10, 15, 28, 210)); p.drawRoundedRect(QRectF(4, 3, 150, 47), 4, 4)
        y0 = 16
        for name in ("LiDAR", "camera", "radar"):
            r = (d.get("ranges") or {}).get(name) or 0
            p.setPen(QColor(SENSOR_COL[name] if name in on else "#64748B"))
            p.drawText(QPointF(9, y0), f"● {name}  {'reach ~%.0f m' % r if name in on else 'OFF'}")
            y0 += 14
        leg = ("● dot = that sensor detects it (green: V2V)   ▢ red = in its lane, NOT detected   "
               "▢ white = braking for it")
        p.setPen(Qt.NoPen); p.setBrush(QColor(10, 15, 28, 210))
        p.drawRoundedRect(QRectF(4, h - fm.height() - 7, min(w - 8, fm.width(leg) + 10), fm.height() + 4), 4, 4)
        p.setPen(QColor("#94A3B8")); p.drawText(QPointF(9, h - 7 - fm.descent()), leg)
        p.setPen(QColor("#64748B"))
        p.drawText(QRectF(0, 2, w - 6, 14), Qt.AlignRight, "wheel: zoom · drag: move · double-click: reset")
        p.end()


def _badge(lab, text, colour):
    lab.setText(text)
    c = QColor(colour)
    lab.setStyleSheet(f"background: rgba({c.red()},{c.green()},{c.blue()},0.18); color: {colour}; "
                      f"border: 1px solid rgba({c.red()},{c.green()},{c.blue()},0.55);")


class DistanceBar(_SafePaint):
    """0 .. scale m: the stop zone (red), the set gap (dashed), the real gap (white), LiDAR (cyan) / camera (amber)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(58)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.real = self.set_gap = 0.0
        self.lidar = self.cam = self.radar = None
        self.stop = 3.0

    def set_values(self, real, set_gap, lidar, cam, stop=3.0, radar=None):
        self.real, self.set_gap, self.lidar, self.cam, self.stop = real, set_gap, lidar, cam, stop
        self.radar = radar
        self.update()

    def _paint(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        x0, x1, y = 12, w - 12, 28
        p.setOpacity(0.45 if self.real is None else 1.0)
        scale = max(20.0, self.set_gap * 2.0, (self.real or 0) * 1.15, (self.lidar or 0) * 1.1, (self.cam or 0) * 1.1,
                    min(self.radar or 0, 150.0) * 1.1)
        X = lambda m: x0 + (x1 - x0) * max(0.0, min(1.0, m / scale))
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#1E293B")); p.drawRoundedRect(QRectF(x0, y - 5, x1 - x0, 10), 5, 5)
        p.setBrush(QColor(239, 68, 68, 110)); p.drawRoundedRect(QRectF(x0, y - 5, X(self.stop) - x0, 10), 5, 5)
        empty = self.real is None                                  # (nothing ahead: the bar without a gap)
        if not empty:
            fill = QColor(GREEN if self.real >= self.set_gap * 0.7 else AMBER if self.real > self.stop else RED)
            p.setBrush(fill); p.drawRoundedRect(QRectF(x0, y - 3, max(2.0, X(self.real) - x0), 6), 3, 3)
        pen = QPen(QColor("#CBD5E1"), 1.5, Qt.DashLine); p.setPen(pen)
        p.drawLine(int(X(self.set_gap)), y - 11, int(X(self.set_gap)), y + 11)
        f = QFont(); f.setPointSize(8); p.setFont(f)
        p.setPen(QColor(GREY))
        p.drawText(QRectF(X(self.set_gap) - 30, y + 11, 60, 14), Qt.AlignCenter, f"set {self.set_gap:g} m")
        p.drawText(QRectF(x0, y + 11, 40, 14), Qt.AlignLeft, "0")
        p.drawText(QRectF(x1 - 50, y + 11, 50, 14), Qt.AlignRight, f"{scale:.0f} m")
        for val, col, up in ((self.lidar, CYAN, True), (self.cam, AMBER, False)):
            if val is None:
                continue
            p.setPen(Qt.NoPen); p.setBrush(QColor(col))
            cx = X(val)
            tri = [(cx, y - 7), (cx - 5, y - 15), (cx + 5, y - 15)] if up else [(cx, y + 7), (cx - 5, y + 15), (cx + 5, y + 15)]
            p.drawPolygon(QPolygonF([QPointF(a, b) for a, b in tri]))
        if self.radar is not None:                                  # radar: a diamond on the bar
            cx = X(self.radar)
            p.setPen(QPen(QColor("#0B1220"), 1)); p.setBrush(QColor(PURPLE))
            p.drawPolygon(QPolygonF([QPointF(cx, y - 6), QPointF(cx + 5, y), QPointF(cx, y + 6), QPointF(cx - 5, y)]))
        if empty:
            p.end(); return
        p.setPen(QPen(QColor("#FFFFFF"), 2)); p.drawLine(int(X(self.real)), y - 8, int(X(self.real)), y + 8)
        f.setBold(True); p.setFont(f); p.setPen(QColor("#FFFFFF"))
        rx = max(x0 + 22, min(x1 - 22, X(self.real)))
        p.drawText(QRectF(rx - 30, 0, 60, 12), Qt.AlignCenter, f"{self.real:.1f} m")
        p.end()


class FollowPanel(QDialog):
    """callbacks: follow2d(which) / follow3d(which) with which = "lead" / "me", cont(), end(), pause(), restart(),
    speed(which, kmh), stopgo(which), stopgo_off(which), minimize(), sensor(name, on)."""

    def __init__(self, parent, leader, follower, callbacks, title=None, sensor_view=False):
        super().__init__(parent)
        self.cb = callbacks
        self.setObjectName("followPanel")
        self.setStyleSheet(STYLE)
        self.setWindowTitle(title or f"Follow test -- {follower}")
        self.setModal(False)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(400, 420)
        self._base_w = 470
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        left = QWidget()
        left.setMinimumWidth(400)
        left.setMaximumWidth(560)
        root.addWidget(left, 0)
        lay = QVBoxLayout(left)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)
        top = QHBoxLayout()
        self.pill = QLabel(); self.pill.setObjectName("pill")
        top.addWidget(self.pill)
        top.addStretch()
        self.climate = QLabel(); self.climate.setObjectName("chip")
        top.addWidget(self.climate)
        if "minimize" in self.cb:
            mn = QToolButton(); mn.setObjectName("follow"); mn.setText("–")
            mn.setToolTip("Minimize to the bottom bar (the test goes on) -- click it there to bring it back")
            mn.setCursor(Qt.PointingHandCursor)
            mn.clicked.connect(lambda: self.cb["minimize"]())
            top.addWidget(mn)
        lay.addLayout(top)
        self.note = QLabel(); self.note.setObjectName("muted"); self.note.setWordWrap(True)
        lay.addWidget(self.note)

        cards = QHBoxLayout()
        cards.setSpacing(8)
        self.follow_btns = {}
        self.ctl = {}
        self.names = {}
        self.lead = self._card(cards, "Truck ahead", leader, "lead")
        self.me = self._card(cards, "Autonomous", follower, "me")
        lay.addLayout(cards)
        # its sensors: switched on / off while it drives (off = it does not see -- to show a collision)
        srow = QHBoxLayout(); srow.setSpacing(4)
        lab = QLabel("Its sensors:"); lab.setObjectName("muted")
        srow.addWidget(lab)
        self.sensor_btns = {}
        for name, text in (("LiDAR", "LiDAR"), ("camera", "Camera"), ("radar", "Radar")):
            b = QPushButton(); b.setObjectName("sensor"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"Switch the AV's {text} on / off while it drives -- off, it brakes only on "
                         "the other sensors (all off: it sees nothing and runs into what is ahead)")
            b.clicked.connect(lambda on, n=name: self.cb["sensor"](n, on) if "sensor" in self.cb else None)
            srow.addWidget(b, 1)
            self.sensor_btns[name] = b
        self.view_btn = QPushButton("Sensor view ▸")
        self.view_btn.setCheckable(True)
        self.view_btn.setToolTip("Bird's-eye view: what each sensor covers and detects, and a table of the detections")
        self.view_btn.toggled.connect(self._toggle_view)
        srow.addWidget(self.view_btn)
        lay.addLayout(srow)

        dist = self._frame()
        dl = QVBoxLayout(dist); dl.setContentsMargins(10, 8, 10, 6); dl.setSpacing(2)
        hdr = QHBoxLayout()
        t = QLabel("Distance"); t.setObjectName("name")
        hdr.addWidget(t)
        hdr.addStretch()
        self.gap = QLabel(); self.gap.setStyleSheet("font-size: 18px; font-weight: 700;")
        hdr.addWidget(self.gap)
        dl.addLayout(hdr)
        self.bar = DistanceBar()
        dl.addWidget(self.bar)
        legend = QLabel(f"<span style='color:#22C55E'>━</span> real gap &nbsp; <span style='color:#CBD5E1'>┆</span> set gap"
                        f" &nbsp; <span style='color:{CYAN}'>▲</span> LiDAR &nbsp; <span style='color:{AMBER}'>▼</span> camera"
                        f" &nbsp; <span style='color:{PURPLE}'>◆</span> radar"
                        f" &nbsp; <span style='color:#F87171'>▮</span> stop zone")
        legend.setWordWrap(True)
        legend.setObjectName("muted")
        legend.setToolTip("The bar runs from the AV's front (0) forwards: the green line is the real gap "
                          "to the truck ahead, the dashed mark the gap it should keep, ▲ / ▼ where its LiDAR / camera "
                          "put the vehicle ahead, red = closer than it stops at the latest")
        dl.addWidget(legend)
        g = QGridLayout(); g.setHorizontalSpacing(10); g.setVerticalSpacing(2)
        for c, h in enumerate(("", "detected at", "error to real", "")):
            m = QLabel(h); m.setObjectName("muted"); g.addWidget(m, 0, c)
        self.sens = {}
        for r, (key, name, col) in enumerate((("lidar", "▲ LiDAR", CYAN), ("cam", "▼ Camera", AMBER),
                                              ("radar", "◆ Radar", PURPLE)), 1):
            n = QLabel(name); n.setStyleSheet(f"color: {col}; font-weight: 600;")
            d, e, x = QLabel(), QLabel(), QLabel()
            x.setObjectName("muted")
            for c, wdg in enumerate((n, d, e, x)):
                g.addWidget(wdg, r, c)
            self.sens[key] = (d, e, x)
        dl.addLayout(g)
        self.ttc = QLabel(); self.ttc.setObjectName("muted")
        self.ttc.setToolTip("Time to collision = gap / closing speed. Perceived: from what its sensors detect (what it "
                            "brakes on). Real: from the true gap to the nearest object in its lane. Amber below 3 s, "
                            "red below 1.5 s; 'lowest' = the lowest of this test (perceived / real).")
        dl.addWidget(self.ttc)
        lay.addWidget(dist)

        bottom = QHBoxLayout()
        self.coll = QLabel(); self.coll.setStyleSheet("font-size: 13px;")
        bottom.addWidget(self.coll)
        bottom.addStretch()
        self.log_btn = QToolButton(); self.log_btn.setText("Log ▸"); self.log_btn.setCheckable(True)
        self.log_btn.toggled.connect(self._toggle_log)
        bottom.addWidget(self.log_btn)
        lay.addLayout(bottom)
        self.log = QListWidget()
        self.log.setWordWrap(True)
        self.log.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.log.setVisible(False)
        lay.addWidget(self.log, 1)
        lay.addStretch(0)

        row = QHBoxLayout()
        self.cont = QPushButton("Continue now"); self.cont.setObjectName("accent")
        self.cont.setToolTip("End the collision hold"); self.cont.clicked.connect(lambda: self.cb["cont"]())
        self.cont.setVisible(False)
        row.addWidget(self.cont)
        row.addStretch()
        self.pause_btn = QPushButton("⏸ Pause")
        self.pause_btn.setToolTip("Both trucks stand still (the test is held) -- again to go on")
        self.pause_btn.clicked.connect(lambda: self.cb["pause"]())
        row.addWidget(self.pause_btn)
        b = QPushButton("↻ Restart")
        b.setToolTip("Start the test again: the truck ahead from the start of its path, the AV behind it, "
                     "counts and log cleared")
        b.clicked.connect(lambda: self.cb["restart"]())
        row.addWidget(b)
        b = QPushButton("■ End test"); b.setObjectName("danger"); b.clicked.connect(lambda: self.cb["end"]())
        row.addWidget(b)
        lay.addLayout(row)

        # the sensor view (bird's eye + the detections table), opened with "Sensor view"
        self.pane = QWidget()
        pv = QVBoxLayout(self.pane)
        pv.setContentsMargins(0, 10, 12, 10)
        pv.setSpacing(6)
        t = QLabel("Sensor view -- what each sensor covers and detects"); t.setObjectName("name")
        pv.addWidget(t)
        self.view = SensorView()
        pv.addWidget(self.view, 3)
        hint = QLabel(f"<span style='color:{CYAN}'>●</span> LiDAR: points on the object (a cluster, no type) &nbsp; "
                      f"<span style='color:{AMBER}'>●</span> camera: classifies it (type + confidence) &nbsp; "
                      f"<span style='color:{PURPLE}'>●</span> radar: distance + relative speed (Doppler), no type"
                      f" &nbsp; <span style='color:{RED}'>▢</span> in its lane, NOT detected")
        hint.setObjectName("muted"); hint.setWordWrap(True)
        pv.addWidget(hint)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Object", "Real gap", "LiDAR", "Camera", "Radar", "Lane"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setFocusPolicy(Qt.NoFocus)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.setToolTip("Everything within ~80 m ahead: each sensor's distance and what it makes of it -- "
                              "LiDAR points, the camera's class and confidence, the radar's relative speed; "
                              "OFF = that sensor is switched off, hidden = behind a nearer object")
        pv.addWidget(self.table, 2)
        self.pane.setVisible(False)
        root.addWidget(self.pane, 1)
        self.resize(self._base_w, 520)
        if sensor_view:
            self.view_btn.setChecked(True)

    def _toggle_view(self, on):
        self.view_btn.setText("Sensor view ◂" if on else "Sensor view ▸")
        self.pane.setVisible(on)
        if on:
            self.resize(max(self.width(), self._base_w + 560), max(self.height(), 680))
        else:
            self.resize(self._base_w, self.height())

    def _frame(self):
        f = QFrame(); f.setObjectName("card")
        return f

    def _card(self, row, title, name, which):
        f = self._frame()
        v = QVBoxLayout(f); v.setContentsMargins(10, 8, 10, 8); v.setSpacing(2)
        head = QHBoxLayout(); head.setSpacing(4)
        t = QLabel(title); t.setObjectName("muted"); head.addWidget(t)
        head.addStretch()
        for view in ("2D", "3D"):                           # follow this AV on the map / in the 3D view
            b = QToolButton(); b.setObjectName("follow"); b.setText(view)
            b.setToolTip(f"Follow {name} in the {view} view (green: following it)")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, w=which, vw=view: self.cb["follow2d" if vw == "2D" else "follow3d"](w))
            head.addWidget(b)
            self.follow_btns[(which, view)] = b
        v.addLayout(head)
        n = QLabel(name); n.setObjectName("name"); v.addWidget(n)
        self.names[which] = (t, n)
        sp = QLabel("0"); sp.setObjectName("big"); v.addWidget(sp)
        unit = QLabel("km/h"); unit.setObjectName("muted"); v.addWidget(unit)
        badge = QLabel(); badge.setObjectName("badge"); badge.setAlignment(Qt.AlignCenter)
        v.addWidget(badge)
        # its speed and its stop and go -- changed while the test runs
        ctl = QHBoxLayout(); ctl.setSpacing(4)
        lab = QLabel("Top speed" if which == "me" else "Speed"); lab.setObjectName("muted")
        ctl.addWidget(lab)
        spin = QDoubleSpinBox(); spin.setRange(1.0, 80.0); spin.setDecimals(0); spin.setSuffix(" km/h")
        spin.setKeyboardTracking(False)
        spin.setToolTip("The AV's top speed (it still brakes on what its LiDAR / camera detect)"
                        if which == "me" else "The truck ahead's speed on its path / route")
        spin.valueChanged.connect(lambda val, w=which: self.cb["speed"](w, val) if "speed" in self.cb else None)
        ctl.addWidget(spin, 1)
        v.addLayout(ctl)
        self.names[which] += (lab,)
        sg_row = QHBoxLayout(); sg_row.setSpacing(4)
        sg = QPushButton("✋ Stop && go ...")
        sg.setToolTip("Stop this truck (braking, how long it stands, again every ...) -- "
                      + ("its own stop, whatever its sensors see" if which == "me" else
                         "the AV behind has to detect it and brake"))
        sg.clicked.connect(lambda _=False, w=which: self.cb["stopgo"](w) if "stopgo" in self.cb else None)
        sg_row.addWidget(sg, 1)
        off = QPushButton("▶ Drive on"); off.setObjectName("accent")
        off.setToolTip("Stop and go off: it drives on now")
        off.clicked.connect(lambda _=False, w=which: self.cb["stopgo_off"](w) if "stopgo_off" in self.cb else None)
        off.setVisible(False)
        sg_row.addWidget(off)
        v.addLayout(sg_row)
        self.ctl[which] = (spin, sg, off)
        row.addWidget(f, 1)
        return sp, unit, badge

    def _toggle_log(self, on):
        self.log.setVisible(on)
        self.log_btn.setText("Log ▾" if on else "Log ▸")
        if on and self.height() < 600:
            self.resize(self.width(), 640)              # (room for the log)
        elif not on and not self.pane.isVisible():
            self.resize(self.width(), 520)

    def update_view(self, d):
        """d = {status, status_col, note, climate, lead: (speed, brake, col), me: (speed, brake, col, sub),
        real, set, stop, lidar: (dist, pts, err) | None, cam: (dist, err) | None, target, collisions, brakes, full,
        held, log}"""
        _badge(self.pill, d["status"], d["status_col"])
        self.climate.setText(d["climate"])
        nm = d.get("names")                                  # (convoy: the selected AV and the one ahead of it)
        if nm:
            for which, title, name, spin_lab in (("lead", nm[0], nm[1], "Top speed" if nm[3] else "Speed"),
                                                 ("me", "Autonomous", nm[2], "Top speed")):
                t, n, lab = self.names[which]
                t.setText(title); n.setText(name); lab.setText(spin_lab)
                for view in ("2D", "3D"):
                    self.follow_btns[(which, view)].setToolTip(f"Follow {name} in the {view} view (green: following it)")
        on = d.get("sensors_on")
        if on is not None:
            for name, b in self.sensor_btns.items():
                st = name in on
                b.setChecked(st)
                label = {"LiDAR": "LiDAR", "camera": "Camera", "radar": "Radar"}[name]
                b.setText(f"{label} {'ON' if st else 'OFF'}")
                c = QColor(SENSOR_COL[name] if st else RED)
                b.setStyleSheet(f"background: rgba({c.red()},{c.green()},{c.blue()},{0.22 if st else 0.16}); "
                                f"color: {SENSOR_COL[name] if st else '#FCA5A5'}; "
                                f"border: 1px solid rgba({c.red()},{c.green()},{c.blue()},0.6);")
        if self.pane.isVisible():
            self.view.set_data(d.get("view"))
            self._fill_table(d.get("table") or [])
        self.note.setText(d.get("note", ""))
        self.note.setVisible(bool(d.get("note")))
        for (sp, unit, badge), (v, brake, col, *sub) in ((self.lead, d["lead"]), (self.me, d["me"])):
            sp.setText(f"{v:.0f}")
            unit.setText("km/h" + (f"  ·  {sub[0]}" if sub and sub[0] else ""))
            _badge(badge, brake, col)
        real = max(0.0, d["real"])
        self.gap.setText(f"{real:.1f} m")
        self.gap.setStyleSheet(f"font-size: 18px; font-weight: 700; color: "
                               f"{GREEN if real >= d['set'] * 0.7 else AMBER if real > d['stop'] else RED};")
        li, ca, ra = d.get("lidar"), d.get("cam"), d.get("radar")
        self.bar.set_values(real, d["set"], li[0] if li else None, ca[0] if ca else None, d["stop"],
                            ra[0] if ra else None)
        off = {"lidar": "LiDAR", "cam": "camera", "radar": "radar"}
        for key, val in (("lidar", li), ("cam", ca), ("radar", ra)):
            dist, err, extra = self.sens[key]
            if on is not None and off[key] not in on:
                dist.setText(f"<span style='color:{GREY}'>switched OFF</span>")
                err.setText(""); extra.setText("")
                continue
            if not val:
                dist.setText(f"<span style='color:{RED}'>not detected</span>")
                err.setText(""); extra.setText("")
                continue
            dist.setText(f"<b>{val[0]:.1f} m</b>")
            e = val[-1]
            err.setText("" if e is None else f"<span style='color:{GREEN if abs(e) < 0.5 else AMBER if abs(e) < 1.5 else RED}'>"
                                             f"{e:+.1f} m</span>")
            extra.setText(f"{val[1]} pts" if key == "lidar" and val[1] else
                          (f"{val[1]}  {d.get('target') or ''}" if key == "radar" and val[1] else (d.get("target") or "")))
        n = d["collisions"]
        self.coll.setText(f"<span style='font-size:18px;font-weight:700;color:{RED if n else GREEN}'>{n}</span>"
                          f" collision{'s' if n != 1 else ''} &nbsp; <span style='color:{GREY}'>· {d['brakes']} "
                          f"braking{'s' if d['brakes'] != 1 else ''}, {d['full']} full</span>")
        ttc = d.get("ttc")
        if ttc:
            col = lambda v: GREY if v is None else RED if v < 1.5 else AMBER if v < 3.0 else GREEN
            fmt = lambda v: "--" if v is None else f"{v:.1f} s"
            self.ttc.setText(
                f"TTC perceived <b style='color:{col(ttc[0])}'>{fmt(ttc[0])}</b> · real "
                f"<b style='color:{col(ttc[1])}'>{fmt(ttc[1])}</b> &nbsp; <span style='color:{GREY}'>lowest "
                f"{fmt(ttc[2])} / {fmt(ttc[3])} · {ttc[4]} warning{'s' if ttc[4] != 1 else ''}, "
                f"{ttc[5]} critical</span>")
        for which in ("lead", "me"):                       # its speed setting / stop and go
            spin, sg, off = self.ctl[which]
            want = d.get(f"{which}_set")
            if want is not None and not spin.hasFocus() and abs(spin.value() - want) >= 0.5:
                spin.blockSignals(True)
                spin.setValue(round(want))
                spin.blockSignals(False)
            on = bool(d.get(f"{which}_sg"))
            off.setVisible(on)
            sg.setText("✋ Stop && go (on) ..." if on else "✋ Stop && go ...")
        self.cont.setVisible(bool(d.get("held")))
        self.pause_btn.setText("▶ Resume" if d.get("paused") else "⏸ Pause")
        for (which, view), b in self.follow_btns.items():
            on = d.get("f2d" if view == "2D" else "f3d") == which
            if b.property("on") != on:
                b.setProperty("on", on)
                b.style().unpolish(b); b.style().polish(b)
        log = d.get("log") or []
        if self.log.count() > len(log) or d.get("log_key") != getattr(self, "_log_key", None):
            self._log_key = d.get("log_key")                # (convoy: another AV's log)
            self.log.clear()
        while self.log.count() < len(log):
            t, text = log[self.log.count()]
            self.log.addItem(f"{t:5.1f} s   {text}")
            self.log.scrollToBottom()

    def set_log(self, log):
        """Another AV's log (convoy: a AV picked)."""
        self.log.clear()
        for t, text in log or []:
            self.log.addItem(f"{t:5.1f} s   {text}")
        self.log.scrollToBottom()

    def _fill_table(self, rows):
        """rows = [{obj, real, LiDAR: (text, colour), camera: (...), radar: (...), lane: (...), bold}]"""
        tb = self.table
        if tb.rowCount() != len(rows):
            tb.setRowCount(len(rows))
        for r, row in enumerate(rows):
            cells = [(row["obj"], "#E5E7EB"), (row["real"], "#CBD5E1"), row["LiDAR"], row["camera"], row["radar"],
                     row["lane"]]
            for c, (text, col) in enumerate(cells):
                it = tb.item(r, c)
                if it is None:
                    it = QTableWidgetItem()
                    tb.setItem(r, c, it)
                if it.text() != text:
                    it.setText(text)
                it.setForeground(QColor(col))
                if c == 0:
                    f = it.font(); f.setBold(bool(row.get("bold"))); it.setFont(f)
