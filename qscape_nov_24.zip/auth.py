"""Users, sign-in / sign-up and permissions (config/users.json).

- The first start (no users yet): "Create the administrator account".
- Then every start: Sign in. "Create an account" (sign up) makes a request: the account waits until an administrator
  approves it.
- Administrators: the user chip in the top bar -> Manage users (add, approve, role, sites, password, delete).
- Sites: administrators see all; the others their own (owner.json) and the ones an administrator shares with them.
- Names on screen: the yards are called sites everywhere (install_neutral_ui).
Passwords: salted PBKDF2-SHA256 (never stored in clear text).
"""
import hashlib
import hmac
import json
import os
import re
import secrets
import time

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QFormLayout, QFrame, QHBoxLayout, QHeaderView,
                             QLabel, QLineEdit, QMessageBox, QPushButton, QStackedWidget, QTableWidget,
                             QTableWidgetItem, QVBoxLayout, QWidget)

ROOT = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(ROOT, "config", "users.json")
SITES_DIR = os.path.join(ROOT, "sites")
OWNER_FILE = "owner.json"                             # sites/<yard>/owner.json: who created the yard
ITERATIONS = 200_000
ACCESS = {"collision": "Collision testing"}
ROLES = {"admin": "Administrator", "user": "User"}
STATUS = {"active": "Active", "pending": "Waiting for approval", "disabled": "Disabled"}

_current = None                                       # the signed-in user (dict without the password hash)


# ---------------- storage ----------------
def _load():
    try:
        with open(USERS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {"users": []}
    except (OSError, ValueError):
        return {"users": []}


def _save(d):
    os.makedirs(os.path.dirname(USERS_FILE), exist_ok=True)
    tmp = USERS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)
    os.replace(tmp, USERS_FILE)


def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS).hex()


def users():
    return [dict(u) for u in _load().get("users", [])]


def has_users():
    return bool(_load().get("users"))


def _find(d, username):
    return next((u for u in d.get("users", []) if u["username"].lower() == username.strip().lower()), None)


def valid_username(name):
    return bool(re.fullmatch(r"[A-Za-z0-9_.\-]{3,32}", name or ""))


def password_problem(pw):
    if len(pw or "") < 6:
        return "The password needs at least 6 characters."
    return None


def add_user(username, password, name="", role="user", access="collision", status="active"):
    d = _load()
    if not valid_username(username):
        raise ValueError("User name: 3-32 letters, digits, '.', '_' or '-'.")
    if _find(d, username):
        raise ValueError(f"The user name '{username}' is taken.")
    p = password_problem(password)
    if p:
        raise ValueError(p)
    salt = secrets.token_hex(16)
    d.setdefault("users", []).append({
        "username": username.strip(), "name": name.strip(), "role": role, "access": access, "status": status,
        "salt": salt, "hash": _hash(password, salt), "created": time.strftime("%Y-%m-%d %H:%M")})
    _save(d)


def update_user(username, **changes):
    d = _load()
    u = _find(d, username)
    if not u:
        raise ValueError("No such user.")
    after = dict(u, **{k: v for k, v in changes.items() if k != "password"})
    admins = [x for x in d["users"] if x["role"] == "admin" and x["status"] == "active"]
    if u in admins and len(admins) == 1 and (after["role"] != "admin" or after["status"] != "active"):
        raise ValueError("This is the only active administrator -- make another user administrator first.")
    if "password" in changes:
        p = password_problem(changes["password"])
        if p:
            raise ValueError(p)
        u["salt"] = secrets.token_hex(16)
        u["hash"] = _hash(changes["password"], u["salt"])
    for k in ("name", "role", "access", "status", "sites"):
        if k in changes:
            u[k] = changes[k]
    _save(d)


def delete_user(username):
    d = _load()
    u = _find(d, username)
    if not u:
        return
    admins = [x for x in d["users"] if x["role"] == "admin" and x["status"] == "active"]
    if u in admins and len(admins) == 1:
        raise ValueError("The only active administrator cannot be deleted.")
    d["users"].remove(u)
    _save(d)


def check(username, password):
    """-> (user dict, None) or (None, why)."""
    d = _load()
    u = _find(d, username)
    if not u or not hmac.compare_digest(u.get("hash", ""), _hash(password or "", u.get("salt", "00"))):
        return None, "Wrong user name or password."
    if u.get("status") == "pending":
        return None, "Your account waits for an administrator's approval."
    if u.get("status") == "disabled":
        return None, "This account is disabled -- ask an administrator."
    d["last_user"] = u["username"]
    u["last_login"] = time.strftime("%Y-%m-%d %H:%M")
    _save(d)
    return {k: v for k, v in u.items() if k not in ("hash", "salt")}, None


def last_user():
    return _load().get("last_user", "")


# ---------------- the user ----------------
# Q-SCAPE has no sign-in: one local user with full access (the user accounts below are kept only so older code paths
# and saved sites keep working)
LOCAL_USER = {"username": "local", "name": "Q-SCAPE", "role": "admin", "access": "collision", "status": "active"}
SESSION_FILE = os.path.join(ROOT, "config", ".session.json")


def handoff():
    """Before the app restarts itself (another yard, project name ...): the signed-in user goes on in the new copy
    without signing in again -- a one-time token (2 minutes) in the environment + config/.session.json."""
    if not _current:
        return
    token = secrets.token_hex(24)
    try:
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            json.dump({"user": _current["username"], "token": token, "t": time.time()}, f)
        os.environ["YARD_SESSION"] = token
    except OSError:
        pass


def resume():
    """The restarted app: the user of the hand-over (re-read: their current permissions), else None."""
    token = os.environ.pop("YARD_SESSION", None)
    if not token:
        return None
    try:
        with open(SESSION_FILE, encoding="utf-8") as f:
            s = json.load(f)
        os.remove(SESSION_FILE)
    except (OSError, ValueError):
        return None
    if not hmac.compare_digest(str(s.get("token", "")), token) or time.time() - float(s.get("t", 0)) > 120:
        return None
    u = _find(_load(), s.get("user", ""))
    if not u or u.get("status") != "active":
        return None
    set_current({k: v for k, v in u.items() if k not in ("hash", "salt")})
    return _current


def current():
    return _current or LOCAL_USER


def set_current(user):
    global _current
    _current = user


def is_admin():
    return current().get("role") == "admin"


def access():
    """Every user: collision testing."""
    return "collision"


def restricted():
    """(Every user: the neutral names -- sites, not yards.)"""
    return True


def collision_allowed():
    return True


# ---------------- sites: who sees which ----------------
# Each site records its creator (sites/<site>/owner.json). Sites without that file are the administrators'.
# Administrators see every site; the other users their own sites and the ones an administrator shared with them
# (Manage users -> Edit -> Shared sites).
def site_owner(site_id):
    try:
        with open(os.path.join(SITES_DIR, site_id, OWNER_FILE), encoding="utf-8") as f:
            return str(json.load(f).get("owner") or "")
    except (OSError, ValueError, AttributeError):
        return ""


def set_site_owner(site_id, username=None):
    """A new yard: its creator (the signed-in user)."""
    username = username or (_current or {}).get("username") or ""
    if not username:
        return
    try:
        with open(os.path.join(SITES_DIR, site_id, OWNER_FILE), "w", encoding="utf-8") as f:
            json.dump({"owner": username, "created": time.strftime("%Y-%m-%d %H:%M")}, f, indent=2)
    except OSError:
        pass


def _user_record(username):
    return _find(_load(), username or "") if username else None


def can_see_site(site_id, user=None):
    u = user if user is not None else _current
    if not u or u.get("role") == "admin":
        return True
    me = u.get("username", "").lower()
    rec = _user_record(u.get("username")) or u
    if site_id in (rec.get("sites") or []):
        return True
    owner = site_owner(site_id)
    if owner.lower() == me and me:
        return True
    return False


def visible_sites(sites):
    return [s for s in sites if can_see_site(s)]


def remember_site(site_id):
    """The yard the signed-in user worked in last (loaded again at their next sign-in)."""
    if not _current:
        return
    d = _load()
    u = _find(d, _current["username"])
    if u is not None and u.get("last_site") != site_id:
        u["last_site"] = site_id
        _save(d)


def choose_site(all_sites, active):
    """The yard to load for the signed-in user: their last one, else the one chosen last, else the first they may
    see; None: they may see none (they create their first yard from the map)."""
    vis = visible_sites(all_sites)
    rec = _user_record((_current or {}).get("username")) or {}
    for s in (rec.get("last_site"), active):
        if s in vis:
            return s
    return vis[0] if vis else None


_NEUTRAL = [
    # the sensor maker's name (LiDAR model, frame, topics)
    (r"\bOuster\s+OS\w*?-(\d+)\b", r"\1-channel LiDAR"), (r"\bOuster\b", "LiDAR"), (r"\bOUSTER\b", "LIDAR"),
    (r"\bouster\b", "lidar"),
    # the app and the yards: "Shipyard Map" -> "Q-SCAPE", yard -> site
    (r"\bShipyard Map\b", "Q-SCAPE"), (r"\bShipyard\b", "Site"), (r"\bshipyard\b", "site"),
    (r"\bYARDS\b", "SITES"), (r"\bYARD\b", "SITE"), (r"\bYards\b", "Sites"), (r"\bYard\b", "Site"),
    (r"\byards\b", "sites"), (r"\byard\b", "site"),
]
_NEUTRAL_RE = [(re.compile(p), r) for p, r in _NEUTRAL]
NEUTRAL_APP_NAME = "Q-SCAPE"


def neutral(text):
    """The text as shown: the yards called sites, no LiDAR maker's name (the app: "Q-SCAPE")."""
    if not restricted() or not isinstance(text, str) or not text:
        return text
    for pat, rep in _NEUTRAL_RE:
        text = pat.sub(rep, text)
    return text


def neutral_js():
    """The same names in a web page (2D map, 3D views): its text, tooltips and window.__nm for 3D labels."""
    rules = json.dumps([[p, r.replace("\\1", "$1")] for p, r in _NEUTRAL])
    return """(function () {
  var R = %s.map(function (x) { return [new RegExp(x[0], 'g'), x[1]]; });
  function nm(s) { if (typeof s !== 'string' || !s) return s; for (var i = 0; i < R.length; i++) s = s.replace(R[i][0], R[i][1]); return s; }
  window.__nm = nm;
  function attrs(n) { ['title', 'placeholder'].forEach(function (a) { var v = n.getAttribute(a); if (v) { var w = nm(v); if (w !== v) n.setAttribute(a, w); } }); }
  function fix(n) {
    if (n.nodeType === 3) { var v = n.nodeValue, w = nm(v); if (w !== v) n.nodeValue = w; return; }
    if (n.nodeType !== 1 || /^(SCRIPT|STYLE|TEXTAREA)$/.test(n.tagName)) return;
    attrs(n);
    for (var c = n.firstChild; c; c = c.nextSibling) fix(c);
  }
  function start() {
    if (!document.body) return;
    document.title = nm(document.title); fix(document.body);
    new MutationObserver(function (ms) {
      ms.forEach(function (m) {
        if (m.type === 'characterData') fix(m.target);
        else if (m.type === 'attributes') attrs(m.target);
        else m.addedNodes.forEach(fix);
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true,
                                attributeFilter: ['title', 'placeholder'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();""" % rules


def install_neutral_ui(app):
    """The neutral names everywhere -- every label,
    button, title, tooltip, menu and tab of the app as it is shown or changed, and the web pages (2D map, 3D views).
    Data the user edits (text boxes, drop-down values) is left as it is. Call after the sign-in, before the app is
    built."""
    if not restricted() or getattr(app, "_neutral_ui", None) is not None:
        return
    from PyQt5.QtCore import QEvent, QObject
    from PyQt5.QtWidgets import QAbstractButton, QAction, QGroupBox, QLabel, QMenu, QTabBar, QWidget

    def wrap(cls, name):
        orig = getattr(cls, name)

        def f(self, text, *a):
            return orig(self, neutral(text), *a)
        setattr(cls, name, f)
    for cls, name in ((QLabel, "setText"), (QAbstractButton, "setText"), (QGroupBox, "setTitle"),
                      (QWidget, "setWindowTitle"), (QWidget, "setToolTip"), (QAction, "setText"),
                      (QAction, "setToolTip")):
        wrap(cls, name)

    def fix(w):
        def same(get, put):
            t = get()
            n = neutral(t)
            if n != t:
                put(n)
        try:
            if isinstance(w, (QLabel, QAbstractButton)):
                same(w.text, w.setText)
            elif isinstance(w, QGroupBox):
                same(w.title, w.setTitle)
            elif isinstance(w, QMenu):
                same(w.title, w.setTitle)
                for a in w.actions():
                    same(a.text, a.setText)
                    same(a.toolTip, a.setToolTip)
            elif isinstance(w, QTabBar):
                for i in range(w.count()):
                    same(lambda i=i: w.tabText(i), lambda t, i=i: w.setTabText(i, t))
                    same(lambda i=i: w.tabToolTip(i), lambda t, i=i: w.setTabToolTip(i, t))
            if w.isWindow():
                same(w.windowTitle, w.setWindowTitle)
            same(w.toolTip, w.setToolTip)
        except RuntimeError:
            pass

    class _Names(QObject):
        def eventFilter(self, obj, ev):
            if ev.type() in (QEvent.Show, QEvent.ToolTip) and isinstance(obj, QWidget):
                fix(obj)
            return False
    app._neutral_ui = _Names(app)
    app.installEventFilter(app._neutral_ui)
    try:                                                      # the web pages (default profile: every view)
        from PyQt5.QtWebEngineWidgets import QWebEngineProfile, QWebEngineScript
        s = QWebEngineScript()
        s.setName("neutral_names")
        s.setSourceCode(neutral_js())
        s.setInjectionPoint(QWebEngineScript.DocumentReady)
        s.setWorldId(QWebEngineScript.MainWorld)
        s.setRunsOnSubFrames(True)
        QWebEngineProfile.defaultProfile().scripts().insert(s)
    except Exception:
        pass


# ---------------- dialogs ----------------
STYLE = """
QDialog#authDialog { background: #0B1220; }
QLabel { color: #E5E7EB; font-size: 12px; }
QLabel#brand { font-size: 20px; font-weight: 800; color: #F8FAFC; }
QLabel#sub { color: #94A3B8; font-size: 12px; }
QLabel#err { color: #FCA5A5; font-size: 12px; }
QLabel#ok { color: #86EFAC; font-size: 12px; }
QFrame#card { background: #111827; border: 1px solid #1F2937; border-radius: 14px; }
QLineEdit, QComboBox { background: #0F172A; color: #F1F5F9; border: 1px solid #334155; border-radius: 8px;
                       padding: 7px 10px; font-size: 13px; }
QLineEdit:focus, QComboBox:focus { border-color: #3B82F6; }
QPushButton { background: #1E293B; color: #E5E7EB; border: 1px solid #334155; border-radius: 8px; padding: 7px 14px;
              font-size: 12px; }
QPushButton:hover { background: #273449; }
QPushButton#primary { background: #2563EB; border-color: #3B82F6; color: white; font-weight: 700; }
QPushButton#primary:hover { background: #1D4ED8; }
QPushButton#link { background: transparent; border: none; color: #93C5FD; padding: 2px; }
QPushButton#link:hover { color: #BFDBFE; text-decoration: underline; }
QPushButton#danger { background: #7F1D1D; border-color: #B91C1C; color: #FEE2E2; }
QTableWidget { background: #0A0F1C; color: #E5E7EB; gridline-color: #1F2937; border: 1px solid #1F2937;
               border-radius: 8px; }
QHeaderView::section { background: #111827; color: #94A3B8; border: none; padding: 5px; }
QTableWidget::item:selected { background: #1D4ED8; }
"""


def _pw_edit(placeholder):
    e = QLineEdit(); e.setEchoMode(QLineEdit.Password); e.setPlaceholderText(placeholder)
    return e


class LoginDialog(QDialog):
    """Sign in / sign up (the first start: create the administrator account)."""

    def __init__(self, app_name="Q-SCAPE", parent=None):
        super().__init__(parent)
        self.setObjectName("authDialog")
        self.setStyleSheet(STYLE)
        self.setWindowTitle(f"{app_name} -- sign in")
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self.user = None
        outer = QVBoxLayout(self); outer.setContentsMargins(28, 24, 28, 24); outer.setSpacing(10)
        b = QLabel(app_name); b.setObjectName("brand"); b.setAlignment(Qt.AlignCenter); outer.addWidget(b)
        self.sub = QLabel(); self.sub.setObjectName("sub"); self.sub.setAlignment(Qt.AlignCenter)
        self.sub.setWordWrap(True); outer.addWidget(self.sub)
        card = QFrame(); card.setObjectName("card"); cl = QVBoxLayout(card); cl.setContentsMargins(20, 18, 20, 18)
        self.stack = QStackedWidget(); cl.addWidget(self.stack)
        outer.addWidget(card)
        # sign in
        si = QWidget(); f = QFormLayout(si); f.setSpacing(10); f.setLabelAlignment(Qt.AlignRight)
        self.si_user = QLineEdit(last_user()); self.si_user.setPlaceholderText("user name")
        self.si_pw = _pw_edit("password")
        f.addRow("User name", self.si_user); f.addRow("Password", self.si_pw)
        self.si_err = QLabel(); self.si_err.setObjectName("err"); self.si_err.setWordWrap(True); f.addRow(self.si_err)
        go = QPushButton("Sign in"); go.setObjectName("primary"); go.setDefault(True); go.clicked.connect(self._sign_in)
        f.addRow(go)
        sw = QPushButton("No account yet? Create one"); sw.setObjectName("link"); sw.clicked.connect(lambda: self._mode("up"))
        f.addRow(sw)
        self.stack.addWidget(si)
        # sign up (or: the first administrator)
        su = QWidget(); g = QFormLayout(su); g.setSpacing(10); g.setLabelAlignment(Qt.AlignRight)
        self.su_user = QLineEdit(); self.su_user.setPlaceholderText("3-32 letters / digits / . _ -")
        self.su_name = QLineEdit(); self.su_name.setPlaceholderText("your name")
        self.su_pw = _pw_edit("at least 6 characters"); self.su_pw2 = _pw_edit("repeat the password")
        g.addRow("User name", self.su_user); g.addRow("Full name", self.su_name)
        g.addRow("Password", self.su_pw); g.addRow("Confirm", self.su_pw2)
        self.su_err = QLabel(); self.su_err.setObjectName("err"); self.su_err.setWordWrap(True); g.addRow(self.su_err)
        self.su_go = QPushButton(); self.su_go.setObjectName("primary"); self.su_go.clicked.connect(self._sign_up)
        g.addRow(self.su_go)
        self.su_back = QPushButton("Have an account? Sign in"); self.su_back.setObjectName("link")
        self.su_back.clicked.connect(lambda: self._mode("in"))
        g.addRow(self.su_back)
        self.stack.addWidget(su)
        self.first = not has_users()
        self._mode("up" if self.first else "in")
        self.setMinimumWidth(420)

    def _mode(self, m):
        from PyQt5.QtWidgets import QSizePolicy
        self.stack.setCurrentIndex(0 if m == "in" else 1)
        for i in range(self.stack.count()):                # (the card is as tall as the form shown)
            pol = QSizePolicy.Preferred if i == self.stack.currentIndex() else QSizePolicy.Ignored
            self.stack.widget(i).setSizePolicy(pol, pol)
        self.stack.adjustSize()
        self.adjustSize()
        if m == "in":
            self.sub.setText("Sign in to continue")
            (self.si_pw if self.si_user.text() else self.si_user).setFocus()
        elif self.first:
            self.sub.setText("First start: create the administrator account. The administrator creates the other "
                             "users and approves the accounts requested.")
            self.su_go.setText("Create the administrator account")
            self.su_back.setVisible(False)
            self.su_user.setFocus()
        else:
            self.sub.setText("Create an account -- an administrator approves it")
            self.su_go.setText("Request the account")
            self.su_back.setVisible(True)
            self.su_user.setFocus()

    def _sign_in(self):
        u, why = check(self.si_user.text().strip(), self.si_pw.text())
        if not u:
            self.si_err.setText(why)
            self.si_pw.selectAll(); self.si_pw.setFocus()
            return
        self.user = u
        self.accept()

    def _sign_up(self):
        if self.su_pw.text() != self.su_pw2.text():
            self.su_err.setText("The passwords are not the same.")
            return
        try:
            if self.first:
                add_user(self.su_user.text().strip(), self.su_pw.text(), self.su_name.text(), role="admin",
                         access="collision", status="active")
            else:
                add_user(self.su_user.text().strip(), self.su_pw.text(), self.su_name.text(), role="user",
                         access="collision", status="pending")
        except ValueError as e:
            self.su_err.setText(str(e))
            return
        if self.first:
            self.first = False
            self.user, _why = check(self.su_user.text().strip(), self.su_pw.text())
            self.accept()
            return
        self.si_user.setText(self.su_user.text().strip()); self.si_pw.clear()
        for e in (self.su_user, self.su_name, self.su_pw, self.su_pw2):
            e.clear()
        self.su_err.clear()
        self._mode("in")
        self.si_err.setObjectName("ok"); self.si_err.setStyleSheet("color: #86EFAC;")
        self.si_err.setText("Account requested. You can sign in once an administrator has approved it.")


def sign_in(app_name="Q-SCAPE"):
    """The sign-in dialog; -> the user, or None (closed: the app does not start)."""
    dlg = LoginDialog(app_name)
    if dlg.exec_() != QDialog.Accepted or not dlg.user:
        return None
    set_current(dlg.user)
    return dlg.user


class _UserForm(QDialog):
    def __init__(self, parent, user=None):
        super().__init__(parent)
        self.setObjectName("authDialog"); self.setStyleSheet(STYLE)
        self.setWindowTitle("Edit user" if user else "Add user")
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        f = QFormLayout(self); f.setSpacing(10)
        self.user = QLineEdit((user or {}).get("username", "")); self.user.setReadOnly(bool(user))
        self.name = QLineEdit((user or {}).get("name", ""))
        self.role = QComboBox(); [self.role.addItem(t, k) for k, t in ROLES.items()]
        self.status = QComboBox(); [self.status.addItem(t, k) for k, t in STATUS.items()]
        for combo, key, default in ((self.role, "role", "user"), (self.status, "status", "active")):
            combo.setCurrentIndex(max(0, combo.findData((user or {}).get(key, default))))
        self.pw = _pw_edit("leave empty: unchanged" if user else "at least 6 characters")
        f.addRow("User name", self.user); f.addRow("Full name", self.name); f.addRow("Role", self.role)
        f.addRow("Status", self.status)
        f.addRow("New password" if user else "Password", self.pw)
        # sites shared with this user (besides the ones they create themselves)
        from PyQt5.QtWidgets import QListWidget, QListWidgetItem
        self.sites = QListWidget()
        self.sites.setToolTip("Sites this user may open besides the ones they create themselves")
        shared = set((user or {}).get("sites") or [])
        uname = (user or {}).get("username", "").lower()
        try:
            names = sorted(n for n in os.listdir(SITES_DIR) if os.path.isdir(os.path.join(SITES_DIR, n)))
        except OSError:
            names = []
        for n in names:
            owner = site_owner(n)
            it = QListWidgetItem(f"{n}   ({'created by ' + owner if owner else 'administrators'})")
            it.setData(Qt.UserRole, n)
            if uname and owner.lower() == uname:                       # (their own: always)
                it.setFlags(it.flags() & ~Qt.ItemIsUserCheckable & ~Qt.ItemIsEnabled)
                it.setText(f"{n}   (their own)")
            else:
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(Qt.Checked if n in shared else Qt.Unchecked)
            self.sites.addItem(it)
        self.sites.setMaximumHeight(120)
        self.sites_label = QLabel("Shared sites")
        f.addRow(self.sites_label, self.sites)
        note = QLabel("Administrators see every site, every user's collision test reports and manage the users. "
                      "Users see their own sites and the ones shared with them, and their own reports.")
        note.setObjectName("sub"); note.setWordWrap(True); f.addRow(note)
        self.role.currentIndexChanged.connect(self._role)
        self._role()
        bb = QHBoxLayout(); bb.addStretch()
        c = QPushButton("Cancel"); c.clicked.connect(self.reject); bb.addWidget(c)
        ok = QPushButton("Save"); ok.setObjectName("primary"); ok.clicked.connect(self.accept); bb.addWidget(ok)
        f.addRow(bb)
        self.setMinimumWidth(460)

    def _role(self):
        admin = self.role.currentData() == "admin"
        self.sites.setEnabled(not admin)                         # (administrators see every site)

    def shared_sites(self):
        out = []
        for i in range(self.sites.count()):
            it = self.sites.item(i)
            if it.flags() & Qt.ItemIsUserCheckable and it.checkState() == Qt.Checked:
                out.append(it.data(Qt.UserRole))
        return out


class UsersDialog(QDialog):
    """Administrators: the users -- add, approve, role, password, delete."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("authDialog"); self.setStyleSheet(STYLE)
        self.setWindowTitle("Users and permissions")
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        lay = QVBoxLayout(self); lay.setContentsMargins(16, 14, 16, 14); lay.setSpacing(10)
        t = QLabel("Users and permissions"); t.setObjectName("brand"); lay.addWidget(t)
        s = QLabel("Accounts requested with 'Create an account' wait here for approval. Changes apply at the user's "
                   "next sign-in."); s.setObjectName("sub"); s.setWordWrap(True); lay.addWidget(s)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["User", "Name", "Role", "Status", "Last sign-in"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.cellDoubleClicked.connect(lambda *_a: self._edit())
        lay.addWidget(self.table, 1)
        bar = QHBoxLayout()
        for text, fn, name in (("Add user", self._add, "primary"), ("Approve", self._approve, ""),
                               ("Edit ...", self._edit, ""), ("Delete", self._delete, "danger")):
            b = QPushButton(text); b.clicked.connect(fn)
            if name:
                b.setObjectName(name)
            bar.addWidget(b)
        bar.addStretch()
        c = QPushButton("Close"); c.clicked.connect(self.accept); bar.addWidget(c)
        lay.addLayout(bar)
        self.resize(820, 420)
        self._fill()

    def _fill(self):
        us = users()
        self.table.setRowCount(len(us))
        for i, u in enumerate(us):
            vals = [u["username"], u.get("name", ""), ROLES.get(u.get("role"), u.get("role")),
                    STATUS.get(u.get("status"), u.get("status")), u.get("last_login", "--")]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                if j == 3 and u.get("status") == "pending":
                    it.setForeground(Qt.yellow)
                self.table.setItem(i, j, it)

    def _sel(self):
        r = self.table.currentRow()
        us = users()
        return us[r] if 0 <= r < len(us) else None

    def _add(self):
        f = _UserForm(self)
        if f.exec_() != QDialog.Accepted:
            return
        try:
            add_user(f.user.text().strip(), f.pw.text(), f.name.text(), f.role.currentData(),
                     "collision", f.status.currentData())
            if f.shared_sites():
                update_user(f.user.text().strip(), sites=f.shared_sites())
        except ValueError as e:
            QMessageBox.warning(self, "Add user", str(e))
        self._fill()

    def _approve(self):
        u = self._sel()
        if not u:
            return
        try:
            update_user(u["username"], status="active")
        except ValueError as e:
            QMessageBox.warning(self, "Approve", str(e))
        self._fill()

    def _edit(self):
        u = self._sel()
        if not u:
            return
        f = _UserForm(self, u)
        if f.exec_() != QDialog.Accepted:
            return
        ch = {"name": f.name.text(), "role": f.role.currentData(),
              "status": f.status.currentData(), "sites": f.shared_sites()}
        if f.pw.text():
            ch["password"] = f.pw.text()
        try:
            update_user(u["username"], **ch)
        except ValueError as e:
            QMessageBox.warning(self, "Edit user", str(e))
        self._fill()

    def _delete(self):
        u = self._sel()
        if not u:
            return
        if (_current or {}).get("username") == u["username"]:
            QMessageBox.warning(self, "Delete", "You cannot delete the account you are signed in with.")
            return
        if QMessageBox.question(self, "Delete", f"Delete the user '{u['username']}'?") != QMessageBox.Yes:
            return
        try:
            delete_user(u["username"])
        except ValueError as e:
            QMessageBox.warning(self, "Delete", str(e))
        self._fill()
