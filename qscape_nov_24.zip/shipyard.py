import sys
import random
import os
import re
import time
import math
import tempfile
import json
import folium
import qtawesome as qta
from datetime import datetime
from collections import deque, defaultdict
from config_loader import load_site
from screen_utils import enable_high_dpi, fit_to_screen, available_geometry
import scenarios as obstacle_scenarios             # 'Scenarios' menu: saved sets of obstacles
import follow_test                                 # AV follows a manual one: braking on its sensors
import site_config as cfg            # every file path + site setting (see site_config.py)
import osm_surroundings              # "Update 3D": buildings / roads / trees from OpenStreetMap

from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QInputDialog,QScrollArea,QTextBrowser, QGridLayout
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile
from PyQt5.QtCore import QUrl, Qt, QMimeData, QTimer, QObject, QThread, pyqtSlot, pyqtSignal,QSize, QEvent
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtGui import QDrag, QPixmap, QIcon, QPainter, QColor, QFont
from PyQt5.QtWidgets import (
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSplitter,
    QListWidget,
    QListWidgetItem,
    QAbstractItemView,
    QMenu,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QFrame,
    QSizePolicy,
    QStackedWidget,
    QToolButton,
    QStyle
)
from PyQt5.QtWidgets import QComboBox, QCheckBox, QButtonGroup, QFileDialog, QSlider, QDoubleSpinBox
from PyQt5.QtWidgets import QStyledItemDelegate, QToolTip
from PyQt5.QtCore import QRect, QPropertyAnimation, QEasingCurve
from PyQt5.QtWidgets import QShortcut, QProgressDialog
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView, QSpinBox
from PyQt5.QtGui import QKeySequence

# =======================================================
# Custom MIME type used to carry an AV / obstacle
# from the side panel to the map when dragged
# =======================================================
AV_MIME_TYPE = "application/x-qscape-vehicle"

# Application version shown in the bottom bar -- bump this on every release.
APP_NAME = "Q-SCAPE"
APP_VERSION = "1.0.0"
# browser identity of the map / 3D pages (tile servers, web filter): see MapWindow.__init__
WEB_USER_AGENT = (f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) qscape/{APP_VERSION} "
                  "(site map; QtWebEngine 5.15)")

# ---- Measured vehicle dimensions (metres): config/vehicle_dimensions.json ----
# AVs / trailers are drawn to these sizes on the map (rotated to their slot or
# heading) and in the 3D LiDAR view. A vehicle's lat/lng is the CENTRE of its footprint.
VEHICLE_DIMENSIONS = cfg.VEHICLE_DIMENSIONS
AV_COLOR = "#F59E0B"        # the AVs' colour in the list
# ---- Obstacle types (config/obstacle_types.json): icon, default size + speed ----
OBSTACLE_TYPES = cfg.OBSTACLE_TYPES
OBSTACLE_FIELD_LABELS = {
    "length": "Length", "width": "Width", "height": "Height",
    "wheelbase": "Wheelbase", "ground_clearance": "Ground clearance",
}


RIGHT_PANEL_WIDTH = 560
SIDEBAR_WIDTH = 72              # the left icon rail (pages open in a drawer over the map)
SIDEBAR_WIDTH_EXPANDED = SIDEBAR_WIDTH
ICON_TILE_SIZE = 88
ICON_IMAGE_SIZE = 56

COLOR_BG = "#1A1A1A"
COLOR_PANEL_BG = "#2A2A2A"
COLOR_BORDER = "#3F3F46"
COLOR_TEXT = "#FFFFFF"
# COLOR_TEXT = "#FBBF24"
COLOR_MUTED_TEXT = "#6B7280"
# COLOR_MUTED_TEXT = "#FBBF24"
# COLOR_BG = "#1E1E1E"
# COLOR_PANEL_BG = "#2A2A2A"
# COLOR_BORDER = "#3F3F46"
# COLOR_TEXT = "#E4E4E7"
# COLOR_MUTED_TEXT = "#A1A1AA"
COLOR_ACCENT = "#7C3AED"
COLOR_ACCENT_HOVER = "#6D28D9"

COLOR_ACCENT_PRESSED = "#5B21B6"


def _make_check_icon():
    """Renders a small black tick to a temp PNG so QSS can use it inside the
    amber QCheckBox indicators. Returns the file path (forward slashes)."""
    path = os.path.join(tempfile.gettempdir(), "shipyard_check.png")
    try:
        qta.icon("fa5s.check", color="black").pixmap(14, 14).save(path, "PNG")
    except Exception:
        return ""
    return path.replace("\\", "/")


def load_app_stylesheet():
    """
    Load the external styles.qss file and fill in the theme colors.
    All static UI styling now lives in styles.qss, kept separate
    from this file's application logic. Colors are still defined
    here (COLOR_* constants) since a few places in the app also
    compute colors dynamically at runtime; styles.qss references
    them via simple @token@ placeholders (not str.format(), so the
    QSS file itself stays plain and readable).
    """
    with open(cfg.STYLESHEET_FILE, "r") as f:
        css = f.read()

    tokens = {
        "@color_bg@": COLOR_BG,
        "@color_panel_bg@": COLOR_PANEL_BG,
        "@color_border@": COLOR_BORDER,
        "@color_text@": COLOR_TEXT,
        "@color_muted_text@": COLOR_MUTED_TEXT,
        "@color_accent@": COLOR_ACCENT,
        "@color_accent_hover@": COLOR_ACCENT_HOVER,
        "@color_accent_pressed@": COLOR_ACCENT_PRESSED,
        "@check_icon@": _make_check_icon(),
    }
    for token, value in tokens.items():
        css = css.replace(token, value)

    return css


ICON_REF_ZOOM = 20
ICON_MIN_SCALE = 0.25

USE_REPORTED_TRUCK_HEADING = False
TRUCK_HEADING_MIN_MOVE_M = 0.3      # ignore moves smaller than this (GPS jitter)

# Icons live in assets/icons. These are file:// URLs, so the map page can use them
# from wherever it is generated; cfg.url_to_file() turns one back into a disk path.
CAR_ICON_PATH = cfg.icon_url(OBSTACLE_TYPES["car"]["icon"])
PEDESTRIAN_ICON_PATH = cfg.icon_url(OBSTACLE_TYPES["pedestrian"]["icon"])
AV_ICON_PATH = cfg.icon_url("truck.png")

# Pseudo-3D AV used for route replay. Drawn facing EAST (right):
# the head is the cab with windshield + yellow headlights.
REPLAY_TRUCK_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="32" viewBox="0 0 64 32">\n<rect x="4" y="9" width="58" height="20" rx="4" fill="rgba(0,0,0,0.28)"/>\n<rect x="2" y="9" width="37" height="18" rx="2" fill="#64748B"/>\n<rect x="2" y="5" width="37" height="19" rx="2" fill="#E2E8F0" stroke="#475569" stroke-width="1"/>\n<line x1="11" y1="5" x2="11" y2="24" stroke="#CBD5E1" stroke-width="1"/>\n<line x1="20" y1="5" x2="20" y2="24" stroke="#CBD5E1" stroke-width="1"/>\n<line x1="29" y1="5" x2="29" y2="24" stroke="#CBD5E1" stroke-width="1"/>\n<rect x="39" y="12" width="5" height="6" fill="#334155"/>\n<rect x="43" y="9" width="20" height="18" rx="3" fill="#1E3A8A"/>\n<rect x="43" y="5" width="20" height="19" rx="3" fill="#3B82F6" stroke="#1E3A8A" stroke-width="1"/>\n<rect x="45" y="7" width="7" height="15" rx="1" fill="#2563EB"/>\n<polygon points="54,7 60,9 60,20 54,22" fill="#BAE6FD" stroke="#0C4A6E" stroke-width="1"/>\n<circle cx="60.5" cy="8" r="2" fill="#FDE047" stroke="#A16207" stroke-width="0.5"/>\n<circle cx="60.5" cy="21" r="2" fill="#FDE047" stroke="#A16207" stroke-width="0.5"/>\n<rect x="1" y="7" width="2" height="4" fill="#EF4444"/>\n<rect x="1" y="18" width="2" height="4" fill="#EF4444"/>\n<rect x="7" y="24" width="9" height="4" rx="1" fill="#0F172A"/>\n<rect x="23" y="24" width="9" height="4" rx="1" fill="#0F172A"/>\n<rect x="47" y="24" width="9" height="4" rx="1" fill="#0F172A"/>\n</svg>'
# Cab-only pseudo-3D AV (no trailer) for the LIVE drive_info marker.
# Drawn facing EAST (right), same as REPLAY_TRUCK_SVG.
LIVE_TRUCK_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="44" height="32" viewBox="0 0 44 32">\n<rect x="3" y="9" width="40" height="20" rx="4" fill="rgba(0,0,0,0.28)"/>\n<rect x="2" y="9" width="22" height="18" rx="2" fill="#475569"/>\n<rect x="2" y="5" width="22" height="19" rx="2" fill="#94A3B8" stroke="#475569" stroke-width="1"/>\n<circle cx="12" cy="14.5" r="5" fill="#334155" stroke="#0F172A" stroke-width="1"/>\n<rect x="23" y="9" width="20" height="18" rx="3" fill="#1E3A8A"/>\n<rect x="23" y="5" width="20" height="19" rx="3" fill="#3B82F6" stroke="#1E3A8A" stroke-width="1"/>\n<rect x="25" y="7" width="7" height="15" rx="1" fill="#2563EB"/>\n<polygon points="34,7 40,9 40,20 34,22" fill="#BAE6FD" stroke="#0C4A6E" stroke-width="1"/>\n<circle cx="40.5" cy="8" r="2" fill="#FDE047" stroke="#A16207" stroke-width="0.5"/>\n<circle cx="40.5" cy="21" r="2" fill="#FDE047" stroke="#A16207" stroke-width="0.5"/>\n<rect x="1" y="7" width="2" height="4" fill="#EF4444"/>\n<rect x="1" y="18" width="2" height="4" fill="#EF4444"/>\n<rect x="5" y="24" width="9" height="4" rx="1" fill="#0F172A"/>\n<rect x="27" y="24" width="9" height="4" rx="1" fill="#0F172A"/>\n</svg>'
OUTER_TRUCK_ICON_PATH = cfg.icon_url(OBSTACLE_TYPES["outer_truck"]["icon"])

# Fail loudly, at startup, if any icon file is actually missing on disk --
# a missing/misspelled/wrong-case file is the single most common reason a
# marker gets created successfully in Leaflet (no JS error at all) but
# never renders anything visible: the <img> just 404s silently inside
# the WebEngine view.
for _icon_name, _icon_path in [
    ("CAR_ICON_PATH", CAR_ICON_PATH),
    ("PEDESTRIAN_ICON_PATH", PEDESTRIAN_ICON_PATH),
    ("AV_ICON_PATH", AV_ICON_PATH),
]:
    if not os.path.isfile(cfg.url_to_file(_icon_path)):
        print(f"!!!!! MISSING ICON FILE: {_icon_name} -> {_icon_path} "
              f"(this file does not exist -- markers using it will be "
              f"created but invisible) !!!!!")
    else:
        print(f"OK icon file found: {_icon_name} -> {cfg.url_to_file(_icon_path)}")

UNKNOWN_OBJECT_ICONS = {kind: cfg.icon_url(t["icon"]) for kind, t in OBSTACLE_TYPES.items()}

# this yard's runtime data: sites/<site>/data/
UNKNOWN_OBJECTS_FILE = cfg.OBSTACLES_FILE

DYNAMIC_OBJECT_STEP_MS = 150
# Starting / highest speed of a moving obstacle (km/h), per type, from
# config/obstacle_types.json. Each one can be changed on the Obstacles page
# (select it in Placed Objects) and is saved with the object.
DYNAMIC_OBJECT_DEFAULT_SPEED_KMH = {k: t["speed_kmh"]["default"] for k, t in OBSTACLE_TYPES.items()}
DYNAMIC_OBJECT_FALLBACK_SPEED_KMH = 8.0
DYNAMIC_OBJECT_MIN_SPEED_KMH = 0.5
DYNAMIC_OBJECT_MAX_SPEED_KMH = {k: t["speed_kmh"]["max"] for k, t in OBSTACLE_TYPES.items()}
DYNAMIC_OBJECT_FALLBACK_MAX_SPEED_KMH = 120.0
DYNAMIC_OBJECT_DETECT_EVERY_N_FRAMES = 4
OBSTACLE_ACCIDENT_HOLD_S = 8.0     # "Collisions" on: crashed obstacles stand still this long
Y3D_HISTORY_FRAMES = 3600         # 3D view replay timeline: the last positions kept (~15-30 min at 2-4 Hz)
ACCIDENT_JS = """
if (!window.showAccident) {
    var st = document.createElement('style');
    st.textContent = '.accident-icon{background:none;border:none}' +
        '.accident-icon div{font-size:26px;line-height:30px;text-align:center;animation:accPulse .6s ease-in-out infinite alternate}' +
        '@keyframes accPulse{from{transform:scale(.8)}to{transform:scale(1.25)}}';
    document.head.appendChild(st);
    window.showAccident = function(lat, lng, text, ms) {
        var M = window.__accMap;
        var mk = L.marker([lat, lng], { icon: L.divIcon({ className: 'accident-icon', html: '<div>\\uD83D\\uDCA5</div>',
                                                          iconSize: [30, 30], iconAnchor: [15, 15] }),
                                        interactive: false, zIndexOffset: 1500 }).addTo(M);
        mk.bindTooltip(text, { permanent: true, direction: 'top', offset: [0, -14], className: 'lidar-tip' });
        setTimeout(function() { M.removeLayer(mk); }, ms);
    };
}
"""

# Safety circle drawn around the moving AV (arrow). Anything that comes
# inside this radius (metres) triggers a pop-up notification.
PROXIMITY_RADIUS_M = 3
PROXIMITY_FILL_COLOR = "#FEF08A"     # light yellow
PROXIMITY_BORDER_COLOR = "#FACC15"

PROXIMITY_MIN_SCREEN_PX = 45

# LiDAR drawn at the FRONT of every AV (live AV and route-replay AV):
# a glass-dome scan volume with range rings, rotating beam sweep, point-cloud rings,
# a sensor head and red return points on anything inside the range.
LIDAR_RADIUS_M = 3                 # lidar range, in real metres
# The LiDAR is mounted exactly on the nose of the AV ICON. This is the distance, in
# icon pixels, from the icon centre to its front edge (the icon is scaled with the zoom,
# and so is this distance, so the LiDAR stays glued to the nose at every zoom level).
LIDAR_NOSE_PX_LIVE = 21            # live AV icon (44 px wide drawing)
LIDAR_NOSE_PX_REPLAY = 31          # route-following AV icon (64 px wide drawing)
LIDAR_MIN_PX = 24                  # never drawn smaller than this on screen (zoomed far out)

LIDAR_CSS = """
.lidar-icon{background:none;border:none;pointer-events:none}
.lidar-wrap{position:relative;width:100%;height:100%;pointer-events:none}
.lidar-svg{position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible}
.lidar-sweep{position:absolute;left:1%;top:1%;width:98%;height:98%;border-radius:50%;
  background:conic-gradient(from 0deg,rgba(34,211,238,0) 0deg,rgba(34,211,238,0) 255deg,
  rgba(34,211,238,.42) 345deg,rgba(207,250,254,.95) 360deg);
  animation:lidarSpin 2s linear infinite}
.lidar-pc{fill:none;stroke:#A5F3FC;stroke-linecap:round;transform-box:fill-box;transform-origin:center}
.lidar-pc1{stroke-width:2.4;stroke-dasharray:.1 7;animation:lidarSpin 7s linear infinite}
.lidar-pc2{stroke-width:2.4;stroke-dasharray:.1 6;animation:lidarSpin 5s linear infinite reverse}
.lidar-pc3{stroke-width:2.4;stroke-dasharray:.1 8;animation:lidarSpin 9s linear infinite}
.lidar-pc4{stroke-width:2.4;stroke-dasharray:.1 9;animation:lidarSpin 6s linear infinite reverse}
.lidar-pulse{fill:none;stroke:#67E8F9;stroke-width:2;transform-box:fill-box;
  transform-origin:center;animation:lidarPulse 2.4s ease-out infinite}
.lidar-beam{stroke:#67E8F9;stroke-width:1.1;stroke-linecap:round;opacity:.08;
  animation:lidarFlicker 1.3s ease-in-out infinite}
.lidar-tip{background:#B91C1C;color:#fff;border:1px solid #FCA5A5;border-radius:4px;
  padding:1px 6px;font-size:11px;font-weight:600;box-shadow:none}
.lidar-tip.leaflet-tooltip-right:before{border-right-color:#B91C1C}
.lidar-alert .lidar-svg:first-of-type circle:first-child{stroke:#EF4444}
.lidar-alert .lidar-sweep{filter:hue-rotate(173deg) saturate(1.6)}
@keyframes lidarFlicker{0%,100%{opacity:.05}50%{opacity:.7}}
@keyframes lidarSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@keyframes lidarPulse{0%{transform:scale(.08);opacity:.85}100%{transform:scale(1);opacity:0}}
"""

# gradients are defined once for the whole page (so removing one lidar can't break the others)
LIDAR_DEFS_SVG = """<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<radialGradient id="lidarDome" cx="50%" cy="50%" r="50%" fx="38%" fy="32%">
  <stop offset="0%" stop-color="#ECFEFF" stop-opacity="0.38"/>
  <stop offset="55%" stop-color="#22D3EE" stop-opacity="0.12"/>
  <stop offset="100%" stop-color="#0891B2" stop-opacity="0.40"/></radialGradient>
<radialGradient id="lidarShadow" cx="50%" cy="50%" r="50%">
  <stop offset="0%" stop-color="#000" stop-opacity="0.55"/>
  <stop offset="100%" stop-color="#000" stop-opacity="0"/></radialGradient>
<linearGradient id="lidarPuckBody" x1="0" y1="0" x2="1" y2="1">
  <stop offset="0%" stop-color="#6B7280"/><stop offset="100%" stop-color="#111827"/></linearGradient>
<linearGradient id="lidarPuckCap" x1="0" y1="0" x2="1" y2="1">
  <stop offset="0%" stop-color="#F3F4F6"/><stop offset="100%" stop-color="#4B5563"/></linearGradient>
</defs></svg>"""

# --- 3D look (oblique projection: the ground footprint stays an exact top-down circle,
#     height is drawn as an upward shift, so it is still the real 3 m on the map) ---
LIDAR_3D_K = 0.62          # how tall the dome looks (1.0 = as tall as it is wide)
LIDAR_SENSOR_H = 14        # sensor height above the ground, in drawing units (98 units = radius)


def _build_lidar_html():
    R, C = 98.0, 100.0
    k = LIDAR_3D_K
    hs = LIDAR_SENSOR_H
    sy = C - hs                                   # sensor centre (y) in the drawing
    out = []
    out.append('<div class="lidar-wrap">')

    # ---- ground plane: the real 3 m footprint ----
    out.append('<svg class="lidar-svg" viewBox="0 0 200 200">')
    out.append(f'<circle cx="{C}" cy="{C}" r="{R}" fill="url(#lidarDome)" '
               f'stroke="#22D3EE" stroke-width="2" stroke-opacity="0.95"/>')
    for rr in (R / 3, 2 * R / 3):
        out.append(f'<circle cx="{C}" cy="{C}" r="{rr:.1f}" fill="none" stroke="#67E8F9" '
                   f'stroke-opacity="0.4" stroke-width="1" stroke-dasharray="3 4"/>')
    out.append(f'<circle class="lidar-pulse" cx="{C}" cy="{C}" r="{R}"/>')
    out.append('</svg>')
    out.append('<div class="lidar-sweep"></div>')

    # ---- everything that has height ----
    out.append('<svg class="lidar-svg" viewBox="0 0 200 200">')

    # meridians of the dome (ground rim -> apex)
    for deg in range(0, 360, 30):
        ph = deg * 3.14159265 / 180
        pts = []
        for el in range(0, 91, 10):
            t = el * 3.14159265 / 180
            r = R * __import__("math").cos(t)
            h = R * __import__("math").sin(t) * k
            pts.append(f"{C + r * __import__('math').cos(ph):.1f},{C + r * __import__('math').sin(ph) - h:.1f}")
        out.append(f'<polyline points="{" ".join(pts)}" fill="none" stroke="#67E8F9" '
                   f'stroke-opacity="0.22" stroke-width="0.8"/>')

    # stacked cross-sections (give the dome its volume)
    import math as _m
    for el in range(10, 90, 10):
        t = el * _m.pi / 180
        r = R * _m.cos(t)
        h = R * _m.sin(t) * k
        out.append(f'<circle cx="{C}" cy="{C - h:.1f}" r="{r:.1f}" fill="#22D3EE" '
                   f'fill-opacity="0.035" stroke="#A5F3FC" stroke-opacity="0.30" stroke-width="0.9"/>')

    # laser point-cloud rings at three elevations, spinning
    for cls, el in (("lidar-pc1", 12), ("lidar-pc2", 32), ("lidar-pc3", 52)):
        t = el * _m.pi / 180
        r = R * _m.cos(t) * 0.98
        h = R * _m.sin(t) * k
        out.append(f'<circle class="lidar-pc {cls}" cx="{C}" cy="{C - h:.1f}" r="{r:.1f}"/>')

    # laser beams from the sensor down to the ground ring (flickering)
    for i, deg in enumerate(range(15, 360, 45)):
        ph = deg * _m.pi / 180
        x2 = C + R * 0.96 * _m.cos(ph)
        y2 = C + R * 0.96 * _m.sin(ph)
        out.append(f'<line class="lidar-beam" x1="{C}" y1="{sy}" x2="{x2:.1f}" y2="{y2:.1f}" '
                   f'style="animation-delay:{i * 0.16:.2f}s"/>')

    # mast + ground shadow + sensor head (cylinder)
    out.append(f'<ellipse cx="{C + 7}" cy="{C + 3}" rx="12" ry="5" fill="url(#lidarShadow)"/>')
    out.append(f'<line x1="{C}" y1="{C}" x2="{C}" y2="{sy}" stroke="#374151" stroke-width="3" '
               f'stroke-linecap="round"/>')
    out.append(f'<ellipse cx="{C}" cy="{sy}" rx="9" ry="4.2" fill="#111827"/>')
    out.append(f'<rect x="{C - 9}" y="{sy - 9}" width="18" height="9" fill="url(#lidarPuckBody)"/>')
    out.append(f'<ellipse cx="{C}" cy="{sy - 9}" rx="9" ry="4.2" fill="url(#lidarPuckCap)" '
               f'stroke="#0E7490" stroke-width="0.8"/>')
    out.append(f'<ellipse cx="{C - 2}" cy="{sy - 9.6}" rx="3.2" ry="1.4" fill="#fff" fill-opacity="0.8"/>')
    out.append(f'<circle cx="{C + 5.5}" cy="{sy - 4.2}" r="1.3" fill="#EF4444"/>')   # status LED
    out.append('</svg></div>')
    return "".join(out)


LIDAR_HTML = _build_lidar_html()

VEHICLE_FOOTPRINT_JS = """
// ---- trucks / trailers drawn to their real size (VEHICLE_DIMENSIONS) ----
window.vehicleSpecs = __SPECS__;
window.vehicleGeom = window.vehicleGeom || {};      // vehicle id -> {kind, heading}
(function() {
    if (document.getElementById('footprint-style')) return;
    var st = document.createElement('style'); st.id = 'footprint-style';
    // only the painted body takes clicks / drags, not the transparent square around
    // it -- parked trailers are 3.6 m apart, their boxes overlap
    st.textContent = '.vehicle-footprint{pointer-events:none !important;background:none;border:none}' +
                     '.vehicle-footprint svg{pointer-events:none;overflow:visible}' +
                     '.vehicle-footprint svg .body{pointer-events:visiblePainted;cursor:pointer}';
    document.head.appendChild(st);
})();
window.metresPerPixel = function(lat) {
    return 40075016.686 * Math.cos(lat * Math.PI / 180) / (256 * Math.pow(2, __MAP__.getZoom()));
};
function fpRect(x, y, w, h, fill, extra) {
    return '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + Math.max(0.5, w).toFixed(1) +
           '" height="' + Math.max(0.5, h).toFixed(1) + '" fill="' + fill + '" ' + (extra || '') + '/>';
}
// kind: 'tractor' | 'trailer_normal' | 'trailer_refrig' | 'trailer_pup'
// heading: compass degrees the FRONT faces. Returns a Leaflet icon centred on the vehicle.
window.footprintIcon = function(kind, heading, lat, label) {
    var sp = window.vehicleSpecs[kind];
    if (!sp) return null;
    var mpp = window.metresPerPixel(lat);
    // (not "L": that would hide Leaflet's global L)
    var Lp = Math.max(10, sp.length / mpp), W = Math.max(4, sp.width / mpp); // never vanish when zoomed out
    var k = Lp / sp.length;                                                  // px per metre actually used
    var S = Math.ceil(Math.sqrt(Lp * Lp + W * W)) + 4, c = S / 2;
    var x0 = c - W / 2, y0 = c - Lp / 2;                                     // drawn facing north (front = top)
    var r = Math.min(W * 0.18, 0.35 * k), parts = [];
    var outline = 'stroke="#0B0B0B" stroke-width="1" rx="' + r.toFixed(1) + '" class="body"';
    if (kind === 'tractor' || kind === 'tractor_manual') {
        var cabCol = kind === 'tractor' ? '#F59E0B' : '#3B82F6';   // autonomous amber, manual blue
        parts.push(fpRect(x0, y0, W, Lp, '#4B5563', outline));                         // chassis
        var cab = Math.min(Lp * 0.55, 2.3 * k);
        parts.push(fpRect(x0, y0, W, cab, cabCol, 'rx="' + r.toFixed(1) + '"'));       // cab at the front
        parts.push(fpRect(x0 + W * 0.12, y0 + cab * 0.10, W * 0.76, Math.max(1, cab * 0.16), '#0F172A'));  // windscreen
        var kp = y0 + sp.front_to_kingpin * k;                                          // fifth wheel / kingpin socket
        parts.push('<circle cx="' + c + '" cy="' + kp.toFixed(1) + '" r="' + Math.max(1.2, 0.45 * k).toFixed(1) +
                   '" fill="#D1D5DB" stroke="#111827" stroke-width="0.6"/>');
        var fa = y0 + sp.front_overhang * k, ra = y0 + Lp - sp.rear_overhang * k;     // axle lines
        [fa, ra].forEach(function(y) {
            parts.push(fpRect(x0 - Math.max(0.6, 0.12 * k), y - Math.max(0.6, 0.25 * k),
                              W + 2 * Math.max(0.6, 0.12 * k), Math.max(1.2, 0.5 * k), '#111827'));
        });
    } else {
        // normal grey, reefer light blue, pup violet; a stripe in the brand colour along one side
        var col = sp.map_color || (sp.reefer_unit ? '#7DD3FC' : sp.length < 13 ? '#C4B5FD' : '#94A3B8');
        parts.push(fpRect(x0, y0, W, Lp, col, outline));
        var brand = { fleet: '#C8102E', brand: '#1E3A8A' }[sp.livery];
        if (brand) parts.push(fpRect(x0 + W * 0.08, y0 + Lp * 0.12, Math.max(1, W * 0.12), Lp * 0.76, brand));
        if (sp.reefer_unit)                                                             // reefer unit on the front wall
            parts.push(fpRect(x0 + W * 0.15, y0 + 0.1 * k, W * 0.7, Math.max(1.5, 0.6 * k), '#0369A1'));
        if (sp.wheelbase_max) {                                                          // rear axles (tandem all the way back)
            var a1 = (sp.kingpin + sp.wheelbase_max) * k, a2 = a1 + (sp.axle_spread || 1.27) * k;
            var axles = [a1, a2]; if (sp.lift_axle) axles.push((sp.kingpin + sp.lift_axle) * k);
            axles.forEach(function(a) {
                parts.push(fpRect(x0 - Math.max(0.5, 0.08 * k), y0 + a - Math.max(0.6, 0.26 * k),
                                  W + 2 * Math.max(0.5, 0.08 * k), Math.max(1.2, 0.52 * k), 'rgba(17,24,39,0.55)'));
            });
        }
        parts.push(fpRect(x0, y0 + Lp - Math.max(1.2, 0.3 * k), W, Math.max(1.2, 0.3 * k), '#334155'));  // rear doors
        parts.push('<circle cx="' + c + '" cy="' + (y0 + sp.kingpin * k).toFixed(1) + '" r="' +
                   Math.max(1.2, 0.3 * k).toFixed(1) + '" fill="#111827"/>');           // kingpin
    }
    if (label && Lp > 80 && W > 14) {
        var fs = Math.min(W * 0.5, 13);
        parts.push('<text x="' + c + '" y="' + (c + fs * 0.35).toFixed(1) + '" font-size="' + fs.toFixed(1) +
                   '" font-family="Segoe UI,Arial" font-weight="700" fill="#0F172A" text-anchor="middle" ' +
                   'transform="rotate(-90 ' + c + ' ' + c + ')">' + String(label).replace(/[<&>]/g, '') + '</text>');
    }
    var svg = '<svg width="' + S + '" height="' + S + '" viewBox="0 0 ' + S + ' ' + S + '">' +
              '<g transform="rotate(' + (heading || 0) + ' ' + c + ' ' + c + ')">' + parts.join('') + '</g></svg>';
    return L.divIcon({ html: svg, className: 'vehicle-footprint', iconSize: [S, S], iconAnchor: [c, c] });
};
"""

LIDAR_JS_TEMPLATE = """
// ---- LiDAR at the front of a truck ----
(function() {
    if (!document.getElementById('lidar-style')) {
        var st = document.createElement('style'); st.id = 'lidar-style';
        st.textContent = __CSS__; document.head.appendChild(st);
    }
    if (!document.getElementById('lidar-defs')) {
        var holder = document.createElement('div'); holder.id = 'lidar-defs';
        holder.innerHTML = __DEFS__; document.body.appendChild(holder);
    }
})();
window.allLidars = window.allLidars || [];

// metres from the truck position to the nose of its drawn icon, at the current zoom
// (nosePx may also be {m: metres} for trucks drawn at their real size)
window.lidarNoseMetres = function(lat, nosePx) {
    if (nosePx && typeof nosePx === 'object') return nosePx.m;
    var z = __MAP__.getZoom();
    var mpp = 40075016.686 * Math.cos(lat * Math.PI / 180) / (256 * Math.pow(2, z));
    return nosePx * (window.iconScale ? window.iconScale() : 1) * mpp;
};
window.lidarFront = function(lat, lon, headingDeg, nosePx) {
    var off = window.lidarNoseMetres(lat, nosePx);
    var r = headingDeg * Math.PI / 180;
    var dN = off * Math.cos(r), dE = off * Math.sin(r);
    return [lat + dN / 111320, lon + dE / (111320 * Math.cos(lat * Math.PI / 180))];
};
window.lidarPixelSize = function(lat) {
    var z = __MAP__.getZoom();
    var mpp = 40075016.686 * Math.cos(lat * Math.PI / 180) / (256 * Math.pow(2, z));
    return Math.max(__MINPX__, Math.round(2 * __R__ / mpp));
};
window.applyLidarSize = function(l) {
    var size = window.lidarPixelSize(l[0].getLatLng().lat);
    l[0].setIcon(L.divIcon({
        html: __HTML__, className: 'lidar-icon',
        iconSize: [size, size], iconAnchor: [size / 2, size / 2]
    }));
};
window.refreshLidarSizes = function() {
    window.allLidars = window.allLidars.filter(function(l) { return l[0]._map; });
    window.allLidars.forEach(function(l) {
        window.applyLidarSize(l);
        var t = l[0]._truck;                       // stay on the nose after a zoom change
        if (t) window.moveLidar(l, t.lat, t.lon, t.heading);
    });
};
__MAP__.on('zoomend', window.refreshLidarSizes);

// returns [sensorMarker, returnPointsGroup]; ownMarker = the truck it is mounted on
window.makeLidar = function(lat, lon, heading, ownMarker, nosePx) {
    var p = window.lidarFront(lat, lon, heading, nosePx);
    var marker = L.marker(p, { interactive: false, keyboard: false, zIndexOffset: -500 })
                  .addTo(__MAP__);
    marker._own = ownMarker || null;
    marker._nosePx = nosePx;
    var hits = L.layerGroup().addTo(__MAP__);
    var l = [marker, hits];
    window.allLidars.push(l);
    window.applyLidarSize(l);
    window.moveLidar(l, lat, lon, heading);
    return l;
};
// Scans everything on the map against ONE lidar. Runs on every truck update AND
// 4 times a second, so obstacles that move into range are detected even when the
// truck is standing still.  Returns the list of detections.
window.lidarScan = function(l) {
    var marker = l[0], g = l[1];
    if (!marker._map) return [];
    var ll = marker.getLatLng();
    var own = marker._own ? marker._own.getLatLng() : null;
    var found = [], seen = {};
    function check(id, mk) {
        if (!mk || !mk.getLatLng) return;
        var q = mk.getLatLng();
        if (own && __MAP__.distance(own, q) < 1.0) return;      // the truck itself
        var d = __MAP__.distance(ll, q);
        if (d > __R__) return;                                  // out of range
        found.push({ id: id, label: (mk.options && mk.options.title) || id,
                     distance: d, lat: q.lat, lng: q.lng });
    }
    function scan(reg, prefix) {
        if (reg) Object.keys(reg).forEach(function(k) { check(prefix + k, reg[k]); });
    }
    // detections from the LiDAR data (hidden 3D sensor page, MapWindow._lidar_detect_tick): what the
    // truck's LiDAR really sees -- points on the object, gap to the truck body; occluded / blind-zone
    // objects are not detected. Without fresh LiDAR data: the old 3 m distance check.
    var det = window.lidarDet, key = null;
    if (det && Date.now() - det.t < 2500) {
        if (window.lidarLive && l === window.lidarLive) key = 'live';
        else if (window.replayLayers) for (var rk in window.replayLayers) {
            if (window.replayLayers[rk][2] === marker) { key = rk; break; }
        }
    }
    if (key !== null && det.trucks[key]) {
        det.trucks[key].dets.forEach(function(d) {
            if (d.gap > det.mapRange) return;
            found.push({ id: d.id, label: (d.label || d.id) + ' · ' + d.points + ' pts', distance: d.gap,
                         lat: d.lat, lng: d.lng, lidar: true, points: d.points });
        });
    } else {
    scan(window.unknownMarkers, '');      // obstacles: cars, pedestrians, outer trucks
    scan(window.vehicleMarkers, '');      // trucks / trailers parked on the map
    if (window.replayLayers) {
        Object.keys(window.replayLayers).forEach(function(k) { check('route:' + k, window.replayLayers[k][1]); });
    }
    }

    var hm = marker._hitMap = marker._hitMap || {};
    found.forEach(function(f) {
        seen[f.id] = true;
        var q = L.latLng(f.lat, f.lng), txt = f.label + ' - ' + f.distance.toFixed(1) + ' m';
        var h = hm[f.id];
        if (!h) {
            h = hm[f.id] = {
                ray: L.polyline([ll, q], { color: '#F87171', weight: 1.8, opacity: 0.9,
                                           dashArray: '3 3', interactive: false }).addTo(g),
                ring: L.circleMarker(q, { radius: 13, color: '#EF4444', weight: 2, fill: false,
                                          dashArray: '3 3', interactive: false }).addTo(g),
                dot: L.circleMarker(q, { radius: 4, color: '#EF4444', fillColor: '#F87171',
                                         fillOpacity: 1, weight: 1, interactive: false }).addTo(g)
            };
            h.dot.bindTooltip(txt, { permanent: true, direction: 'right', offset: [10, 0],
                                     className: 'lidar-tip' });
        } else {
            h.ray.setLatLngs([ll, q]); h.ring.setLatLng(q); h.dot.setLatLng(q);
            h.dot.setTooltipContent(txt);
        }
    });
    Object.keys(hm).forEach(function(id) {                      // no longer in range
        if (!seen[id]) {
            var h = hm[id];
            g.removeLayer(h.ray); g.removeLayer(h.ring); g.removeLayer(h.dot);
            delete hm[id];
        }
    });

    marker._detected = found;
    var alertM = det && det.alertRange != null ? det.alertRange : __R__;
    var el = marker.getElement();
    var alarm = found.some(function(f) { return f.distance <= alertM; });
    if (el) { if (alarm) el.classList.add('lidar-alert'); else el.classList.remove('lidar-alert'); }
    return found;
};
// LiDAR detections pushed from Python: {trucks: {truck id: {dets: [...]}}, mapRange, alertRange}
window.setLidarDetections = function(d) {
    d.t = Date.now(); window.lidarDet = d;
    window.allLidars.forEach(function(l) { if (l[0]._map && l[0]._truck) window.lidarScan(l); });
};

window.moveLidar = function(layers, lat, lon, heading) {
    layers[0]._truck = { lat: lat, lon: lon, heading: heading };
    var p = window.lidarFront(lat, lon, heading, layers[0]._nosePx);
    layers[0].setLatLng(L.latLng(p[0], p[1]));
    window.lidarScan(layers);
};

if (!window.__lidarTimer) {
    window.__lidarTimer = setInterval(function() {
        window.allLidars.forEach(function(l) { if (l[0]._map && l[0]._truck) window.lidarScan(l); });
    }, 250);
}
"""


PATH_REPLAY_INTERVAL_MS = 1000
FOLLOW_REPORT_RANGE_M = follow_test.REPORT_RANGE_M    # LiDAR detections reported during a follow test
FOLLOW_STEP_MS = 100                                  # the follow test's control step
LANE_OFFSET_M = 1.75                                  # collision testing on a two-way route: half a lane width

# Saved drive routes of this yard: every *.txt in sites/<site>/routes/
SAVED_PATHS = cfg.site_routes()
NO_ROUTE_LABEL = "None (no route)"

_PATH_LINE_RE = re.compile(
    r"lat=(-?\d+(?:\.\d+)?)\s*\|\s*lng=(-?\d+(?:\.\d+)?)\s*\|\s*heading=(-?\d+(?:\.\d+)?)"
)


def parse_saved_path_file(filename):
    """
    Reads a saved path (.txt) and returns [(lat, lon, heading), ...] in file order.

    Understands the lines the drive_info log writes:
        2026-10-06 12:33:05 | vehicle=GNSS-TRUCK | lat=42.7111 | lng=-84.6429 | heading=270.03 | {json}
    If a line is damaged but still carries the JSON message, the position is
    taken from that instead. Lines it cannot read are skipped.
    """
    points = []
    with open(filename, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            m = _PATH_LINE_RE.search(line)
            if m:
                points.append((float(m.group(1)), float(m.group(2)), float(m.group(3))))
                continue

            brace = line.find("{")
            if brace != -1:
                try:
                    pos = json.loads(line[brace:])["msg"]["position"]
                    points.append((float(pos["lat"]), float(pos["lng"]),
                                   float(pos.get("heading", 0))))
                except (ValueError, KeyError, TypeError):
                    pass
    return points


def load_route(name):
    """Points for a route name from SAVED_PATHS: [(lat, lon, heading), ...]."""
    source = SAVED_PATHS[name]
    if isinstance(source, str):
        if not os.path.isabs(source):
            source = os.path.join(os.path.dirname(os.path.abspath(__file__)), source)
        return parse_saved_path_file(source)
    return [(float(a), float(b), float(c)) for a, b, c in source]


def _metres_between(lat1, lon1, lat2, lon2):
    """Ground distance in metres (flat-earth approximation -- fine inside one yard)."""
    dx = (lon2 - lon1) * 111320.0 * math.cos(math.radians((lat1 + lat2) / 2))
    dy = (lat2 - lat1) * 111320.0
    return math.hypot(dx, dy)


def _compass(heading):
    names = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    return names[int(((heading % 360) + 22.5) // 45) % 8]


def _fmt_duration(seconds):
    seconds = int(round(max(0, seconds)))
    return f"{seconds // 60:d}:{seconds % 60:02d} min"


# ---------------------------------------------------------------------------
# Real 3D LiDAR view (three.js): the AV with the LiDAR bolted to its front bumper,
# nearby objects and the LiDAR returns. Drag to rotate, wheel to zoom, buttons for
# front / rear / left / right / top. three.js is loaded from Files/three.min.js.
# ---------------------------------------------------------------------------
LIDAR3D_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
html,body{margin:0;height:100%;overflow:hidden;background:#0b1220;font-family:'Segoe UI',Arial,sans-serif}
#c{position:absolute;top:0;left:0;width:100%;height:100%;display:block}
#bar{position:absolute;top:8px;left:8px;z-index:2}
#bar select{margin:0 6px 6px 0;background:rgba(17,28,51,.95);color:#e5f6ff;border:1px solid rgba(251,191,36,.6);
  border-radius:6px;padding:4px 6px;font-size:12px;cursor:pointer}
#bar button,#bar label{display:inline-block;margin:0 6px 6px 0;background:rgba(17,28,51,.85);color:#e5f6ff;
  border:1px solid rgba(34,211,238,.45);border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
#bar button:hover{background:#16305a}
#info{position:absolute;left:8px;bottom:8px;color:#a5f3fc;font-size:12px;z-index:2;
  background:rgba(11,18,32,.7);padding:6px 10px;border-radius:6px;white-space:pre}
#msg{position:absolute;top:0;left:0;right:0;bottom:0;display:none;align-items:center;justify-content:center;
  color:#fca5a5;font-size:15px;text-align:center;padding:24px}
#details{position:absolute;top:8px;right:8px;width:250px;max-height:calc(100% - 60px);overflow-y:auto;z-index:2;
  background:rgba(11,18,32,.85);border:1px solid rgba(34,211,238,.35);border-radius:8px;padding:10px 12px;
  color:#e5f6ff;font-size:12px;box-sizing:border-box}
#details.hidden{display:none}
#details .t{color:#FBBF24;font-size:15px;font-weight:700;margin-bottom:6px}
#details table{width:100%;border-collapse:collapse}
#details td{padding:3px 0;vertical-align:top}
#details td:first-child{color:#94a3b8;padding-right:8px;white-space:nowrap}
#details td:last-child{text-align:right;font-weight:600}
#details .h{color:#67e8f9;font-weight:700;margin:10px 0 4px;border-top:1px solid rgba(148,163,184,.25);padding-top:8px}
#details .o{display:flex;justify-content:space-between;padding:2px 0}
#details .o span:last-child{color:#fca5a5}
#details .bar{height:6px;background:#1e293b;border-radius:3px;margin:4px 0 2px;overflow:hidden}
#details .bar div{height:100%;background:#F97316}
</style></head><body>
<canvas id="c"></canvas>
<div id="bar">
  <button data-v="front">Front</button><button data-v="rear">Rear</button>
  <button data-v="left">Left</button><button data-v="right">Right</button>
  <button data-v="top">Top</button>
  <label><input type="checkbox" id="follow" checked> follow truck</label>
  <label><input type="checkbox" id="showDetails" checked> details</label>
  <br>
  <select id="sensor" title="Which LiDAR to simulate">
    <option value="roof" selected>Roof LiDAR - 360&deg;, 30 m (point cloud)</option>
    <option value="bumper">Bumper LiDAR - 3 m dome</option>
  </select>
  <select id="density" title="Point-cloud resolution drawn (Full spec = 0.18&deg; x 0.35&deg;, heavier)">
    <option value="low">Density: Low (1.0&deg; x 1.5&deg;)</option>
    <option value="medium" selected>Density: Medium (0.4&deg; x 0.7&deg;)</option>
    <option value="full">Density: Full spec (0.18&deg; x 0.35&deg;)</option>
  </select>
</div>
<div id="details">waiting for truck data...</div>
<div id="info">waiting for truck data...</div>
<div id="msg"></div>
<!-- three.js r128 ships with the app (assets/web/three.min.js) so the view works offline
     and behind proxies that block Qt's browser; the CDN is only a fallback -->
<script src="assets/web/three.min.js"></script>
<script>
if (typeof THREE === 'undefined')
  document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\/script>');
</script>
<script>
(function () {
  function fail(t) { var m = document.getElementById('msg'); m.textContent = t; m.style.display = 'flex'; }
  if (typeof THREE === 'undefined') { fail('The 3D view could not load three.js (assets/web/three.min.js is missing and the internet copy is unreachable).'); return; }

  // measured vehicle sizes (VEHICLE_DIMENSIONS in shipyard.py)
  var VSPEC = __VEHICLE_SPECS__, TR = VSPEC.tractor;
  var TL = TR.length, TW = TR.width, TH = TR.height, FRONT = -TL / 2;   // tractor centred, forward = -Z
  var DEG = Math.PI / 180, R = 3.0, OFFSET = TL / 2 + 0.1, SENSOR_Y = 1.35;
  var canvas = document.getElementById('c'), renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true }); }
  catch (e) { fail('WebGL is not available, so the 3D view cannot be drawn.'); return; }
  renderer.setPixelRatio(window.devicePixelRatio || 1);

  var scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b1220);
  scene.fog = new THREE.Fog(0x0b1220, 30, 70);
  var camera = new THREE.PerspectiveCamera(50, 1, 0.1, 200);
  scene.add(new THREE.HemisphereLight(0xdbeafe, 0x1f2937, 0.95));
  var sun = new THREE.DirectionalLight(0xffffff, 0.8); sun.position.set(6, 12, 4); scene.add(sun);

  var ground = new THREE.Mesh(new THREE.CircleGeometry(60, 64), new THREE.MeshLambertMaterial({ color: 0x1f2937 }));
  ground.rotation.x = -Math.PI / 2; scene.add(ground);
  var grid = new THREE.GridHelper(80, 80, 0x334155, 0x273449); grid.position.y = 0.01; scene.add(grid);

  // ---------------- the truck (forward = -Z) ----------------
  var truck = new THREE.Group(); scene.add(truck);
  function box(w, h, l, color, x, y, z, parent) {
    var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, l), new THREE.MeshLambertMaterial({ color: color }));
    m.position.set(x, y, z); (parent || truck).add(m); return m;
  }
  function wheel(x, z) {
    var w = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.4, 20), new THREE.MeshLambertMaterial({ color: 0x111827 }));
    w.rotation.z = Math.PI / 2; w.position.set(x, 0.5, z); truck.add(w);
  }
  // real tractor: TL x TW, cab up to TH, axles / fifth wheel from the measured overhangs
  var CAB_L = 2.3, CAB_Z = FRONT + CAB_L / 2, CAB_BOTTOM = 0.95;
  box(TW - 0.2, 0.5, TL, 0x374151, 0, 0.75, 0);                                   // chassis
  box(TW, TH - CAB_BOTTOM, CAB_L, 0xf59e0b, 0, CAB_BOTTOM + (TH - CAB_BOTTOM) / 2, CAB_Z);   // cab
  box(TW - 0.4, 0.9, 0.05, 0x0f172a, 0, TH - 1.0, FRONT - 0.01);                 // windscreen
  box(TW + 0.05, 0.35, 0.3, 0x6b7280, 0, 0.6, FRONT - 0.1);                      // front bumper
  var fifth = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.12, 24), new THREE.MeshLambertMaterial({ color: 0x9ca3af }));
  fifth.position.set(0, 1.06, FRONT + TR.front_to_kingpin); truck.add(fifth);    // kingpin socket
  var axF = FRONT + TR.front_overhang, axR = -FRONT - TR.rear_overhang;
  [axF, axR].forEach(function (z) { wheel(-(TW / 2 - 0.2), z); wheel(TW / 2 - 0.2, z); });

  // ---------------- LiDAR, bolted to the front bumper ----------------
  var lidar = new THREE.Group(); lidar.position.set(0, SENSOR_Y, -(OFFSET + 0.1)); truck.add(lidar);
  var bumperParts = [
    box(0.16, 0.62, 0.16, 0x9ca3af, 0, 0.99, -(OFFSET + 0.1)),            // mast from the bumper
    box(0.4, 0.05, 0.4, 0x6b7280, 0, 1.2, -(OFFSET + 0.1))                // mounting plate
  ];
  var puck = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.22, 24), new THREE.MeshPhongMaterial({ color: 0x1f2937, shininess: 80 }));
  lidar.add(puck);
  var cap = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 0.06, 24), new THREE.MeshPhongMaterial({ color: 0xe5e7eb }));
  cap.position.y = 0.14; lidar.add(cap);
  var led = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
  led.position.set(0.14, 0.04, 0); lidar.add(led);

  var domeGeo = new THREE.SphereGeometry(R, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  lidar.add(new THREE.Mesh(domeGeo, new THREE.MeshBasicMaterial({ color: 0x22d3ee, wireframe: true, transparent: true, opacity: 0.16 })));
  lidar.add(new THREE.Mesh(domeGeo, new THREE.MeshBasicMaterial({ color: 0x22d3ee, transparent: true, opacity: 0.05, side: THREE.DoubleSide, depthWrite: false })));
  var gr = Math.sqrt(R * R - SENSOR_Y * SENSOR_Y);          // where the dome meets the ground
  var gDisc = new THREE.Mesh(new THREE.CircleGeometry(gr, 64), new THREE.MeshBasicMaterial({ color: 0x22d3ee, transparent: true, opacity: 0.12, depthWrite: false }));
  gDisc.rotation.x = -Math.PI / 2; gDisc.position.y = -SENSOR_Y + 0.02; lidar.add(gDisc);
  var gRing = new THREE.Mesh(new THREE.RingGeometry(gr - 0.04, gr, 64), new THREE.MeshBasicMaterial({ color: 0x67e8f9, side: THREE.DoubleSide }));
  gRing.rotation.x = -Math.PI / 2; gRing.position.y = -SENSOR_Y + 0.03; lidar.add(gRing);

  // rotating vertical scan plane
  var fanGroup = new THREE.Group(); lidar.add(fanGroup);
  fanGroup.add(new THREE.Mesh(new THREE.CircleGeometry(R, 48), new THREE.MeshBasicMaterial({
    color: 0x67e8f9, transparent: true, opacity: 0.10, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending })));
  var edgePts = []; for (var i = 0; i <= 64; i++) edgePts.push(new THREE.Vector3(Math.cos(i / 64 * 2 * Math.PI) * R, Math.sin(i / 64 * 2 * Math.PI) * R, 0));
  fanGroup.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(edgePts), new THREE.LineBasicMaterial({ color: 0xcffafe, transparent: true, opacity: 0.8 })));

  // laser channels: dotted rings that spin
  var scanGroup = new THREE.Group(); lidar.add(scanGroup);
  var gp = [], dp = [], N = 140;
  for (var a = -65; a <= 40; a += 5) {
    for (var k = 0; k < N; k++) {
      var ph = k / N * 2 * Math.PI + (a % 10 === 0 ? 0 : Math.PI / N);
      if (a < 0) {
        var range = SENSOR_Y / Math.sin(-a * DEG);
        if (range <= R) { var d = SENSOR_Y / Math.tan(-a * DEG); gp.push(d * Math.cos(ph), -SENSOR_Y + 0.02, d * Math.sin(ph)); }
      } else {
        dp.push(R * Math.cos(a * DEG) * Math.cos(ph), R * Math.sin(a * DEG), R * Math.cos(a * DEG) * Math.sin(ph));
      }
    }
  }
  function pts(arr, color, size, op) {
    var g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
    return new THREE.Points(g, new THREE.PointsMaterial({ color: color, size: size, transparent: true, opacity: op, depthWrite: false }));
  }
  var groundPts = pts(gp, 0xa5f3fc, 0.07, 0.9); scanGroup.add(groundPts);
  scanGroup.add(pts(dp, 0x67e8f9, 0.045, 0.35));

  // ---------------- Roof LiDAR: 360 deg, 0.3-30 m, +/-22.5 deg, 10 Hz ----------------
  // Configuration from the sensor spec. Every frame casts one ray per
  // (azimuth, channel) from the sensor and keeps the nearest hit on the ground
  // or on a nearby object's box, with +/-5 cm range noise -> point cloud.
  var ROOF = { minR: 0.3, maxR: 30, vfov: 22.5, hz: 10, sigma: 0.025 };
  var DENSITY = { low: { h: 1.0, v: 1.5 }, medium: { h: 0.4, v: 0.7 }, full: { h: 0.18, v: 0.35 } };
  var CAB_TOP = TH;                                       // measured tractor height
  var roof = new THREE.Group(); roof.position.set(0, CAB_TOP, CAB_Z); truck.add(roof);
  (function () {
    var bracket = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 0.7), new THREE.MeshLambertMaterial({ color: 0x4b5563 }));
    bracket.position.y = 0.03; roof.add(bracket);
    var stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.1, 12), new THREE.MeshLambertMaterial({ color: 0x9ca3af }));
    stem.position.y = 0.11; roof.add(stem);
    var body = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.14, 0.2, 28), new THREE.MeshPhongMaterial({ color: 0x1f2937, shininess: 90 }));
    body.position.y = 0.26; roof.add(body);
    var window_ = new THREE.Mesh(new THREE.CylinderGeometry(0.135, 0.135, 0.07, 28, 1, true), new THREE.MeshBasicMaterial({ color: 0x22d3ee, transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
    window_.position.y = 0.26; roof.add(window_);
    var top = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.04, 28), new THREE.MeshPhongMaterial({ color: 0xe5e7eb }));
    top.position.y = 0.38; roof.add(top);
  })();
  var roofSensor = new THREE.Object3D(); roofSensor.position.y = 0.26; roof.add(roofSensor);   // optical centre
  // spinning beam marker, so the sensor visibly rotates
  var roofBeam = new THREE.Mesh(new THREE.PlaneGeometry(ROOF.maxR, 0.04), new THREE.MeshBasicMaterial({
    color: 0xfbbf24, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false }));
  roofBeam.geometry.translate(ROOF.maxR / 2, 0, 0); roofBeam.rotation.x = -Math.PI / 2;
  var roofSpin = new THREE.Group(); roofSpin.position.y = 0.26; roofSpin.add(roofBeam); roof.add(roofSpin);

  var MAXPTS = Math.round(360 / 0.18) * (Math.floor(2 * 22.5 / 0.35) + 1);
  var cloudPos = new Float32Array(MAXPTS * 3), cloudCol = new Float32Array(MAXPTS * 3);
  var cloudGeo = new THREE.BufferGeometry();
  var cloudPosAttr = new THREE.BufferAttribute(cloudPos, 3).setUsage(THREE.DynamicDrawUsage);
  var cloudColAttr = new THREE.BufferAttribute(cloudCol, 3).setUsage(THREE.DynamicDrawUsage);
  cloudGeo.setAttribute('position', cloudPosAttr); cloudGeo.setAttribute('color', cloudColAttr);
  cloudGeo.setDrawRange(0, 0);
  var cloud = new THREE.Points(cloudGeo, new THREE.PointsMaterial({ size: 0.07, vertexColors: true, sizeAttenuation: true }));
  cloud.frustumCulled = false; scene.add(cloud);

  // height colour ramp (blue on the ground -> red at 4 m), precomputed
  var RAMP = []; (function () { var c = new THREE.Color();
    for (var i = 0; i < 64; i++) { c.setHSL(0.66 * (1 - i / 63), 1, 0.55); RAMP.push([c.r, c.g, c.b]); } })();

  var objBoxes = [];         // nearby objects as boxes in world metres (filled by updateScene)
  var mode = 'roof', density = 'medium';
  var lastScan = -1e9, scanStats = { pts: 0, ms: 0, hz: 0 }, scanTimes = [];

  function rayBox(sx, sy, sz, dx, dy, dz, b, tmax) {
    // ray into the box's own frame (box spans x +-hw, y 0..h, z +-hl)
    var ox = sx - b.x, oz = sz - b.z;
    var lx = b.c * ox - b.s * oz, lz = b.s * ox + b.c * oz;
    var ldx = b.c * dx - b.s * dz, ldz = b.s * dx + b.c * dz;
    var tn = 0, tf = tmax, t1, t2, tmp;
    if (Math.abs(ldx) < 1e-9) { if (lx < -b.hw || lx > b.hw) return -1; }
    else { t1 = (-b.hw - lx) / ldx; t2 = (b.hw - lx) / ldx; if (t1 > t2) { tmp = t1; t1 = t2; t2 = tmp; }
      if (t1 > tn) tn = t1; if (t2 < tf) tf = t2; if (tn > tf) return -1; }
    var y0 = b.y0 || 0;                                    // ground clearance: beams pass under the body
    if (Math.abs(dy) < 1e-9) { if (sy < y0 || sy > b.h) return -1; }
    else { t1 = (y0 - sy) / dy; t2 = (b.h - sy) / dy; if (t1 > t2) { tmp = t1; t1 = t2; t2 = tmp; }
      if (t1 > tn) tn = t1; if (t2 < tf) tf = t2; if (tn > tf) return -1; }
    if (Math.abs(ldz) < 1e-9) { if (lz < -b.hl || lz > b.hl) return -1; }
    else { t1 = (-b.hl - lz) / ldz; t2 = (b.hl - lz) / ldz; if (t1 > t2) { tmp = t1; t1 = t2; t2 = tmp; }
      if (t1 > tn) tn = t1; if (t2 < tf) tf = t2; if (tn > tf) return -1; }
    return tn > 0 ? tn : -1;
  }

  function roofScan() {
    var t0 = performance.now(), d = DENSITY[density], S = new THREE.Vector3();
    truck.updateMatrixWorld(true); roofSensor.getWorldPosition(S);
    var hStep = d.h * DEG, nCols = Math.round(360 / d.h), nRows = Math.floor(2 * ROOF.vfov / d.v) + 1;

    // which objects can each azimuth column hit at all
    var bins = new Array(nCols);
    objBoxes.forEach(function (b, bi) {
      b.hits = 0; b.pot = 0; b.occ = null;
      var dx = b.x - S.x, dz = b.z - S.z, dist = Math.sqrt(dx * dx + dz * dz);
      if (dist - b.rad > ROOF.maxR) return;
      var az = Math.atan2(dx, -dz), half = dist <= b.rad ? Math.PI : Math.asin(b.rad / dist);
      var c0 = Math.floor((az - half) / hStep), c1 = Math.ceil((az + half) / hStep);
      if (c1 - c0 >= nCols) { c0 = 0; c1 = nCols - 1; }
      for (var c = c0; c <= c1; c++) { var k = ((c % nCols) + nCols) % nCols; (bins[k] = bins[k] || []).push(bi); }
    });

    var sinE = [], cosE = [];
    for (var r = 0; r < nRows; r++) { var e = (-ROOF.vfov + r * d.v) * DEG; sinE.push(Math.sin(e)); cosE.push(Math.cos(e)); }
    var n = 0, sig2 = ROOF.sigma * 2;
    for (var c = 0; c < nCols; c++) {
      var phi = c * hStep, sp = Math.sin(phi), cp = Math.cos(phi), list = bins[c];
      for (var r2 = 0; r2 < nRows; r2++) {
        var dx = cosE[r2] * sp, dy = sinE[r2], dz = -cosE[r2] * cp;
        var best = ROOF.maxR, hit = false, hitBox = -1;
        if (dy < 0) { var tg = -S.y / dy; if (tg < best) { best = tg; hit = true; } }
        if (list) for (var k2 = 0; k2 < list.length; k2++) {
          var tb = rayBox(S.x, S.y, S.z, dx, dy, dz, objBoxes[list[k2]], best);
          if (tb > 0) { best = tb; hit = true; hitBox = list[k2]; }
        }
        if (window.lidarDiag && list) for (var k3 = 0; k3 < list.length; k3++) {
          // diagnostics only: would this beam hit the box if nothing were in front of it?
          var bx = objBoxes[list[k3]], tp = rayBox(S.x, S.y, S.z, dx, dy, dz, bx, ROOF.maxR);
          if (tp > 0 && (dy >= 0 || tp < -S.y / dy)) {
            bx.pot = (bx.pot || 0) + 1;
            if (hitBox >= 0 && hitBox !== list[k3]) bx.occ = objBoxes[hitBox].label;
          }
        }
        if (!hit || best < ROOF.minR) continue;
        if (hitBox >= 0) objBoxes[hitBox].hits++;
        var tn = best + (Math.random() + Math.random() + Math.random() - 1.5) * sig2;   // ~ +/-5 cm
        var px = S.x + dx * tn, py = Math.max(0.01, S.y + dy * tn), pz = S.z + dz * tn, i3 = n * 3;
        cloudPos[i3] = px; cloudPos[i3 + 1] = py; cloudPos[i3 + 2] = pz;
        var col = RAMP[Math.min(63, Math.floor(py / 4 * 63))];
        cloudCol[i3] = col[0]; cloudCol[i3 + 1] = col[1]; cloudCol[i3 + 2] = col[2];
        n++;
      }
    }
    cloudGeo.setDrawRange(0, n);
    cloudPosAttr.needsUpdate = true; cloudColAttr.needsUpdate = true;
    lastScanHits = {};
    objBoxes.forEach(function (b) { lastScanHits[b.id] = { hits: b.hits, pot: b.pot, occ: b.occ }; });

    var now = performance.now();
    scanTimes.push(now); while (scanTimes.length > 11) scanTimes.shift();
    scanStats.pts = n; scanStats.ms = now - t0;
    scanStats.hz = scanTimes.length > 1 ? (scanTimes.length - 1) * 1000 / (now - scanTimes[0]) : 0;
  }

  // diagnostics: what the roof LiDAR currently has in its scene, and how many
  // points of the last frame landed on each object
  var lastScanHits = {};     // id -> counts from the last completed scan
  window.lidarObjectHits = function () {
    return objBoxes.map(function (b) {
      var h = lastScanHits[b.id] || {};
      return { id: b.id, label: b.label, dist: b.dist != null ? +b.dist.toFixed(1) : null, hits: h.hits || 0,
               unoccluded: window.lidarDiag ? (h.pot || 0) : undefined,
               blockedBy: window.lidarDiag ? h.occ : undefined };
    });
  };

  function densityAt30(d) {      // points per m^2 on a surface 30 m away, at the drawn resolution
    return 1 / ((30 * d.h * DEG) * (30 * d.v * DEG));
  }
  function specHtml() {
    var d = DENSITY[density], dens = densityAt30(d);
    var rows = [
      ['Mount', 'Cab roof, ' + (CAB_TOP + 0.26).toFixed(2) + ' m'],
      ['Detection range', ROOF.minR + ' - ' + ROOF.maxR + ' m'],
      ['Horizontal FOV', '360°'],
      ['Vertical FOV', '±' + ROOF.vfov + '° (45°)'],
      ['Angular res. (spec)', 'H 0.18° / V 0.35°'],
      ['Angular res. (drawn)', 'H ' + d.h + '° / V ' + d.v + '°'],
      ['Density @ 30 m', dens.toFixed(1) + ' pts/m²' + (dens >= 5 ? ' ✔' : ' (< 5)')],
      ['Frame rate', scanStats.hz.toFixed(1) + ' Hz (spec ≥ 10)'],
      ['Points / frame', scanStats.pts.toLocaleString()],
      ['Latency (spec)', '≤ 10 ms / frame'],
      ['Simulation compute', scanStats.ms.toFixed(1) + ' ms / frame on this PC'],
      ['Range accuracy', '±5 cm'],
      ['Eye safety', 'Class 1 laser'],
      ['Interface', 'Gigabit Ethernet (UDP)'],
      ['Sync', 'PTP / NMEA'],
      ['Power / weight', '14-20 W, ≤ 500 g'],
      ['Operating temp.', '-40 to +60 °C, IP68/69K']
    ];
    return '<div class="h">Roof LiDAR configuration</div><table>' + rows.map(function (r) {
      return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td></tr>'; }).join('') + '</table>';
  }

  function applyMode() {
    var r = mode === 'roof';
    lidar.visible = !r; bumperParts.forEach(function (m) { m.visible = !r; });
    roof.visible = r; cloud.visible = r; hitGroup.visible = !r;
    scene.fog.near = r ? 55 : 30; scene.fog.far = r ? 130 : 70;
    if (r) { dist = Math.max(dist, 26); lastScan = -1e9; } else { dist = Math.min(dist, 13); }
    if (lastScene) window.updateScene(lastScene);
  }

  // ---------------- nearby objects + LiDAR returns ----------------
  var objGroup = new THREE.Group(); scene.add(objGroup);
  var hitGroup = new THREE.Group(); scene.add(hitGroup);
  var SPEC = {
    car: { w: 1.8, h: 1.5, l: 4.4, c: 0x60a5fa }, truck: { w: 2.5, h: 3.0, l: 6.5, c: 0xf97316 },
    trailer: { w: 2.6, h: 3.4, l: 12, c: 0x94a3b8 }, box: { w: 1, h: 1, l: 1, c: 0xa78bfa },
    pedestrian: { r: 0.25, h: 1.75, c: 0xfacc15 }
  };
  // parked trucks / trailers at their measured size
  var VCOL = { tractor: 0xf59e0b, trailer_normal: 0x94a3b8, trailer_refrig: 0x7dd3fc, trailer_pup: 0xc4b5fd };
  Object.keys(VSPEC).forEach(function (k) {
    SPEC[k] = { w: VSPEC[k].width, h: VSPEC[k].height, l: VSPEC[k].length, c: VCOL[k] || 0x94a3b8 };
  });
  function classify(o) {
    if (o.dims && SPEC[o.dims]) return o.dims;              // parked vehicle with known type
    var t = String(o.label || '').toLowerCase();
    if (o.kind === 'truck') return 'truck';
    if (/ped|person|human|walk/.test(t)) return 'pedestrian';
    if (/truck/.test(t)) return 'truck';
    if (/car|auto|sedan/.test(t)) return 'car';
    if (o.kind === 'vehicle') return 'trailer';
    return 'box';
  }
  function clearGroup(g) {
    while (g.children.length) {
      var c = g.children.pop();
      if (c.geometry) c.geometry.dispose();
      if (c.material) c.material.dispose();
    }
  }
  function sampleObject(g, type, S, out, spec) {
    var sp = spec || SPEC[type], step = 0.2, p = new THREE.Vector3(), n = new THREE.Vector3(), to = new THREE.Vector3();
    function consider(lx, ly, lz, nx, ny, nz) {
      if (out.length > 12000) return;
      p.set(lx, ly, lz); g.localToWorld(p);
      n.set(nx, ny, nz).applyQuaternion(g.quaternion);
      to.copy(S).sub(p);
      if (to.length() <= R && n.dot(to) > 0) out.push(p.x, p.y, p.z);
    }
    var x, y, z;
    if (type === 'pedestrian') {
      for (var a = 0; a < 360; a += 15) for (y = 0.05; y <= sp.h; y += 0.15)
        consider(sp.r * Math.cos(a * DEG), y, sp.r * Math.sin(a * DEG), Math.cos(a * DEG), 0, Math.sin(a * DEG));
      return;
    }
    var hw = sp.w / 2, hl = sp.l / 2;
    for (y = 0.05; y <= sp.h; y += step) {
      for (z = -hl; z <= hl; z += step) { consider(hw, y, z, 1, 0, 0); consider(-hw, y, z, -1, 0, 0); }
      for (x = -hw; x <= hw; x += step) { consider(x, y, hl, 0, 0, 1); consider(x, y, -hl, 0, 0, -1); }
    }
    for (x = -hw; x <= hw; x += step) for (z = -hl; z <= hl; z += step) consider(x, sp.h, z, 0, 1, 0);
  }

  // The scene is in world metres around an origin (the first position of the
  // selected truck), so the truck really drives across the grid; each update
  // glides it from its previous position to the new one.
  var TWEEN_S = 0.9;
  var origin = null, sceneKey = null, heading = 0, lastObjs = 0, lastHits = 0, lastScene = null;
  var fromPos = new THREE.Vector3(), toPos = new THREE.Vector3(), fromHd = 0, toHd = 0, tweenT0 = -1e9;
  var rayLines = null, routeGroup = new THREE.Group(); scene.add(routeGroup);

  function toXZ(lat, lng) {
    return new THREE.Vector3((lng - origin.lng) * 111320 * Math.cos(origin.lat * DEG), 0,
                             -(lat - origin.lat) * 111320);
  }
  function line(points, color, opacity) {
    var g = new THREE.BufferGeometry().setFromPoints(points);
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: opacity }));
  }
  function esc(t) {
    return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function renderDetails(s, objs) {
    var d = s.details || {}, html = '<div class="t">' + esc(d.title || 'Truck') + '</div>';
    if (d.progress != null) {
      html += '<div class="bar"><div style="width:' + Math.max(0, Math.min(100, d.progress)) + '%"></div></div>';
    }
    html += '<table>' + (d.rows || []).map(function (r) {
      return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td></tr>';
    }).join('') + '</table>';
    var near = objs.filter(function (o) { return (o.rel ? o.rel.r : o.dist || 0) <= ROOF.maxR; })
                   .sort(function (a, b) { return (a.rel ? a.rel.r : 0) - (b.rel ? b.rel.r : 0); });
    function sgn(v) { return (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(1); }
    html += '<div class="h">Nearby objects (' + near.length + ')</div>' +
            '<div style="color:#94a3b8;font-size:11px;margin-bottom:4px">From the LiDAR to the nearest point: ' +
            'x = ahead (+) / behind (−), y = left (+) / right (−)</div>';
    html += near.length ? near.map(function (o) {
      var r = o.rel;
      return '<div class="o" style="flex-wrap:wrap"><span>' + esc(o.label) + ' <small style="color:#94a3b8">' +
             esc(classify(o)) + '</small></span>' +
             (r ? '<span style="color:#fde68a;font-variant-numeric:tabular-nums">x ' + sgn(r.x) + ' m &nbsp; y ' +
                  sgn(r.y) + ' m</span><span style="width:100%;text-align:right;color:#94a3b8;font-size:11px">' +
                  'range ' + r.r.toFixed(1) + ' m' + (r.z > 0.3 ? ' · ' + r.z.toFixed(1) + ' m above' :
                  r.z < -0.3 ? ' · ' + (-r.z).toFixed(1) + ' m below the sensor' : '') + '</span>'
                : '<span>' + (o.dist != null ? o.dist.toFixed(1) + ' m' : '') + '</span>') + '</div>';
    }).join('') : '<div style="color:#94a3b8">None within ' + ROOF.maxR + ' m</div>';
    if (mode === 'roof') html += specHtml();
    document.getElementById('details').innerHTML = html;
  }

  window.updateScene = function (s) {
    var jump = !origin || s.key !== sceneKey;
    if (jump) { origin = { lat: s.lat, lng: s.lng }; sceneKey = s.key; }
    var p = toXZ(s.lat, s.lng);
    var samePose = !jump && p.distanceTo(toPos) < 1e-3 && Math.abs((s.heading || 0) - toHd) < 1e-3;
    if (jump || p.distanceTo(toPos) > 40) {          // new truck / big gap: no glide
      fromPos.copy(p); fromHd = s.heading || 0; tweenT0 = -1e9;
    } else if (!samePose) {                          // a periodic refresh must not restart the glide
      fromPos.copy(truck.position); fromHd = heading; tweenT0 = performance.now();
    }
    toPos.copy(p); toHd = s.heading || 0;

    // LiDAR returns are computed with the truck at its NEW pose
    truck.position.copy(toPos); truck.rotation.y = -toHd * DEG;
    truck.updateMatrixWorld(true);
    var S = new THREE.Vector3(); lidar.getWorldPosition(S);

    clearGroup(objGroup); clearGroup(hitGroup); clearGroup(routeGroup); rayLines = null;
    lastScene = s;
    var hits = [], objs = s.objects || [];
    objBoxes = [];
    objs.forEach(function (o) {
      var type = classify(o), sp = SPEC[type], g = new THREE.Group();
      if (o.size && o.size.l > 0 && o.size.w > 0 && o.size.h > 0) {   // obstacle's own (edited) dimensions
        sp = { w: o.size.w, l: o.size.l, h: o.size.h, c: sp.c, gc: Math.min(o.size.gc || 0, o.size.h * 0.9),
               r: Math.max(o.size.w, o.size.l) / 2 };
      }
      var gc = sp.gc || 0;                                             // ground clearance
      var mesh = type === 'pedestrian'
        ? new THREE.Mesh(new THREE.CylinderGeometry(sp.r, sp.r, sp.h, 14), new THREE.MeshLambertMaterial({ color: sp.c, transparent: true, opacity: mode === 'roof' ? 0.25 : 0.55 }))
        : new THREE.Mesh(new THREE.BoxGeometry(sp.w, sp.h - gc, sp.l), new THREE.MeshLambertMaterial({ color: sp.c, transparent: true, opacity: mode === 'roof' ? 0.25 : 0.55 }));
      mesh.position.y = type === 'pedestrian' ? sp.h / 2 : gc + (sp.h - gc) / 2; g.add(mesh);
      g.position.copy(toXZ(o.lat, o.lng));
      g.rotation.y = -(o.heading || 0) * DEG;
      objGroup.add(g); g.updateMatrixWorld(true);
      // box for the roof LiDAR scan
      var hw = type === 'pedestrian' ? sp.r : sp.w / 2, hl = type === 'pedestrian' ? sp.r : sp.l / 2;
      objBoxes.push({ x: g.position.x, z: g.position.z, c: Math.cos(g.rotation.y), s: Math.sin(g.rotation.y),
                      hw: hw, hl: hl, h: sp.h, y0: type === 'pedestrian' ? 0 : gc,
                      rad: Math.sqrt(hw * hw + hl * hl),
                      id: o.id, label: o.label, dist: o.dist, hits: 0 });
      if (mode !== 'roof') sampleObject(g, type, S, hits, sp);
    });
    if (hits.length) {
      hitGroup.add(pts(hits, 0xef4444, 0.12, 1.0));
      var rays = [];
      for (var i = 0; i < hits.length; i += 18) rays.push(S.x, S.y, S.z, hits[i], hits[i + 1], hits[i + 2]);
      var rg = new THREE.BufferGeometry(); rg.setAttribute('position', new THREE.Float32BufferAttribute(rays, 3));
      rayLines = new THREE.LineSegments(rg, new THREE.LineBasicMaterial({ color: 0xf87171, transparent: true, opacity: 0.45 }));
      hitGroup.add(rayLines);
    }

    // route: driven part grey, the part still ahead orange
    var route = s.route || [], split = Math.max(0, Math.min(route.length - 1, s.routeSplit || 0));
    if (route.length > 1) {
      var rpts = route.map(function (q) { var v = toXZ(q[0], q[1]); v.y = 0.06; return v; });
      if (split > 0) routeGroup.add(line(rpts.slice(0, split + 1), 0x94a3b8, 0.6));
      if (split < rpts.length - 1) routeGroup.add(line(rpts.slice(split), 0xf97316, 0.95));
    }

    // each object relative to the ACTIVE LiDAR (roof or bumper), in the truck frame:
    // x = ahead, y = left, z = up -- to the object's nearest point (closest point on its box)
    var Ssen = new THREE.Vector3();
    (mode === 'roof' ? roofSensor : lidar).getWorldPosition(Ssen);
    var hr = toHd * DEG, fx = Math.sin(hr), fz = -Math.cos(hr), lx = -Math.cos(hr), lz = -Math.sin(hr);
    objBoxes.forEach(function (b, i) {
      var ox = Ssen.x - b.x, oz = Ssen.z - b.z;
      var px = Math.max(-b.hw, Math.min(b.hw, b.c * ox - b.s * oz));           // sensor in the box frame,
      var pz = Math.max(-b.hl, Math.min(b.hl, b.s * ox + b.c * oz));           // clamped onto the box
      var py = Math.max(b.y0 || 0, Math.min(b.h, Ssen.y));
      var wx = b.c * px + b.s * pz + b.x, wz = -b.s * px + b.c * pz + b.z;    // back to the world
      var dx = wx - Ssen.x, dy = py - Ssen.y, dz = wz - Ssen.z;
      objs[i].rel = { x: dx * fx + dz * fz, y: dx * lx + dz * lz, z: dy, r: Math.sqrt(dx * dx + dy * dy + dz * dz) };
    });

    lastObjs = objs.length; lastHits = hits.length / 3;
    if (mode !== 'roof') document.getElementById('info').textContent =
      'Heading ' + Math.round(((toHd % 360) + 360) % 360) + '\u00B0   |   objects nearby: ' + lastObjs +
      '   |   LiDAR returns (within ' + R + ' m): ' + Math.round(lastHits);
    renderDetails(s, objs);
  };
  document.getElementById('showDetails').addEventListener('change', function (e) {
    document.getElementById('details').classList.toggle('hidden', !e.target.checked);
  });

  // ---------------- orbit camera: drag = rotate, wheel = zoom ----------------
  var target = new THREE.Vector3(0, 1.0, 0), relAz = 150 * DEG, el = 28 * DEG, dist = 13, follow = true;
  function placeCamera() {
    var a = follow ? heading * DEG + relAz : relAz;
    camera.position.set(target.x + dist * Math.cos(el) * Math.sin(a), target.y + dist * Math.sin(el),
                        target.z - dist * Math.cos(el) * Math.cos(a));
    camera.lookAt(target);
  }
  var drag = false, lx = 0, ly = 0;
  canvas.addEventListener('mousedown', function (e) { drag = true; lx = e.clientX; ly = e.clientY; });
  window.addEventListener('mouseup', function () { drag = false; });
  window.addEventListener('mousemove', function (e) {
    if (!drag) return;
    relAz += (e.clientX - lx) * 0.008; el += (e.clientY - ly) * 0.006;
    el = Math.max(4 * DEG, Math.min(88 * DEG, el)); lx = e.clientX; ly = e.clientY;
  });
  canvas.addEventListener('wheel', function (e) {
    e.preventDefault(); dist = Math.max(4, Math.min(80, dist * Math.exp(e.deltaY * 0.001)));
  }, { passive: false });
  function setView(rel, elev) { relAz = follow ? rel : heading * DEG + rel; el = elev; }
  Array.prototype.forEach.call(document.querySelectorAll('#bar button'), function (b) {
    b.addEventListener('click', function () {
      var v = b.getAttribute('data-v');
      if (v === 'front') setView(0, 14 * DEG); else if (v === 'rear') setView(Math.PI, 14 * DEG);
      else if (v === 'left') setView(-Math.PI / 2, 14 * DEG); else if (v === 'right') setView(Math.PI / 2, 14 * DEG);
      else if (v === 'top') el = 88 * DEG;
    });
  });
  document.getElementById('follow').addEventListener('change', function (e) {
    if (e.target.checked && !follow) relAz -= heading * DEG;
    else if (!e.target.checked && follow) relAz += heading * DEG;
    follow = e.target.checked;
  });

  function resize() {
    var w = window.innerWidth, h = window.innerHeight;
    renderer.setSize(w, h, false); camera.aspect = w / Math.max(1, h); camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize); resize();

  var last = performance.now();
  function frame(t) {
    var dt = Math.min(0.1, (t - last) / 1000); last = t;

    // glide the truck to its latest position / heading (shortest turn)
    var k = Math.min(1, (t - tweenT0) / (TWEEN_S * 1000));
    truck.position.lerpVectors(fromPos, toPos, k);
    var dh = ((toHd - fromHd) % 360 + 540) % 360 - 180;
    heading = fromHd + dh * k;
    truck.rotation.y = -heading * DEG;
    if (rayLines) rayLines.visible = k >= 1;       // rays start at the sensor's new spot
    target.set(truck.position.x, 1.0, truck.position.z);
    // ground + grid follow the truck in whole metres, so the grid lines stay put
    // in the world and the truck is seen driving over them
    ground.position.set(Math.round(truck.position.x), 0, Math.round(truck.position.z));
    grid.position.set(ground.position.x, 0.01, ground.position.z);

    if (mode === 'roof' && origin) {
      roofSpin.rotation.y -= dt * 2 * Math.PI * ROOF.hz / 4;     // visual only (slowed down)
      var period = 1000 / ROOF.hz;
      if (t - lastScan >= period - 8) {          // fixed 10 Hz schedule (not re-anchored to each screen frame)
        lastScan = t - lastScan > 2 * period ? t : lastScan + period;
        roofScan();
        document.getElementById('info').textContent =
          'Roof LiDAR  |  ' + scanStats.pts.toLocaleString() + ' points/frame  |  ' +
          scanStats.hz.toFixed(1) + ' Hz  |  sim ' + scanStats.ms.toFixed(1) + ' ms  |  objects in range: ' +
          objBoxes.length + '  |  heading ' + Math.round(((heading % 360) + 360) % 360) + '°';
      }
    }

    scanGroup.rotation.y += dt * 1.6;
    fanGroup.rotation.y -= dt * 3.1;
    groundPts.material.opacity = 0.75 + 0.25 * Math.sin(t * 0.01);
    led.visible = Math.floor(t / 400) % 2 === 0;
    placeCamera(); renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }

  document.getElementById('sensor').addEventListener('change', function (e) { mode = e.target.value; applyMode(); });
  document.getElementById('density').addEventListener('change', function (e) {
    density = e.target.value; lastScan = -1e9; if (lastScene) renderDetails(lastScene, lastScene.objects || []);
  });
  applyMode();
  requestAnimationFrame(frame);
})();
</script></body></html>
"""


class DrawerGrip(QFrame):
    """Right edge of the side drawer: drag it to make the drawer wider / narrower."""
    moved = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("drawerGrip")
        self.setFixedWidth(6)
        self.setCursor(Qt.SizeHorCursor)
        self._x = None

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._x = e.globalPos().x()

    def mouseMoveEvent(self, e):
        if self._x is not None:
            dx = e.globalPos().x() - self._x
            self._x = e.globalPos().x()
            self.moved.emit(dx)

    def mouseReleaseEvent(self, e):
        self._x = None


class MapHost(QWidget):
    """Holds the 2D map / 3D view and the floating panels drawn over them."""
    resized = pyqtSignal()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resized.emit()


class FloatingPanel(QFrame):
    """A panel floating INSIDE the map area (e.g. the LiDAR 3D view): drag it by its
    title bar, resize it from any edge or corner; it always stays inside the area."""
    closed = pyqtSignal()
    EDGE = 6                               # px of border that resizes

    def __init__(self, title, content, icon=None, parent=None):
        super().__init__(parent)
        self.setObjectName("floatPanel")
        self.setMouseTracking(True)
        self.setMinimumSize(300, 200)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(self.EDGE, self.EDGE, self.EDGE, self.EDGE)
        lay.setSpacing(0)

        self.bar = QFrame()
        self.bar.setObjectName("floatPanelBar")
        self.bar.setFixedHeight(30)
        self.bar.setCursor(Qt.SizeAllCursor)
        bar_lay = QHBoxLayout(self.bar)
        bar_lay.setContentsMargins(10, 0, 4, 0)
        bar_lay.setSpacing(6)
        if icon is not None:
            ic = QLabel()
            ic.setPixmap(icon.pixmap(14, 14))
            bar_lay.addWidget(ic)
        title_lbl = QLabel(title)
        title_lbl.setObjectName("floatPanelTitle")
        bar_lay.addWidget(title_lbl)
        bar_lay.addStretch()
        self.title = title
        min_btn = QToolButton()
        min_btn.setObjectName("floatPanelClose")
        min_btn.setText("–")
        min_btn.setCursor(Qt.PointingHandCursor)
        min_btn.setToolTip("Minimize (to the bottom bar -- click it there to bring it back)")
        min_btn.clicked.connect(self.minimize_panel)
        bar_lay.addWidget(min_btn)
        close_btn = QToolButton()
        close_btn.setObjectName("floatPanelClose")
        close_btn.setText("✕")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setToolTip("Close")
        close_btn.clicked.connect(self.close_panel)
        bar_lay.addWidget(close_btn)
        self.bar.installEventFilter(self)
        lay.addWidget(self.bar)
        lay.addWidget(content, 1)

        self._drag = None                  # ("move" | edges, start global pos, start geometry)

    def close_panel(self):
        self.hide()
        self.closed.emit()

    def minimize_panel(self):
        """To the bottom bar (it keeps running: the cameras / LiDAR go on, only out of sight)."""
        win = self.window()
        if hasattr(win, "minimize_to_tray"):
            win.minimize_to_tray(self, self.title)
        else:
            self.hide()

    def place_in_corner(self, corner="bottom-right", size=(470, 330)):
        p = self.parentWidget()
        w = min(size[0], max(self.minimumWidth(), int(p.width() * 0.6)))
        h = min(size[1], max(self.minimumHeight(), int(p.height() * 0.6)))
        m = 12
        x = p.width() - w - m if "right" in corner else m
        y = p.height() - h - m if "bottom" in corner else m
        self.setGeometry(x, y, w, h)
        self.keep_inside()

    def keep_inside(self):
        p = self.parentWidget()
        if p is None:
            return
        g = self.geometry()
        w = min(g.width(), p.width()); h = min(g.height(), p.height())
        x = max(0, min(g.x(), p.width() - w)); y = max(0, min(g.y(), p.height() - h))
        self.setGeometry(x, y, w, h)

    # -- edges under the mouse: any of "l", "r", "t", "b"
    def _edges_at(self, pos):
        e, r = self.EDGE + 2, self.rect()
        edges = ""
        if pos.x() <= e: edges += "l"
        if pos.x() >= r.width() - e: edges += "r"
        if pos.y() <= e: edges += "t"
        if pos.y() >= r.height() - e: edges += "b"
        return edges

    _CURSORS = {"l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor, "t": Qt.SizeVerCursor, "b": Qt.SizeVerCursor,
                "lt": Qt.SizeFDiagCursor, "rb": Qt.SizeFDiagCursor, "rt": Qt.SizeBDiagCursor, "lb": Qt.SizeBDiagCursor}

    def mousePressEvent(self, event):
        edges = self._edges_at(event.pos())
        if event.button() == Qt.LeftButton and edges:
            self._drag = (edges, event.globalPos(), self.geometry())
        self.raise_()

    def mouseMoveEvent(self, event):
        if self._drag is None:
            self.setCursor(self._CURSORS.get(self._edges_at(event.pos()), Qt.ArrowCursor))
            return
        mode, start, g = self._drag
        d = event.globalPos() - start
        p = self.parentWidget()
        x, y, w, h = g.x(), g.y(), g.width(), g.height()
        if mode == "move":
            x, y = g.x() + d.x(), g.y() + d.y()
        else:
            minw, minh = self.minimumWidth(), self.minimumHeight()
            if "l" in mode:
                nx = max(0, min(g.right() - minw, g.x() + d.x())); w = g.right() - nx + 1; x = nx
            if "r" in mode:
                w = max(minw, min(p.width() - g.x(), g.width() + d.x()))
            if "t" in mode:
                ny = max(0, min(g.bottom() - minh, g.y() + d.y())); h = g.bottom() - ny + 1; y = ny
            if "b" in mode:
                h = max(minh, min(p.height() - g.y(), g.height() + d.y()))
        self.setGeometry(x, y, w, h)
        self.keep_inside()

    def mouseReleaseEvent(self, event):
        self._drag = None

    def eventFilter(self, obj, event):           # dragging by the title bar moves the panel
        if obj is self.bar:
            if event.type() == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
                self._drag = ("move", event.globalPos(), self.geometry())
                self.raise_()
                return True
            if event.type() == QEvent.MouseMove and self._drag is not None:
                self.mouseMoveEvent(event)
                return True
            if event.type() == QEvent.MouseButtonRelease:
                self._drag = None
                return True
        return super().eventFilter(obj, event)


class LidarView3D(QWidget):
    """The 3D LiDAR view of ONE AV (live AV or a route AV); shown in a
    FloatingPanel inside the map area."""

    targetChanged = pyqtSignal(str)     # the AV shown was switched

    def __init__(self, targets_provider, parent=None):
        super().__init__(parent)
        self._targets_provider = targets_provider
        # until the user picks one, an AV that is following a route is shown
        # in preference to the live AV
        self._user_picked = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        top = QHBoxLayout()
        top.setContentsMargins(8, 6, 8, 6)
        top.addWidget(QLabel("Truck:"))
        self.target_combo = QComboBox()
        self.target_combo.setMinimumWidth(240)
        self.target_combo.activated.connect(self._on_user_pick)
        self.target_combo.currentIndexChanged.connect(
            lambda _i: self.targetChanged.emit(self.current_target()))
        top.addWidget(self.target_combo)
        top.addStretch()
        lay.addLayout(top)

        self.view = QWebEngineView()
        # file:// base URL so the page can load assets/web/three.min.js from the app folder
        html = LIDAR3D_HTML.replace("__VEHICLE_SPECS__", json.dumps(VEHICLE_DIMENSIONS))
        self.view.setHtml(html, QUrl.fromLocalFile(cfg.ROOT_DIR + os.sep))
        lay.addWidget(self.view, 1)

        self.refresh_targets()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh_targets)
        self._timer.start(1000)

    def _on_user_pick(self, _index):
        self._user_picked = True

    def refresh_targets(self):
        items = self._targets_provider()
        keys = [k for _, k in items]
        current = self.current_target() if self.target_combo.count() else None
        wanted = current
        route_keys = [k for k in keys if k != "live"]
        if wanted not in keys or (not self._user_picked and wanted == "live" and route_keys):
            wanted = route_keys[-1] if route_keys else "live"   # newest route AV
        shown = [(self.target_combo.itemText(i), self.target_combo.itemData(i))
                 for i in range(self.target_combo.count())]
        if shown == list(items) and wanted == current:     # labels too: "(arrived)"
            return
        self.target_combo.blockSignals(True)
        self.target_combo.clear()
        for label, key in items:
            self.target_combo.addItem(label, key)
        self.target_combo.setCurrentIndex(max(0, self.target_combo.findData(wanted)))
        self.target_combo.blockSignals(False)
        if self.current_target() != current:
            self.targetChanged.emit(self.current_target())

    def select_target(self, key):
        """Show this AV (e.g. from the AV list's "Show in LiDAR 3D")."""
        self.refresh_targets()
        idx = self.target_combo.findData(str(key))
        if idx >= 0:
            self._user_picked = True
            self.target_combo.setCurrentIndex(idx)

    def current_target(self):
        return self.target_combo.currentData() or "live"

    def set_scene(self, key, lat, lng, heading, objects_json, details=None,
                  route=None, route_split=0):
        try:
            objects = json.loads(objects_json) if objects_json else []
        except (TypeError, ValueError):
            objects = []
        payload = json.dumps({"key": str(key), "lat": lat, "lng": lng, "heading": heading,
                              "objects": objects, "details": details or {},
                              "route": route or [], "routeSplit": route_split})
        self.view.page().runJavaScript(f"window.updateScene && window.updateScene({payload});")


class NewAVDialog(QDialog):
    """A new AV dropped on the map: its ID (topic <site>_<project>_<ID>) and an optional saved route to drive."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("themedDialog")
        self.setWindowTitle("New AV")

        layout = QFormLayout(self)

        self.id_edit = QLineEdit()
        self.id_edit.setObjectName("dialogLineEdit")
        self.id_edit.setPlaceholderText("e.g. 530100")
        layout.addRow("AV ID:", self.id_edit)
        note = QLabel("Autonomous vehicle with the default LiDAR + cameras")
        note.setStyleSheet("color:#93C5FD;")
        layout.addRow("", note)

        # Optional: a saved route (SAVED_PATHS) the AV will follow.
        self.route_combo = QComboBox()
        self.route_combo.setObjectName("dialogComboBox")
        self.route_combo.addItem(NO_ROUTE_LABEL)
        self.route_combo.addItems(list(SAVED_PATHS.keys()))
        layout.addRow("Route (optional):", self.route_combo)
        self.speed_spin = QDoubleSpinBox()
        self.speed_spin.setRange(0.0, 80.0)
        self.speed_spin.setSuffix(" km/h")
        self.speed_spin.setSpecialValueText("as saved")
        self.speed_spin.setToolTip("Speed limit on the route (0 = as the route was saved); "
                                   "changeable later: right-click the AV -> Speed limit")
        layout.addRow("Speed limit:", self.speed_spin)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.setObjectName("dialogButtonBox")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def get_values(self):
        return self.id_edit.text().strip(), "Auto Drive"

    def get_route(self):
        """Chosen route name, or None when 'None (no route)' is selected."""
        text = self.route_combo.currentText()
        return None if text == NO_ROUTE_LABEL else text

    def get_speed(self):
        """Speed limit on the route (km/h), None = as saved."""
        return self.speed_spin.value() or None


class NewUnknownObjectDialog(QDialog):
    """
    Popup asking for an Object ID + whether the dropped car / outer
    AV / pedestrian should be Static (stays put) or Dynamic (moves
    along a path the user draws on the map right after this closes).
    """

    def __init__(self, parent=None, object_type="object", allow_auto=False):
        super().__init__(parent)
        self.setObjectName("themedDialog")
        self.setWindowTitle(f"New {object_type.replace('_', ' ').title()}")

        layout = QFormLayout(self)

        self.id_edit = QLineEdit()
        self.id_edit.setObjectName("dialogLineEdit")
        layout.addRow("Object ID:", self.id_edit)

        self.mode_combo = QComboBox()
        self.mode_combo.setObjectName("dialogComboBox")
        self.mode_combo.addItems(["Static", "Dynamic"])
        layout.addRow("Placement:", self.mode_combo)

        self.drive_combo = None
        if allow_auto:                       # a vehicle in a yard chosen on the map: manual or autonomous driving
            self.drive_combo = QComboBox()
            self.drive_combo.setObjectName("dialogComboBox")
            self.drive_combo.addItem("Manual (drives its path)", False)
            self.drive_combo.addItem("Autonomous (brakes for what it detects)", True)
            self.drive_combo.setToolTip("Autonomous: it stops for vehicles / obstacles in its lane as its camera / "
                                        "LiDAR detect them in the current climate (late, or too late, in fog)")
            layout.addRow("Driving:", self.drive_combo)
            self.mode_combo.currentTextChanged.connect(lambda t: self.drive_combo.setEnabled(t == "Dynamic"))
            self.drive_combo.setEnabled(False)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.setObjectName("dialogButtonBox")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def get_values(self):
        return self.id_edit.text().strip(), self.mode_combo.currentText()

    def autonomous(self):
        return bool(self.drive_combo and self.drive_combo.isEnabled() and self.drive_combo.currentData())


class AVListWidget(QListWidget):
    """
    A QListWidget whose items can be dragged out.
    Each item carries a small JSON payload (avId)
    stored under Qt.UserRole, which we pack into custom
    QMimeData when a drag starts.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setSelectionMode(QAbstractItemView.SingleSelection)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        if item is None:
            return

        payload = item.data(Qt.UserRole)
        if not payload:
            return

        mime = QMimeData()
        mime.setData(AV_MIME_TYPE, json.dumps(payload).encode("utf-8"))

        mime.setText(item.text())

        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec_(Qt.CopyAction)


class DraggableIconLabel(QLabel):

    def __init__(self, vehicle_type, image_path, parent=None, category="fleet"):
        super().__init__(parent)

        self.vehicle_type = vehicle_type
        self.category = category
        self._drag_start_pos = None

        pixmap = QPixmap(cfg.url_to_file(image_path))
        self.setPixmap(
            pixmap.scaled(
                ICON_IMAGE_SIZE,
                ICON_IMAGE_SIZE,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

        self.setAlignment(Qt.AlignCenter)
        self.setFixedSize(ICON_TILE_SIZE - 12, ICON_TILE_SIZE - 12)
        self.setToolTip(f"Drag onto the map to place a new {vehicle_type}")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_start_pos = event.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_start_pos is None or not (event.buttons() & Qt.LeftButton):
            return

        if (event.pos() - self._drag_start_pos).manhattanLength() < QApplication.startDragDistance():
            return

        payload = {"type": self.vehicle_type, "new": True, "category": self.category}

        mime = QMimeData()
        mime.setData(AV_MIME_TYPE, json.dumps(payload).encode("utf-8"))

        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec_(Qt.CopyAction)


class OsmUpdateWorker(QThread):
    """Downloads the yard's surroundings from OpenStreetMap off the UI thread."""
    progress = pyqtSignal(str)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, bounds, parent=None):
        super().__init__(parent)
        self._bounds = bounds

    def run(self):
        try:
            data = osm_surroundings.download(self._bounds, progress=self.progress.emit)
            self.done.emit(data)
        except Exception as e:
            self.failed.emit(str(e))


class TerrainWorker(QThread):
    """The ground height (hills) for surroundings downloaded before terrain existed -- once, off the UI thread."""
    done = pyqtSignal(object)

    def __init__(self, bbox, parent=None):
        super().__init__(parent)
        self._bbox = bbox

    def run(self):
        try:
            import terrain
            self.done.emit(terrain.download(self._bbox))
        except Exception as e:                                   # offline: stays flat, tried again next start
            print(f"[3D] ground height not downloaded: {e}")


class ObstacleDimensionsDialog(QDialog):
    """(i) on an obstacle in Placed Objects: view / edit its dimensions (metres).
    Starts from the obstacle's saved values, else the type defaults in
    config/obstacle_types.json."""

    def __init__(self, title, object_type, current, defaults, parent=None):
        super().__init__(parent)
        self.setObjectName("themedDialog")
        self.setWindowTitle("Obstacle dimensions")
        self.setMinimumWidth(380)
        self._defaults = dict(defaults)
        labels = dict(OBSTACLE_FIELD_LABELS)
        labels.update(OBSTACLE_TYPES.get(object_type, {}).get("field_labels", {}))

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 18, 20, 16)
        outer.setSpacing(10)
        head = QLabel(title)
        head.setObjectName("obstacleCardTitle")
        outer.addWidget(head)
        hint = QLabel("Sizes in metres. Used for the 3D LiDAR view. "
                      "Defaults come from config/obstacle_types.json.")
        hint.setObjectName("obstacleCardHint")
        hint.setWordWrap(True)
        outer.addWidget(hint)

        form = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(8)
        self.spins = {}
        for key, default in self._defaults.items():
            spin = QDoubleSpinBox()
            spin.setObjectName("speedSpin")
            spin.setDecimals(2)
            spin.setRange(0.0 if key == "ground_clearance" else 0.05, 40.0)
            spin.setSingleStep(0.05)
            spin.setSuffix(" m")
            spin.setValue(float(current.get(key, default)))
            spin.setToolTip(f"Default: {default:g} m")
            form.addRow(labels.get(key, key.replace("_", " ").title()), spin)
            self.spins[key] = spin
        outer.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.setObjectName("dialogButtonBox")
        reset = buttons.addButton("Reset to defaults", QDialogButtonBox.ResetRole)
        reset.clicked.connect(self._reset)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def _reset(self):
        for key, spin in self.spins.items():
            spin.setValue(float(self._defaults[key]))

    def values(self):
        return {key: round(spin.value(), 3) for key, spin in self.spins.items()}


def _file_time(path):
    """'YYYY-MM-DD HH:MM:SS' of a file's last change ('' if it is not there)."""
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(os.path.getmtime(path)))
    except OSError:
        return ""


def _same_day(stamp, ref):
    """A date-time shown after another: only its time when it is the same day."""
    stamp, ref = str(stamp or ""), str(ref or "")
    return stamp[11:] if len(stamp) > 11 and stamp[:10] == ref[:10] else stamp


def _wrap_path(p):
    """A folder path that a word-wrapped label can break after each separator (else it widens its panel)."""
    return str(p).replace("\\", "\\​").replace("/", "/​")


class RowActionsDelegate(QStyledItemDelegate):
    """Action icons at the right end of every row of a side-panel list (show on map, drive, info, delete, ⋯ more
    ...): a click on an icon runs that action for that row. The row itself still selects, drags and opens its
    right-click menu as before. actions(row) -> [(key, icon, icon on a gold row, tooltip)]."""

    clicked = pyqtSignal(int, str)         # row, action key
    ICON = 16
    STEP = 25

    def __init__(self, actions, slots, parent=None):
        super().__init__(parent)
        self._actions = actions
        self.slots = slots                     # (the most icons a row has: room kept free of text)
        self.on_icon = False                   # (the last press was on an icon: the row's own click is skipped)

    def _rects(self, option, n):
        r = option.rect
        y = r.top() + (min(r.height(), 34) - self.ICON) // 2 + 1
        x = r.right() - 8 - n * self.STEP
        return [QRect(x + i * self.STEP + (self.STEP - self.ICON) // 2, y, self.ICON, self.ICON) for i in range(n)]

    def _hit(self, option, index, pos):
        acts = self._actions(index.row()) or []
        for a, rc in zip(acts, self._rects(option, len(acts))):
            if rc.adjusted(-4, -4, 4, 4).contains(pos):
                return a
        return None

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        room = option.rect.width() - self.slots * self.STEP - 40 - (option.decorationSize.width()
                                                                    if not option.icon.isNull() else 0)
        if option.text and room > 40:                     # (the text stops before the icons)
            fm = option.fontMetrics
            option.text = "\n".join(fm.elidedText(t, Qt.ElideRight, room) for t in option.text.split("\n"))

    def sizeHint(self, option, index):
        s = super().sizeHint(option, index)
        return QSize(s.width(), max(s.height(), 30))

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        active = bool(option.state & (QStyle.State_Selected | QStyle.State_MouseOver))   # (a gold row)
        acts = self._actions(index.row()) or []
        for a, rc in zip(acts, self._rects(option, len(acts))):
            a[2 if active else 1].paint(painter, rc)

    def editorEvent(self, event, model, option, index):
        if event.type() in (QEvent.MouseButtonPress, QEvent.MouseButtonRelease, QEvent.MouseButtonDblClick):
            a = self._hit(option, index, event.pos())
            if event.type() != QEvent.MouseButtonRelease:
                self.on_icon = a is not None
            if a is not None:
                if event.type() == QEvent.MouseButtonRelease and event.button() == Qt.LeftButton:
                    self.clicked.emit(index.row(), a[0])
                return True
        return super().editorEvent(event, model, option, index)

    def skip_click(self):
        """The row's own click / double-click handler: was it a click on an icon (then not)?"""
        return self.on_icon

    def helpEvent(self, event, view, option, index):
        a = self._hit(option, index, event.pos())
        if a is not None:
            QToolTip.showText(event.globalPos(), a[3], view)
            return True
        return super().helpEvent(event, view, option, index)


class MapView(QWebEngineView):

    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.setAcceptDrops(True)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self.main_window, "_position_map_overlays"):
            self.main_window._position_map_overlays()

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat(AV_MIME_TYPE):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat(AV_MIME_TYPE):
            event.acceptProposedAction()
        else:
            event.ignore()


    def dropEvent(self, event):
        if not event.mimeData().hasFormat(AV_MIME_TYPE):
            event.ignore()
            return

        raw = bytes(event.mimeData().data(AV_MIME_TYPE))
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            event.ignore()
            return

        pos = event.pos()
        self.main_window.handle_av_drop(pos.x(), pos.y(), payload)
        event.acceptProposedAction()


def _nowhere(*_a):
    """(No slots / buildings to keep obstacles out of: every point is free.)"""
    return False


def point_in_polygon(lat, lng, poly_latlng):
    n = len(poly_latlng)
    inside = False
    j = n - 1
    for i in range(n):
        yi, xi = poly_latlng[i]
        yj, xj = poly_latlng[j]
        intersects = ((yi > lat) != (yj > lat)) and (
            lng < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-15) + xi
        )
        if intersects:
            inside = not inside
        j = i
    return inside


class MapBridge(QObject):

    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window

    @pyqtSlot(str, float, float)
    def vehicleMoved(self, vehicle_id, lat, lng):
        self.main_window.handle_vehicle_moved(vehicle_id, lat, lng)

    @pyqtSlot(str)
    def removeVehicleFromMap(self, vehicle_id):
        self.main_window.remove_vehicle_from_map(vehicle_id)

    @pyqtSlot(str)
    def toggleDynamicObject(self, object_id):
        self.main_window.toggle_dynamic_object(object_id)

    @pyqtSlot(float, float)
    def mapMenu(self, lat, lng):                       # right-click on the map itself
        QTimer.singleShot(0, lambda: self.main_window.map_context_menu(lat, lng))

    @pyqtSlot(str)
    def vehicleMenu(self, vehicle_id):                 # right-click on an AV
        QTimer.singleShot(0, lambda: self.main_window.vehicle_context_menu(vehicle_id))

    @pyqtSlot(str, str)
    def objectMenu(self, object_id, cat):              # right-click on anything (2D obstacles, the 3D view)
        QTimer.singleShot(0, lambda: self.main_window.object_context_menu(object_id, cat))


class MapWindow(QMainWindow):

    @staticmethod
    def _icon(name, color="white", **kw):
        """qtawesome icon that never crashes the UI if a name is missing."""
        try:
            return qta.icon(name, color=color, **kw)
        except Exception:
            return qta.icon("fa5s.circle", color=color)

    def _make_side_item(self, icon_name, text, short, sub=False):
        """Rail button: icon with a short caption under it; the full name in the tooltip."""
        btn = QToolButton()
        btn.setObjectName("railSub" if sub else "railItem")
        btn.setText(short)
        btn.setProperty("navText", text)
        btn.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        btn.setCheckable(True)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setIcon(self._icon(icon_name, "#A1A1AA", color_on="#FBBF24",
                               color_active="#FFFFFF"))
        btn.setIconSize(QSize(16, 16) if sub else QSize(19, 19))
        btn.setFixedSize(SIDEBAR_WIDTH - 12, 44 if sub else 50)
        btn.setToolTip(text)
        return btn

    @staticmethod
    def _repolish(widget):
        """Re-apply the stylesheet after a dynamic property change."""
        widget.style().unpolish(widget)
        widget.style().polish(widget)

    def __init__(self):
        super().__init__()
        # The network's web filter blocks Qt's built-in browser identity ("... Chrome/83 ...",
        # an outdated Chrome): map tiles came back as 403 -> empty squares on the 2D map.
        # The app's own identity passes and also follows OpenStreetMap's tile usage policy.
        QWebEngineProfile.defaultProfile().setHttpUserAgent(WEB_USER_AGENT)
        # moving obstacles: avoid each other (default) or crash ("Collisions" check-box)
        self.obstacle_collisions = False          # obstacle collisions: OFF at every start (tick it when wanted)
        self._accident_pairs = set()
        self.accident_count = 0

        self.setWindowTitle("Q-SCAPE -- Quest Simulation & Collision Analysis Platform Environment")
        # size used when leaving full screen / maximized -- never bigger than the screen
        fit_to_screen(self, 1400, 900)
        self.unknown_objects_file = UNKNOWN_OBJECTS_FILE

        self.dynamic_objects = {}
        self._pending_dynamic_object = None

        self.lidar_view = None          # the 3D LiDAR window (created on first use)
        self._lidar_last = {}           # AV key -> last (lat, lon, heading) seen
        self._lidar_live_prev = None    # (lat, lon, time) for the live AV's speed
        self._lidar_live_speed = "--"
        self._finished_routes = {}      # vehicle_id -> replay state of a route that has ended
        # The 3D view refreshes its surroundings on its own clock, so obstacles that are
        # added or moving show up even while the AV is parked / between route points.
        self._lidar_refresh_timer = QTimer(self)
        self._lidar_refresh_timer.timeout.connect(self._lidar_refresh_tick)
        self._lidar_refresh_timer.start(250)

        self.map_var_name = None

        # vehicle_id -> {"points": [...], "index": int, "timer": QTimer, "file": str}
        self.path_replays = {}
        self._hover_in_flight = False

        # ----------------------------
        # The site: built from its map parameter file in sites/<site>/cc_config (made by Sites -> New site from
        # the map: outline, centre, bounds)
        # ----------------------------
        self.data, self.site_info, self.site_warnings = load_site(cfg.CC_CONFIG_DIR, cfg.ACTIVE_SITE)
        # open lanes where random moving obstacles are spawned: the yard's operational
        # area (else the whole yard rectangle)
        (s_lat, w_lon), (n_lat, e_lon) = self.site_info["bounds"]
        self.dynamic_zones = [self.site_info["operational_area"] or
                              [[n_lat, w_lon], [n_lat, e_lon], [s_lat, e_lon], [s_lat, w_lon]]]

        # ----------------------------
        # Map: centred on the yard; zoom limits from app_settings.json "map"
        # ----------------------------
        map_cfg = cfg.APP_SETTINGS.get("map", {})

        self.map = folium.Map(
            location=self.site_info["center"],
            zoom_start=map_cfg.get("zoom_start", 18),
            zoom_control=False,
            min_zoom=map_cfg.get("min_zoom", 17.5),
            max_zoom=map_cfg.get("max_zoom", 21),
            max_bounds=True,
            # min_zoom is 17.5: with Leaflet's default zoomSnap of 1, any pan
            # (e.g. the click popup) rounds 17.5 back up to 18, so allow half steps.
            zoom_snap=0.5,
            tiles=None,
        )
        # Leaflet (+ jQuery) ship with the app in assets/web/lib -- the CDNs folium uses
        # by default are blocked on this network, and once Qt's browser cache is cleared
        # the 2D map would stay blank. Bootstrap / Font Awesome / awesome-markers are not
        # used by this app, so they are left out.
        lib = lambda *p: QUrl.fromLocalFile(os.path.join(cfg.WEB_DIR, "lib", *p)).toString()
        self.map.default_js = [("leaflet", lib("leaflet", "leaflet.js")),
                               ("jquery", lib("jquery-3.7.1.min.js"))]
        self.map.default_css = [("leaflet_css", lib("leaflet", "leaflet.css"))]
        # OpenStreetMap only has tiles up to zoom 19; above that, stretch the
        # zoom-19 tiles instead of requesting tiles that don't exist (blank map).
        # (folium puts min/max zoom on the tile layer, and Leaflet takes the map's
        # limits from it -- so they must be repeated here)
        # Tiles only exist for whole zoom levels: with min_zoom 17.5 Leaflet asked for
        # ".../17.5/x/y.png" (404 -> empty squares on the map), so the tile zooms are
        # clamped to whole numbers (17..19); the map itself still zooms in half steps.
        min_zoom = map_cfg.get("min_zoom", 17.5)
        folium.TileLayer(
            "OpenStreetMap",
            min_zoom=min_zoom,
            max_zoom=map_cfg.get("max_zoom", 21),
            min_native_zoom=int(math.floor(min_zoom)),
            max_native_zoom=19,
        ).add_to(self.map)

        self.map.get_root().html.add_child(folium.Element("""
        <style>
        .leaflet-control-attribution { display: none !important; }
        /* dark behind the (inverted) tiles: a tile still loading is not a white square */
        .leaflet-container { background: #1b1f24 !important; }
        .leaflet-tile-pane {
            filter: invert(1) hue-rotate(180deg) brightness(0.8) contrast(0.95);
        }
        .leaflet-bottom { margin-bottom: 26px; }
        </style>

        """))

        self.map.fit_bounds(self.site_info["bounds"])


        html_file = cfg.MAP_HTML_FILE          # generated/shipyard_map.html (rebuilt every start)
        self.map.save(html_file)

        with open(html_file, "r", encoding="utf-8") as f:
            html_content = f.read()

        match = re.search(r"var\s+(map_[0-9a-fA-F]+)\s*=\s*L\.map", html_content)
        self.map_var_name = match.group(1) if match else None

        if self.map_var_name is None:
            print("WARNING: could not detect Leaflet map variable name; "
                  "drag-and-drop marker placement will not work.")


        self.browser = MapView(self)

        self.channel = QWebChannel()
        self.bridge = MapBridge(self)
        self.channel.registerObject("bridge", self.bridge)
        self.browser.page().setWebChannel(self.channel)

        self.browser.load(QUrl.fromLocalFile(html_file))
        self.browser.loadFinished.connect(self.on_map_loaded)
        # ---- overlays on the map: collapse / immersive ----
        self.collapse_map_btn = QToolButton(self.browser)
        self.collapse_map_btn.setObjectName("mapOverlayButton")
        self.collapse_map_btn.setIcon(self._icon("fa5s.chevron-left", "white"))
        self.collapse_map_btn.setFixedSize(38, 38)
        self.collapse_map_btn.clicked.connect(self.toggle_map_maximized)

        self.maximize_map_btn = QToolButton(self.browser)
        self.maximize_map_btn.setObjectName("mapOverlayButton")
        self.maximize_map_btn.setIcon(self._icon("fa5s.expand", "white"))
        self.maximize_map_btn.setFixedSize(38, 38)
        self.maximize_map_btn.clicked.connect(self.toggle_map_immersive)

        for w in (self.collapse_map_btn, self.maximize_map_btn):
            w.raise_()
        self._position_map_overlays()

        # ----------------------------
        # Left area: sidebar navigation + page stack
        # ----------------------------
        self.stack = QStackedWidget()
        self.pages = {}
        self.nav_buttons = {}
        self.side_group = QButtonGroup(self)
        self.side_group.setExclusive(True)

        nav_items = [
            # key,        icon,                   text,                     caption,     kind
            ("avs",       "fa5s.truck",           "Autonomous Vehicles",    "AVs",       "sub"),
            ("objects",   "fa5s.walking",         "Obstacles",              "Obstacles", "sub"),
            ("routes",    "fa5s.road",            "Routes",                 "Routes",    "sub"),
            ("scenarios", "fa5s.layer-group",     "Scenarios",              "Scenarios", "sub"),
            ("reports",   "fa5s.clipboard-list",  "Reports",                "Reports",   "main"),
        ]
        self.nav_titles = {k: t for k, _i, t, _c, _k in nav_items}
        self.nav_icons = {k: i for k, i, _t, _c, _k in nav_items}

        # ---- the icon rail: always slim; a click opens that page in the drawer ----
        self.sidebar = QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(SIDEBAR_WIDTH)
        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setContentsMargins(6, 10, 6, 10)
        sidebar_layout.setSpacing(4)

        self.sidebar_collapse_btn = QToolButton()
        self.sidebar_collapse_btn.setObjectName("sideToggle")
        self.sidebar_collapse_btn.setIcon(self._icon("fa5s.bars", "#FBBF24"))
        self.sidebar_collapse_btn.setIconSize(QSize(16, 16))
        self.sidebar_collapse_btn.setFixedSize(40, 40)
        self.sidebar_collapse_btn.setCursor(Qt.PointingHandCursor)
        self.sidebar_collapse_btn.setToolTip("Open / close the panel")
        self.sidebar_collapse_btn.clicked.connect(self._toggle_side_content)
        sidebar_layout.addWidget(self.sidebar_collapse_btn, 0, Qt.AlignHCenter)
        sidebar_layout.addSpacing(10)

        self.nav_items = []     # every rail button
        self.sub_rows = []      # the set-up pages
        self.nav_counts = {}    # key -> count badge (AVs / Obstacles)

        for key, icon_name, text, short, kind in nav_items:
            is_sub = (kind == "sub")
            if key == "reports":
                divider = QFrame()
                divider.setObjectName("navDivider")
                divider.setFixedHeight(1)
                self._nav_divider = divider
                sidebar_layout.addSpacing(6)
                sidebar_layout.addWidget(divider)
                sidebar_layout.addSpacing(6)
            btn = self._make_side_item(icon_name, text, short, sub=is_sub)
            self.side_group.addButton(btn)
            self.nav_buttons[key] = btn
            btn.clicked.connect(lambda _checked, k=key: self._on_nav_clicked(k))
            self.nav_items.append(btn)
            if is_sub:
                self.sub_rows.append(btn)
            if key in ("avs", "objects"):
                # live count badge on the icon's top-right corner
                pill = QLabel("0", btn)
                pill.setObjectName("navCount")
                pill.setAlignment(Qt.AlignCenter)
                pill.setAttribute(Qt.WA_TransparentForMouseEvents)
                pill.setFixedHeight(15)
                self.nav_counts[key] = pill
            sidebar_layout.addWidget(btn, 0, Qt.AlignHCenter)
        sidebar_layout.addStretch()

        # --- AVs: the site's autonomous vehicles (drag the AV icon onto the map to add one) ---
        create_group = QGroupBox("New AV")
        create_layout = QVBoxLayout(create_group)
        create_layout.setSpacing(6)
        hint_label = QLabel("Drag the icon onto the map (it stands on the nearest road)")
        hint_label.setProperty("role", "fieldLabel")
        hint_label.setWordWrap(True)
        hint_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        create_layout.addWidget(hint_label)
        icon_row = QHBoxLayout()
        icon_row.setSpacing(18)
        icon_row.addStretch()
        icon_row.addLayout(self._build_icon_tile("truck", AV_ICON_PATH, "AV"))
        icon_row.addStretch()
        create_layout.addLayout(icon_row)
        self.create_group = create_group

        page_fleet = QWidget()
        page_fleet_layout = QVBoxLayout(page_fleet)
        page_fleet_layout.addWidget(create_group)

        self.auto_group = QGroupBox("Autonomous vehicles (AVs)")
        auto_layout = QVBoxLayout(self.auto_group)
        auto_layout.setSpacing(6)
        auto_hint = QLabel("Double-click an AV to show it on the map; right-click it (list or map) for its path, a "
                           "saved route, follow in 3D. Collision Testing (top bar) uses these AVs or makes its own.")
        auto_hint.setObjectName("obstacleHint")
        auto_hint.setWordWrap(True)
        auto_layout.addWidget(auto_hint)
        self.av_list = AVListWidget()
        self.av_list.setObjectName("avList")
        self.av_list.setMinimumHeight(140)
        self.av_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        auto_layout.addWidget(self.av_list)

        fleet_buttons_row = QHBoxLayout()
        fleet_buttons_row.setSpacing(8)
        self.delete_selected_vehicles_button = QPushButton("Delete Selected")
        self.delete_selected_vehicles_button.setObjectName("stopObjectButton")
        self.delete_selected_vehicles_button.setCursor(Qt.PointingHandCursor)
        self.delete_selected_vehicles_button.clicked.connect(self.delete_selected_vehicles)
        fleet_buttons_row.addWidget(self.delete_selected_vehicles_button)
        self.clear_all_vehicles_button = QPushButton("Clear All")
        self.clear_all_vehicles_button.setObjectName("stopObjectButton")
        self.clear_all_vehicles_button.setCursor(Qt.PointingHandCursor)
        self.clear_all_vehicles_button.clicked.connect(self.clear_all_vehicles)
        fleet_buttons_row.addWidget(self.clear_all_vehicles_button)
        auto_layout.addLayout(fleet_buttons_row)
        page_fleet_layout.addWidget(self.auto_group)
        page_fleet_layout.addStretch()
        self.stack.addWidget(page_fleet)
        self.pages["avs"] = page_fleet

        self.av_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.av_list.customContextMenuRequested.connect(
            lambda pos, l=self.av_list: self.show_av_menu(pos, l))
        # Double-click an AV in the list -> show it on the map
        self.av_list.itemDoubleClicked.connect(self._locate_vehicle_on_map)

        # --- Unknown objects: car / outer truck / pedestrian ---
        unknown_group = QGroupBox("Unknown Objects")
        unknown_layout = QVBoxLayout(unknown_group)
        unknown_layout.setSpacing(6)

        unknown_hint_label = QLabel(
            "Drag onto the map, then choose Static or Dynamic"
        )
        unknown_hint_label.setProperty("role", "fieldLabel")
        unknown_hint_label.setWordWrap(True)
        unknown_layout.addWidget(unknown_hint_label)

        unknown_icon_row = QHBoxLayout()
        unknown_icon_row.setSpacing(14)
        unknown_icon_row.addStretch()

        unknown_icon_row.addLayout(
            self._build_icon_tile(
                "car", CAR_ICON_PATH, "Car", category="unknown"
            )
        )
        unknown_icon_row.addLayout(
            self._build_icon_tile(
                "outer_truck", OUTER_TRUCK_ICON_PATH, "Outer Truck", category="unknown"
            )
        )
        unknown_icon_row.addLayout(
            self._build_icon_tile(
                "pedestrian", PEDESTRIAN_ICON_PATH, "Pedestrian", category="unknown"
            )
        )
        unknown_icon_row.addStretch()
        if self.map_yard:
            # a yard chosen on the map (roads, traffic): more vehicle kinds -- van, bus, truck + trailer
            extra = QHBoxLayout()
            extra.setSpacing(14)
            extra.addStretch()
            for kind in ("van", "bus", "truck_trailer"):
                if kind in OBSTACLE_TYPES:
                    extra.addLayout(self._build_icon_tile(kind, UNKNOWN_OBJECT_ICONS[kind],
                                                          OBSTACLE_TYPES[kind].get("label", kind), category="unknown"))
            extra.addStretch()
            self._extra_vehicle_row = extra

        unknown_layout.addLayout(unknown_icon_row)
        if getattr(self, "_extra_vehicle_row", None) is not None:
            unknown_layout.addLayout(self._extra_vehicle_row)

        self.path_status_label = QLabel("")
        self.path_status_label.setProperty("role", "statusLabel")
        self.path_status_label.setWordWrap(True)
        unknown_layout.addWidget(self.path_status_label)

        self.finish_path_button = QPushButton("Finish Path")
        self.finish_path_button.setObjectName("finishPathButton")
        self.finish_path_button.setCursor(Qt.PointingHandCursor)
        self.finish_path_button.setEnabled(False)
        self.finish_path_button.clicked.connect(self.finish_path_drawing)
        unknown_layout.addWidget(self.finish_path_button)

        objects_label = QLabel("Placed Objects")
        objects_label.setProperty("role", "fieldLabel")
        unknown_layout.addWidget(objects_label)

        self.unknown_list = QListWidget()
        self.unknown_list.setObjectName("obstacleList")     # rows leave room for the (i)
        self.unknown_list.setMinimumHeight(90)
        unknown_layout.addWidget(self.unknown_list)
        self.unknown_list.setSelectionMode(QAbstractItemView.ExtendedSelection)

        self.unknown_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.unknown_list.customContextMenuRequested.connect(self.show_unknown_menu)
        # (each row's action icons -- show on the map, stop / go, dimensions, delete, more: _setup_row_actions)

        # --- card for the selected moving obstacle(s): stop/resume + speed ---
        self.obstacle_hint = QLabel(
            "Select a moving obstacle to stop / resume it or change its speed.")
        self.obstacle_hint.setObjectName("obstacleHint")
        self.obstacle_hint.setWordWrap(True)
        unknown_layout.addWidget(self.obstacle_hint)

        self.obstacle_card = QFrame()
        self.obstacle_card.setObjectName("obstacleCard")
        card_layout = QVBoxLayout(self.obstacle_card)
        card_layout.setContentsMargins(12, 10, 12, 10)
        card_layout.setSpacing(8)

        card_head = QHBoxLayout()
        self.speed_title = QLabel("")
        self.speed_title.setObjectName("obstacleCardTitle")
        # long names wrap instead of widening the panel
        self.speed_title.setWordWrap(True)
        self.speed_title.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        card_head.addWidget(self.speed_title, 1)
        self.movement_state_chip = QLabel("")
        self.movement_state_chip.setObjectName("stateChip")
        self.movement_state_chip.setFixedHeight(20)
        card_head.addWidget(self.movement_state_chip, 0, Qt.AlignTop)
        card_layout.addLayout(card_head)

        controls_row = QHBoxLayout()
        controls_row.setSpacing(10)
        # one button: Stop while moving, Resume while stopped
        self.movement_toggle_btn = QPushButton()
        self.movement_toggle_btn.setObjectName("movementToggle")
        self.movement_toggle_btn.setCursor(Qt.PointingHandCursor)
        self.movement_toggle_btn.setIconSize(QSize(14, 14))
        self.movement_toggle_btn.clicked.connect(self.toggle_selected_movement)
        controls_row.addWidget(self.movement_toggle_btn)
        # slider in 0.5 km/h steps; the spin box shows / types the exact value
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setObjectName("speedSlider")
        self.speed_slider.setCursor(Qt.PointingHandCursor)
        controls_row.addWidget(self.speed_slider, 1)
        self.speed_spin = QDoubleSpinBox()
        self.speed_spin.setObjectName("speedSpin")
        self.speed_spin.setDecimals(1)
        self.speed_spin.setSingleStep(0.5)
        self.speed_spin.setSuffix(" km/h")
        self.speed_spin.setMinimumWidth(96)
        controls_row.addWidget(self.speed_spin)
        card_layout.addLayout(controls_row)

        self.speed_range_label = QLabel("")
        self.speed_range_label.setObjectName("obstacleCardHint")
        card_layout.addWidget(self.speed_range_label)

        unknown_layout.addWidget(self.obstacle_card)
        self.obstacle_card.hide()

        self.speed_slider.valueChanged.connect(
            lambda v: self.speed_spin.setValue(v / 2.0))
        self.speed_spin.valueChanged.connect(self._on_speed_control_changed)
        self.unknown_list.itemSelectionChanged.connect(self._refresh_speed_control)
        # saving to disk is delayed while the slider is being dragged
        self._speed_save_timer = QTimer(self)
        self._speed_save_timer.setSingleShot(True)
        self._speed_save_timer.timeout.connect(self.save_unknown_objects)

        objects_buttons_row = QHBoxLayout()
        objects_buttons_row.setSpacing(8)

        self.delete_selected_objects_button = QPushButton("Delete Selected")
        self.delete_selected_objects_button.setObjectName("stopObjectButton")
        self.delete_selected_objects_button.setCursor(Qt.PointingHandCursor)
        self.delete_selected_objects_button.clicked.connect(self.delete_selected_unknown_objects)
        objects_buttons_row.addWidget(self.delete_selected_objects_button)

        self.clear_all_objects_button = QPushButton("Clear All")
        self.clear_all_objects_button.setObjectName("stopObjectButton")
        self.clear_all_objects_button.setCursor(Qt.PointingHandCursor)
        self.clear_all_objects_button.clicked.connect(self.clear_all_unknown_objects)
        objects_buttons_row.addWidget(self.clear_all_objects_button)

        unknown_layout.addLayout(objects_buttons_row)
        unknown_layout.addWidget(self._collision_checkbox())

        page_objects = QWidget()


        page_objects = QWidget()
        page_objects_layout = QVBoxLayout(page_objects)
        page_objects_layout.addWidget(unknown_group)
        self.stack.addWidget(page_objects)
        self.pages["objects"] = page_objects

        # --- Routes: saved routes -- new ones from source to destination / drawn ---
        self.pages["routes"] = self._build_routes_page()
        self.stack.addWidget(self.pages["routes"])
        # --- Scenarios: saved sets of obstacles (scenarios.py) ---
        self.pages["scenarios"] = self._build_scenarios_page()
        self.stack.addWidget(self.pages["scenarios"])
        # --- Reports: the saved collision test results (open them again, replay them) ---
        self.pages["reports"] = self._build_reports_page()
        self.stack.addWidget(self.pages["reports"])

        self.load_vehicles()
        self.load_unknown_objects()

        # ---- left area = the icon rail (+ the drawer while it is pinned) ----
        self.left_area = QWidget()
        self.left_area.setObjectName("leftArea")
        self.left_area.setAttribute(Qt.WA_StyledBackground, True)   # never show the default grey
        self.left_area.setFixedWidth(SIDEBAR_WIDTH)
        left_layout = QHBoxLayout(self.left_area)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)
        # (the rail scrolls when the main area is short -- e.g. a collision-test panel fitted below it on a laptop;
        #  else its buttons' height kept the map from shrinking)
        rail_scroll = QScrollArea()
        rail_scroll.setObjectName("railScroll")
        rail_scroll.setWidget(self.sidebar)
        rail_scroll.setWidgetResizable(True)
        rail_scroll.setFrameShape(QFrame.NoFrame)
        rail_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        rail_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)          # (mouse wheel scrolls it)
        rail_scroll.setFixedWidth(SIDEBAR_WIDTH)
        rail_scroll.setStyleSheet("QScrollArea#railScroll { background: transparent; border: none; }")
        self.rail_scroll = rail_scroll
        left_layout.addWidget(rail_scroll)
        self.left_layout = left_layout

        # ---- the drawer: the pages, sliding in over the map (or pinned next to the rail) ----
        pages_scroll = QScrollArea()
        self.pages_scroll = pages_scroll
        pages_scroll.setWidgetResizable(True)
        pages_scroll.setFrameShape(QFrame.NoFrame)
        pages_scroll.setWidget(self.stack)

        self.drawer = QFrame()
        self.drawer.setObjectName("sideDrawer")
        self.drawer.setAttribute(Qt.WA_StyledBackground, True)
        drawer_lay = QHBoxLayout(self.drawer)
        drawer_lay.setContentsMargins(0, 0, 0, 0)
        drawer_lay.setSpacing(0)
        drawer_body = QWidget()
        body_lay = QVBoxLayout(drawer_body)
        body_lay.setContentsMargins(0, 0, 0, 0)
        body_lay.setSpacing(0)
        head = QFrame()
        head.setObjectName("drawerHeader")
        head_lay = QHBoxLayout(head)
        head_lay.setContentsMargins(14, 8, 8, 8)
        head_lay.setSpacing(10)
        self.drawer_icon = QLabel()
        self.drawer_icon.setObjectName("drawerIcon")
        self.drawer_icon.setFixedSize(30, 30)
        self.drawer_icon.setAlignment(Qt.AlignCenter)
        head_lay.addWidget(self.drawer_icon)
        self.drawer_title = QLabel()
        self.drawer_title.setObjectName("drawerTitle")
        head_lay.addWidget(self.drawer_title, 1)

        def head_button(icon_name, tip):
            b = QToolButton()
            b.setObjectName("drawerHeadBtn")
            b.setIcon(self._icon(icon_name, "#A1A1AA", color_on="#FBBF24"))
            b.setIconSize(QSize(13, 13))
            b.setFixedSize(30, 30)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(tip)
            head_lay.addWidget(b)
            return b
        self.drawer_pin_btn = head_button(
            "fa5s.thumbtack", "Pin: keep the panel open next to the menu (the map moves aside)")
        self.drawer_pin_btn.setCheckable(True)
        self.drawer_pin_btn.toggled.connect(self._set_drawer_pinned)
        self.drawer_close_btn = head_button("fa5s.times", "Close (Esc)")
        self.drawer_close_btn.clicked.connect(lambda: self._close_drawer())
        body_lay.addWidget(head)
        body_lay.addWidget(pages_scroll, 1)
        drawer_lay.addWidget(drawer_body, 1)
        self.drawer_grip = DrawerGrip()
        self.drawer_grip.moved.connect(self._resize_drawer)
        drawer_lay.addWidget(self.drawer_grip)
        self.drawer.hide()
        self.drawer_open = False
        self.drawer_pinned = False
        self._current_nav = "avs"
        self._ui_ready = False
        self._drawer_width = self._default_drawer_width()
        self._drawer_anim = QPropertyAnimation(self.drawer, b"geometry", self)
        self._drawer_anim.setDuration(190)
        self._drawer_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._drawer_anim.finished.connect(self._drawer_anim_done)
        self._esc_shortcut = QShortcut(QKeySequence(Qt.Key_Escape), self)
        self._esc_shortcut.activated.connect(lambda: self._close_drawer())
        self._esc_shortcut.setEnabled(False)

        # ---- map area = layer checkbox bar + map ----
        map_area = QWidget()
        map_area_layout = QVBoxLayout(map_area)
        map_area_layout.setContentsMargins(0, 0, 0, 0)
        map_area_layout.setSpacing(0)

        layer_bar = QFrame()
        layer_bar.setObjectName("layerBar")
        layer_bar_layout = QHBoxLayout(layer_bar)
        layer_bar_layout.setContentsMargins(12, 4, 12, 4)
        layer_bar_layout.setSpacing(10)

        # check-boxes in groups: vehicles (AVs, obstacles) | sensors | climate -- in a strip that scrolls sideways
        # when the map
        # area is narrow (e.g. drawer pinned on a small screen), so it never widens the window
        groups_holder = QWidget()
        groups_holder.setObjectName("layerGroups")
        groups_lay = QHBoxLayout(groups_holder)
        groups_lay.setContentsMargins(0, 0, 0, 0)
        groups_lay.setSpacing(10)
        groups_scroll = QScrollArea()
        groups_scroll.setObjectName("layerGroupsScroll")
        groups_scroll.setWidget(groups_holder)
        groups_scroll.setWidgetResizable(True)
        groups_scroll.setFrameShape(QFrame.NoFrame)
        groups_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        groups_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        groups_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        groups_scroll.setMinimumWidth(120)
        layer_bar_layout.addWidget(groups_scroll, 1)

        def layer_group(title):
            box = QFrame(); box.setObjectName("layerGroup")
            box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)   # never squeezed / clipped
            box.setToolTip(title)
            gl = QHBoxLayout(box); gl.setContentsMargins(3, 2, 3, 2); gl.setSpacing(2)
            groups_lay.addWidget(box)
            return gl

        # compact icon toggles: the name / help shows when the mouse is over them
        def toggle(icon_name, tip, checked=False):
            b = QToolButton()
            b.setObjectName("layerToggle")
            b.setCheckable(True)
            b.setChecked(checked)
            b.setIcon(self._icon(icon_name, "#A1A1AA", color_on="#111111"))
            b.setIconSize(QSize(15, 15))
            b.setFixedSize(30, 26)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(tip)
            return b

        self.layer_state = {}
        self.layer_cbs = {}
        gl = layer_group("Vehicles")
        for key, icon_name, text in (("avs", "fa5s.truck", "AVs"), ("obstacles", "fa5s.walking", "Obstacles")):
            cb = toggle(icon_name, f"{text} -- show / hide on the map and in 3D", checked=True)
            self.layer_state[key] = True
            cb.toggled.connect(lambda on, k=key: self.set_layer_visible(k, on))
            self.layer_cbs[key] = cb
            gl.addWidget(cb)

        # LiDAR 3D view / AV cameras as panels inside the map area (movable, resizable)
        gl = layer_group("Sensors")
        self.lidar_panel_cb = toggle("fa5s.dot-circle", "LiDAR View -- the LiDAR 3D view of an AV in a panel over the map")
        self.lidar_panel_cb.toggled.connect(self._on_lidar_panel_toggled)
        gl.addWidget(self.lidar_panel_cb)
        # the AV's cameras (sites/<site>/vehicles/truck_cameras.json), in a panel
        self.camera_panel_cb = toggle("fa5s.video", "Camera View -- what the AV's cameras see: " + ", ".join(
            f"{c['label']} ({c.get('model', '')}, HFOV {c['hfov_deg']:g}°)" for c in cfg.SENSOR_CAMERAS.get("cameras", [])))
        self.camera_panel_cb.toggled.connect(self._on_camera_panel_toggled)
        gl.addWidget(self.camera_panel_cb)
        self.camera_view = None
        self.camera_panel = None

        # Climate for the 3D site, the AV cameras and the simulated LiDAR (config/climates.json);
        # starts with the first preset (clear sky) every time
        gl = layer_group("Climate")
        self.climate_combo = QComboBox()
        self.climate_combo.setObjectName("climateCombo")
        self.climate_combo.setIconSize(QSize(16, 16))
        self.climate_combo.setCursor(Qt.PointingHandCursor)
        for i, c in enumerate(cfg.CLIMATES):
            try:
                icon = self._icon(c.get("icon") or "mdi6.weather-sunny", "#93C5FD")
            except Exception:
                icon = self._icon("fa5s.cloud", "#93C5FD")
            self.climate_combo.addItem(icon, c.get("label", c["id"]), c["id"])
            self.climate_combo.setItemData(i, c.get("description", ""), Qt.ToolTipRole)
        self.climate_combo.setFixedHeight(26)
        self.climate_combo.setMinimumContentsLength(13)
        self.climate_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        # (the box stays compact in the bar; its drop-down list is as wide as the longest climate name)
        fm = self.climate_combo.fontMetrics()
        self.climate_combo.view().setMinimumWidth(
            max([fm.horizontalAdvance(c.get("label", c["id"])) for c in cfg.CLIMATES] or [120]) + 16 + 56)
        self.climate_combo.view().setTextElideMode(Qt.ElideNone)
        self.climate_combo.currentIndexChanged.connect(self._on_climate_changed)
        gl.addWidget(self.climate_combo)
        self.climate = cfg.CLIMATES[0]
        self._update_climate_tooltip()

        # the satellite photo as the ground of the 3D view (real_world.py: downloaded once per site)
        self.satellite_btn = toggle("fa5s.globe-americas", "Satellite ground -- the satellite photo of the site as the "
                                                           "ground of the 3D view (downloaded once)")
        self.satellite_btn.toggled.connect(self._on_satellite_toggled)
        gl.addWidget(self.satellite_btn)
        self.satellite = False
        self._imagery = None
        self._imagery_dl = None
        groups_lay.addStretch()
        groups_scroll.setFixedHeight(groups_holder.sizeHint().height() + 7)   # + a thin scroll bar

        # ---- 2D | 3D | Split view switch (right end of the layer bar) ----
        view_switch = QFrame()
        view_switch.setObjectName("viewSwitch")
        vs_lay = QHBoxLayout(view_switch)
        vs_lay.setContentsMargins(2, 2, 2, 2)
        vs_lay.setSpacing(0)
        self.view_group = QButtonGroup(self)
        self.view_buttons = {}
        for mode, icon_name in (("2d", "fa5s.map"), ("3d", "fa5s.cube"), ("split", "fa5s.columns")):
            b = QToolButton()
            b.setObjectName("viewSwitchButton")
            b.setIcon(self._icon(icon_name, "#A1A1AA", color_on="#111111"))
            b.setIconSize(QSize(14, 14))
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip({"2d": "2D -- flat map", "3d": "3D -- the whole yard in 3D",
                          "split": "Split -- 2D map and 3D view side by side"}[mode])
            b.clicked.connect(lambda _c, m=mode: self.set_map_view(m))
            self.view_group.addButton(b)
            self.view_buttons[mode] = b
            vs_lay.addWidget(b)
        self.view_buttons["2d"].setChecked(True)

        # "Update 3D": real buildings / roads / trees around the yard (3D view only)
        self.update3d_btn = QToolButton()
        self.update3d_btn.setObjectName("update3dButton")
        self.update3d_btn.setIcon(self._icon("fa5s.globe-americas", "#FBBF24"))
        self.update3d_btn.setIconSize(QSize(15, 15))
        self.update3d_btn.setCursor(Qt.PointingHandCursor)
        self.update3d_btn.setToolTip("Update 3D -- download the buildings, roads, fences, trees and water around "
                                     "this yard from OpenStreetMap and show them in the 3D view")
        self.update3d_btn.clicked.connect(self.update_3d_surroundings)
        self.update3d_btn.hide()
        self._osm_worker = None
        layer_bar_layout.addWidget(self.update3d_btn)
        # "More": the 3D view's options (were on the 3D view's own bar: LiDAR, path, textures, terrain, coverage ...)
        self.view3d_opts_btn = QToolButton()
        self.view3d_opts_btn.setObjectName("update3dButton")
        self.view3d_opts_btn.setIcon(self._icon("fa5s.sliders-h", "#FBBF24"))
        self.view3d_opts_btn.setIconSize(QSize(14, 14))
        self.view3d_opts_btn.setText("More")
        self.view3d_opts_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.view3d_opts_btn.setCursor(Qt.PointingHandCursor)
        self.view3d_opts_btn.setToolTip("3D view options: LiDAR points, replay path, textures, terrain, sensor "
                                        "coverage, planned route, replay timeline, measuring, sun shadows, parked "
                                        "cars and people")
        self.view3d_opts_btn.setPopupMode(QToolButton.InstantPopup)
        self.view3d_opts_btn.setMenu(self._build_view3d_menu())
        self.view3d_opts_btn.hide()
        layer_bar_layout.addSpacing(4)
        layer_bar_layout.addWidget(self.view3d_opts_btn)
        layer_bar_layout.addSpacing(6)
        layer_bar_layout.addWidget(view_switch)
        map_area_layout.addWidget(layer_bar)
        # the 2D map and the 3D yard view share this space -- one of them, or both side
        # by side (3D is built on first use); floating panels (LiDAR) sit on top
        self.map_host = MapHost()
        host_lay = QVBoxLayout(self.map_host)
        host_lay.setContentsMargins(0, 0, 0, 0)
        self.map_split = QSplitter(Qt.Horizontal)
        self.map_split.setObjectName("mapSplit")
        self.map_split.setChildrenCollapsible(False)
        self.map_split.setHandleWidth(6)
        self.map_split.addWidget(self.browser)
        host_lay.addWidget(self.map_split)
        self.yard3d_view = None
        self.lidar_panel = None
        self.map_host.resized.connect(self._keep_panels_inside)
        self.map_host.resized.connect(self._place_drawer)
        self.drawer.setParent(self.map_host)          # floats over the map until pinned
        self.drawer.hide()
        map_area_layout.addWidget(self.map_host, 1)
        self._yard3d_timer = QTimer(self)
        self._yard3d_timer.timeout.connect(self._push_yard3d)
        # obstacle detection from the LiDAR data: a hidden 3D page simulates the AV'
        # LiDAR 4x a second while one is moving (route / collision test) -- see _lidar_detect_tick
        self.sensor_view = None
        self._sensor_ready = False
        self._lidar_detect_busy = False
        self._lidar_dets = {}
        self._lidar_detect_timer = QTimer(self)
        self._lidar_detect_timer.timeout.connect(self._lidar_detect_tick)
        self._lidar_detect_timer.start(250)

        # markers created later (drag-drop, restore) should respect hidden layers
        self.layer_timer = QTimer(self)
        self.layer_timer.timeout.connect(self._reapply_hidden_layers)
        self.layer_timer.start(1500)

        self.nav_count_timer = QTimer(self)
        self.nav_count_timer.timeout.connect(self._update_nav_counts)
        self.nav_count_timer.start(2000)
        self._update_nav_counts()

        splitter = QSplitter()
        self.splitter = splitter
        splitter.addWidget(self.left_area)
        splitter.addWidget(map_area)
        splitter.setSizes([SIDEBAR_WIDTH, 1000])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        central = QWidget()
        central_layout = QVBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)
        self.header_bar = self._build_header()
        central_layout.addWidget(self.header_bar)
        # the main area + (below it, above the bottom bar) a panel fitted into the main window: Collision testing
        self.main_vsplit = QSplitter(Qt.Vertical)
        self.main_vsplit.setChildrenCollapsible(False)
        self.main_vsplit.setHandleWidth(6)
        self.main_vsplit.addWidget(splitter)
        self.main_vsplit.setStretchFactor(0, 1)
        central_layout.addWidget(self.main_vsplit, 1)
        self.footer_bar = self._build_footer()
        central_layout.addWidget(self.footer_bar)

        self._navigate("avs")
        self._show_sub_items(False)
        QTimer.singleShot(1500, self._show_site_warnings)
        self.setCentralWidget(central)

        try:                                              # (each list row: its own action icons)
            self._setup_row_actions()
        except Exception:
            sys.excepthook(*sys.exc_info())

        def _ui_done():
            self._ui_ready = True
            self._clear_rail_selection()            # drawer starts closed: nothing highlighted
            self._place_rail_badges()
        QTimer.singleShot(0, _ui_done)

        # -----------------------


        # -----------------------

    # =======================================================
    # map layer toggles, map overlays
    # =======================================================
    def _build_header(self):
        # [site selector] [site menu] [project] ........ [Collision Testing] [i] [Sensors] | [user]
        bar = QFrame()
        bar.setObjectName("topBar")
        bar.setFixedHeight(52)
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(16, 0, 16, 0)
        lay.setSpacing(6)

        self._top_texts = []                     # (button, text): icon only when the bar is short of room

        def top_button(icon_name, text="", tip=""):
            b = QToolButton()
            b.setObjectName("topBarButton")
            b.setCursor(Qt.PointingHandCursor)
            b.setIcon(self._icon(icon_name, "#FBBF24"))
            b.setIconSize(QSize(18, 18))
            if text:
                b.setText(text)
                b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
                self._top_texts.append((b, text))
            if tip:
                b.setToolTip(tip)
            return b

        # ---- site selector: every folder in sites/ with a map parameter file ----
        yard_icon = QLabel()
        yard_icon.setPixmap(self._icon("fa5s.map-marked-alt", "#FBBF24").pixmap(18, 18))
        lay.addWidget(yard_icon)
        lay.addSpacing(4)
        self.site_combo = QComboBox()
        self.site_combo.setObjectName("siteCombo")
        self.site_combo.setCursor(Qt.PointingHandCursor)
        self.site_combo.setToolTip("Site -- choose another site to load it")
        import auth
        for site_id in auth.visible_sites(cfg.available_sites()):     # (the sites this user may see)
            label = (self.site_info["display_name"] if site_id == cfg.ACTIVE_SITE
                     else cfg.site_display_name(site_id))
            self.site_combo.addItem(f"{label}  ({site_id})" if label != site_id else site_id, site_id)
        self.site_combo.setCurrentIndex(max(0, self.site_combo.findData(cfg.ACTIVE_SITE)))
        self.site_combo.activated.connect(self._on_site_selected)
        lay.addWidget(self.site_combo)

        # ---- site menu: new from the map / edit the area / delete ----
        self.yard_menu_btn = QToolButton()
        self.yard_menu_btn.setObjectName("yardMenuButton")
        self.yard_menu_btn.setIcon(self._icon("fa5s.edit", "#E5E7EB"))
        self.yard_menu_btn.setToolTip("Sites: a new site from the map, edit this site's area, delete a site")
        self.yard_menu_btn.setCursor(Qt.PointingHandCursor)
        self.yard_menu_btn.setPopupMode(QToolButton.InstantPopup)
        ym = QMenu(self.yard_menu_btn)
        ym.addAction(self._icon("fa5s.map-marked-alt", "#60A5FA"), "New site from the map ...", self.new_yard_from_map)
        ym.addAction(self._icon("fa5s.draw-polygon", "#60A5FA"), "Edit this site's area on the map ...",
                     self.edit_yard_area)
        ym.addSeparator()
        ym.addAction(self._icon("fa5s.trash-alt", "#EF4444"), "Delete a site ...", self.delete_yard)
        self.yard_menu_btn.setMenu(ym)
        lay.addWidget(self.yard_menu_btn)

        # ---- project name: part of the AVs' ids / topics <site>_<project>_<AV id> ----
        lay.addSpacing(8)
        proj_icon = QLabel()
        proj_icon.setPixmap(self._icon("fa5s.project-diagram", "#93C5FD").pixmap(16, 16))
        proj_icon.setToolTip("Project name")
        lay.addWidget(proj_icon)
        self.project_edit = QLineEdit(cfg.PROJECT_NAME)
        self.project_edit.setObjectName("projectEdit")
        self.project_edit.setFixedWidth(96)
        self.project_edit.setToolTip(f"Project name -- the AVs' ids (topics) are "
                                     f"<site>_<project>_<AV id>, e.g. {cfg.av_id('530052')}")
        self.project_edit.editingFinished.connect(self._on_project_edited)
        lay.addWidget(self.project_edit)
        lay.addStretch()

        # ---- collision testing ----
        self.collision_btn = top_button("fa5s.car-crash", "Collision Testing",
                                        "AVs on a saved route one behind the other: each brakes only on its own "
                                        "camera / LiDAR / radar / V2V (TTC, detections, sensors on / off)")
        self.collision_btn.clicked.connect(self.collision_test_dialog)
        lay.addWidget(self.collision_btn)
        self.collision_info_btn = top_button("fa5s.info-circle", "",
                                             "Collision testing -- how it works: camera, LiDAR, radar, V2V, sensor "
                                             "fusion, braking / TTC, climate, collision reasons (each one's purpose, "
                                             "how it detects, the method in use and others not integrated)")
        self.collision_info_btn.setIcon(self._icon("fa5s.info-circle", "#60A5FA"))
        self.collision_info_btn.clicked.connect(self.open_collision_info)
        lay.addWidget(self.collision_info_btn)

        self.sensor_mode_btn = top_button("fa5s.microchip", "Sensors",
                                          "Sensor set-up for collision testing: SIMULATED (the scene's objects, a "
                                          "model per sensor) or REAL-WORLD processing (camera picture, LiDAR point "
                                          "cloud, radar echoes, tracking)")
        self.sensor_mode_btn.clicked.connect(self.open_sensor_mode)
        lay.addWidget(self.sensor_mode_btn)
        self._update_sensor_mode_btn()

        # small screens (e.g. a 1366 px laptop): the buttons show their icon only (name in the tooltip) when the
        # bar would not fit with their names -- the window never reaches past the screen
        self._top_bar, self._top_compact, self._top_full_w = bar, False, None
        self.site_combo.setMaximumWidth(260)
        bar.installEventFilter(self)
        return bar

    def _fit_top_bar(self):
        bar = getattr(self, "_top_bar", None)
        if bar is None:
            return
        if self._top_full_w is None and not self._top_compact:
            self._top_full_w = bar.sizeHint().width()          # (with the names)
        compact = bar.width() < (self._top_full_w or 0)
        if compact == self._top_compact:
            return
        self._top_compact = compact
        for b, text in self._top_texts:
            if compact:
                b.setText("")
                b.setToolButtonStyle(Qt.ToolButtonIconOnly)
                if not (b.toolTip() or "").startswith(text):
                    b.setToolTip(f"{text} -- {b.toolTip()}" if b.toolTip() else text)
            else:
                b.setText(text)
                b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

    def eventFilter(self, obj, ev):
        if obj is getattr(self, "_top_bar", None) and ev.type() == QEvent.Resize:
            self._fit_top_bar()
        return super().eventFilter(obj, ev)

    def _on_site_selected(self, index):
        site_id = self.site_combo.itemData(index)
        if site_id == cfg.ACTIVE_SITE:
            return
        answer = QMessageBox.question(
            self, "Load site",
            f"Load site '{site_id}'?\n\nThe app reloads with that site's map, AVs, obstacles and routes. Everything "
            f"placed in '{cfg.ACTIVE_SITE}' is kept in its own folder and comes back when you switch back.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if answer != QMessageBox.Yes:
            self.site_combo.setCurrentIndex(max(0, self.site_combo.findData(cfg.ACTIVE_SITE)))
            return
        cfg.set_active_site(site_id)
        self.restart_application()

    # ---------------- yards: new / change files / delete (yard_manager.py) ----------------
    def _ask_restart(self, title, text):
        if QMessageBox.question(self, title, text + "\n\nRestart the app now?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) == QMessageBox.Yes:
            self.save_vehicles()
            self.restart_application()


    def new_yard_from_map(self):
        """A new yard from a boundary chosen on the map (search a place, draw / take its outline); its
        surroundings (buildings, roads, objects) are downloaded as with Update 3D -- see yard_from_map.py."""
        import yard_from_map
        outline = self.site_info.get("operational_area") or []
        if len(outline) < 3:
            (s, w), (n, e) = self.site_info["bounds"]
            outline = [[n, w], [s, w], [s, e], [n, e]]
        dlg = yard_from_map.ChooseYardDialog(self, center=self.site_info.get("center"), current_outline=outline)
        if dlg.exec_() != QDialog.Accepted or not dlg.site_id:
            return
        sid = dlg.site_id
        name = (dlg.result_info or {}).get("display_name") or sid
        self.site_combo.addItem(f"{name}  ({sid})" if name != sid else sid, sid)
        got = getattr(dlg, "download_summary", None)
        text = (f"Yard '{sid}' was created from the map." +
                (f"\n\nSurroundings downloaded: {got}" if got else
                 "\n\nIts surroundings are not downloaded yet: use Update 3D (3D view) after loading it.") +
                "\n\nLoad it now (the app restarts)?")
        if QMessageBox.question(self, "New yard", text, QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.Yes) == QMessageBox.Yes:
            self.save_vehicles()
            cfg.set_active_site(sid)
            self.restart_application()


    def edit_yard_area(self):
        """Yards -> Edit this yard's area on the map: move / resize / reshape the loaded yard's boundary on the map
        (as Choose from map); saved into its map parameter file (the old one kept in backup/), surroundings again."""
        import yard_from_map
        outline = self.site_info.get("operational_area") or []
        if len(outline) < 3:
            (s, w), (n, e) = self.site_info["bounds"]
            outline = [[n, w], [s, w], [s, e], [n, e]]
        dlg = yard_from_map.ChooseYardDialog(self, center=self.site_info.get("center"), current_outline=outline,
                                             edit_site=cfg.ACTIVE_SITE, edit_name=self.site_info.get("display_name"))
        if dlg.exec_() != QDialog.Accepted or not dlg.site_id:
            return
        got = getattr(dlg, "download_summary", None)
        self._ask_restart("Yard area", f"The new area of '{cfg.ACTIVE_SITE}' was saved." +
                          (f"\n\nSurroundings downloaded again: {got}" if got else "") +
                          "\n\nIt is used when the yard is loaded again.")

    def delete_yard(self):
        import yard_manager
        import auth
        others = [s for s in auth.visible_sites(cfg.available_sites()) if s != cfg.ACTIVE_SITE]
        if not others:
            QMessageBox.information(self, "Delete yard", "There is no other yard to delete (the yard that is "
                                                         "loaded now cannot be deleted).")
            return
        dlg = yard_manager.DeleteYardDialog(others, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        sid = dlg.site_id()
        if QMessageBox.question(self, "Delete yard", f"Delete the yard '{sid}'?\n\nIts folder is moved to "
                                                     f"backup/deleted_sites/.") != QMessageBox.Yes:
            return
        try:
            dest = yard_manager.delete_site(sid)
        except OSError as e:
            QMessageBox.critical(self, "Delete yard", f"Could not delete '{sid}': {e}")
            return
        i = self.site_combo.findData(sid)
        if i >= 0:
            self.site_combo.removeItem(i)
        QMessageBox.information(self, "Delete yard", f"'{sid}' was deleted (kept in {dest}).")

    def _on_project_edited(self):
        new = re.sub(r"[^A-Za-z0-9_\-]", "", self.project_edit.text().strip())
        if not new:
            new = cfg.DEFAULT_PROJECT_NAME
        if new == cfg.PROJECT_NAME:
            self.project_edit.setText(new)
            return
        example = cfg.av_id("530052", project=new)
        if QMessageBox.question(self, "Project name",
                                f"Change the project name to '{new}'?\n\nThe AVs' ids (topics) become "
                                f"<site>_{new}_<AV id>, e.g. {example}. The app restarts.",
                                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            self.project_edit.setText(cfg.PROJECT_NAME)
            return
        for i in range(self.av_list.count()):     # each AV: its new id
            it = self.av_list.item(i)
            p = dict(it.data(Qt.UserRole) or {})
            if p.get("avId") and not p.get("collisionTest"):
                p["avId"] = p["rover"] = cfg.av_id(p.get("number") or cfg.av_number(p["avId"]),
                                                             project=new)
                it.setData(Qt.UserRole, p)
        cfg.set_project_name(new)
        self.save_vehicles()
        self.restart_application()


    # ---------------- AVs: name / id / topic ----------------
    def vehicle_label(self, vehicle_id):
        """What a vehicle is called on screen: an AV's name, else its id."""
        _l, _i, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if p and p.get("name"):
            return str(p["name"])
        return str(vehicle_id)

    def _vehicle_labels(self):
        lst = getattr(self, "av_list", None)
        out = {}
        for i in range(lst.count() if lst is not None else 0):
            p = lst.item(i).data(Qt.UserRole) or {}
            if p.get("avId") and p.get("name"):
                out[p["avId"]] = p["name"]
        return out


    def restart_application(self):
        """Starts a fresh copy of the app (same command line) and closes this one --
        the cleanest way to rebuild everything for another yard."""
        from PyQt5.QtCore import QProcess
        import auth
        if not getattr(self, "_signing_out", False):
            auth.handoff()                                 # (the same user goes on in the new copy)
        args = sys.argv[:] if sys.argv and sys.argv[0] else [os.path.join(cfg.ROOT_DIR, "main.py")]
        if not QProcess.startDetached(sys.executable, args, cfg.ROOT_DIR):
            QMessageBox.warning(self, "Load shipyard",
                                "Could not restart automatically -- please start the app again.")
        self.close()
        QApplication.instance().quit()

    def sign_out(self):
        """Sign out: the app starts again at the sign-in."""
        if QMessageBox.question(self, "Sign out", "Sign out? The app starts again at the sign-in.") != QMessageBox.Yes:
            return
        self._signing_out = True
        self.save_vehicles()
        self.restart_application()


    def _show_site_warnings(self):
        """Problems found in the CC configuration files (shown once after loading)."""
        if self.site_warnings:
            QMessageBox.warning(
                self, f"Configuration -- {self.site_info['display_name']}",
                "Some configuration could not be used:\n\n- " + "\n- ".join(self.site_warnings) +
                f"\n\nFolder: {cfg.CC_CONFIG_DIR}")


    def _build_footer(self):
        """Bottom bar, same look as the header: app name + current version."""
        bar = QFrame()
        bar.setObjectName("bottomBar")
        bar.setFixedHeight(30)   # slimmer than the header so small screens keep map space
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(14, 0, 14, 0)
        lay.setSpacing(18)

        name_label = self.footer_label = QLabel(self._footer_text())
        name_label.setObjectName("bottomBarText")
        lay.addWidget(name_label)
        lay.addStretch()
        import window_tray                       # minimized windows (Follow test, cameras, LiDAR ...) wait here
        self.window_tray = window_tray.WindowTray(bar)
        lay.addWidget(self.window_tray)


        self.version_label = QLabel(f"Version {APP_VERSION}")
        self.version_label.setObjectName("bottomBarVersion")
        lay.addWidget(self.version_label)
        return bar

    def _footer_text(self):
        """The bottom bar: the app, the site, its AVs, obstacles, routes, scenarios, collision tests running and
        saved."""
        head = f"{APP_NAME}   |   {self.site_info['display_name']} ({cfg.ACTIVE_SITE})   |   "
        now = time.time()
        rc = getattr(self, "_footer_reports", None)
        if rc is None or now - rc[0] > 30:                # (the saved reports: counted every 30 s)
            try:
                rc = self._footer_reports = (now, len(self.list_collision_reports()))
            except Exception:
                rc = self._footer_reports = (now, 0)

        def n(lst):
            w = getattr(self, lst, None)
            return w.count() if w is not None else 0
        running = len(getattr(self, "collision_tests", None) or {})
        return head + (f"{n('av_list')} AVs, {n('unknown_list')} obstacles, "
                       f"{len(SAVED_PATHS)} routes, {len(getattr(self, 'scenarios', None) or [])} scenarios   |   "
                       + (f"{running} collision test{'s' if running != 1 else ''} running, " if running else "")
                       + f"{rc[1]} collision report{'s' if rc[1] != 1 else ''} saved")

    def _user_details_text(self, short=False):
        """The signed-in user: name (user name) · role [· last sign-in]."""
        import auth
        u = auth.current() or {}
        role = "Administrator" if auth.is_admin() else "User"
        who = f"{u.get('name')} ({u.get('username')})" if u.get("name") else str(u.get("username", ""))
        if short:
            return f"Signed in: {who}  ·  {role}"
        return (f"Signed in as {who}\nRole: {role}"
                + (f"\nAccount created: {u['created']}" if u.get("created") else "")
                + (f"\nLast sign-in: {u['last_login']}" if u.get("last_login") else ""))

    def make_minimizable(self, w, title):
        """A window of the app: minimized it waits in the bottom bar (click its button to bring it back)."""
        import window_tray
        return window_tray.make_minimizable(w, getattr(self, "window_tray", None), title)

    def minimize_to_tray(self, w, title):
        tray = getattr(self, "window_tray", None)
        if tray is None:
            w.hide()
        else:
            tray.add(w, title)

    def _show_sub_items(self, show):
        """(The rail always shows every item.)"""
        for row in self.sub_rows:
            row.setVisible(True)

    def _navigate(self, key):
        """Show a page in the drawer and keep the rail in sync."""
        page = self.pages.get(key)
        if page is None:
            return
        self.stack.setCurrentWidget(page)
        self._current_nav = key
        title = self.nav_titles.get(key) or key.replace("_", " ").title()
        self.drawer_title.setText(title)
        self.drawer_icon.setPixmap(self._icon(self.nav_icons.get(key, "fa5s.th-large"), "#FBBF24")
                                   .pixmap(QSize(16, 16)))
        btn = self.nav_buttons.get(key)
        if btn is not None:
            btn.setChecked(True)
        else:
            self._clear_rail_selection()
        if key == "reports":
            self.refresh_reports()
        if key == "routes":
            self.refresh_routes()
        if self._ui_ready:
            self._open_drawer()
            if key == "routes":                              # (the rows' heights for the panel's real width)
                QTimer.singleShot(0, self.refresh_routes)

    def _clear_rail_selection(self):
        checked = self.side_group.checkedButton()
        if checked is not None:
            self.side_group.setExclusive(False)
            checked.setChecked(False)
            self.side_group.setExclusive(True)

    def _on_nav_clicked(self, key):
        """Rail click: open that page; clicking the open page's icon again closes the drawer."""
        if self.drawer_open and self._current_nav == key and not self.drawer_pinned:
            self._close_drawer()
            return
        self._navigate(key)

    def _panel_width(self):
        return self._drawer_width

    def _default_drawer_width(self):
        """~a third of the screen: RIGHT_PANEL_WIDTH at most, 360 px at least."""
        screen_w = available_geometry(self).width()
        return max(360, min(RIGHT_PANEL_WIDTH, int(screen_w * 0.34)))

    # ---------------- the drawer (pages over the map, or pinned next to the rail) ----------------
    def _toggle_side_content(self):
        """Hamburger on the rail: open the last page / close the drawer."""
        if self.drawer_open:
            self._close_drawer()
        else:
            self._navigate(self._current_nav or "avs")

    def _set_side_expanded(self, expand):          # kept for older callers
        if expand:
            self._navigate(self._current_nav or "avs")
        else:
            self._close_drawer()

    def _drawer_rect(self, shown=True):
        host = self.map_host
        w = max(320, min(self._drawer_width, host.width() - 60))
        h = max(200, host.height() - 16)
        return QRect(8 if shown else -w - 12, 8, w, h)

    def _place_drawer(self):
        if self.drawer_open and not self.drawer_pinned and \
                self._drawer_anim.state() != QPropertyAnimation.Running:
            self.drawer.setGeometry(self._drawer_rect())

    def _open_drawer(self, animate=True):
        if self.drawer_pinned:
            self.drawer.show()
            self.drawer_open = True
            self._apply_left_width()
            return
        was_open = self.drawer_open and self.drawer.isVisible()
        self.drawer_open = True
        self._esc_shortcut.setEnabled(True)
        self.drawer.raise_()
        self.drawer.show()
        if was_open or not animate:
            self._drawer_anim.stop()
            self.drawer.setGeometry(self._drawer_rect())
            return
        self._drawer_anim.stop()
        self._drawer_anim.setStartValue(self._drawer_rect(False))
        self._drawer_anim.setEndValue(self._drawer_rect(True))
        self._drawer_anim.start()

    def _close_drawer(self, animate=True):
        if not self.drawer_open:
            return
        self.drawer_open = False
        self._esc_shortcut.setEnabled(False)
        self._clear_rail_selection()
        if self.drawer_pinned:
            self.drawer.hide()
            self._apply_left_width()
            return
        if not animate or not self.drawer.isVisible():
            self._drawer_anim.stop()
            self.drawer.hide()
            return
        self._drawer_anim.stop()
        self._drawer_anim.setStartValue(self.drawer.geometry())
        self._drawer_anim.setEndValue(self._drawer_rect(False))
        self._drawer_anim.start()

    def _drawer_anim_done(self):
        if not self.drawer_open and not self.drawer_pinned:
            self.drawer.hide()

    def _set_drawer_pinned(self, pinned):
        """Pinned: the drawer sits next to the rail and the map moves aside.
        Unpinned: it floats over the map."""
        self.drawer_pinned = pinned
        self._drawer_anim.stop()
        if pinned:
            self.drawer.setParent(self.left_area)
            self.left_layout.addWidget(self.drawer, 1)
            self._esc_shortcut.setEnabled(False)
            self.drawer.setVisible(self.drawer_open)
        else:
            self.left_layout.removeWidget(self.drawer)
            self.drawer.setParent(self.map_host)
            if self.drawer_open:
                self.drawer.setGeometry(self._drawer_rect())
                self.drawer.show()
                self.drawer.raise_()
                self._esc_shortcut.setEnabled(True)
        self.drawer_pin_btn.setToolTip("Unpin: let the panel float over the map" if pinned else
                                       "Pin: keep the panel open next to the menu (the map moves aside)")
        self._apply_left_width()

    def _apply_left_width(self):
        total = max(self.splitter.width(), 1)
        if self.drawer_pinned and self.drawer_open:
            # the map keeps at least ~45 % of the room
            w = SIDEBAR_WIDTH + int(max(320, min(self._drawer_width, total * 0.55 - SIDEBAR_WIDTH)))
            self.left_area.setFixedWidth(w)
            self.splitter.setSizes([w, max(total - w, 1)])
        else:
            self.left_area.setFixedWidth(SIDEBAR_WIDTH)
            self.splitter.setSizes([SIDEBAR_WIDTH, max(total - SIDEBAR_WIDTH, 1)])
        QTimer.singleShot(60, self._refresh_map_size)

    def _resize_drawer(self, dx):
        """Dragging the drawer's right edge."""
        limit = (self.splitter.width() - SIDEBAR_WIDTH - 300) if self.drawer_pinned else (self.map_host.width() - 60)
        self._drawer_width = int(max(320, min(limit, self._drawer_width + dx)))
        if self.drawer_pinned:
            self._apply_left_width()
        else:
            self.drawer.setGeometry(self._drawer_rect())
    def _refresh_map_size(self):
        var = getattr(self, "map_var_name", None)
        if var:
            self.browser.page().runJavaScript(
                f"if (typeof {var} !== 'undefined') {{ {var}.invalidateSize(); }}")
        self._position_map_overlays()


    def _update_nav_counts(self):
        """Live counts on the rail icons: AVs, placed obstacles."""
        counts = {"avs": self.av_list.count(), "objects": self.unknown_list.count()}
        for key, pill in self.nav_counts.items():
            n = counts.get(key, 0)
            pill.setText(str(n) if n < 1000 else "999+")
            btn = self.nav_buttons[key]
            btn.setToolTip(f"{btn.property('navText')}  ({n})")
        self._place_rail_badges()
        fl = getattr(self, "footer_label", None)                 # (the bottom bar's counts)
        if fl is not None:
            try:
                import auth
                t = self._footer_text()
                if auth.neutral(t) != fl.text():
                    fl.setText(t)
            except Exception:
                pass

    def _place_rail_badges(self):
        """Count badges on the top-right corner of their icons."""
        for key, pill in self.nav_counts.items():
            btn = self.nav_buttons[key]
            pill.adjustSize()
            pill.move(min(btn.width() - pill.width() - 1, btn.width() // 2 + 5), 2)
            pill.raise_()


    # ---- side-panel lists: action icons on each row (like the Routes list) ----
    def _act(self, key, icon, color, tip):
        """(key, icon, icon on a gold row, tooltip) -- the icons cached."""
        cache = self.__dict__.setdefault("_act_icons", {})
        if (icon, color) not in cache:
            cache[(icon, color)] = (self._icon(icon, color), self._icon(icon, "#111111"))
        return (key,) + cache[(icon, color)] + (tip,)

    def _row_actions(self, lst, slots, actions, handler):
        d = RowActionsDelegate(lambda row: actions(lst, row), slots, lst)

        def go(row, key):
            it = lst.item(row)
            if it is None:
                return
            if lst.currentItem() is not it:
                lst.setCurrentItem(it)
            try:
                handler(lst, it, key)
            except Exception:
                sys.excepthook(*sys.exc_info())
        d.clicked.connect(go)
        lst.setItemDelegate(d)
        lst.setMouseTracking(True)
        lst.setProperty("rowActions", True)
        return d

    def _setup_row_actions(self):
        """Every side-panel list gets its row icons: AVs, Obstacles, Scenarios, Reports. '⋯' opens the row's full
        right-click menu."""
        self._row_actions(self.av_list, 6, self._av_row_acts, self._av_row_do)
        self._row_actions(self.unknown_list, 5, self._obstacle_row_acts, self._obstacle_row_do)
        if hasattr(self, "scenario_list"):
            d = self._row_actions(self.scenario_list, 3, self._scenario_row_acts, self._scenario_row_do)
            self.scenario_list.itemClicked.disconnect()
            self.scenario_list.itemClicked.connect(lambda it, d=d: None if d.skip_click() else
                                                   self._on_scenario_clicked(it))
        if hasattr(self, "report_list"):
            d = self._row_actions(self.report_list, 4, self._report_row_acts, self._report_row_do)
            self.report_list.itemClicked.disconnect()
            self.report_list.itemClicked.connect(lambda it, d=d: None if d.skip_click() else
                                                 self._open_report_item(it))
        lst = self.av_list
        d = lst.itemDelegate()
        lst.itemDoubleClicked.disconnect()
        lst.itemDoubleClicked.connect(lambda it, d=d: None if d.skip_click() else self._locate_vehicle_on_map(it))

    def _row_menu_at_cursor(self, lst, show):
        """'⋯': the row's own right-click menu, at the right end of that row."""
        from PyQt5.QtCore import QPoint
        r = lst.visualItemRect(lst.currentItem()) if lst.currentItem() is not None else None
        if r is not None:
            show(QPoint(r.right() - 24, r.center().y()))

    def _confirm_delete(self, what):
        return QMessageBox.question(self, "Delete", f"Delete {what}?") == QMessageBox.Yes

    def _av_row_acts(self, lst, row):
        it = lst.item(row)
        p = (it.data(Qt.UserRole) or {}) if it is not None else {}
        vid = p.get("avId")
        placed = p.get("latitude") is not None or vid in self.path_replays or vid in self._finished_routes
        out = []
        if placed:
            out.append(self._act("locate", "fa5s.map-marker-alt", "#60A5FA", "Show it on the map"))
            out.append(self._act("3d", "fa5s.cube", "#A78BFA", "Follow it in 3D"))
        out.append(self._act("route", "fa5s.road", "#F97316",
                             "Driving -- stop it, or another route ..." if vid in self.path_replays else
                             "Drive a saved route ..."))
        out.append(self._act("info", "fa5s.info-circle", "#22D3EE", "Information"))
        out.append(self._act("delete", "fa5s.trash-alt", "#F87171", "Delete (asks first)"))
        out.append(self._act("more", "fa5s.ellipsis-h", "#A1A1AA", "More: everything of the right-click menu"))
        return out

    def _av_row_do(self, lst, item, key):
        from PyQt5.QtGui import QCursor
        p = item.data(Qt.UserRole) or {}
        vid = p.get("avId")
        if key == "locate":
            self._locate_vehicle_on_map(item)
        elif key == "3d":
            self.follow_in_3d(vid)
        elif key == "route":
            menu = QMenu(self)
            for name in SAVED_PATHS:
                menu.addAction(self._icon("fa5s.road", "#F97316"), name, lambda n=name: self.start_route(vid, n))
            if not SAVED_PATHS:
                menu.addAction("No saved route yet (Routes page: New route ...)").setEnabled(False)
            if vid in self.path_replays:
                menu.addSeparator()
                menu.addAction(self._icon("fa5s.stop", "#F87171"), "Stop driving", lambda: self.stop_path_replay(vid))
            menu.exec_(QCursor.pos())
        elif key == "info":
            self.show_vehicle_info(p)
        elif key == "delete":
            if self._confirm_delete(f"'{self.vehicle_label(vid)}'"):
                self.delete_vehicle(p, lst, item)
        elif key == "more":
            self._row_menu_at_cursor(lst, lambda pos: self.show_av_menu(pos, lst))


    def _obstacle_row_acts(self, lst, row):
        it = lst.item(row)
        p = (it.data(Qt.UserRole) or {}) if it is not None else {}
        oid = p.get("objectId")
        out = []
        if oid and self._object_position("object", oid):
            out.append(self._act("locate", "fa5s.map-marker-alt", "#60A5FA", "Show it on the map"))
        st = self.dynamic_objects.get(oid)
        if p.get("mode") == "dynamic" and st is not None:
            out.append(self._act("move", "fa5s.pause", "#FBBF24", "Stop its movement") if st["timer"].isActive()
                       else self._act("move", "fa5s.play", "#4ADE80", "Resume its movement"))
        out += [self._act("dims", "fa5s.ruler-combined", "#22D3EE", "View / edit its dimensions"),
                self._act("delete", "fa5s.trash-alt", "#F87171", "Delete (asks first)"),
                self._act("more", "fa5s.ellipsis-h", "#A1A1AA", "More: everything of the right-click menu")]
        return out

    def _obstacle_row_do(self, lst, item, key):
        p = item.data(Qt.UserRole) or {}
        oid = p.get("objectId")
        if key == "locate":
            pos = self._object_position("object", oid)
            if pos:
                self.show_in_2d(pos[0], pos[1])
        elif key == "move":
            self.toggle_dynamic_object(oid)
            lst.viewport().update()
        elif key == "dims":
            self.edit_obstacle_dimensions(item)
        elif key == "delete":
            if self._confirm_delete(f"'{item.text()}'"):
                self.delete_unknown_object(p, item)
        elif key == "more":
            self._row_menu_at_cursor(lst, self.show_unknown_menu)

    def _scenario_row_acts(self, lst, row):
        it = lst.item(row)
        name = it.data(Qt.UserRole) if it is not None else None
        s = next((x for x in self.scenarios if x["name"] == name), None)
        out = [self._act("place", "fa5s.play", "#4ADE80", "Place it on the map (the obstacles there are replaced)")]
        if s is not None and not s.get("default"):
            out += [self._act("update", "fa5s.save", "#60A5FA", "Update: overwrite it with the obstacles on the map"),
                    self._act("delete", "fa5s.trash-alt", "#F87171", "Delete the scenario (asks first)")]
        return out

    def _scenario_row_do(self, lst, item, key):
        if key == "place":
            self._on_scenario_clicked(item)
        elif key == "update":
            self.update_selected_scenario()
        elif key == "delete":
            self.delete_selected_scenario()

    def _report_row_acts(self, lst, row):
        it = lst.item(row)
        m = (it.data(Qt.UserRole) or {}) if it is not None else {}
        out = []
        if m.get("kind") == "collision" and m.get("replay"):
            out.append(self._act("replay", "fa5s.play-circle", "#4ADE80",
                                 "Replay this test as it was: the collision-test window (cards, detection details, "
                                 "camera, log), the 2D map and the 3D view -- play / pause, speed, seek, jump to "
                                 "each collision"))
        return out + [self._act("open", "fa5s.external-link-alt", "#22D3EE", "Open the report"),
                      self._act("folder", "fa5s.folder-open", "#FBBF24", "Open its folder"),
                      self._act("delete", "fa5s.trash-alt", "#F87171", "Delete the report (asks first)")]

    def _report_row_do(self, lst, item, key):
        if key == "replay":
            m = item.data(Qt.UserRole) or {}
            if m.get("dir"):
                self.open_collision_replay(m["dir"])
        elif key == "open":
            self._open_report_item(item)
        elif key == "folder":
            self._open_report_folder()
        elif key == "delete":
            self._delete_report()

    def _locate_vehicle_on_map(self, item):
        """Double-click on an AV/trailer in the fleet list: centre the map on
        that vehicle, open its popup and flash a highlight ring around it.

        The live marker position is used when the marker exists (so it is
        correct even if the vehicle was dragged or moved after being added);
        otherwise the saved latitude/longitude in the item payload is used.
        """
        payload = item.data(Qt.UserRole) or {}
        vehicle_id = payload.get("avId")
        if not vehicle_id:
            return

        lat = payload.get("latitude")
        lng = payload.get("longitude")
        # An AV driving a saved route has no saved lat/long (it is not in a
        # slot); its position lives on the replay marker in the map instead.
        has_coords = lat is not None and lng is not None
        if not has_coords:
            lat, lng = 0, 0

        if not self.map_var_name:
            QMessageBox.information(self, "Map not ready",
                                    "The map is still loading. Try again in a moment.")
            return

        vid = json.dumps(vehicle_id)
        m = self.map_var_name
        js = f"""
        (function() {{
            var mk = window.vehicleMarkers && window.vehicleMarkers[{vid}];
            // truck following a saved route: its marker is the replay marker
            if (!mk && window.replayLayers && window.replayLayers[{vid}]) {{
                mk = window.replayLayers[{vid}][1];
            }}
            if (!mk && !{json.dumps(has_coords)}) {{ return false; }}
            var ll = mk ? mk.getLatLng() : L.latLng({lat}, {lng});
            {m}.setView(ll, Math.max({m}.getZoom(), 20));
            if (mk) {{
                mk.openPopup();
                mk.setZIndexOffset(2000);
            }}
            // temporary highlight ring so the vehicle is easy to spot
            if (window._locateRing) {{ {m}.removeLayer(window._locateRing); }}
            window._locateRing = L.circleMarker(ll, {{
                radius: 28, color: '#FBBF24', weight: 4,
                fillColor: '#FBBF24', fillOpacity: 0.15
            }}).addTo({m});
            var ring = window._locateRing;
            setTimeout(function() {{
                if (ring && {m}.hasLayer(ring)) {{ {m}.removeLayer(ring); }}
                if (window._locateRing === ring) {{ window._locateRing = null; }}
            }}, 3000);
            return true;
        }})();
        """

        def _after_locate(found):
            if found is False:
                QMessageBox.information(
                    self, "Not on map",
                    f"{vehicle_id} has not been placed on the map yet.")

        self.browser.page().runJavaScript(js, _after_locate)


    # ---------------- map layer checkboxes ----------------
    def set_layer_visible(self, key, visible):
        self.layer_state[key] = visible
        self._apply_layer(key, visible)

    def _reapply_hidden_layers(self):
        for key, visible in self.layer_state.items():
            if not visible:
                self._apply_layer(key, False)

    def _apply_layer(self, key, visible):
        if not self.map_var_name:
            return
        m = self.map_var_name
        op = "addLayer" if visible else "removeLayer"
        if key == "avs":
            lst = self.av_list
            ids = [(lst.item(i).data(Qt.UserRole) or {}).get("avId") or lst.item(i).text() for i in range(lst.count())]
            js = (
                "(function() {"
                f" var ids = {json.dumps(ids)};"
                " ids.forEach(function(id) {"
                "   var k = (window.vehicleMarkers || {})[id];"
                f"   if (k) {{ {m}.{op}(k); }}"
                " });"
                "})();"
            )
        elif key == "obstacles":
            js = (
                "(function() {"
                " Object.values(window.unknownMarkers || {}).forEach(function(k) {"
                f"   {m}.{op}(k);"
                " });"
                "})();"
            )
        else:
            return
        self.browser.page().runJavaScript(js)

    # ---------------- 2D map  <->  3D yard view ----------------
    def set_map_view(self, mode):
        """'2d' = the Leaflet map, '3d' = the whole site in 3D (assets/web/yard3d.html),
        'split' = both side by side (drag the divider). The 3D view is fed live from
        the map (positions every half second)."""
        self.view_buttons[mode].setChecked(True)
        if mode in ("3d", "split") and self.yard3d_view is None:
            self.yard3d_view = QWebEngineView()
            # the 3D view talks back too (right-click a vehicle / obstacle -> its menu)
            self._channel3d = QWebChannel(self.yard3d_view.page())
            self._channel3d.registerObject("bridge", self.bridge)
            self.yard3d_view.page().setWebChannel(self._channel3d)
            self.yard3d_view.loadFinished.connect(self._on_yard3d_loaded)
            self.yard3d_view.load(QUrl.fromLocalFile(cfg.YARD3D_HTML_FILE))
            self.map_split.addWidget(self.yard3d_view)
        self.browser.setVisible(mode in ("2d", "split"))
        if self.yard3d_view is not None:
            self.yard3d_view.setVisible(mode in ("3d", "split"))
        if mode == "split":
            half = max(1, self.map_split.width() // 2)
            self.map_split.setSizes([half, half])
        if mode == "2d" and not self._camera_panel_open() and not self._y3d_recording():
            self._yard3d_timer.stop()
        elif not self._yard3d_timer.isActive():
            self._yard3d_timer.start(500)
        self.update3d_btn.setVisible(mode != "2d")
        self.view3d_opts_btn.setVisible(mode != "2d")
        if mode != "3d":
            QTimer.singleShot(60, self._refresh_map_size)
        if self.lidar_panel is not None and self.lidar_panel.isVisible():
            self.lidar_panel.raise_()

    # ---------------- floating LiDAR panel ----------------
    def _on_lidar_panel_toggled(self, on):
        if on:
            self.open_lidar_3d_view()
        elif self.lidar_panel is not None:
            self.lidar_panel.hide()

    def _keep_panels_inside(self):
        if self.lidar_panel is not None and self.lidar_panel.isVisible():
            self.lidar_panel.keep_inside()
        if self._camera_panel_open():
            self.camera_panel.keep_inside()

    # ---------------- "Update 3D": surroundings from OpenStreetMap ----------------
    def update_3d_surroundings(self):
        if self._osm_worker is not None:
            return                                           # already downloading
        self.update3d_btn.setEnabled(False)
        self.update3d_btn.setToolTip("Updating 3D ... downloading from OpenStreetMap")
        self._osm_worker = OsmUpdateWorker(self.site_info["bounds"], self)
        self._osm_worker.progress.connect(lambda t: self.update3d_btn.setToolTip(t))
        self._osm_worker.done.connect(self._on_osm_done)
        self._osm_worker.failed.connect(self._on_osm_failed)
        self._osm_worker.finished.connect(self._on_osm_finished)
        self._osm_worker.start()

    def _on_osm_done(self, data):
        osm_surroundings.save(data, cfg.OSM_SURROUNDINGS_FILE)
        self._osm_road_lines = self._road_router = None          # (the new roads: snapping / routing again)
        self._send_surroundings(data)
        print(f"[3D] surroundings updated: {osm_surroundings.summary(data)}")
        QMessageBox.information(
            self, "Update 3D",
            f"Surroundings of {self.site_info['display_name']} updated from OpenStreetMap:\n\n"
            f"{osm_surroundings.summary(data)}\n\nSaved for this yard -- shown in the 3D view from now on.")

    def _on_osm_failed(self, error):
        QMessageBox.warning(
            self, "Update 3D",
            "The surroundings could not be downloaded from OpenStreetMap.\n\n"
            f"{error}\n\nThe servers are sometimes busy -- please try again in a minute."
            + ("\n\nThe previously downloaded surroundings are still shown."
               if os.path.exists(cfg.OSM_SURROUNDINGS_FILE) else ""))

    def _on_osm_finished(self):
        self._osm_worker = None
        self.update3d_btn.setEnabled(True)
        self.update3d_btn.setToolTip("Update 3D -- download the buildings, roads, fences, trees and water around "
                                     "this yard from OpenStreetMap and show them in the 3D view")

    def _fetch_terrain(self, bbox):
        """Hills for this yard's 3D view: downloaded once, added to its saved surroundings (works offline after)."""
        if getattr(self, "_terrain_worker", None) is not None or getattr(self, "_terrain_tried", None) == cfg.ACTIVE_SITE:
            return
        self._terrain_tried = cfg.ACTIVE_SITE
        site, path = cfg.ACTIVE_SITE, cfg.OSM_SURROUNDINGS_FILE

        def done(t):
            data = osm_surroundings.load(path)
            if not data or data.get("terrain") or cfg.ACTIVE_SITE != site:
                return
            data["terrain"] = t
            osm_surroundings.save(data, path)
            print(f"[3D] ground height added: {t.get('min_m')} .. {t.get('max_m')} m")
            self._run_3d(f"window.setTerrain && window.setTerrain({json.dumps(t)});")

        def finished():
            self._terrain_worker = None
        w = self._terrain_worker = TerrainWorker(bbox, self)
        w.done.connect(done); w.finished.connect(finished); w.start()

    def _send_surroundings(self, data):
        if data:
            self._run_3d(f"window.setSurroundings && window.setSurroundings({json.dumps(data)});")

    def _yard3d_layout(self):
        """Everything static for the 3D view: the site's area, the vehicle / obstacle sizes, the AV's sensors."""
        return {
            "center": self.site_info["center"], "bounds": self.site_info["bounds"],
            "operational_area": self.site_info.get("operational_area", []),
            "from_map": True,                                             # (a site made from the map)
            "vehicle_dims": VEHICLE_DIMENSIONS,
            "obstacle_dims": {k: t.get("dimensions", {}) for k, t in OBSTACLE_TYPES.items()},
            "lidar_radius": LIDAR_RADIUS_M,
            "truck_cameras": cfg.SENSOR_CAMERAS,
            "lidar": cfg.SENSOR_LIDAR,
        }

    # ---------------- the 3D view's options ("More" next to Update 3D) ----------------
    VIEW3D_OPTS = [   # (element id in yard3d.html, text, tooltip) -- None: a separator
        ("showLidar", "LiDAR points", "Live roof-LiDAR point cloud of the AVs"),
        ("showPath", "Replay path", "The line path of the replayed truck and trailer"),
        ("showTex", "Textures", "Surface textures: asphalt, ground, paving, facades, brick walls, vehicle paint (this "
                                "view only -- the camera / LiDAR sensors are not affected)"),
        ("showTer", "Terrain", "The real ground height: hills and slopes (this view only -- the simulation, LiDAR and "
                               "cameras stay flat)"),
        None,
        ("optCov", "Sensor coverage", "Where each AV's LiDAR sees the ground (cyan) and where buildings, "
                                      "vehicles, hills or its own blind ring hide it (red)"),
        ("optPlan", "Planned route", "The road ahead of each test AV (~120 m), coloured by its planned speed"),
        ("optReplay", "Replay timeline", "A timeline of the last minutes: scrub back, play, jump to collisions and "
                                         "near misses"),
        ("optMeasure", "Measure distance / height", "Click two points: the distance, height difference and slope"),
        None,
        ("optShadow", "Sun shadows", "Buildings, trees and vehicles cast shadows at the time of day below"),
        ("optPeople", "Parked cars and people", "Decoration only: not LiDAR or camera targets"),
        ("optLod", "Simplify distant buildings", "Far-away buildings without windows and outlines (faster)"),
    ]

    def _build_view3d_menu(self):
        from PyQt5.QtWidgets import QWidgetAction, QSlider
        m = QMenu(self)
        m.setToolTipsVisible(True)
        self._view3d_actions = {}
        for o in self.VIEW3D_OPTS:
            if o is None:
                m.addSeparator()
                continue
            key, text, tip = o
            a = m.addAction(text)
            a.setCheckable(True)
            a.setToolTip(tip)
            a.toggled.connect(lambda on, k=key: self._set_view3d_opt(k, on))
            self._view3d_actions[key] = a
        box = QWidget()                                       # time of day (sun shadows)
        h = QHBoxLayout(box)
        h.setContentsMargins(28, 2, 10, 4)
        h.addWidget(QLabel("Time of day"))
        self._sun_slider = QSlider(Qt.Horizontal)
        self._sun_slider.setRange(24, 74)                     # quarter hours: 06:00 .. 18:30
        self._sun_slider.setFixedWidth(120)
        self._sun_txt = QLabel("10:00")
        h.addWidget(self._sun_slider)
        h.addWidget(self._sun_txt)
        self._sun_slider.valueChanged.connect(self._on_sun_slider)
        wa = QWidgetAction(m)
        wa.setDefaultWidget(box)
        m.insertAction(self._view3d_actions["optPeople"], wa)
        m.aboutToShow.connect(self._sync_view3d_menu)
        return m

    def _on_sun_slider(self, v):
        self._sun_txt.setText(f"{v // 4:02d}:{v % 4 * 15:02d}")
        if not getattr(self, "_view3d_syncing", False):
            self._set_view3d_opt("sunHour", v / 4)

    def _set_view3d_opt(self, key, value):
        if getattr(self, "_view3d_syncing", False) or self.yard3d_view is None:
            return
        self.yard3d_view.page().runJavaScript(
            f"window.setViewOpt && window.setViewOpt({json.dumps(key)}, {json.dumps(value)});")

    def _sync_view3d_menu(self):
        """The menu shows the 3D view's current options (they are kept by the view itself)."""
        if self.yard3d_view is None:
            return

        def got(o):
            if not isinstance(o, dict):
                return
            self._view3d_syncing = True
            try:
                for key, a in self._view3d_actions.items():
                    a.setChecked(bool(o.get(key)))
                self._view3d_actions["showTer"].setVisible(bool(o.get("terrain")))
                self._sun_slider.setValue(int(round(float(o.get("sunHour") or 10) * 4)))
            finally:
                self._view3d_syncing = False
        self.yard3d_view.page().runJavaScript("window.viewOpts ? window.viewOpts() : null;", got)

    def _on_yard3d_loaded(self, ok):
        if ok:                                            # (its options: in the "More" menu above the map)
            self.yard3d_view.page().runJavaScript("window.hostMenu && window.hostMenu(true);")
        self._on_3d_page_loaded(self.yard3d_view, ok)
        self._yard3d_loaded = bool(ok)
        hist = list(getattr(self, "_y3d_hist", None) or [])
        if ok and hist:                                   # (a test recorded before the 3D view was opened: its replay)
            self.yard3d_view.page().runJavaScript(
                f"window.setReplayHistory && window.setReplayHistory({json.dumps(hist)});")
        for js in (getattr(self, "_pending_3d_js", None) or []) if ok else []:   # "Go to 3D view here", follow
            self.yard3d_view.page().runJavaScript(js)
        self._pending_3d_js = []

    def _on_3d_page_loaded(self, view, ok):
        """A 3D page (the yard view or the Camera View panel) has loaded: give it the yard."""
        if not ok or view is None:
            print("[3D] page failed to load")
            return
        page = view.page()
        page.runJavaScript(f"window.setLayout && window.setLayout({json.dumps(self._yard3d_layout())});")
        # surroundings downloaded earlier with "Update 3D" (kept per yard, works offline)
        data = osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE)
        if data:
            page.runJavaScript(f"window.setSurroundings && window.setSurroundings({json.dumps(data)});")
            if view is self.yard3d_view and not data.get("terrain") and data.get("bbox"):
                self._fetch_terrain(data["bbox"])               # (downloaded before ground height existed)
        page.runJavaScript(f"window.setClimate && window.setClimate({json.dumps(self.climate)});")
        if getattr(self, "satellite", False) and self._imagery:
            self._push_real_world(view)
        if view is self.yard3d_view:
            page.runJavaScript(f"window.setCameraOverlay && window.setCameraOverlay({json.dumps(self._camera_panel_open())});")
        self._push_yard3d()

    # ---------------- obstacle detection from the LiDAR data ----------------
    def _lidar_avs_active(self):
        """A moving AV (a route, a collision test)?"""
        if getattr(self, "follow_tests", None):
            return True
        if any(st.get("autonomous") and st["timer"].isActive() for st in self.dynamic_objects.values()):
            return True                                   # (autonomous cars / vans / buses: their own LiDAR)
        if any(self._is_auto_drive(v) for v in list(self.path_replays.keys())):
            return True
        return time.time() - getattr(self, "_live_seen_t", 0) < 5.0

    def _ensure_sensor_view(self):
        if self.sensor_view is None:
            self.sensor_view = QWebEngineView()               # never shown: it only computes
            self.sensor_view.loadFinished.connect(self._on_sensor_loaded)
            url = QUrl.fromLocalFile(cfg.YARD3D_HTML_FILE)
            url.setQuery("mode=sensor")
            self.sensor_view.load(url)

    def _on_sensor_loaded(self, ok):
        self._sensor_ready = bool(ok)
        self._on_3d_page_loaded(self.sensor_view, ok)
        print("[LiDAR] obstacle detection from the simulated LiDAR data " + ("started" if ok else "failed to load"))

    def _lidar_detect_tick(self):
        if not self._lidar_avs_active():
            if self._lidar_dets:                              # nothing moving any more: clear the map display
                self._lidar_dets = {}
                if self.map_var_name:
                    self.browser.page().runJavaScript("window.setLidarDetections && window.setLidarDetections({trucks: {}});")
            return
        self._ensure_sensor_view()
        if not self._sensor_ready or self._lidar_detect_busy:
            return
        if not self._yard3d_timer.isActive():
            self._push_yard3d()                               # positions for the sensor page
        opt = {"exclude": {}}
        if getattr(self, "follow_tests", None):           # follow test: the leader is detected further away
            opt["report_range_m"] = FOLLOW_REPORT_RANGE_M
        real_ids = [str(m) for ct in (getattr(self, "collision_tests", None) or {}).values() if ct.get("real")
                    for m in ct["members"]]
        if real_ids:                                      # real-world sensors: the raw point clouds too
            opt.update(cloud=True, cloud_ids=real_ids, cloud_range_m=60)
        self._lidar_detect_busy = True
        self.sensor_view.page().runJavaScript(
            f"window.lidarDetect ? window.lidarDetect({json.dumps(opt)}) : null", self._on_lidar_detect)

    def _on_lidar_detect(self, res):
        self._lidar_detect_busy = False
        if getattr(self, "_closing", False):
            return
        if not isinstance(res, dict):
            return
        self._lidar_dets = res.get("trucks") or {}
        self._lidar_dets_t = time.time()                  # (the follow test uses fresh detections only)
        clouds = getattr(self, "_lidar_clouds", None)
        if clouds is None:
            clouds = self._lidar_clouds = {}
        for tid, e in self._lidar_dets.items():           # (real-world sensors: kept here, not sent to the map)
            if isinstance(e, dict) and "cloud" in e:
                clouds[str(tid)] = (self._lidar_dets_t, e.pop("pos", None), e.pop("cloud"))
        d = cfg.LIDAR.get("detection") or {}
        payload = {"trucks": self._lidar_dets, "mapRange": float(d.get("map_range_m", 8.0)),
                   "alertRange": float(d.get("alert_range_m", 3.0))}
        if self.map_var_name:
            self.browser.page().runJavaScript(f"window.setLidarDetections && window.setLidarDetections({json.dumps(payload)});")

    def _lidar_detection_rows(self, truck_id):
        """Rows for a details panel: what this AV's LiDAR detects (nearest first)."""
        if not self._lidar_dets or str(truck_id) not in self._lidar_dets:
            return []
        dets = self.lidar_detections(truck_id)
        rows = [["LiDAR detections", f"{len(dets)} object(s) within "
                 f"{(cfg.LIDAR.get('detection') or {}).get('report_range_m', 20):g} m"]]
        for d in dets[:4]:
            rows.append([f"  {d.get('label') or d['id']}", f"{d['gap']:.1f} m  ·  {d['points']} pts"])
        return rows

    def lidar_detections(self, truck_id):
        """The latest LiDAR detections of one AV (id, label, points, gap, range, x, y ...)."""
        return (self._lidar_dets.get(str(truck_id)) or {}).get("dets", [])

    # every 3D page: the yard view, the Camera View panel and the hidden LiDAR sensor page
    def _3d_views(self, visible_only=False):
        out = []
        if getattr(self, "sensor_view", None) is not None and getattr(self, "_sensor_ready", False):
            out.append(self.sensor_view)
        if self.yard3d_view is not None and (not visible_only or self.yard3d_view.isVisible()):
            out.append(self.yard3d_view)
        if getattr(self, "camera_view", None) is not None and (not visible_only or self._camera_feed_live()):
            out.append(self.camera_view)
        return out

    def _camera_feed_live(self):
        """The camera page needs live positions while its panel is shown or a collision test uses it."""
        return (self._camera_panel_open()
                or getattr(self, "_ctest_cam_live", False)        # (collision test: front camera)
                or time.time() < getattr(self, "_ctest_shot_until", 0.0))   # (a collision's camera image)

    def _run_3d(self, js, visible_only=False):
        for v in self._3d_views(visible_only):
            v.page().runJavaScript(js)

    # ---------------- Camera View: the AV's perception cameras ----------------
    def _camera_panel_open(self):
        return getattr(self, "camera_panel", None) is not None and self.camera_panel.isVisible()

    def _on_camera_panel_toggled(self, on):
        if on:
            self.open_camera_view()
        elif getattr(self, "camera_panel", None) is not None:
            self.camera_panel.hide()
        self._after_camera_panel_change()

    def open_camera_view(self, show=True):
        """'Camera View' check-box: both cameras of an AV (config/truck_cameras.json)
        rendered from the 3D yard, in a panel inside the map area (like the LiDAR view).
        show=False: the page only (a collision test renders its camera images from it hidden)."""
        if getattr(self, "camera_view", None) is None:
            self.camera_view = QWebEngineView()
            self.camera_view.loadFinished.connect(lambda ok: self._on_3d_page_loaded(self.camera_view, ok))
            url = QUrl.fromLocalFile(cfg.YARD3D_HTML_FILE)
            url.setQuery("mode=cameras")
            self.camera_view.load(url)
            self.camera_panel = FloatingPanel("Truck cameras", self.camera_view,
                                              self._icon("fa5s.video", "#FBBF24"), self.map_host)
            self.camera_panel.closed.connect(lambda: self.camera_panel_cb.setChecked(False))
            # both views side by side: wide (127 x 79.5 deg) + standard (66 x 54 deg) ~ 3.7 : 1
            w = max(520, min(940, int(self.map_host.width() * 0.68)))
            self.camera_panel.place_in_corner("top-right", size=(w, int(w / 3.7) + 80))
        if not show:
            self._after_camera_panel_change()
            return
        if not self.camera_panel.isVisible():
            self.camera_panel.show()
            self.camera_panel.keep_inside()
        self.camera_panel.raise_()
        if not self.camera_panel_cb.isChecked():
            self.camera_panel_cb.blockSignals(True)
            self.camera_panel_cb.setChecked(True)
            self.camera_panel_cb.blockSignals(False)
        self._after_camera_panel_change()

    def _after_camera_panel_change(self):
        """Positions go to the 3D pages while one is shown; FoV outlines in the yard view."""
        on = self._camera_panel_open()
        if self.yard3d_view is not None:
            self.yard3d_view.page().runJavaScript(f"window.setCameraOverlay && window.setCameraOverlay({json.dumps(on)});")
        if self._camera_feed_live() or (self.yard3d_view is not None and self.yard3d_view.isVisible()) or \
                self._y3d_recording():
            if not self._yard3d_timer.isActive():
                self._yard3d_timer.start(500)
            self._push_yard3d()
        else:
            self._yard3d_timer.stop()


    # ---------------- satellite ground in the 3D view (real_world.py) ----------------
    def _on_satellite_toggled(self, on):
        self.satellite = bool(on)
        if not on:
            self._push_real_world()
            return
        if self.yard3d_view is None or not self.yard3d_view.isVisible():
            self.set_map_view("3d")                     # it is a 3D view
        import real_world
        self._imagery = self._imagery or real_world.load_index()
        if self._imagery:
            self._push_real_world()
        else:
            self._download_imagery()

    def _download_imagery(self):
        import real_world
        if self._imagery_dl is not None:
            return
        self._imagery_dl = real_world.Download(self.site_info["bounds"])
        self._imagery_prog = QProgressDialog("Downloading the satellite imagery of the yard ...", "Cancel", 0, 100, self)
        self._imagery_prog.setWindowTitle("Real world")
        self._imagery_prog.setMinimumDuration(0)
        self._imagery_prog.canceled.connect(self._imagery_dl.cancel)
        self._imagery_timer = QTimer(self)
        self._imagery_timer.timeout.connect(self._poll_imagery)
        self._imagery_timer.start(200)

    def _poll_imagery(self):
        dl = self._imagery_dl
        done, total = dl.progress
        if not dl.done:
            self._imagery_prog.setMaximum(max(1, total))
            self._imagery_prog.setValue(done)
            self._imagery_prog.setLabelText(f"Downloading the satellite imagery of the yard ... {done} / {total} tiles")
            return
        self._imagery_timer.stop()
        self._imagery_prog.close()
        self._imagery_dl = None
        import real_world
        if dl.error:
            if dl.error != "cancelled":
                QMessageBox.warning(self, "Real world", f"The satellite imagery could not be downloaded:\n\n{dl.error}")
            if not self._imagery:
                self.satellite = False
            return
        self._imagery = real_world.load_index()
        print(f"[real world] imagery: {len(self._imagery['chunks']) if self._imagery else 0} chunk(s) "
              f"in {real_world.imagery_dir()}")
        self._push_real_world()

    def _push_real_world(self, view=None):
        """The Real world state to the 3D yard view and the AV camera page."""
        payload = self._imagery if self.satellite else None
        js = f"window.setRealWorld && window.setRealWorld({json.dumps(self.satellite)}, {json.dumps(payload)});"
        for v in ([view] if view is not None else [self.yard3d_view, getattr(self, "camera_view", None)]):
            if v is not None and v is not getattr(self, "sensor_view", None):
                v.page().runJavaScript(js)

    # ---------------- Climate: weather / light for the 3D yard, cameras and LiDAR ----------------
    def _on_climate_changed(self, index):
        if 0 <= index < len(cfg.CLIMATES):
            self.set_climate(cfg.CLIMATES[index]["id"])

    def set_climate(self, climate_id):
        c = next((c for c in cfg.CLIMATES if c["id"] == climate_id), None)
        if c is None:
            return
        self.climate = c
        i = self.climate_combo.findData(climate_id)
        if i >= 0 and i != self.climate_combo.currentIndex():
            self.climate_combo.blockSignals(True)
            self.climate_combo.setCurrentIndex(i)
            self.climate_combo.blockSignals(False)
        self._run_3d(f"window.setClimate && window.setClimate({json.dumps(c)});")
        self._update_climate_tooltip()
        print(f"[3D] climate: {c.get('label', climate_id)}")

    def _update_climate_tooltip(self):
        c = self.climate
        lid = c.get("lidar") or {}
        lines = [f"Climate: {c.get('label', c['id'])}", c.get("description", ""),
                 f"Camera visibility ~{c.get('visibility_m', 0):,.0f} m"]
        if lid.get("extinction_per_m") or lid.get("clutter"):
            lines.append(f"LiDAR: extinction {lid.get('extinction_per_m', 0):g}/m, "
                         f"+{lid.get('noise_m', 0) * 100:g} cm noise, "
                         f"{lid.get('clutter', 0) * 100:g}% false returns within {lid.get('clutter_max_m', 0):g} m")
        else:
            lines.append("LiDAR: unaffected")
        lines.append("Applies to the 3D view, the AV cameras, the LiDAR point cloud and the collision tests "
                     "(presets in config/climates.json)")
        self.climate_combo.setToolTip("\n".join(l for l in lines if l))

    def _push_yard3d(self):
        """Live positions for the 3D view, collected from the map's markers."""
        if (not self._3d_views(visible_only=True) and not self._y3d_recording()) or not self.map_var_name:
            return
        self.browser.page().runJavaScript(self._objects_js(), self._send_yard3d_dynamic)

    def _y3d_recording(self):
        """A collision test is recorded for a replay ("Save this test for replay?" Yes)."""
        return any(ct.get("replay") is not None for ct in (getattr(self, "collision_tests", None) or {}).values())

    def _objects_js(self):
        """JS that returns every AV / trailer / obstacle / route marker of the map (JSON)."""
        return """
        (function() {
            var out = [], geom = window.vehicleGeom || {};
            function add(id, mk, cat, kind, hd, label) {
                if (!mk || !mk.getLatLng || !mk._map) return;          // hidden layers stay hidden
                var q = mk.getLatLng();
                out.push({ id: id, cat: cat, kind: kind || null, lat: q.lat, lng: q.lng, h: hd || 0,
                           label: label || id });
            }
            Object.keys(window.vehicleMarkers || {}).forEach(function(k) {
                var g = geom[k] || {}, mk = window.vehicleMarkers[k], tractor = (g.kind || '').indexOf('tractor') === 0;
                add(k, mk, tractor ? 'truck' : 'trailer',
                    g.kind || 'trailer_normal', g.heading, LABELS[k] || k);
            });
            Object.keys(window.unknownMarkers || {}).forEach(function(k) {
                var mk = window.unknownMarkers[k];
                add(k, mk, 'object', null, mk._heading, (mk.options && mk.options.title) || k);
            });
            Object.keys(window.replayLayers || {}).forEach(function(k) {
                var mk = window.replayLayers[k][1];
                add(k, mk, 'route', mk._fpKind || 'tractor', mk._fpHeading != null ? mk._fpHeading : (mk._rotation || 0) + 90, LABELS[k] || k);
            });
            if (window.truckMarker) add('live', window.truckMarker, 'route', 'tractor', window.truckFpHeading, 'Live truck');
            return JSON.stringify(out);
        })();
        """.replace("var out = [],", f"var LABELS = {json.dumps(self._vehicle_labels())}, out = [],")

    def _send_yard3d_dynamic(self, objects_json):
        if getattr(self, "_closing", False) or (not self._3d_views(visible_only=True) and not self._y3d_recording()):
            return
        try:
            objects = self._enrich_objects(json.loads(objects_json) if objects_json else [])
        except (TypeError, ValueError):
            return
        payload = {
            "objects": objects,
            "layers": dict(self.layer_state),
            "t": round(time.time(), 2),
        }
        try:
            payload["plans"] = self._y3d_plans()
            payload["tstat"] = self._y3d_test_status()
        except Exception:
            sys.excepthook(*sys.exc_info())
        ev = getattr(self, "_y3d_events", None)
        if ev:
            payload["events"], self._y3d_events = ev, []
        for ct in (getattr(self, "collision_tests", None) or {}).values():   # (a test saved for replay: recorded)
            if ct.get("replay") is not None:
                try:                                      # (+ the climate of that moment: the replay shows it)
                    ct["replay"].add_positions(dict(payload, climate=(self.climate or {}).get("id")))
                except Exception:
                    sys.excepthook(*sys.exc_info())
        js = f"window.updateDynamic && window.updateDynamic({json.dumps(payload)});"
        views = self._3d_views(visible_only=True)
        # the 3D view's replay timeline: kept while it is shown or a test drives (also when the 2D map is shown)
        testing = bool(getattr(self, "follow_tests", None))
        if testing or (self.yard3d_view is not None and self.yard3d_view in views):
            hist = getattr(self, "_y3d_hist", None)
            if hist is None:
                hist = self._y3d_hist = deque(maxlen=Y3D_HISTORY_FRAMES)
            hist.append(payload)
            if testing and self.yard3d_view is not None and self.yard3d_view not in views and \
                    getattr(self, "_yard3d_loaded", False):
                views.append(self.yard3d_view)                # (hidden: it only records)
        for v in views:
            v.page().runJavaScript(js)

    def _y3d_event(self, kind, text, lat, lng, t=None, lines=None):
        """A collision / near miss / collision prevented by V2V ('v2v_save') for the 3D view's replay timeline (sent
        with the next positions). t: when it happened (default now); lines: shown under its beacon in 3D."""
        ev = getattr(self, "_y3d_events", None)
        if ev is None:
            ev = self._y3d_events = []
        e = {"kind": kind, "text": str(text), "lat": float(lat), "lng": float(lng),
             "t": round(time.time() if t is None else float(t), 2)}
        if lines:
            e["lines"] = [str(x) for x in lines]
        ev.append(e)
        del ev[:-50]

    def _y3d_near_miss(self, fid, ft, ctl, me):
        """A near miss: the true time to collision fell below the critical TTC (once until it is clear again).
        Shown in the 3D view only when 'Show near misses in 3D' is ticked in the collision-test setup."""
        if not getattr(self, "_ct_near_miss", False):
            return
        ttc =ctl.ttc_true if getattr(ctl, "ttc_true", None) is not None else ctl.ttc
        if ttc is not None and ttc < follow_test.TTC_CRIT_S:
            if not ft.get("y3d_nm"):
                ft["y3d_nm"] = True
                self._y3d_event("near_miss", f"Near miss: {self.vehicle_label(fid)} -- TTC {ttc:.1f} s", me[0], me[1])
        elif ttc is None or ttc > follow_test.TTC_WARN_S:
            ft["y3d_nm"] = False

    def _y3d_test_status(self):
        """Each test AV now: name, speed, what it is doing, TTC (the 3D view's test panel, live and in replays)."""
        out = {}
        for fid, ft in list((getattr(self, "follow_tests", None) or {}).items()):
            ctl = ft.get("ctl")
            if ctl is None:
                continue
            ttc = ctl.ttc_true if getattr(ctl, "ttc_true", None) is not None else ctl.ttc
            out[str(fid)] = {"name": str(self.vehicle_label(fid)), "kmh": round(ctl.v * 3.6, 1),
                             "state": str(ctl.state or ""), "ttc": None if ttc is None else round(ttc, 1),
                             "n": int((getattr(ctl, "stats", None) or {}).get("collisions", 0) or 0)}
        return out

    def _ctest_save_replay(self, ct, how):
        """"Save this test for replay?" Yes: the recording -> <the test's report folder>/replay.json.gz (Reports ->
        Collision tests -> Replay). Needs the report folder (a test saved for replay is always kept in Reports)."""
        import collision_replay
        rec, d = ct.get("replay"), ct.get("report_dir")
        if rec is None or not d or not rec.usable():
            return None
        R = ct["route"]
        trucks = [(m, f"AV {k + 1}" + (" · front" if k == 0 else ""), str(self.vehicle_label(m)))
                  for k, m in enumerate(ct["members"])]
        meta = {"route": R.get("name"), "started": ct.get("started"), "ended_by": how, "trucks": trucks,
                "climates": list(ct.get("climates") or []), "real": bool(ct.get("real")),
                "climate0": ct.get("climate0"),
                "cams": [c.get("label") or c.get("id") or "camera" for c in self._ctest_cams(configs=True)]}
        line = [[round(p[0], 7), round(p[1], 7)] for p in R.get("trail") or []]
        dims = {k: [v["length"], v["width"]] for k, v in VEHICLE_DIMENSIONS.items()
                if isinstance(v, dict) and v.get("length") and v.get("width")}
        path = rec.save(os.path.join(d, collision_replay.REPLAY_FILE), meta, list(ct.get("log") or []), line, dims)
        mb = os.path.getsize(path) / 1e6
        print(f"[collision test] replay saved: {path} ({mb:.1f} MB)")
        if how != "app closed":
            try:
                self.status_message("Replay saved with the results -- Reports -> Collision tests -> Replay", 8000)
            except Exception:
                pass
        return path

    def open_collision_replay(self, report_dir):
        """Reports -> a collision test -> Replay: the test played back as it was recorded (the collision-test window
        with its cards, detection details, camera images and log; the vehicles on the 2D map and in the 3D view)."""
        import collision_replay
        import auth
        if not auth.collision_allowed():
            return
        try:
            with open(os.path.join(report_dir, "report.json"), encoding="utf-8") as f:
                rep = json.load(f)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Replay", f"Could not open the report:\n{type(e).__name__}: {e}")
            return
        rep["dir"] = report_dir
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            rec = collision_replay.load(os.path.join(report_dir, collision_replay.REPLAY_FILE))
        except Exception as e:
            QMessageBox.warning(self, "Replay", f"Could not read the replay:\n{type(e).__name__}: {e}")
            return
        finally:
            QApplication.restoreOverrideCursor()
        old = getattr(self, "_replay_player", None)
        if old is not None:
            old.close()
        try:
            self._replay_player = collision_replay.ReplayPlayer(self, rec, rep)
        except Exception as e:
            sys.excepthook(*sys.exc_info())
            QMessageBox.warning(self, "Replay", f"Could not play the replay:\n{type(e).__name__}: {e}")

    def _y3d_plans(self):
        """The road ahead of each test AV (~120 m) with the speed it plans there (km/h): the 3D view's route
        preview. Speed: speeding up to its top speed, braking comfortably for what it follows / stops for."""
        out = {}
        now = time.time()
        for fid, ft in list((getattr(self, "follow_tests", None) or {}).items()):
            ctl = ft.get("ctl")
            if ctl is None:
                continue
            R = ft.get("route")
            if R is not None:
                s0, total = ft["s"], R["total"]
                ahead = 120.0 if R["loop"] else max(0.0, min(120.0, R["end"] - s0))
                pose = lambda s: self._route_pose(R, s % total if R["loop"] else s)
            else:
                trail, s0 = ft.get("trail") or [], ft["s"]
                if len(trail) < 2:
                    continue
                ahead = max(0.0, min(120.0, trail[-1][3] - s0))
                pose = lambda s, tr=trail: self._trail_pose(tr, s)
            if ahead < 2.0:
                continue
            t = now - ft["t0"]
            tg = ctl.target if ctl.target and t - ctl.target["t"] <= follow_test.HOLD_S else None
            stop_at, v_lead = None, 0.0
            if tg is not None:
                v_lead = float(tg.get("v_lead", 0.0) or 0.0)
                stop_at = float(tg["gap"]) - max(follow_test.STOP_GAP_M, ctl.gap_set if v_lead > 0.5 else 0.0)
            held = now < ft.get("hold_until", 0.0) or ft.get("finished")
            pts, d = [], 0.0
            while True:
                if held:
                    v = 0.0
                else:
                    v = min(ctl.v_max, math.sqrt(ctl.v * ctl.v + 2.0 * follow_test.ACCEL * d))
                    if stop_at is not None:
                        v = min(v, max(v_lead, math.sqrt(max(0.0, 2.0 * follow_test.A_COMFORT * (stop_at - d)))))
                lat, lng, _h = pose(s0 + d)
                pts.append([round(lat, 7), round(lng, 7), round(v * 3.6, 1)])
                if d >= ahead:
                    break
                d = min(ahead, d + 4.0)
            out[str(fid)] = pts
        return out

    def _enrich_objects(self, objects):
        """Obstacle types + sizes / which vehicles carry a LiDAR."""
        for o in objects:                         # obstacles: their type + own dimensions
            if o["cat"] == "route":               # LiDAR dome only on the AVs
                o["lidar"] = o["id"] == "live" or self._is_auto_drive(o["id"])
            elif o["cat"] == "truck":             # a parked AV: its LiDAR scans too
                o["lidar"] = o.get("kind") == "tractor"
            if o["cat"] != "object":
                continue
            _item, payload = self.find_unknown_item_by_id(o["id"])
            if payload:
                o["type"] = payload.get("type")
                # an autonomous car / van / bus / truck + trailer: its own roof LiDAR + front cameras
                o["lidar"] = bool(payload.get("autonomous")) and payload.get("type") != "pedestrian"
                d = self._obstacle_default_dims(payload.get("type"))          # (from this payload: one lookup)
                d.update({k: v for k, v in (payload.get("dimensions") or {}).items() if k in d})
                if d.get("length") and d.get("width") and d.get("height"):
                    o["size"] = {"l": d["length"], "w": d["width"], "h": d["height"],
                                 "gc": d.get("ground_clearance", 0.0), "wb": d.get("wheelbase")}
        return objects

    # ---------------- map overlays ----------------
    def _position_map_overlays(self):
        if not hasattr(self, "maximize_map_btn"):
            return
        self.collapse_map_btn.move(14, 14)
        self.maximize_map_btn.move(58, 14)


    def _icon_for_vehicle_type(self, vehicle_type):
        if vehicle_type == "truck":
            return AV_ICON_PATH
        return UNKNOWN_OBJECT_ICONS.get(vehicle_type, CAR_ICON_PATH)


    def _style_av_item(self, item, autonomous=True):
        """Colour dot + tooltip of an AV in the list."""
        item.setIcon(self._icon("fa5s.circle", AV_COLOR))
        payload = item.data(Qt.UserRole) or {}
        item.setToolTip(f"{payload.get('name') or payload.get('avId')}\nAutonomous vehicle (AV)\n"
                        f"ID: {payload.get('number', '')}\nTopic: {payload.get('avId')}")


    @staticmethod
    def _vehicle_kind(vehicle_type, payload=None):
        """Key into VEHICLE_DIMENSIONS for an AV (its body: the tractor)."""
        return "tractor"


    def _vehicle_popup_html(self, vehicle_id, vehicle_type=None, location_id=None, location_type=None):
        """Popup shown when an AV marker is clicked: its name (ID) in bold."""
        shown = self.vehicle_label(vehicle_id)
        return f"<b>AV: {shown}</b>" + (f"<br><small>{vehicle_id}</small>" if shown != str(vehicle_id) else "")


    def _random_point_in_polygon(self, polygon, max_attempts=50):
        """Uniform-ish random point inside a polygon via bounding-box
        rejection sampling against point_in_polygon."""
        lats = [p[0] for p in polygon]
        lons = [p[1] for p in polygon]
        lat_min, lat_max = min(lats), max(lats)
        lon_min, lon_max = min(lons), max(lons)

        for _ in range(max_attempts):
            lat = random.uniform(lat_min, lat_max)
            lon = random.uniform(lon_min, lon_max)
            if point_in_polygon(lat, lon, polygon):
                return {"lat": lat, "lon": lon}

        # fallback: polygon centroid, always safely inside
        return {
            "lat": sum(lats) / len(lats),
            "lon": sum(lons) / len(lons),
        }

    def _generate_random_open_point(self):
        """Pick a random open-corridor polygon, then a random point inside
        it. Guaranteed to avoid parking/docking since these polygons are
        defined as the drivable areas, not derived by exclusion."""
        for _ in range(30):
            zone = random.choice(self.dynamic_zones)
            point = self._random_point_in_polygon(zone)
            return point
        return point

    def _generate_random_path(self, num_points=5):
        return [self._generate_random_open_point() for _ in range(num_points)]


    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F11:
            if self.isFullScreen():
                self.showMaximized()
            else:
                self.showFullScreen()
        elif event.key() == Qt.Key_Escape and self.isFullScreen():
            self.showMaximized()
        else:
            super().keyPressEvent(event)

    def closeEvent(self, event):
        # closing: no new calls into the 3D / map pages (their answers arriving into deleted windows crashed the
        # app on exit -- Windows: sip.pyd access violation); the periodic callbacks return at once from now on
        self._closing = True
        for t in self.findChildren(QTimer):
            try:
                t.stop()
            except RuntimeError:
                pass
        for cid in list(getattr(self, "collision_tests", None) or {}):
            try:
                self.end_collision_test(cid, quiet=True, keep_avs=False)
            except Exception:
                sys.excepthook(*sys.exc_info())
        if self.lidar_view is not None:
            self.lidar_view.close()
        super().closeEvent(event)


    def _build_icon_tile(self, vehicle_type, image_path, caption, category="fleet"):
        tile = QFrame()
        tile.setObjectName("iconTile")
        tile.setFixedSize(ICON_TILE_SIZE, ICON_TILE_SIZE)

        tile_layout = QVBoxLayout(tile)
        tile_layout.setContentsMargins(0, 0, 0, 0)

        icon_label = DraggableIconLabel(vehicle_type, image_path, parent=tile, category=category)
        tile_layout.addWidget(icon_label, alignment=Qt.AlignCenter)

        if category == "fleet":
            if vehicle_type == "truck":
                self.truck_icon = icon_label
            else:
                self.trailer_icon = icon_label
        else:
            if not hasattr(self, "unknown_icons"):
                self.unknown_icons = {}
            self.unknown_icons[vehicle_type] = icon_label

        caption_label = QLabel(caption, alignment=Qt.AlignHCenter)
        caption_label.setProperty("role", "tileCaption")

        column = QVBoxLayout()
        column.setSpacing(4)
        column.addWidget(tile, alignment=Qt.AlignHCenter)
        column.addWidget(caption_label)
        return column


    def on_map_loaded(self, ok):
        if not ok:
            print("Map page FAILED to load (loadFinished(False)) — "
                  "check for a QtWebEngine/sandbox or file-path issue.")
            return

        print("Map page loaded successfully (loadFinished(True)).")

        QTimer.singleShot(200, self.enable_child_drag_support)

        webchannel_js = """
        (function() {
            var script = document.createElement('script');
            script.src = 'qrc:///qtwebchannel/qwebchannel.js';
            script.onload = function() {
                new QWebChannel(qt.webChannelTransport, function(channel) {
                    window.bridge = channel.objects.bridge;
                });
            };
            document.head.appendChild(script);
        })();
        """
        self.browser.page().runJavaScript(webchannel_js)

        limits = self.site_info["bounds"]
        if self.map_yard:                     # a yard chosen on the map: its whole surroundings (AVs drive there)
            (s_, w_), (n_, e_) = (osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE) or {}).get("bbox") or limits
            pad_lat, pad_lng = (n_ - s_) * 0.35, (e_ - w_) * 0.35        # (roads run on past the download area)
            limits = [[s_ - pad_lat, w_ - pad_lng], [n_ + pad_lat, e_ + pad_lng]]
        js = f"""
        var bounds = L.latLngBounds({json.dumps(limits[0])},
                                    {json.dumps(limits[1])});

        {self.map_var_name}.setMaxBounds(bounds);
        {self.map_var_name}.options.maxBoundsViscosity = 1.0;

        if (!window.zoomControlAdded) {{
            L.control.zoom({{position: 'bottomleft'}}).addTo({self.map_var_name});
            window.zoomControlAdded = true;
        }}
        if (!window.mapMenuAdded) {{                 // right-click: Go to 3D view here, place a truck ...
            {self.map_var_name}.on('contextmenu', function(e) {{
                if (window.bridge && window.bridge.mapMenu) window.bridge.mapMenu(e.latlng.lat, e.latlng.lng);
            }});
            window.mapMenuAdded = true;
        }}
        """
        self.browser.page().runJavaScript(js)

        path_draw_js = f"""
        window.startPathDrawing = function(startLat, startLon) {{
            window.stopPathDrawing();

            window.currentPathPoints = [[startLat, startLon]];
            window.drawLayer = L.layerGroup().addTo({self.map_var_name});

            L.circleMarker([startLat, startLon], {{
                radius: 5, color: '#9b59b6', fillColor: '#9b59b6', fillOpacity: 1
            }}).addTo(window.drawLayer);

            window.pathDrawClickHandler = function(e) {{
                window.currentPathPoints.push([e.latlng.lat, e.latlng.lng]);

                L.circleMarker(e.latlng, {{
                    radius: 5, color: '#9b59b6', fillColor: '#9b59b6', fillOpacity: 1
                }}).addTo(window.drawLayer);

                if (window.drawPolyline) {{
                    window.drawLayer.removeLayer(window.drawPolyline);
                }}
                window.drawPolyline = L.polyline(window.currentPathPoints, {{
                    color: '#9b59b6', weight: 3, dashArray: '6,6'
                }}).addTo(window.drawLayer);
            }};

            {self.map_var_name}.on('click', window.pathDrawClickHandler);
        }};

        window.stopPathDrawing = function() {{
            if (window.pathDrawClickHandler) {{
                {self.map_var_name}.off('click', window.pathDrawClickHandler);
                window.pathDrawClickHandler = null;
            }}
            if (window.drawLayer) {{
                {self.map_var_name}.removeLayer(window.drawLayer);
                window.drawLayer = null;
                window.drawPolyline = null;
            }}
        }};
        """
        self.browser.page().runJavaScript(path_draw_js)

        js = f"""
        {self.map_var_name}.on('click', function(e) {{
            // A click on a truck / trailer / object marker must show that marker's
            // own popup (its name), not the generic Lat/Lng popup.
            var t = e.originalEvent && e.originalEvent.target;
            if (t && t.closest && t.closest('.leaflet-marker-icon')) {{ return; }}
            L.popup()
            .setLatLng(e.latlng)
            .setContent(
                "Lat: " + e.latlng.lat +
                "<br>Lng: " + e.latlng.lng
            )
            .openOn({self.map_var_name});
        }});
        """
        self.browser.page().runJavaScript(js)

        lidar_js = (LIDAR_JS_TEMPLATE
                    .replace("__MAP__", self.map_var_name)
                    .replace("__R__", str(LIDAR_RADIUS_M))
                                .replace("__MINPX__", str(LIDAR_MIN_PX))
                    .replace("__CSS__", json.dumps(LIDAR_CSS))
                    .replace("__DEFS__", json.dumps(LIDAR_DEFS_SVG))
                    .replace("__HTML__", json.dumps(LIDAR_HTML)))

        footprint_js = (VEHICLE_FOOTPRINT_JS
                        .replace("__MAP__", self.map_var_name)
                        .replace("__SPECS__", json.dumps(VEHICLE_DIMENSIONS)))

        icon_scaling_js = f"""
        window.vehicleSlotPolygons = window.vehicleSlotPolygons || {{}};
        window.vehicleIconUrls = window.vehicleIconUrls || {{}};

        {footprint_js}

        {lidar_js}

        // ---- zoom-proportional scale: car / outer truck / pedestrian / live truck ----
        window.iconScale = function() {{
            var z = {self.map_var_name}.getZoom();
            return Math.max({ICON_MIN_SCALE}, Math.min(1, Math.pow(2, z - {ICON_REF_ZOOM})));
        }};

        window.applyUnknownIconScale = function(m) {{
            var base = m._baseSize || 40;
            var size = Math.round(base * window.iconScale());
            m.setIcon(L.divIcon({{
                html: '<div style="transform:rotate(' + (m._heading || 0) + 'deg);">' +
                      '<img src="' + m._iconUrl + '" width="' + size + '" height="' + size + '">' +
                      '</div>',
                className: "",
                iconSize: [size, size], iconAnchor: [size / 2, size / 2]
            }}));
        }};

        window.refreshObjectIconScales = function() {{
            Object.values(window.unknownMarkers || {{}}).forEach(window.applyUnknownIconScale);
            Object.values(window.replayLayers || {{}}).forEach(function(layers) {{
                var rm = layers[1];
                if (rm && rm._fpHeading != null) {{                // real-size route truck
                    rm.setIcon(window.footprintIcon(rm._fpKind || 'tractor', rm._fpHeading, rm.getLatLng().lat, rm._fpLabel));
                    return;
                }}
                var rel = rm && rm.getElement();
                var rin = rel && rel.querySelector('div');
                if (rin) {{
                    rin.style.transform = 'rotate(' + (rm._rotation || 0) +
                                          'deg) scale(' + window.iconScale() + ')';
                }}
            }});
            if (window.truckMarker && window.truckFpHeading != null) {{   // real-size live truck
                window.truckMarker.setIcon(window.footprintIcon(
                    'tractor', window.truckFpHeading, window.truckMarker.getLatLng().lat, 'Live'));
            }} else if (window.truckMarker) {{
                var el = window.truckMarker.getElement();
                var inner = el && el.querySelector('div');
                if (inner) {{
                    inner.style.transform = 'rotate(' + (window.truckHeading || 0) +
                                            'deg) scale(' + window.iconScale() + ')';
                }}
            }}
        }};
        {self.map_var_name}.on('zoomend', window.refreshObjectIconScales);
        window.refreshObjectIconScales();

        // kind / heading (optional): draw the vehicle at its real size, front facing `heading`
        window.registerVehicleSlot = function(vehicleId, polygonPoints, iconUrl, kind, heading) {{
            window.vehicleSlotPolygons[vehicleId] = polygonPoints;
            if (iconUrl) window.vehicleIconUrls[vehicleId] = iconUrl;
            if (kind) window.vehicleGeom[vehicleId] = {{ kind: kind, heading: heading || 0 }};
            window.resizeVehicleIcon(vehicleId);
        }};


        window.resizeVehicleIcon = function(vehicleId) {{

            var marker = window.vehicleMarkers && window.vehicleMarkers[vehicleId];
            var polygon = window.vehicleSlotPolygons && window.vehicleSlotPolygons[vehicleId];
            var iconUrl = window.vehicleIconUrls && window.vehicleIconUrls[vehicleId];

            var geom = window.vehicleGeom[vehicleId];
            if (marker && geom && window.footprintIcon) {{
                var fp = window.footprintIcon(geom.kind, geom.heading, marker.getLatLng().lat, vehicleId);
                if (fp) {{ marker.setIcon(fp); return; }}
            }}


            if (!marker || !polygon || !polygon.length || !iconUrl) return;
            var size = 40, rotation = 0;


            var icon = L.divIcon({{
                html: '<div style="width:' + size + 'px;height:' + size + 'px;transform:rotate(' + rotation + 'deg);">' +
                      '<img src="' + iconUrl + '" width="' + size + '" height="' + size + '">' +
                      '</div>',
                className: "",
                iconSize: [size, size],
                iconAnchor: [size / 2, size / 2]
            }});


            marker.setIcon(icon);
        }};
        {self.map_var_name}.on('zoomend', function() {{
            var ids = Object.assign({{}}, window.vehicleSlotPolygons || {{}}, window.vehicleGeom || {{}});
            for (var vid in ids) {{
                window.resizeVehicleIcon(vid);
            }}
        }});
        """
        self.browser.page().runJavaScript(icon_scaling_js)


        QTimer.singleShot(300, self.restore_vehicle_markers)
        QTimer.singleShot(300, self.restore_unknown_markers)


    # =====================================================
    # A yard chosen on the map: vehicles on the road, drawn paths, menus, follow
    # =====================================================
    @property
    def map_yard(self):
        """A site made with Sites -> New site from the map."""
        return (getattr(self, "site_info", None) or {}).get("created_from") == "map"

    def _road_lines(self):
        if getattr(self, "_osm_road_lines", None) is None:
            osm = osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE) or {}
            self._osm_road_lines = [r["line"] for r in osm.get("roads", [])
                                    if r.get("kind") not in ("footway", "path", "steps", "cycleway", "pedestrian")
                                    and len(r.get("line") or []) >= 2]
        return self._osm_road_lines

    def _road_snap(self, lat, lng, max_m=30.0):
        """(lat, lng, heading) on the centre line of the nearest OpenStreetMap road (heading along it) -- or the
        point as it is (heading None) when no road is within max_m."""
        kx = 111320.0 * math.cos(math.radians(lat))
        best = None
        for line in self._road_lines():
            for a, b in zip(line, line[1:]):
                ax, ay = (a[1] - lng) * kx, (a[0] - lat) * 111320.0
                bx, by = (b[1] - lng) * kx, (b[0] - lat) * 111320.0
                if min(abs(ax), abs(bx)) > max_m + 200 and ax * bx > 0:
                    continue
                dx, dy = bx - ax, by - ay
                L2 = dx * dx + dy * dy
                t = 0.0 if L2 <= 0 else max(0.0, min(1.0, -(ax * dx + ay * dy) / L2))
                px, py = ax + t * dx, ay + t * dy
                d = math.hypot(px, py)
                if best is None or d < best[0]:
                    best = (d, px, py, dx, dy)
        if best and best[0] <= max_m and (best[3] or best[4]):
            _d, px, py, dx, dy = best
            return lat + py / 111320.0, lng + px / kx, math.degrees(math.atan2(dx, dy)) % 360.0
        return lat, lng, None

    def _vehicle_position(self, vehicle_id):
        """(lat, lng, heading) where the vehicle is now (driving, parked, or None)."""
        st = self.path_replays.get(vehicle_id) or self._finished_routes.get(vehicle_id)
        if st and st.get("points"):
            i = max(0, min(len(st["points"]) - 1, st.get("index", 1) - 1))
            return tuple(st["points"][i])
        _l, _i, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if p and p.get("latitude") is not None:
            return p["latitude"], p["longitude"], float(p.get("heading") or 0.0)
        return None

    def _place_on_road(self, object_type, lat, lng, payload, is_new, new_av_values):
        """An AV dropped on the map: it stands on the nearest road, along it."""
        if is_new:
            vehicle_id, _mode = new_av_values
        else:
            vehicle_id = payload.get("avId")
            if not vehicle_id:
                return
            _l, _i, known = self.find_list_item_by_vehicle_id(vehicle_id)
            if known and known.get("latitude") is not None:
                QMessageBox.information(self, "Already Placed", f"{vehicle_id} is already on the map -- drag its "
                                                                "marker to move it (right-click it for its path).")
                return
        lat, lng, heading = self._road_snap(lat, lng)
        heading = 0.0 if heading is None else heading
        if is_new:
            number = vehicle_id
            vehicle_id = cfg.av_id(number)
            data = {"type": "truck", "avId": vehicle_id, "rover": vehicle_id, "number": number,
                    "name": f"AV {number}", "driveMode": "Auto Drive"}
        else:
            data = dict(self.find_list_item_by_vehicle_id(vehicle_id)[2] or payload)
        data.update(latitude=lat, longitude=lng, locationType="ROAD", locationId=None, heading=round(heading, 1))
        if is_new:
            item = QListWidgetItem(data.get("name"))
            item.setData(Qt.UserRole, data)
            self._style_av_item(item, True)
            self.av_list.addItem(item)
        else:
            _l, item, _p = self.find_list_item_by_vehicle_id(vehicle_id)
            item.setData(Qt.UserRole, data)
        self._restore_single_marker(data, AV_ICON_PATH, "avId")
        self.save_vehicles()
        if is_new:
            self.status_message(f"AV {data['name']} added with the default LiDAR + cameras -- right-click it to "
                                "draw its path")

    def _move_on_road(self, vehicle_id, lat, lng, payload, item):
        """A placed AV dragged on the map: onto the nearest road, along it."""
        lat, lng, heading = self._road_snap(lat, lng)
        heading = float(payload.get("heading") or 0.0) if heading is None else heading
        payload.update(latitude=lat, longitude=lng, locationType="ROAD", locationId=None, heading=round(heading, 1))
        item.setData(Qt.UserRole, payload)
        self.save_vehicles()
        vid = json.dumps(vehicle_id)
        self.browser.page().runJavaScript(f"""
        if (window.vehicleMarkers && window.vehicleMarkers[{vid}]) {{
            window.vehicleMarkers[{vid}].setLatLng([{lat}, {lng}]);
            window.registerVehicleSlot({vid}, [], null, {json.dumps(self._vehicle_kind(payload.get('type'), payload))},
                                       {heading});
        }}""")

    def status_message(self, text, ms=8000):
        """A short note over the map (disappears by itself)."""
        lab = getattr(self, "_toast", None)
        if lab is None:
            lab = self._toast = QLabel(self.browser)
            lab.setWordWrap(True)
            lab.setStyleSheet("background:rgba(17,24,39,235);color:#F9FAFB;border:1px solid #4ADE80;"
                              "border-radius:8px;padding:8px 12px;")
            self._toast_timer = QTimer(self)
            self._toast_timer.setSingleShot(True)
            self._toast_timer.timeout.connect(lab.hide)
        lab.setText(text)
        lab.setFixedWidth(min(560, max(200, self.browser.width() - 40)))
        lab.adjustSize()
        lab.move(max(0, (self.browser.width() - lab.width()) // 2), max(0, self.browser.height() - lab.height() - 40))
        lab.show()
        lab.raise_()
        self._toast_timer.start(ms)

    # ---- right-click menus ----
    def map_context_menu(self, lat, lng):
        from PyQt5.QtGui import QCursor
        m = QMenu(self)
        m.addAction(self._icon("fa5s.cube", "#60A5FA"), "Go to 3D view here", lambda: self.goto_3d(lat, lng, "3d"))
        m.addAction(self._icon("fa5s.columns", "#60A5FA"), "Show here in 3D beside the map",
                    lambda: self.goto_3d(lat, lng, "split"))
        m.addSeparator()
        m.addAction(self._icon("fa5s.truck", "#FBBF24"), "Place a new AV here ...",
                    lambda: self.on_latlng_resolved({"lat": lat, "lng": lng}, {"type": "truck", "new": True}))
        if getattr(self, "_follow_2d", None):
            m.addSeparator()
            m.addAction("Stop following on the 2D map", lambda: setattr(self, "_follow_2d", None))
        m.exec_(QCursor.pos())

    def vehicle_context_menu(self, vehicle_id):
        from PyQt5.QtGui import QCursor
        _l, _i, p = self.find_list_item_by_vehicle_id(vehicle_id)
        driving = vehicle_id in self.path_replays
        m = QMenu(self)
        shown = str(self.vehicle_label(vehicle_id))
        title = m.addAction(shown if shown.lower().startswith("av") else f"AV {shown}")
        title.setEnabled(False)
        self._common_object_actions(m, "truck", vehicle_id)
        m.addSeparator()
        m.addAction(self._icon("fa5s.route", "#F97316"), "Draw a path to drive ...",
                    lambda: self.draw_av_path(vehicle_id))
        m.addAction(self._icon("fa5s.map-signs", "#22D3EE"), "Path from source to destination (roads) ...",
                    lambda: self.draw_av_path(vehicle_id, auto=True))
        if (p or {}).get("path") and not driving:
            m.addAction(self._icon("fa5s.play", "#4ADE80"), "Drive its path again",
                        lambda: self.drive_av_path(vehicle_id, p["path"], p.get("pathSpeedKmh") or 15,
                                                      p.get("pathLoop", True)))
        self._av_test_actions(m, vehicle_id, p)
        if driving:
            m.addAction(self._icon("fa5s.stop", "#EF4444"), "Stop driving (stays here)",
                        lambda: (self.end_follow_test(vehicle_id) if vehicle_id in (getattr(self, "follow_tests", None) or {})
                                 else self.stop_av_here(vehicle_id)))
        m.addSeparator()
        m.addAction(self._icon("fa5s.video", "#60A5FA"), "Follow in 3D", lambda: self.follow_in_3d(vehicle_id))
        if getattr(self, "_follow_2d", None) == vehicle_id:
            m.addAction("Stop following on the 2D map", lambda: setattr(self, "_follow_2d", None))
        else:
            m.addAction(self._icon("fa5s.crosshairs", "#60A5FA"), "Follow on the 2D map",
                        lambda: self.follow_on_2d(vehicle_id))
        m.addSeparator()
        m.addAction(self._icon("fa5s.trash-alt", "#EF4444"), "Remove from the map", lambda: self._remove_from_map(vehicle_id))
        m.exec_(QCursor.pos())

    # ---- the same menu actions for every AV / trailer / obstacle (lists, 2D map, 3D view) ----
    def object_context_menu(self, object_id, cat=""):
        """Right-click on a vehicle / obstacle (2D map, 3D view): its menu."""
        if cat == "object" or (cat == "" and self.find_unknown_item_by_id(object_id)[0] is not None):
            self.obstacle_context_menu(object_id)
        elif object_id == "live":
            return
        else:
            self.vehicle_context_menu(object_id)

    def _hidden_objects(self):
        if not hasattr(self, "_hidden_ids"):
            self._hidden_ids = set()
        return self._hidden_ids

    def _object_position(self, kind, oid):
        if kind == "object":
            st = self.dynamic_objects.get(oid)
            if st and st.get("pose"):
                return st["pose"][0], st["pose"][1]
            _i, p = self.find_unknown_item_by_id(oid)
            return (p["latitude"], p["longitude"]) if p and p.get("latitude") is not None else None
        q = self._vehicle_position(oid)
        return (q[0], q[1]) if q else None

    def _common_object_actions(self, menu, kind, oid):
        """Show in 2D, Go to 3D, Hide and stop / Show and start, Restart."""
        pos = self._object_position(kind, oid)
        hidden = oid in self._hidden_objects()
        if pos and not hidden:
            menu.addAction(self._icon("fa5s.map-marker-alt", "#60A5FA"), "Show in 2D",
                           lambda: self.show_in_2d(pos[0], pos[1]))
            menu.addAction(self._icon("fa5s.cube", "#60A5FA"), "Go to 3D view here",
                           lambda: self.goto_3d(pos[0], pos[1], "3d"))
        if hidden:
            menu.addAction(self._icon("fa5s.eye", "#4ADE80"), "Show and start",
                           lambda: self.set_object_hidden(kind, oid, False))
        elif pos:
            menu.addAction(self._icon("fa5s.eye-slash", "#FBBF24"), "Hide and stop",
                           lambda: self.set_object_hidden(kind, oid, True))
        moving = (kind == "object" and oid in self.dynamic_objects) or \
                 (kind != "object" and (oid in self.path_replays or oid in self._finished_routes)
                  and oid not in (getattr(self, "follow_tests", None) or {}))
        if moving and not hidden:
            menu.addAction(self._icon("fa5s.redo", "#93C5FD"), "Restart (from the start of its path)",
                           lambda: self.restart_object(kind, oid))

    def show_in_2d(self, lat, lng):
        if self.view_buttons["3d"].isChecked():
            self.set_map_view("split")
        self.browser.page().runJavaScript(f"{self.map_var_name}.setView([{lat}, {lng}], "
                                          f"Math.max({self.map_var_name}.getZoom(), 19));")

    def set_object_hidden(self, kind, oid, hidden):
        """Hidden: gone from the 2D map and the 3D view (so from the LiDAR / detections too), and held -- a driving
        AV / moving obstacle stands -- until it is shown again."""
        H = self._hidden_objects()
        (H.add if hidden else H.discard)(oid)
        vid, m = json.dumps(oid), self.map_var_name
        self.browser.page().runJavaScript(
            f"(function(){{var on={'false' if hidden else 'true'};"
            f"function sw(l){{if(!l)return;if(on){{if(!l._map)l.addTo({m});}}else if(l._map){m}.removeLayer(l);}}"
            f"sw((window.vehicleMarkers||{{}})[{vid}]);sw((window.unknownMarkers||{{}})[{vid}]);"
            f"((window.replayLayers||{{}})[{vid}]||[]).forEach(sw);}})();")
        if kind == "object":
            st = self.dynamic_objects.get(oid)
            if st:
                (st["timer"].stop if hidden else st["timer"].start)()
            self._static_fp = None
        else:
            st = self.path_replays.get(oid)
            if st is not None and not st.get("follow"):
                st["hidden"] = hidden
                if hidden:
                    st["timer"].stop()
                elif not st.get("paused") and not st.get("held"):
                    st["timer"].start(int(st.get("interval_ms", PATH_REPLAY_INTERVAL_MS)))
        self.status_message(f"{oid} {'hidden -- held until Show and start' if hidden else 'shown again'}", 4000)

    def restart_object(self, kind, oid):
        """A moving obstacle / driving AV from the start of its path / route again."""
        if kind == "object":
            st = self.dynamic_objects.get(oid)
            if st:
                st.update(index=0, offset=0.0, wait=0)
                st.pop("crash_until", None)
            return
        st = self.path_replays.get(oid)
        if st is None and oid in self._finished_routes:             # (a route that came to its end)
            f = self._finished_routes[oid]
            self._begin_replay(oid, f["points"], f["file"], interval_ms=f.get("interval_ms"), loop=f.get("loop", False))
            return
        if st is None:
            return
        st["index"] = 0
        if "pos" in st:
            st["pos"] = 0.0
        if not st["timer"].isActive() and not st.get("paused") and not st.get("hidden"):
            st["timer"].start(int(st.get("interval_ms", PATH_REPLAY_INTERVAL_MS)))

    def _av_test_actions(self, m, vehicle_id, payload, routes=True):
        """Routes, speed limit, the collision test -- in the AV's menus (map and lists)."""
        st = self.path_replays.get(vehicle_id) or self._finished_routes.get(vehicle_id) or {}
        following = vehicle_id in (getattr(self, "follow_tests", None) or {})
        if ((st.get("points") and len(st["points"]) > 1 and not st.get("follow")) or (payload or {}).get("path")):
            m.addAction(self._icon("fa5s.save", "#FBBF24"), "Save its path as a route ...",
                        lambda: self.save_route_from_av(vehicle_id))
        if not following and routes:
            self._route_menu(m, vehicle_id)
        if vehicle_id in self.path_replays and not following:
            sp = self.path_replays[vehicle_id].get("speed_limit")
            m.addAction(self._icon("fa5s.tachometer-alt", "#93C5FD"),
                        "Speed limit ..." + (f"  ({sp:g} km/h)" if sp else ""),
                        lambda: self.speed_limit_dialog(vehicle_id))
        if following:
            m.addAction(self._icon("fa5s.stop-circle", "#EF4444"), "End the collision test",
                        lambda: self.end_follow_test(vehicle_id))
            m.addAction("Show the collision test", lambda: self._follow_panel_show(vehicle_id))

    def _follow_panel_show(self, vehicle_id):
        ft = (getattr(self, "follow_tests", None) or {}).get(vehicle_id) or {}
        ct = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy"))
        w = ct.get("window") if ct else getattr(self, "_follow_panels", {}).get(vehicle_id)
        if w is not None:
            w.show(); w.raise_()

    def _remove_from_map(self, vehicle_id):
        if vehicle_id in (getattr(self, "follow_tests", None) or {}):
            self.end_follow_test(vehicle_id, quiet=True)
        if vehicle_id in self.path_replays or vehicle_id in self._finished_routes:
            self.stop_path_replay(vehicle_id)
        if self._follow_2d_is(vehicle_id):
            self._follow_2d = None
        vid = json.dumps(vehicle_id)
        self.browser.page().runJavaScript(
            f"if(window.vehicleMarkers && window.vehicleMarkers[{vid}]){{ {self.map_var_name}.removeLayer("
            f"window.vehicleMarkers[{vid}]); delete window.vehicleMarkers[{vid}]; }}")
        self.remove_vehicle_from_map(vehicle_id)

    def _follow_2d_is(self, vehicle_id):
        return getattr(self, "_follow_2d", None) == vehicle_id

    # ---- 3D view at a place / following an AV ----
    def _when_3d_ready(self, js):
        """Runs `js` in the yard 3D view now -- or once it has loaded (it is made on first use)."""
        if self.yard3d_view is not None and getattr(self, "_yard3d_loaded", False):
            self.yard3d_view.page().runJavaScript(js)
        else:
            self._pending_3d_js = (getattr(self, "_pending_3d_js", None) or []) + [js]

    def goto_3d(self, lat, lng, mode="3d"):
        self.set_map_view(mode)
        self._when_3d_ready(f"window.yard3dFocus && window.yard3dFocus({lat}, {lng}, 90, 38);")

    def follow_in_3d(self, vehicle_id):
        self._follow_3d = vehicle_id
        if self.view_buttons["2d"].isChecked():
            self.set_map_view("split")
        self._when_3d_ready(f"window.yard3dFollow && window.yard3dFollow({json.dumps(vehicle_id)});")

    def follow_on_2d(self, vehicle_id):
        self._follow_2d = vehicle_id
        pos = self._vehicle_position(vehicle_id)
        if pos:
            self.browser.page().runJavaScript(f"{self.map_var_name}.setView([{pos[0]}, {pos[1]}], "
                                              f"Math.max({self.map_var_name}.getZoom(), 18));")

    # ---- an AV's own path (drawn on the map, like a moving obstacle's) ----
    def draw_av_path(self, vehicle_id, auto=False):
        """Click a path on the map (each point) -- or (auto) only the destination and any via points: the path is
        found along the roads, and back to the source if wanted."""
        pos = self._vehicle_position(vehicle_id)
        if not pos:
            QMessageBox.information(self, "Truck path", f"Place {vehicle_id} on the map first.")
            return
        if auto and self._router() is None:
            QMessageBox.information(self, "Path from source to destination",
                                    "This yard has no roads from OpenStreetMap yet: Update 3D (top bar) downloads them.")
            return
        self._pending_av_path = vehicle_id
        self._pending_path_auto = bool(auto)
        self._pending_dynamic_object = None
        self.browser.page().runJavaScript(f"window.startPathDrawing({pos[0]}, {pos[1]});")
        if auto:
            self._show_path_bar(f"Source: where {self.vehicle_label(vehicle_id)} is. Click the DESTINATION (and any via "
                                "points on the way, in order) -- the path follows the roads. Then Finish.")
        else:
            self._show_path_bar(f"Click the road points of {self.vehicle_label(vehicle_id)}'s path, then Finish.")

    def _router(self):
        """The yard's road router (OpenStreetMap roads of Update 3D), or None without roads."""
        import road_router
        if getattr(self, "_road_router", None) is None:
            osm = osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE) or {}
            r = road_router.RoadRouter(osm.get("roads") or [])
            self._road_router = r if len(r) else False
        return self._road_router or None

    ROUTE_BACK = (("No -- it stops at the destination", None),
                  ("Back to the source the same way", "same"),
                  ("Back to the source by other roads (where there are)", "different"))

    def _route_path_dialog(self, vehicle_id, clicks, drawn=False, replace=None):
        """The path from the source (the AV) to the destination along the roads: back to the source or not, its
        speed, again and again, save as a route -- previewed on the map while the dialog is open. drawn (Routes ->
        New route -> Draw it on the map): the clicked points are the source, the via points and the destination --
        along the roads through them (as source -> destination), or exactly as drawn (straight lines)."""
        import road_router
        stops = [(float(p[0]), float(p[1])) for p in clicks]
        dlg = QDialog(self)
        dlg.setObjectName("themedDialog")
        dlg.setWindowTitle(f"Path from source to destination -- {self.vehicle_label(vehicle_id)}" if vehicle_id else
                           f"Update path -- {replace}" if replace else
                           "New route (drawn on the map)" if drawn else "New route: source to destination")
        f = QFormLayout(dlg)
        shape = QComboBox()
        shape.addItem("Along the roads, through my points (like source → destination)", "roads")
        shape.addItem("Exactly as I drew it (straight lines between my points)", "drawn")
        if self._router() is None:
            shape.setCurrentIndex(1)
            shape.setEnabled(False)
            shape.setToolTip("This yard has no roads from OpenStreetMap yet (Update 3D downloads them): as drawn")
        else:
            shape.setCurrentIndex(int(getattr(self, "_route_shape_pref", 0)))
            shape.setToolTip("Along the roads: the first point is the source, the last the destination, the others "
                             "via points -- the path follows the roads (in the driving lane) like 'From a source to a "
                             "destination'.\nExactly as drawn: straight lines between the points (e.g. yard lanes "
                             "that are not OpenStreetMap roads).")
        if drawn:
            f.addRow("Path:", shape)
        back = QComboBox()
        for text, val in self.ROUTE_BACK:
            back.addItem(text, val)
        back.setCurrentIndex(int(getattr(self, "_route_back_pref", 0)))
        f.addRow("Return:", back)
        speed = QDoubleSpinBox(); speed.setRange(1.0, 60.0); speed.setValue(15.0); speed.setSuffix(" km/h")
        f.addRow("Speed:", speed)
        again = QCheckBox("Again and again (round trip)")
        f.addRow("", again)
        save = QCheckBox("Save it as a route (Collision Testing, Drive a route, New Truck -> Route)")
        f.addRow("", save)
        follow = QCheckBox("Follow it in 3D")
        f.addRow("", follow)
        info = QLabel(); info.setWordWrap(True); info.setMinimumWidth(460)
        f.addRow(info)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Drive it" if vehicle_id else "Save route ...")
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        f.addRow(bb)
        if not vehicle_id:                                    # (a new route only: saved, no AV drives it now --
            for c in (speed, again, save, follow):            #  the speed is the driving AV's: set when it drives)
                c.setVisible(False)
                lab = f.labelForField(c)
                if lab is not None:
                    lab.setVisible(False)
        state = {"res": None}

        def km(m):
            return f"{m / 1000:.2f} km" if m >= 1000 else f"{m:.0f} m"

        def as_drawn(b):
            """The clicked points joined by straight lines (back: the same way / straight to the start)."""
            out_m = sum(road_router.dist(p, q) for p, q in zip(stops, stops[1:]))
            pts = list(stops)
            if b == "same":
                pts = pts + pts[-2::-1]
            elif b == "different":
                pts = pts + [pts[0]]
            back_m = sum(road_router.dist(p, q) for p, q in zip(pts, pts[1:])) - out_m
            return {"points": pts, "dst": stops[-1], "out_m": out_m, "back_m": back_m, "roads": [],
                    "back_roads": [], "shared_m": 0.0, "notes": [], "side": None, "back": b, "drawn": True}

        def shape_texts():
            d = drawn and shape.currentData() == "drawn"
            for i, t in enumerate(("No -- it stops at its last point", "Back to the start the same way",
                                   "Back to the start directly (closes the loop)") if d else
                                  [t for t, _v in self.ROUTE_BACK]):
                back.setItemText(i, t)

        def plan():
            b = back.currentData()
            again.setEnabled(bool(b))
            if not b:
                again.setChecked(False)
            try:
                if drawn and shape.currentData() == "drawn":
                    res = as_drawn(b)
                else:
                    res = self._router().plan(stops, back=b, side=self._drive_side())
            except ValueError as e:
                state["res"] = None
                info.setText(f"<span style='color:#F87171'>No path: {e}</span>")
                bb.button(QDialogButtonBox.Ok).setEnabled(False)
                self._route_preview(None)
                return
            state["res"] = res
            bb.button(QDialogButtonBox.Ok).setEnabled(True)
            if res.get("drawn"):
                info.setText(f"<b>{len(stops)} points · {km(res['out_m'])}</b> as drawn (straight lines)"
                             + (f"<br>Way back: {km(res['back_m'])}" if b else "")
                             + f"<br>In all {km(res['out_m'] + res['back_m'])}")
                self._route_preview(res)
                return
            via = " → ".join(n for n, _m in res["roads"][:6]) + (" → ..." if len(res["roads"]) > 6 else "")
            txt = (f"<b>Way out: {km(res['out_m'])}</b> along {via}"
                   + (f" · {len(stops) - 2} via point{'s' if len(stops) > 3 else ''}" if len(stops) > 2 else ""))
            if b:
                bvia = " → ".join(n for n, _m in res["back_roads"][:6]) + (" → ..." if len(res["back_roads"]) > 6 else "")
                txt += (f"<br><b>Way back: {km(res['back_m'])}</b> along {bvia}"
                        + (f" · <span style='color:#FBBF24'>{res['shared_m'] / max(1.0, res['back_m']):.0%} on the "
                           f"roads of the way out</span> (no other road there)" if b == "different" and
                           res["shared_m"] > 20 else " · by other roads" if b == "different" else ""))
            total = res["out_m"] + res["back_m"]
            txt += f"<br>In all {km(total)}" + (f" · ~{total / max(0.3, speed.value() / 3.6) / 60:.1f} min at "
                                                f"{speed.value():g} km/h" if vehicle_id else "")
            if res.get("side"):
                txt += (f"<br>In the {res['side']}-hand lane of two-way roads ({'India / UK' if res['side'] == 'left' else 'US / Europe'} "
                        "-- app settings \"drive_side\"); one-way carriageways their own way")
            if res["notes"]:
                txt += "<br><span style='color:#FBBF24'>" + "; ".join(res["notes"]) + "</span>"
            info.setText(txt)
            self._route_preview(res)
        back.currentIndexChanged.connect(lambda *_a: plan())
        speed.valueChanged.connect(lambda *_a: plan())
        shape.currentIndexChanged.connect(lambda *_a: (shape_texts(), plan()))
        shape_texts()
        plan()
        ok = dlg.exec_() == QDialog.Accepted
        self._route_preview(None)
        res = state["res"]
        if not ok or res is None:
            return
        self._route_back_pref = back.currentIndex()
        if drawn and shape.isEnabled():
            self._route_shape_pref = shape.currentIndex()
        if not vehicle_id:                                    # (Routes page: saved under a name)
            n = len(SAVED_PATHS) + 1
            if res.get("drawn"):
                ok = self._save_route(road_router.densify(res["points"], 0.85), 200, bool(res["back"]), None,
                                      "drawn on the map", default_name=replace or f"Drawn route {n}")
            else:
                back_txt = {"same": "back the same way", "different": "back by other roads"}.get(res["back"],
                                                                                                 "one way")
                ok = self._save_route(road_router.densify(res["points"], 0.85), 200, bool(res["back"]), None,
                                      ("drawn points, along the roads" if drawn else "roads: source -> destination")
                                      + f", {back_txt}",
                                      default_name=replace or ((f"Drawn route {n}" if drawn else f"Road route {n}")
                                                               + (" (round trip)" if res["back"] else "")),
                                      lane=res.get("side"))
            if ok:
                self.refresh_routes()
            return
        step = max(0.2, speed.value() / 3.6 * self.TRUCK_PATH_STEP_MS / 1000.0)
        dense = road_router.densify(res["points"], step)
        _l, item, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if item is not None:                                  # kept with the AV: "Drive its path again"
            p = dict(p)
            p.update(path=[[a, b] for a, b in res["points"]], pathSpeedKmh=speed.value(), pathLoop=False)
            item.setData(Qt.UserRole, p)
            self.save_vehicles()
        self._begin_replay(vehicle_id, dense, f"path to destination ({speed.value():.0f} km/h)",
                           interval_ms=self.TRUCK_PATH_STEP_MS, loop=again.isChecked())
        if follow.isChecked():
            self.follow_in_3d(vehicle_id)
        if save.isChecked():
            pts = road_router.densify(res["points"], 0.85)
            back_txt = {"same": "back the same way", "different": "back by other roads"}.get(res["back"], "one way")
            self._save_route(pts, 200, bool(res["back"]), None,
                             f"roads: source -> destination, {back_txt}",
                             default_name=f"{self.vehicle_label(vehicle_id)} to destination"
                                          + (" and back" if res["back"] else ""), lane=res.get("side"))

    def _route_preview(self, res):
        """The planned path on the map while the dialog is open: the way out orange, the way back purple."""
        m = self.map_var_name
        if res is None:
            self.browser.page().runJavaScript(
                f"(function(){{ (window.routePreview||[]).forEach(function(l){{ {m}.removeLayer(l); }}); "
                f"window.routePreview = []; }})();")
            return
        pts = [[round(a, 7), round(b, 7)] for a, b in res["points"]]
        import road_router
        if res.get("dst") is not None:                        # (where the way out ends: the point at the destination)
            n_out = min(range(len(pts)), key=lambda i: road_router.dist(res["points"][i], res["dst"]))
        else:
            n_out, acc = len(pts) - 1, 0.0
            for i in range(1, len(res["points"])):
                acc += road_router.dist(res["points"][i - 1], res["points"][i])
                if acc >= res["out_m"] - 0.5:
                    n_out = i
                    break
        out_len = max(2, n_out + 1)
        self.browser.page().runJavaScript(f"""
        (function(){{
            (window.routePreview||[]).forEach(function(l){{ {m}.removeLayer(l); }});
            var p = {json.dumps(pts)}, k = {out_len};
            var ls = [];
            ls.push(L.polyline(p.slice(0, k), {{color: '#F97316', weight: 6, opacity: 0.9}}).addTo({m}));
            if (k < p.length) ls.push(L.polyline(p.slice(k - 1), {{color: '#A855F7', weight: 4, opacity: 0.95,
                                                                    dashArray: '10 7'}}).addTo({m}));
            ls.push(L.circleMarker(p[0], {{radius: 8, color: '#fff', weight: 2, fillColor: '#16A34A', fillOpacity: 1}})
                    .bindTooltip('Source').addTo({m}));
            ls.push(L.circleMarker(p[k - 1], {{radius: 8, color: '#fff', weight: 2, fillColor: '#DC2626', fillOpacity: 1}})
                    .bindTooltip('Destination').addTo({m}));
            window.routePreview = ls;
            try {{ {m}.fitBounds(L.polyline(p).getBounds(), {{padding: [40, 40]}}); }} catch (e) {{}}
        }})();""")

    def _show_path_bar(self, text):
        bar = getattr(self, "_path_bar", None)
        if bar is None:
            bar = self._path_bar = QFrame(self.browser)
            bar.setStyleSheet("QFrame{background:rgba(17,24,39,230);border:1px solid #F97316;border-radius:8px;}"
                              "QLabel{color:#F9FAFB;border:none;background:transparent;}")
            h = QHBoxLayout(bar)
            h.setContentsMargins(12, 6, 8, 6)
            self._path_bar_label = QLabel()
            h.addWidget(self._path_bar_label)
            fin = QPushButton("Finish path")
            fin.clicked.connect(self._finish_av_path)
            h.addWidget(fin)
            undo = QPushButton("Undo point")
            undo.clicked.connect(lambda: self.browser.page().runJavaScript(
                "if(window.currentPathPoints && window.currentPathPoints.length>1){window.currentPathPoints.pop();"
                "if(window.drawPolyline){window.drawPolyline.setLatLngs(window.currentPathPoints);}}"))
            h.addWidget(undo)
            cancel = QPushButton("Cancel")
            cancel.clicked.connect(self._cancel_av_path)
            h.addWidget(cancel)
        self._path_bar_label.setText(text)
        bar.adjustSize()
        bar.move(max(0, (self.browser.width() - bar.width()) // 2), 12)
        bar.show()
        bar.raise_()

    def _cancel_av_path(self):
        self._pending_av_path = None
        self.browser.page().runJavaScript("if(window.stopPathDrawing){ window.stopPathDrawing(); }")
        if getattr(self, "_path_bar", None) is not None:
            self._path_bar.hide()

    def _finish_av_path(self):
        vid = getattr(self, "_pending_av_path", None)
        if not vid:
            return
        self.browser.page().runJavaScript("window.currentPathPoints || [];",
                                          lambda pts, v=vid: self._av_path_drawn(v, pts))

    def _av_path_drawn(self, vehicle_id, points):
        auto = getattr(self, "_pending_path_auto", False)
        self._pending_path_auto = False
        self._cancel_av_path()
        if vehicle_id == "__route__":                     # (Routes page -> New route: no AV)
            self._new_route_drawn(points, auto)
            return
        if not points or len(points) < 2:
            QMessageBox.warning(self, "Truck path", "Click the destination on the map." if auto else
                                "Click at least one more point on the map for the path.")
            return
        if auto:
            self._route_path_dialog(vehicle_id, points)
            return
        dlg = QDialog(self)
        dlg.setObjectName("themedDialog")
        dlg.setWindowTitle(f"Path of {self.vehicle_label(vehicle_id)}")
        f = QFormLayout(dlg)
        speed = QDoubleSpinBox()
        speed.setRange(1.0, 60.0)
        speed.setValue(15.0)
        speed.setSuffix(" km/h")
        f.addRow("Speed:", speed)
        loop = QCheckBox("Drive it there and back, again and again")
        loop.setChecked(True)
        f.addRow("", loop)
        follow = QCheckBox("Follow it in 3D")
        f.addRow("", follow)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        f.addRow(bb)
        if dlg.exec_() != QDialog.Accepted:
            return
        path = [[float(p[0]), float(p[1])] for p in points]
        _l, item, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if item is not None:                                  # kept with the AV: "Drive its path again"
            p = dict(p)
            p.update(path=path, pathSpeedKmh=speed.value(), pathLoop=loop.isChecked())
            item.setData(Qt.UserRole, p)
            self.save_vehicles()
        self.drive_av_path(vehicle_id, path, speed.value(), loop.isChecked())
        if follow.isChecked():
            self.follow_in_3d(vehicle_id)

    TRUCK_PATH_STEP_MS = 200                                # a drawn path is driven in steps of 0.2 s

    def drive_av_path(self, vehicle_id, path, speed_kmh=15.0, loop=True):
        """The AV drives the drawn path at `speed_kmh` (there and back again with `loop`)."""
        pts = [{"lat": a, "lon": b} for a, b in path]
        if loop:
            pts = pts + pts[-2::-1]
        step = max(0.2, float(speed_kmh) / 3.6 * self.TRUCK_PATH_STEP_MS / 1000.0)
        dense = self._densify_path_by_distance(pts, step)
        out, last_h = [], 0.0
        for i, q in enumerate(dense):
            n = dense[min(i + 1, len(dense) - 1)] if i + 1 < len(dense) else None
            if n is not None and (n["lat"] != q["lat"] or n["lon"] != q["lon"]):
                last_h = math.degrees(math.atan2((n["lon"] - q["lon"]) * math.cos(math.radians(q["lat"])),
                                                 n["lat"] - q["lat"])) % 360.0
            out.append((q["lat"], q["lon"], last_h))
        self._begin_replay(vehicle_id, out, f"drawn path ({speed_kmh:.0f} km/h)", interval_ms=self.TRUCK_PATH_STEP_MS,
                           loop=loop)

    def stop_av_here(self, vehicle_id):
        """Stop a driving AV: it stays where it is (parked there, on the road)."""
        pos = self._vehicle_position(vehicle_id)
        self.stop_path_replay(vehicle_id)
        _l, item, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if pos and item is not None:
            p = dict(p)
            p.update(latitude=pos[0], longitude=pos[1], heading=round(pos[2], 1), locationType="ROAD", locationId=None)
            item.setData(Qt.UserRole, p)
            self._restore_single_marker(p, AV_ICON_PATH, "avId")
            self.save_vehicles()

    # ---- a drawn path saved as a route (any AV can drive it: New AV -> Route, or Follow route) ----
    def save_route_from_av(self, vehicle_id):
        st = self.path_replays.get(vehicle_id) or self._finished_routes.get(vehicle_id)
        _l, _i, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if st and st.get("points") and len(st["points"]) > 1 and not st.get("follow"):
            points, step, loop = st["points"], st.get("interval_ms", PATH_REPLAY_INTERVAL_MS), st.get("loop", False)
        elif p and p.get("path"):
            self.drive_av_path(vehicle_id, p["path"], p.get("pathSpeedKmh") or 15, p.get("pathLoop", True))
            st = self.path_replays[vehicle_id]
            points, step, loop = st["points"], st["interval_ms"], st["loop"]
        else:
            QMessageBox.information(self, "Save as route", "This truck has no path yet: right-click it -> Draw a path.")
            return
        self._save_route(points, step, loop, (p or {}).get("pathSpeedKmh"), vehicle_id)

    def _save_route(self, points, step_ms, loop, speed, source, default_name=None, lane=None):
        """Asks a name, writes sites/<yard>/routes/<name>.txt (header + lat / lng / heading lines) -- any AV can
        then drive it (New AV -> Route, Follow route, Drive a route). speed: None = the driving AV's own.
        lane: "left" / "right" = already in that lane (made along the roads): not moved again by Collision Testing."""
        n = len([k for k in SAVED_PATHS if not re.match(r"^Route \d+$", k)]) + 1
        name, ok = QInputDialog.getText(self, "Save as route", "Route name:", text=default_name or f"Saved route {n}")
        name = (name or "").strip().replace("|", "/")
        if not ok or not name:
            return None
        if name in SAVED_PATHS and QMessageBox.question(self, "Save as route", f"Replace the route '{name}'?") \
                != QMessageBox.Yes:
            return None
        os.makedirs(cfg.ROUTES_DIR, exist_ok=True)
        path = SAVED_PATHS.get(name) if isinstance(SAVED_PATHS.get(name), str) else \
            os.path.join(cfg.ROUTES_DIR, re.sub(r"[^A-Za-z0-9_.-]+", "_", name) + ".txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# route: {name} | interval_ms={int(step_ms)} | loop={1 if loop else 0}"
                    + (f" | speed_kmh={float(speed):g}" if speed else "") + (f" | lane={lane}" if lane else "")
                    + f" | from {source}\n")
            for lat, lon, h in points:
                f.write(f"lat={lat:.9f} | lng={lon:.9f} | heading={h:.2f}\n")
        SAVED_PATHS.clear()
        SAVED_PATHS.update(cfg.site_routes())
        self.status_message(f"Route '{name}' saved ({len(points)} points) -- New Truck -> Route, or right-click a "
                            "truck -> Drive a route, to drive it with another truck")
        return name


    def _route_menu(self, menu, vehicle_id):
        if SAVED_PATHS:
            sub = menu.addMenu(self._icon("fa5s.road", "#FBBF24"), "Drive a route")
            for name in SAVED_PATHS:
                sub.addAction(name, lambda n=name: self.start_route(vehicle_id, n))

    # ---- stop and go of a driving (manual) AV ----
    def stop_and_go_dialog(self, vehicle_id):
        st = self.path_replays.get(vehicle_id)
        if not st:
            return
        v = self._stop_go_ask(vehicle_id)
        if v:
            self.stop_and_go(vehicle_id, *v)

    def _stop_go_ask(self, vehicle_id, parent=None):
        """(braking m/s², stands s, again every s) -- or None."""
        dlg = QDialog(parent or self)
        dlg.setObjectName("themedDialog")
        dlg.setWindowTitle(f"Stop and go -- {self.vehicle_label(vehicle_id)}")
        f = QFormLayout(dlg)
        brake = QComboBox()
        for text, a in (("Gentle (1.5 m/s²)", 1.5), ("Normal (3 m/s²)", 3.0), ("Hard (5 m/s²)", 5.0),
                        ("Sudden (stops at once)", 0.0)):
            brake.addItem(text, a)
        brake.setCurrentIndex(1)
        f.addRow("Braking:", brake)
        hold = QDoubleSpinBox(); hold.setRange(0.5, 300); hold.setValue(6); hold.setSuffix(" s")
        f.addRow("Stands still for:", hold)
        rep = QDoubleSpinBox(); rep.setRange(0, 600); rep.setValue(0); rep.setSuffix(" s"); rep.setSpecialValueText("once")
        rep.setToolTip("Stop again this long after it drove on (0 = once) -- e.g. a turning area")
        f.addRow("Again every:", rep)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Stop now")
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        f.addRow(bb)
        if dlg.exec_() != QDialog.Accepted:
            return None
        return brake.currentData(), hold.value(), rep.value()

    @staticmethod
    def _nominal_speed(st):
        """m/s of a drive at its own pace (its points / step)."""
        dt = st.get("interval_ms", PATH_REPLAY_INTERVAL_MS) / 1000.0
        step_m = (st["cum"][-1] / max(1, len(st["points"]) - 1)) if st.get("cum") else 1.0
        return max(0.1, step_m / dt)

    def set_av_speed(self, vehicle_id, kmh):
        """Speed limit of a driving AV (km/h): it drives its path / route at this speed (stop and go too)."""
        st = self.path_replays.get(vehicle_id)
        if not st or st.get("follow") or not kmh:
            return
        st["rate_full"] = max(0.01, float(kmh) / 3.6 / self._nominal_speed(st))
        sg = st.get("sg")
        if not sg or sg.get("phase") in ("run",):
            st["rate"] = st["rate_full"]
        st["speed_limit"] = float(kmh)
        _l, item, p = self.find_list_item_by_vehicle_id(vehicle_id)
        if item is not None:
            item.setData(Qt.UserRole, dict(p, speedLimitKmh=float(kmh)))

    def speed_limit_dialog(self, vehicle_id):
        st = self.path_replays.get(vehicle_id)
        if not st:
            return
        cur = self._av_speed_kmh(vehicle_id) or 15.0
        v, ok = QInputDialog.getDouble(self, "Speed limit", f"Speed of {self.vehicle_label(vehicle_id)} (km/h):",
                                       round(st.get("speed_limit") or cur, 1), 1.0, 80.0, 1)
        if ok:
            self.set_av_speed(vehicle_id, v)

    def stop_and_go(self, vehicle_id, decel=3.0, hold_s=6.0, repeat_s=0.0):
        st = self.path_replays.get(vehicle_id)
        if not st:
            return
        dt = st.get("interval_ms", PATH_REPLAY_INTERVAL_MS) / 1000.0
        st.setdefault("rate", st.get("rate_full", 1.0))
        st["sg"] = {"phase": "brake", "decel": float(decel), "hold": float(hold_s), "repeat": float(repeat_s),
                    "v_nom": self._nominal_speed(st), "dt": dt, "t": time.time()}
        if not decel:
            st["rate"] = 0.0
        print(f"[stop and go] {vehicle_id}: stopping ({decel:g} m/s², {hold_s:g} s"
              + (f", again every {repeat_s:g} s)" if repeat_s else ")"))

    def stop_and_go_off(self, vehicle_id):
        st = self.path_replays.get(vehicle_id)
        if st and "sg" in st:
            st["sg"] = {"phase": "go", "decel": 3.0, "hold": 0, "repeat": 0, "v_nom": st["sg"]["v_nom"],
                        "dt": st["sg"]["dt"], "t": time.time(), "last": True}

    def _stop_go_update(self, vehicle_id, st):
        sg = st.get("sg")
        if not sg:
            return
        now = time.time()
        if sg["phase"] == "brake":
            st["rate"] = max(0.0, st["rate"] - (sg["decel"] * sg["dt"] / sg["v_nom"] if sg["decel"] else 1.0))
            if st["rate"] <= 0.0:
                sg["phase"], sg["until"] = "hold", now + sg["hold"]
        elif sg["phase"] == "hold":
            if now >= sg["until"]:
                sg["phase"] = "go"
        elif sg["phase"] == "go":
            full = st.get("rate_full", 1.0)                                         # (up to its speed limit)
            st["rate"] = min(full, st["rate"] + 1.0 * sg["dt"] / sg["v_nom"])       # drives on at 1 m/s²
            if st["rate"] >= full:
                if sg["repeat"] and not sg.get("last"):
                    sg["phase"], sg["next"] = "run", now + sg["repeat"]
                else:
                    st.pop("sg", None)
        elif sg["phase"] == "run" and now >= sg.get("next", now):
            sg["phase"] = "brake"

    def _av_speed_kmh(self, vehicle_id):
        st = self.path_replays.get(vehicle_id)
        if not st or not st.get("cum"):
            return None
        dt = st.get("interval_ms", PATH_REPLAY_INTERVAL_MS) / 1000.0
        v = st["cum"][-1] / max(1, len(st["points"]) - 1) / dt
        return 3.6 * v * st.get("rate", 1.0)

    # ---- follow test: an AV follows a manual one, braking on its LiDAR / camera only ----


    @staticmethod
    def _trail_pose(trail, s, ss=None):
        """(lat, lon, heading) at distance s along the trail [(lat, lon, heading, s)] (ss: its s values, if known)."""
        import bisect
        if not trail:
            return (0.0, 0.0, 0.0)
        ss = ss or [q[3] for q in trail]
        i = bisect.bisect_right(ss, s) - 1
        if i < 0:
            return trail[0][:3]
        if i >= len(trail) - 1:
            return trail[-1][:3]
        a, b = trail[i], trail[i + 1]
        f = (s - a[3]) / max(1e-6, b[3] - a[3])
        h = math.degrees(math.atan2((b[1] - a[1]) * math.cos(math.radians(a[0])), b[0] - a[0])) % 360.0 \
            if (a[0], a[1]) != (b[0], b[1]) else a[2]
        return (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, h)

    @staticmethod
    def _on_trail(trail, s_from, s_to, dets, ss=None):
        """Detections placed on the follower's road ahead: x = metres along it, y = metres beside it (the lane test
        of follow_test uses them); ones behind it or not along it are left out. ss: the trail's s values (a long
        route: the segments are found by bisection)."""
        if not dets or len(trail) < 2:
            return dets
        segs = []
        if ss:
            import bisect
            i0 = max(0, bisect.bisect_right(ss, s_from - 1.0) - 1)
            i1 = min(len(trail) - 1, bisect.bisect_right(ss, s_to + 2.0))
            segs = [(trail[i], trail[i + 1]) for i in range(i0, i1)]
        else:
            # only the road between s_from and s_to (the end of the trail: walked backwards; the part behind skipped)
            for i in range(len(trail) - 2, -1, -1):
                a, b = trail[i], trail[i + 1]
                if b[3] < s_from - 1.0:
                    break
                if a[3] > s_to + 2.0:
                    continue
                segs.append((a, b))
        if segs:                                          # (a box around that road: objects far away are skipped)
            m = 12.0 / 111320.0
            la0 = min(min(a[0], b[0]) for a, b in segs) - m
            la1 = max(max(a[0], b[0]) for a, b in segs) + m
            mo = m / max(0.2, math.cos(math.radians(segs[0][0][0])))
            lo0 = min(min(a[1], b[1]) for a, b in segs) - mo
            lo1 = max(max(a[1], b[1]) for a, b in segs) + mo
        out = []
        for d in dets:
            lat, lng = d.get("lat"), d.get("lng")
            if lat is None or lng is None:
                out.append(d)
                continue
            if not segs or not (la0 <= lat <= la1 and lo0 <= lng <= lo1):
                continue
            kx = 111320.0 * math.cos(math.radians(lat))
            best = None
            for a, b in segs:
                ax, ay = (a[1] - lng) * kx, (a[0] - lat) * 111320.0
                dx, dy = (b[1] - a[1]) * kx, (b[0] - a[0]) * 111320.0
                L2 = dx * dx + dy * dy
                u = 0.0 if L2 <= 0 else max(0.0, min(1.0, -(ax * dx + ay * dy) / L2))
                lat_off = math.hypot(ax + u * dx, ay + u * dy)
                if best is None or lat_off < best[0]:
                    best = (lat_off, a[3] + u * (b[3] - a[3]))
            if best is None or best[1] <= s_from + 0.5:
                continue                                          # beside / behind it
            out.append(dict(d, x=best[1] - s_from, y=best[0]))
        return out

    def _follow_objects(self, follower_id):
        """Everything the front camera / radar could see: AVs / trailers / obstacles
        [(id, label, lat, lon, L, W, kind, moving, heading, speed m/s)] (follow_test._obj).
        Made once per ~0.1 s for all the AVs of a test (reading the lists is not cheap)."""
        now = time.time()
        cache = getattr(self, "_fobj_cache", None)
        if cache is None or now - cache[0] > 0.09:
            cache = self._fobj_cache = (now, self._follow_objects_all())
        return [o for o in cache[1] if o[0] != follower_id]

    def _follow_objects_all(self):
        L_t = float(VEHICLE_DIMENSIONS.get("tractor", {}).get("length", 4.94))
        out = []
        hidden = self._hidden_objects()
        follower_id = None
        for vid, st in self.path_replays.items():
            if vid != follower_id and st.get("points") and vid not in hidden:
                q = self._vehicle_position(vid)
                if q:
                    out.append((vid, str(self.vehicle_label(vid)), q[0], q[1], L_t, 2.5, "truck", True, q[2],
                                (self._speed_of(vid) or 0.0) / 3.6))
        for lst in (self.av_list,):
            for i in range(lst.count()):
                p = lst.item(i).data(Qt.UserRole) or {}
                vid = p.get("avId")
                if vid and vid != follower_id and vid not in self.path_replays and p.get("latitude") is not None \
                        and vid not in hidden:
                    truck = p.get("type") == "truck"
                    out.append((vid, str(self.vehicle_label(vid)), p["latitude"], p["longitude"],
                                L_t if truck else 16.0, 2.6, "truck" if truck else "trailer", False,
                                float(p.get("heading") or 0.0), 0.0))
        for oid, st in self.dynamic_objects.items():
            if st.get("pose") and oid not in hidden:
                la, lo, h, L, W = st["pose"]
                out.append((oid, oid, la, lo, L, W, st.get("type") or "object", True, h,
                            float(st.get("speed_kmh") or 0.0) / 3.6))
        kinds = getattr(self, "_static_fp_kind", {})
        for f in self._static_footprints():
            if f[0] in self.dynamic_objects:              # (a moving obstacle: its saved start point is not an object --
                continue                                  #  it stood there as a parked ghost the AVs stopped for)
            out.append((f[0], f[0], f[1], f[2], f[4], f[5], kinds.get(f[0]) or "object", False, f[3], 0.0))
        return out

    def _speed_of(self, vehicle_id):
        """km/h of a driving AV: an autonomous one in a follow test / convoy (its own speed) or one on a route."""
        ft = (getattr(self, "follow_tests", None) or {}).get(vehicle_id)
        if ft:
            return ft["ctl"].v * 3.6
        return self._av_speed_kmh(vehicle_id)


    def end_follow_test(self, follower_id, quiet=False, whole_convoy=True):
        ft = (getattr(self, "follow_tests", None) or {}).get(follower_id)
        if ft and ft.get("convoy") and whole_convoy and ft["convoy"] in (getattr(self, "collision_tests", None) or {}):
            self.end_collision_test(ft["convoy"], quiet)      # (one AV of a collision test: the whole test ends)
            return
        ft = (getattr(self, "follow_tests", None) or {}).pop(follower_id, None)
        if not ft:
            return
        ft["timer"].stop()
        ft["timer"].deleteLater()
        if not quiet:
            self.stop_av_here(follower_id)                 # it stays where it is
            ctl = ft["ctl"]
            print(f"[follow test] {follower_id}: {ctl.stats['brakes']} brakings ({ctl.stats['full_brakes']} full), "
                  f"{ctl.stats['collisions']} collision(s) in {ft['climate']}")
        panel = getattr(self, "_follow_panels", {}).pop(follower_id, None)
        if panel is not None and not ft.get("convoy"):
            panel.close()

    def _toggle_follow_2d(self, vehicle_id):
        if getattr(self, "_follow_2d", None) == vehicle_id:
            self._follow_2d = None
        else:
            self.follow_on_2d(vehicle_id)

    def _toggle_follow_3d(self, vehicle_id):
        if getattr(self, "_follow_3d", None) == vehicle_id and self.yard3d_view is not None and self.yard3d_view.isVisible():
            self._follow_3d = None
            self._run_3d("window.yard3dUnfollow && window.yard3dUnfollow();")
        else:
            self.follow_in_3d(vehicle_id)


    def _hold_av(self, vehicle_id, seconds):
        """A driving AV stands still for `seconds` (its drive goes on afterwards)."""
        st = self.path_replays.get(vehicle_id)
        if not st or seconds <= 0:
            return
        st["timer"].stop()
        st["held"] = True

        def go_on(s=st):
            if self.path_replays.get(vehicle_id) is s and s.get("held"):
                s["held"] = False
                if not s.get("paused"):                    # (a paused test stays paused)
                    s["timer"].start(int(s.get("interval_ms", PATH_REPLAY_INTERVAL_MS)))
        st["_resume"] = go_on
        QTimer.singleShot(int(seconds * 1000), go_on)

    def _follow_continue(self, follower_id):
        """Collision hold: go on now."""
        ft = (self.follow_tests or {}).get(follower_id)
        if not ft:
            return
        ft["hold_until"] = 0.0
        st = self.path_replays.get(ft["leader"])
        if st and st.get("held") and st.get("_resume"):
            st["_resume"]()


    def _follow_set_sensor(self, follower_id, name, on):
        """A sensor of an AV switched on / off from the test window (while it drives)."""
        ft = (self.follow_tests or {}).get(follower_id)
        if not ft:
            return
        if name == "V2V":                                 # (collision testing: V2V on / off while it drives)
            ft["ctl"].set_v2v(time.time() - ft["t0"], on)
            return
        ft["ctl"].set_sensor(time.time() - ft["t0"], name, on)
        if not on:
            print(f"[follow test] {follower_id}: {name} switched OFF -> {follow_test.sensors_text(ft['ctl'].sensors)}")

    # ---- Collision testing (top bar): AVs driving a saved route one behind the other ----
    def collision_test_dialog(self):
        """Top bar "Collision Testing": a saved route and how many AVs drive it one behind the other
        (each: which AV, top speed, gap, LiDAR / camera / radar at the start)."""
        import collision_panel
        import auth
        if not SAVED_PATHS:
            QMessageBox.information(self, "Collision testing", "No saved route yet: right-click a truck with a path "
                                    "-> Save its path as a route ..., then start the collision test.")
            return
        for cid in list(getattr(self, "collision_tests", None) or {}):    # (one test at a time)
            w = self.collision_tests[cid].get("window")
            if w is not None:
                w.show(); w.raise_()
            return
        autos = []
        for i in range(self.av_list.count()):
            p = self.av_list.item(i).data(Qt.UserRole) or {}
            if p.get("avId") and not p.get("collisionTest"):
                autos.append((p["avId"], str(self.vehicle_label(p["avId"]))))
        info_cache = {}

        def route_info(name):
            if name not in info_cache:
                R = self._route_trail(name)
                if R is None:
                    info_cache[name] = ("could not be read", False)
                else:
                    info_cache[name] = (
                        f"{R['total']:.0f} m · {'loop (drives round and round)' if R['loop'] else 'ends at its last point'}"
                        + (" · two-way: out and back on the same road -- the AVs keep to their lane"
                           if R["two_way"] else " · on the roads' centre lines -- the AVs keep to their lane"
                           if R.get("on_centre") else " · one-way"), R["two_way"] or bool(R.get("on_centre")),
                        bool(R["loop"]))
            return info_cache[name]
        clim = (f"{(self.climate or {}).get('label', '?')}: camera ~{follow_test.camera_range(self.climate, self._ctest_cams()[0]):.0f} m"
                f" · LiDAR ~{follow_test.lidar_range(self.climate):.0f} m · radar ~{follow_test.radar_range(self.climate):.0f} m"
                f" · road grip {follow_test.road_grip(self.climate):.0%}")
        dlg = collision_panel.CollisionSetupDialog(self, list(SAVED_PATHS), route_info, autos, clim, self._drive_side(),
                                                   history=lambda: (dlg.reject(),
                                                                    QTimer.singleShot(0, self.open_collision_history)),
                                                   climates=[(c["id"], c.get("label", c["id"])) for c in cfg.CLIMATES],
                                                   setups_file=self._ctest_setups_file())
        while True:
            if dlg.exec_() != QDialog.Accepted:
                return
            route, side, rows, hold, loops, plan, v2v_cfg = dlg.values()
            picked = [r[0] for r in rows if r[0]]
            if len(picked) == len(set(picked)):
                break
            QMessageBox.information(dlg, "Collision testing", "Each AV can be used once.")
        self._ct_near_miss = dlg.near_miss.isChecked()   # (near-miss beacons in the 3D view: off unless ticked)
        try:                                             # (the setup: "Last test" in the saved setups)
            collision_panel.save_setup(self._ctest_setups_file(), collision_panel.LAST_SETUP, dlg.config())
        except Exception:
            sys.excepthook(*sys.exc_info())
        # the results into Reports? (asked each time -- not every quick test fills the Reports list)
        mb = QMessageBox(QMessageBox.Question, "Collision testing",
                         "Save the results of this test to Reports?", QMessageBox.Yes | QMessageBox.No, self)
        mb.setInformativeText("Yes: when the test finishes / ends, its results (with the collisions' camera images) "
                              "are kept in Reports.\nNo: the results summary still shows at the end -- with a "
                              "'Save to Reports' button if you want to keep them after all.")
        mb.setDefaultButton(QMessageBox.No)
        save = mb.exec_() == QMessageBox.Yes
        # the whole test recorded for a replay? (a quick demo: play it, pause, jump straight to the collisions)
        last = bool((cfg.APP_SETTINGS.get("collision_replay") or {}).get("save", True))
        mb2 = QMessageBox(QMessageBox.Question, "Collision testing", "Save this test for replay?",
                          QMessageBox.Yes | QMessageBox.No, self)
        mb2.setInformativeText("Yes: the whole test is recorded -- this window (cards, detection details, camera "
                               "images, log), the 2D map and the 3D view -- and kept with its results in Reports "
                               "(then also when you answered No above). Reports -> Collision tests -> Replay plays "
                               "it back as it was: play / pause, speed, seek, and jump straight to each collision / "
                               "near miss -- e.g. for a short demo without running the test again.")
        mb2.setDefaultButton(QMessageBox.Yes if last else QMessageBox.No)
        replay = mb2.exec_() == QMessageBox.Yes
        if replay != last:
            try:
                cfg.save_app_settings_section("collision_replay", {"save": replay})
            except Exception:
                sys.excepthook(*sys.exc_info())
        temp, members = [], []
        for k, (tid, kmh, gap, sens) in enumerate(rows):
            if not tid:
                tid = self._ctest_new_av(f"CT{k + 1}")
                temp.append(tid)
            members.append((tid, kmh, gap, sens))
        before = self._ctest_before([m[0] for m in members if m[0] not in temp])
        if self.start_collision_test(route, members, hold, temp=temp, drive_side=side, loops=loops, plan=plan,
                                     v2v=v2v_cfg, publish=dlg.publish_values(), save=save,
                                     before=before, replay=replay) is None:
            for t in temp:
                self._ctest_remove_av(t)

    @staticmethod
    def _ctest_setups_file():
        """This yard's saved collision-test setups (Setup: Load / Save)."""
        return os.path.join(cfg.SITE_DIR, "collision_setups.json")

    def _ctest_before(self, ids):
        """The yard's AVs used in a collision test, as they were before it (put back when it ends): {id: {data:
        their saved info (place), route: the saved route they were driving | None}}."""
        out = {}
        for vid in ids:
            _l, item, p = self.find_list_item_by_vehicle_id(vid)
            if item is None:
                continue
            st = self.path_replays.get(vid)
            route = st.get("file") if st and not st.get("follow") and st.get("file") in SAVED_PATHS else None
            out[vid] = {"data": json.loads(json.dumps(p or {}, default=str)), "route": route}
        return out

    def _ctest_restore(self, ct):
        """After a collision test: the map as before it -- the yard's AVs back where they were (or on the route
        they were driving), the climate it started with."""
        changed = False
        for vid, b in (ct.get("before") or {}).items():
            if vid in (ct.get("temp") or ()):
                continue
            try:
                if vid in self.path_replays or vid in self._finished_routes:
                    self.stop_path_replay(vid)
                self.remove_marker(vid)
                _l, item, _p = self.find_list_item_by_vehicle_id(vid)
                if item is None:
                    continue
                p = dict(b["data"])
                item.setData(Qt.UserRole, p)
                changed = True
                if b.get("route") and not getattr(self, "_closing", False):
                    self.start_route(vid, b["route"])
                elif p.get("latitude") is not None and p.get("longitude") is not None:
                    self._restore_single_marker(p, AV_ICON_PATH, "avId")
            except Exception:
                sys.excepthook(*sys.exc_info())
        if changed:
            try:
                self.save_vehicles()
            except Exception:
                sys.excepthook(*sys.exc_info())
        c0 = ct.get("climate0")
        if c0 and c0 != (self.climate or {}).get("id") and not getattr(self, "_closing", False):
            try:
                self.set_climate(c0)
            except Exception:
                sys.excepthook(*sys.exc_info())

    def _ctest_new_av(self, number):
        """An AV made for a collision test (not saved; removed when the test ends)."""
        tid = cfg.av_id(number)
        if self.find_list_item_by_vehicle_id(tid)[1] is not None:
            return tid
        data = {"type": "truck", "avId": tid, "rover": tid, "number": number, "name": f"AV {number[2:]}",
                "driveMode": "Auto Drive", "latitude": None, "longitude": None, "locationType": None,
                "locationId": None, "collisionTest": True}
        item = QListWidgetItem(data["name"])
        item.setData(Qt.UserRole, data)
        self._style_av_item(item, True)
        self.av_list.addItem(item)
        return tid

    def _ctest_remove_av(self, vid):
        try:
            self._remove_from_map(vid)
        except Exception:
            sys.excepthook(*sys.exc_info())
        lst = self.av_list
        for i in range(lst.count() - 1, -1, -1):
            if (lst.item(i).data(Qt.UserRole) or {}).get("avId") == vid:
                lst.takeItem(i)

    def _route_trail(self, route_name, drive_side=None):
        """A saved route as a road to drive: {trail [(lat, lon, heading, s)], ss, total, loop, end}. A loop route
        is laid out twice (the lane ahead runs on over its start)."""
        try:
            pts = load_route(route_name)
        except (OSError, KeyError, ValueError, TypeError) as e:
            QMessageBox.warning(self, "Collision testing", f"Route '{route_name}' could not be loaded:\n{e}")
            return None
        src = SAVED_PATHS.get(route_name)
        meta = cfg.route_meta(src) if isinstance(src, str) else {}
        loop = str(meta.get("loop", "0")) == "1"
        trail, s = [], 0.0
        for q in pts:
            if trail:
                d = _metres_between(trail[-1][0], trail[-1][1], q[0], q[1])
                if d < 0.05:
                    continue
                s += d
            trail.append((q[0], q[1], q[2], s))
        if len(trail) < 2 or s < 20:
            QMessageBox.warning(self, "Collision testing", f"Route '{route_name}' is too short ({s:.0f} m).")
            return None
        in_lane = meta.get("lane") if meta.get("lane") in ("left", "right") else None
        side = drive_side or self._drive_side()
        # (a route made along the roads is in its lane already -- "lane=left / right" in its header: not moved again)
        two_way = False if in_lane else self._route_two_way(trail)
        # on the roads' centre lines (a route made from the OpenStreetMap roads): the roads are two-way -- the AVs
        # keep to their lane too (else a car parked at the kerb or oncoming traffic stood in their way)
        on_centre = not two_way and not in_lane and self._on_road_centre([{"lat": q[0], "lon": q[1]} for q in trail])
        if in_lane:
            side = in_lane
        if two_way or on_centre:                          # out and back on the same road: drive in a lane
            trail = self._lane_offset(trail, LANE_OFFSET_M if side == "left" else -LANE_OFFSET_M)
            s = trail[-1][3]
        total = s
        if loop:
            close = _metres_between(trail[-1][0], trail[-1][1], trail[0][0], trail[0][1])
            total = s + close
            trail = trail + [(q[0], q[1], q[2], q[3] + total) for q in trail]
        return {"name": route_name, "trail": trail, "ss": [q[3] for q in trail], "total": total, "loop": loop,
                "end": trail[-1][3], "two_way": two_way, "side": side, "on_centre": on_centre}

    def _on_road_centre(self, path, samples=12, tol_m=1.0):
        """Does this path run on OpenStreetMap roads' centre lines (sampled points all within tol_m of one)?"""
        try:
            if len(path) < 3 or not self._road_lines():
                return False
            step = max(1, len(path) // samples)
            return all(self._road_snap(p["lat"], p["lon"], max_m=tol_m)[2] is not None for p in path[::step])
        except Exception:
            return False

    @staticmethod
    def _route_two_way(trail):
        """Does the route come back along the same road the other way (out and back)? Then both directions use the
        same road and the AVs must keep to their lane (else they meet head-on and stop for each other)."""
        step = max(1, len(trail) // 300)
        pts = trail[::step]
        kx = 111320.0 * math.cos(math.radians(trail[0][0]))
        xy = [((q[1] - trail[0][1]) * kx, (q[0] - trail[0][0]) * 111320.0, q[3]) for q in pts]
        hd = [math.atan2(b[0] - a[0], b[1] - a[1]) for a, b in zip(xy, xy[1:])]
        n = 0
        for i in range(len(hd)):
            for j in range(i + 1, len(hd)):
                if xy[j][2] - xy[i][2] < 40 or math.hypot(xy[i][0] - xy[j][0], xy[i][1] - xy[j][1]) > 3.0:
                    continue
                if abs((hd[i] - hd[j] + math.pi) % (2 * math.pi) - math.pi) > math.radians(120):
                    n += 1
                    if n >= 5:
                        return True
        return False

    def _drive_side(self):
        """Which side of the road vehicles keep to: app settings "drive_side", else by the yard's country (left:
        India, UK, Japan, Australia ...)."""
        v = str(cfg.APP_SETTINGS.get("drive_side") or "").lower()
        if v in ("left", "right"):
            return v
        lat, lng = (self.site_info or {}).get("center") or (0.0, 0.0)
        left = (6 <= lat <= 37 and 68 <= lng <= 98) or (49 <= lat <= 61 and -11 <= lng <= 2) or \
               (24 <= lat <= 46 and 122 <= lng <= 146) or (-45 <= lat <= -10 and 112 <= lng <= 154)
        return "left" if left else "right"

    @staticmethod
    def _lane_offset(trail, d):
        """The route moved d metres to the left (+) / right (-) of its direction of travel: the lane to drive in.
        Points that would run backwards (the inside of a sharp U-turn) are dropped."""
        if len(trail) < 3 or not d:
            return trail
        lat0 = trail[0][0]
        kx = 111320.0 * math.cos(math.radians(lat0))
        xy = [((q[1] - trail[0][1]) * kx, (q[0] - lat0) * 111320.0) for q in trail]
        out = []
        for i in range(len(xy)):
            a, b = xy[max(0, i - 1)], xy[min(len(xy) - 1, i + 1)]
            dx, dy = b[0] - a[0], b[1] - a[1]
            n = math.hypot(dx, dy) or 1.0
            ox, oy = xy[i][0] - dy / n * d, xy[i][1] + dx / n * d            # left normal (-dy, dx)
            if out:
                px, py = out[-1][0], out[-1][1]
                if (ox - px) * dx + (oy - py) * dy <= 0:                     # (it would go backwards: a cusp)
                    continue
            out.append((ox, oy))
        res, s = [], 0.0
        for x, y in out:
            lat, lng = lat0 + y / 111320.0, trail[0][1] + x / kx
            if res:
                s += _metres_between(res[-1][0], res[-1][1], lat, lng)
            res.append((lat, lng, 0.0, s))
        return res

    def start_collision_test(self, route_name, members, hold_s=10.0, temp=(), geometry=None, picked=None,
                             shown=None, drive_side=None, loops=1, plan=None, v2v=None, real=None, publish=None,
                             hw_pub=None, save=True, before=None, replay=False):
        """replay: the whole test recorded (positions, planned routes, collisions / near misses) and saved for a replay
        with its results when it ends (Reports -> Collision tests -> Replay: collision_replay).
        real: the sensors' set-up -- True real-world processing, False simulated, None the top bar's choice.
        save: the results into Reports at the end (else only the summary, with a Save button); before: the yard's
        AVs as they were (_ctest_before: put back when the test ends).
        publish: hw_publish settings (the chosen AVs' state as MQTT messages to drive hardware) or None;
        hw_pub: a running hw_publish.Publisher to go on with (Restart).
        members = [(AV id, top speed km/h, gap m, sensors)]: AV 1 at the front of the route,
        each next one behind it. They drive the route; each brakes only on its own sensors. A two-way route (out
        and back on the same road): they keep to the drive_side lane. loops: 1 once, n times, 0 until ended (a loop
        route: round and round; else: from its end all start again at its start)."""
        R = self._route_trail(route_name, drive_side)
        if R is None or not members:
            return None
        L = float(VEHICLE_DIMENSIONS.get("tractor", {}).get("length", 4.94))
        spacing = [m[2] + L for m in members[1:]]
        room = R["total"] - L - 2.0
        if sum(spacing) > room:                          # (a short route: the gaps shrink to fit)
            spacing = [x * room / sum(spacing) for x in spacing]
        s0 = [L / 2 + 1.0 + sum(spacing)]
        for x in spacing:
            s0.append(s0[-1] - x)
        for tid, *_ in members:                          # (busy elsewhere: stopped first)
            if tid in (getattr(self, "follow_tests", None) or {}):
                self.end_follow_test(tid, quiet=True)
            if tid in self.path_replays or tid in self._finished_routes:
                self.stop_path_replay(tid)
            self.remove_marker(tid)
        self.collision_tests = getattr(self, "collision_tests", None) or {}
        self.follow_tests = getattr(self, "follow_tests", None) or {}
        cid = f"ctest:{int(time.time() * 1000)}"
        ids = [m[0] for m in members]
        ct = {"route": R, "members": ids, "hold_s": float(hold_s), "temp": list(temp), "log": [], "seen": {},
              "t0": time.time(), "picked": picked if picked in ids else None,
              "shown": set(shown) if shown is not None else {"camera", "LiDAR", "radar", "V2V"},
              "id": cid, "loops": max(0, int(loops)), "lap": 1, "s0": list(s0), "finished": False,
              "plan": list(plan) if plan else None, "loop_avs": {},
              "save": bool(save), "before": dict(before or {}),
              "v2v": dict(v2v) if v2v else None,
              "real": (self.sensor_mode() == "real") if real is None else bool(real),
              "real_methods": self._real_methods_now(),
              "started": time.strftime("%Y-%m-%d %H:%M:%S"), "climate0": (self.climate or {}).get("id"),
              "climates": [(self.climate or {}).get("label", "?")],
              "lap_log": [{"loop": 1, "t0": 0.0, "t1": None, "climate": (self.climate or {}).get("label", "?")}],
              "setup": [{"id": m[0], "top_kmh": float(m[1]), "gap_m": float(m[2]),
                         "sensors": [s for s in follow_test.SENSORS_ALL if s in set(m[3])],
                         "v2v": "V2V" in set(m[3])} for m in members]}
        self.collision_tests[cid] = ct
        ct["collisions"] = []
        if replay:                                       # (positions, the window, details, camera: collision_replay)
            import collision_replay
            ct["replay"] = collision_replay.Recorder()
            ct["save"] = True                            # (a replay goes with its results: Reports -> Replay)
            self._y3d_events = []
            if not self._yard3d_timer.isActive():
                self._yard3d_timer.start(500)
        try:                                             # V2V (only if an AV uses it or scene vehicles send)
            import v2v as v2v_mod
            vcfg = dict(v2v_mod.DEFAULTS, **(v2v or {}))
            ct["v2v"] = vcfg
            ct["v2v_ch"] = v2v_mod.Channel(vcfg, self._v2v_buildings() if vcfg.get("block") else [],
                                           origin=tuple((self.site_info or {}).get("center") or R["trail"][0][:2]))
        except Exception:
            sys.excepthook(*sys.exc_info())
            ct["v2v_ch"] = None
        self._ctest_draw_route(cid)
        for k, (tid, kmh, gap, sens) in enumerate(members):
            pose = self._trail_pose(R["trail"], s0[k], R["ss"])
            self._replay_draw_start(tid, [pose], f"collision test {route_name}")
            self.path_replays[tid] = {"points": [pose], "index": 1, "timer": QTimer(self), "busy": False,
                                      "file": f"collision test {route_name}", "cum": [0.0], "loop": False,
                                      "label": f"collision test {route_name}", "interval_ms": FOLLOW_STEP_MS,
                                      "follow": True}
            ctl = follow_test.Follower(gap, kmh, set(sens), follow_test.road_grip(self.climate))
            ctl.v2v = "V2V" in set(sens)
            ctl.v2v_brake = (ct.get("v2v") or {}).get("mode", "brake") == "brake"
            timer = QTimer(self)
            timer.timeout.connect(lambda fid=tid: self._route_tick(fid))
            self.follow_tests[tid] = {"route": R, "trail": R["trail"], "s": s0[k], "leader": ids[k - 1] if k else None,
                                      "ctl": ctl, "timer": timer, "t0": time.time(), "last": time.time(),
                                      "hold_until": 0.0, "L": L, "hold_s": float(hold_s), "snap": None, "convoy": cid,
                                      "climate": (self.climate or {}).get("label", ""), "true_gap": None,
                                      "dist": 0.0, "drive_t": 0.0, "v_top_seen": 0.0, "v_hist": [],
                                      "goal_m": (int(loops) * R["total"]) if R["loop"] and int(loops) > 0 else None,
                                      "real": self._real_state() if ct["real"] else None}
            ctl._note(0.0, f"starts on {route_name} as AV {k + 1}, top speed {kmh:g} km/h, gap {gap:g} m, "
                           f"sensors: {follow_test.sensors_text(ctl.sensors)}"
                           + (f" + V2V ({'brakes on it' if ctl.v2v_brake else 'warns only'})" if ctl.v2v else "")
                           + f", climate {(self.climate or {}).get('label', '?')}")
            # something parked on the route where it starts (it cannot drive on: move that off the route)
            self._fobj_cache = None
            for o in self._follow_objects(tid):
                if o[0] in ids:
                    continue
                d = _metres_between(pose[0], pose[1], o[2], o[3])
                if d < L / 2 + float(o[4] or 4.5) / 2:
                    ctl._note(0.0, f"NOTE: {o[1]} stands on the route where this AV starts ({d:.1f} m) -- it "
                                   "blocks it; move it off the route or remove it")
            timer.start(FOLLOW_STEP_MS)
        for m in ids:                                    # loop 1 (its plan: climate, speeds, sensors, stop & go)
            self._ctest_enter_loop(cid, m, 1)
        if getattr(self, "camera_view", None) is None:   # (ready for a collision's camera image)
            try:
                self.open_camera_view(show=False)
            except Exception:
                sys.excepthook(*sys.exc_info())
        ct["lap_log"][0].update(climate=(self.climate or {}).get("label", "?"), settings=self._ctest_plan_text(ct, 1))
        self._ctest_window(cid, geometry)
        ct["timer"] = QTimer(self)
        ct["timer"].timeout.connect(lambda c=cid: self._ctest_update(c))
        ct["timer"].start(300)
        ct["cam_timer"] = QTimer(self)
        ct["cam_timer"].timeout.connect(lambda c=cid: self._ctest_camera(c))
        ct["cam_timer"].start(450)
        if ct["real"]:                                   # real-world camera: every AV's picture, in turn
            ct["rcam_timer"] = QTimer(self)
            ct["rcam_timer"].timeout.connect(lambda c=cid: self._real_cam_tick(c))
            ct["rcam_timer"].start(60)
            self._ctest_cam_live_update()
        # publish to hardware (MQTT): the settings are kept; it starts only when asked (setup "start at once", or the
        # test window's MQTT button) -- default OFF
        try:
            import hw_publish
            ct["publish"] = dict(publish or (hw_pub.cfg if hw_pub is not None else hw_publish.settings()))
            if hw_pub is not None or (publish or {}).get("on"):
                self._ctest_pub_start(cid, hw_pub)
        except Exception:
            sys.excepthook(*sys.exc_info())
        print(f"[collision test] ({'REAL-WORLD' if ct['real'] else 'simulated'} sensors) {route_name} ({'once' if loops == 1 else 'until ended' if not loops else f'{loops} loops'}"
              "): " + " -> ".join(str(self.vehicle_label(t)) for t in ids))
        return cid

    def _route_pose(self, R, s):
        return self._trail_pose(R["trail"], s, R["ss"])

    def _ctest_pub_states(self, ct):
        """[(state, status)] of the AVs chosen for publishing to hardware (hw_publish.Publisher.payload)."""
        import hw_publish
        out = []
        R = ct["route"]
        lat0, lon0 = R["trail"][0][0], R["trail"][0][1]
        now = time.time()
        for n in (ct.get("publish") or {}).get("trucks") or []:
            if not 1 <= n <= len(ct["members"]):
                continue
            tid = ct["members"][n - 1]
            ft = (self.follow_tests or {}).get(tid)
            if not ft:
                continue
            ctl = ft["ctl"]
            lat, lon, hd = self._route_pose(R, ft["s"])
            x, y = hw_publish.local_xy(lat0, lon0, lat, lon)
            h1 = self._route_pose(R, max(0.0, ft["s"] - 3.0))[2]          # (the road's curvature over 6 m)
            h2 = self._route_pose(R, min(R["end"], ft["s"] + 3.0))[2]
            curv = ((h2 - h1 + 180.0) % 360.0 - 180.0) / 6.0
            state = str(ctl.state or "")
            if ct.get("finished") or ft.get("finished") or state.startswith(("finished", "at the end")):
                status = "finished"
            elif ft.get("paused") or ct.get("paused"):
                status = "paused"
            elif now < ft.get("hold_until", 0.0):
                status = "held"
            else:
                status = "running"
            tg = ctl.target if ctl.target and (now - ft["t0"]) - ctl.target.get("t", -99) <= follow_test.HOLD_S \
                else None
            out.append(({"n": n, "id": tid, "name": str(self.vehicle_label(tid)), "lat": lat, "lon": lon,
                         "heading": hd, "x": x, "y": y, "curv": curv, "v": ctl.v, "a": ctl.a, "v_max": ctl.v_max,
                         "a_full": ctl.a_full, "state": state, "stop_go": bool(ctl.sg), "target": tg,
                         "ttc": ctl.ttc, "route": {"name": R["name"], "s": round(ft["s"], 1),
                                                   "total": round(R["total"], 1), "loop": int(ct.get("lap", 1))}},
                        status))
        return out

    def _ctest_pub_start(self, cid, hw_pub=None):
        """Start publishing the chosen AVs' state over MQTT (hw_pub: a running publisher to go on with)."""
        import hw_publish
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("hw_pub") is not None:
            return False
        ids = ct["members"]
        p = ct["publish"]
        p["trucks"] = [n for n in (p.get("trucks") or []) if 1 <= int(n) <= len(ids)]
        if not p["trucks"]:
            return False
        pub = hw_pub or hw_publish.Publisher(p, cid, ct["route"]["name"])
        pub.test_id = cid
        ct["hw_pub"] = pub
        pub.announce([(n, str(self.vehicle_label(ids[n - 1]))) for n in p["trucks"]])
        ct["pub_timer"] = QTimer(self)
        ct["pub_timer"].timeout.connect(lambda c=cid: self._ctest_publish(c))
        ct["pub_timer"].start(max(40, int(1000 / max(1, int(p.get("rate_hz", 10))))))
        p["on"] = True
        print(f"[collision test] MQTT publishing STARTED to {p['host']}:{p['port']}: "
              + ", ".join(hw_publish.topic_of(p, n) for n in p["trucks"]))
        return True

    def _ctest_pub_stop(self, cid):
        """Stop publishing: each AV's last message 'ended' (speed 0, brake on), status offline, disconnected."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct:
            return
        if ct.get("pub_timer") is not None:
            ct["pub_timer"].stop(); ct["pub_timer"].deleteLater()
            ct["pub_timer"] = None
        pub = ct.pop("hw_pub", None)
        if pub is not None:
            try:
                pub.close(self._ctest_pub_states(ct))
                print(f"[collision test] MQTT publishing STOPPED ({pub.sent} messages)")
            except Exception:
                sys.excepthook(*sys.exc_info())
        if ct.get("publish") is not None:
            ct["publish"]["on"] = False

    def _ctest_mqtt(self, cid, settings=False):
        """The test window's MQTT button: start / stop publishing; settings=True (or nothing chosen yet): the
        publish settings first (broker, AVs, topics)."""
        import hw_publish
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct:
            return
        running = ct.get("hw_pub") is not None
        if running and not settings:
            self._ctest_pub_stop(cid)
            self._ctest_update(cid)
            return
        p = ct.get("publish") or hw_publish.settings()
        if settings or not [n for n in (p.get("trucks") or []) if 1 <= int(n) <= len(ct["members"])]:
            trucks = [(k + 1, str(self.vehicle_label(m))) for k, m in enumerate(ct["members"])]
            d = hw_publish.make_dialog(ct.get("window") or self, trucks, dict(p), in_test=True)
            if d.exec_() != QDialog.Accepted:
                return
            v = d.values()
            hw_publish.save_settings(v)
            if running:                                      # (new settings: again with them)
                self._ctest_pub_stop(cid)
            ct["publish"] = dict(v, on=False)
            if not (running or not settings):
                self._ctest_update(cid)
                return
        if not self._ctest_pub_start(cid):
            QMessageBox.information(ct.get("window") or self, "MQTT publishing",
                                    "No AV is chosen for publishing: MQTT settings ... -> tick the AVs.")
        self._ctest_update(cid)

    def _ctest_publish(self, cid):
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        pub = (ct or {}).get("hw_pub")
        if pub is None:
            return
        try:
            pub.publish(self._ctest_pub_states(ct))
        except Exception:
            sys.excepthook(*sys.exc_info())

    # ---- the test's route and its collisions on the map ----
    COLLISION_MAP_JS = """
    if (!window.collisionMarker) {
        var st = document.createElement('style');
        st.textContent = '.coll-mark{background:none;border:none}' +
          '.coll-mark div{width:26px;height:26px;border-radius:13px;background:#DC2626;color:#fff;font:700 12px/22px ' +
          'Segoe UI,Arial;text-align:center;border:2px solid #fff;box-shadow:0 0 0 3px rgba(220,38,38,.35),0 2px 6px ' +
          'rgba(0,0,0,.5)}' +
          '.coll-mark.focus div{animation:collPulse .7s ease-in-out infinite alternate}' +
          '@keyframes collPulse{from{box-shadow:0 0 0 3px rgba(220,38,38,.35)}to{box-shadow:0 0 0 14px rgba(220,38,38,0)}}';
        document.head.appendChild(st);
        window.collMarkers = {};
        window.collisionMarker = function (map, key, lat, lng, num, html, focus, other) {
            var old = window.collMarkers[key];
            if (old) { old.forEach(function (l) { map.removeLayer(l); }); }
            var icon = L.divIcon({className: 'coll-mark' + (focus ? ' focus' : ''), html: '<div>' + num + '</div>',
                                  iconSize: [26, 26], iconAnchor: [13, 13]});
            var m = L.marker([lat, lng], {icon: icon, zIndexOffset: 1500, title: 'Collision ' + num}).addTo(map);
            m.bindPopup(html, {maxWidth: 360});
            var ls = [m];
            if (other) {
                ls.push(L.circleMarker(other, {radius: 6, color: '#FBBF24', weight: 2, fillOpacity: 0.6}).addTo(map));
                ls.push(L.polyline([[lat, lng], other], {color: '#FBBF24', weight: 2, dashArray: '4 4'}).addTo(map));
            }
            window.collMarkers[key] = ls;
            if (focus) { map.setView([lat, lng], Math.max(map.getZoom(), 19)); m.openPopup(); }
        };
        window.clearCollisionMarkers = function (map, prefix) {
            Object.keys(window.collMarkers).forEach(function (k) {
                if (!prefix || k.indexOf(prefix) === 0) {
                    window.collMarkers[k].forEach(function (l) { map.removeLayer(l); });
                    delete window.collMarkers[k];
                }
            });
        };
    }
    """

    def _ctest_draw_route(self, cid):
        """The collision test's route on the map (the lane the AVs drive: cyan) with its start."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct:
            return
        R = ct["route"]
        pts, last = [], None
        for q in R["trail"]:
            if q[3] > R["total"] + 0.5:
                break
            if last is None or q[3] - last >= 2.0:
                pts.append([round(q[0], 7), round(q[1], 7)])
                last = q[3]
        if R["loop"] and pts:
            pts.append(pts[0])
        if len(pts) < 2:
            return
        m = self.map_var_name
        self.browser.page().runJavaScript(f"""
        (function(){{
            window.ctestLayers = window.ctestLayers || {{}};
            var old = window.ctestLayers[{json.dumps(cid)}];
            if (old) {{ old.forEach(function(l){{ {m}.removeLayer(l); }}); }}
            var pts = {json.dumps(pts)};
            var under = L.polyline(pts, {{color: '#0E7490', weight: 7, opacity: 0.45, interactive: false}}).addTo({m});
            var line = L.polyline(pts, {{color: '#22D3EE', weight: 3, opacity: 0.95, dashArray: '10 6',
                                        interactive: false}}).addTo({m});
            var start = L.circleMarker(pts[0], {{radius: 7, color: '#fff', weight: 2, fillColor: '#16A34A',
                                                fillOpacity: 1}}).addTo({m});
            start.bindTooltip({json.dumps("Collision test start: " + R["name"])});
            window.ctestLayers[{json.dumps(cid)}] = [under, line, start];
        }})();""")

    def _ctest_clear_map(self, cid):
        m = self.map_var_name
        self.browser.page().runJavaScript(f"""
        (function(){{
            var old = window.ctestLayers && window.ctestLayers[{json.dumps(cid)}];
            if (old) {{ old.forEach(function(l){{ {m}.removeLayer(l); }}); delete window.ctestLayers[{json.dumps(cid)}]; }}
            if (window.clearCollisionMarkers) window.clearCollisionMarkers({m}, {json.dumps(cid + "#")});
        }})();""")

    COLLISION_LOG = "collision_tests.jsonl"

    def _ctest_record_collision(self, fid, ft, near, v, me, objs, t):
        """Everything about a collision of a test AV, kept to re-check it later (the window's Collisions list,
        Collision history): where, what, speeds, what each sensor saw or why not, the reason, a bird's-eye snapshot.
        Saved in this yard's logs/collision_tests.jsonl."""
        ct = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy"))
        ctl = ft["ctl"]
        tg = ctl.target if ctl.target and t - ctl.target["t"] <= follow_test.HOLD_S else None
        ob = next((o for o in objs if str(o[0]) == str(near[1])), None)
        label = near[2]
        by = (tg or {}).get("by") or {}
        seen_by = {s: round(float(by[s]), 1) for s in follow_test.SENSORS_ALL if by.get(s) is not None}
        sensors = [s for s in follow_test.SENSORS_ALL if s in ctl.sensors]
        need = v * v / (2.0 * max(0.5, ctl.a_full))
        other_v = float(ob[9]) if ob is not None and len(ob) > 9 and ob[9] else 0.0
        why = {s: self._why_not(ft, s) for s in follow_test.SENSORS_ALL}
        if not sensors:
            reason = f"All its sensors were switched OFF -- nothing could detect {label}."
            kind = "sensors off"
        elif v < 0.8:
            reason = (f"{label} moved into the AV while the AV almost stood ({v * 3.6:.0f} km/h) -- the other "
                      f"one did not give way ({other_v * 3.6:.0f} km/h).")
            kind = "hit by the other"
        elif tg and str(tg.get("id")) == str(near[1]):
            reason = (f"Detected too late: at {v * 3.6:.0f} km/h the AV needs {need:.1f} m to stop (full brake "
                      f"{ctl.a_full:.1f} m/s², road grip {ctl.grip:.0%}) -- "
                      + ("it came into the lane closer than that (crossing / cutting in / out of a bend)."
                         if other_v > 0.5 else "it was detected closer than that."))
            kind = "detected too late"
        elif tg:
            reason = (f"It was braking for {tg.get('label')} and did NOT detect {label} -- "
                      + "; ".join(f"{s}: {why[s]}" for s in sensors))
            kind = "not detected"
        else:
            reason = f"{label} was NOT detected by any switched-on sensor -- " + "; ".join(f"{s}: {why[s]}" for s in sensors)
            kind = "not detected"
        try:
            view, table = self._follow_sensor_view(fid)
        except Exception:
            view, table = None, []
        if view:
            view = dict(view, on=sorted(view.get("on") or []),
                        objs=[dict(o, det=sorted(o.get("det") or [])) for o in view.get("objs", [])],
                        hit=str(near[1]), span=28.0, ego_label=str(self.vehicle_label(fid)))
        members = (ct or {}).get("members") or []
        rec = {
            "test": ft.get("convoy"), "n": len((ct or {}).get("collisions", [])) + 1,
            "time": time.strftime("%Y-%m-%d %H:%M:%S"), "t": round(t, 1), "yard": cfg.ACTIVE_SITE,
            "route": ((ct or {}).get("route") or {}).get("name"), "s": round(ft["s"], 1),
            "truck": str(self.vehicle_label(fid)), "truck_id": fid,
            "truck_no": members.index(fid) + 1 if fid in members else None,
            "hit": str(label), "hit_id": str(near[1]), "hit_kind": (ob[6] if ob is not None else "object"),
            "lat": me[0], "lng": me[1], "heading": round(me[2], 1),
            "other": [ob[2], ob[3]] if ob is not None else None,
            "speed_kmh": round(v * 3.6, 1), "other_kmh": round(other_v * 3.6, 1), "stop_dist_m": round(need, 1),
            "climate": (self.climate or {}).get("label", ""), "grip": round(ctl.grip, 2),
            "sensors": sensors, "seen_by": seen_by,
            "why": {s: (why[s] if s in sensors else "switched OFF") for s in follow_test.SENSORS_ALL if s not in seen_by},
            "kind": kind, "reason": reason, "min_ttc": ctl.stats.get("min_ttc"),
            "log": [[round(a, 1), b] for a, b in ctl.log[-8:]], "view": view, "table": table,
            "lap": ft.get("lap_i") or (ct or {}).get("lap"),
        }
        try:
            self._ctest_verify(ft, rec, ob, why)
        except Exception:
            sys.excepthook(*sys.exc_info())
        try:
            rec["other_info"] = self._ctest_other_info(fid, ft, ob, me, near)
        except Exception:
            sys.excepthook(*sys.exc_info())
        try:
            v = self._ctest_v2v_record(ct, fid, ft, near[1], time.time())
            if v is not None:
                rec["v2v"] = v
                rec.pop("_cls", None)
                import collision_panel                    # (the check / how to avoid it: with the V2V facts)
                rec.update(collision_panel.classify(rec))
        except Exception:
            sys.excepthook(*sys.exc_info())
        if ct is not None:
            ct.setdefault("collisions", []).append(rec)
        self.show_collision_on_map(rec, focus=False)
        # the camera image of this moment (the AV's collision camera, its detections drawn), then saved
        QTimer.singleShot(14000, lambda r=rec: self._ctest_flush_rec(r))
        try:
            self._ctest_collision_shot(fid, rec)
        except Exception:
            sys.excepthook(*sys.exc_info())
            self._ctest_flush_rec(rec)
        return rec

    SHOT_TRIES = 20                                           # a collision's camera image: tried for ~12 s

    def _ctest_flush_rec(self, rec):
        """A collision record into the yard's logs/collision_tests.jsonl (once: with its camera image when it came)."""
        if rec.get("_saved"):
            return
        rec["_saved"] = True
        if not any(not r.get("_saved") for ct in (getattr(self, "collision_tests", None) or {}).values()
                   for r in ct.get("collisions") or []):
            self._ctest_shot_until = 0.0                      # (no image awaited: the camera page's feed as before)
            if not getattr(self, "_closing", False):
                QTimer.singleShot(0, self._after_camera_panel_change)
        try:
            os.makedirs(cfg.LOG_DIR, exist_ok=True)
            with open(os.path.join(cfg.LOG_DIR, self.COLLISION_LOG), "a", encoding="utf-8") as f:
                f.write(json.dumps({k: v for k, v in rec.items() if not k.startswith("_")}, default=str) + "\n")
        except Exception as e:
            print(f"[collision test] collision not saved: {e}")

    def _ctest_collision_shot(self, fid, rec, tries=0):
        """The colliding AV's collision camera at that moment (rendered on the Camera View page, which is opened
        hidden if needed) -> rec["camera"] = {file (jpg), overlay (its detection boxes / misses), calc, label}."""
        if rec.get("_saved") or getattr(self, "_closing", False):
            return
        if tries == 0:                                        # (the camera page gets live positions meanwhile)
            self._ctest_shot_until = time.time() + 14.0
            if getattr(self, "camera_view", None) is None:
                self.open_camera_view(show=False)
            else:
                self._after_camera_panel_change()
        if getattr(self, "camera_view", None) is None:
            if tries < self.SHOT_TRIES:
                QTimer.singleShot(600, lambda: self._ctest_collision_shot(fid, rec, tries + 1))
            else:
                self._ctest_flush_rec(rec)
            return
        confs = self._ctest_cams(configs=True)
        ct = (getattr(self, "collision_tests", None) or {}).get(rec.get("test")) or {}
        conf = confs[min(ct.get("cam_sel", 0), len(confs) - 1)]
        cam_keys = ("x_left_cm", "y_cm", "z_cm", "yaw_deg", "pitch_deg", "hfov_deg", "vfov_deg", "origin_height_m")
        opt = {"id": fid, "w": 800, "quality": 80, "cam": {k: conf[k] for k in cam_keys if conf.get(k) is not None}}

        def shoot(objects):
            try:
                self._send_yard3d_dynamic(objects)
            except Exception:
                sys.excepthook(*sys.exc_info())
            if getattr(self, "camera_view", None) is not None:
                self.camera_view.page().runJavaScript(
                    f"window.frontCamShot ? window.frontCamShot({json.dumps(opt)}) : null",
                    lambda res: self._ctest_collision_shot_result(fid, rec, conf, res, tries))
        self.browser.page().runJavaScript(self._objects_js(), shoot)

    def _ctest_collision_shot_result(self, fid, rec, conf, res, tries):
        import base64
        if rec.get("_saved") or getattr(self, "_closing", False):
            return
        if not isinstance(res, dict) or not res.get("jpeg"):
            if tries < self.SHOT_TRIES:                       # (the camera page still loading its scene)
                QTimer.singleShot(600, lambda: self._ctest_collision_shot(fid, rec, tries + 1))
            else:
                print(f"[collision test] no camera image for collision {rec.get('n')}: "
                      f"{(res or {}).get('err') if isinstance(res, dict) else 'the camera page did not answer'}")
                self._ctest_flush_rec(rec)
            return
        try:
            d = os.path.join(cfg.LOG_DIR, "collision_images")
            os.makedirs(d, exist_ok=True)
            name = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{rec.get('test')}_{rec.get('n')}") + ".jpg"
            path = os.path.join(d, name)
            with open(path, "wb") as f:
                f.write(base64.b64decode(res["jpeg"]))
            overlay, calc = (self._camera_overlay(fid, res, conf) if fid in (self.follow_tests or {})
                             else ({"w": res["w"], "h": res["h"], "boxes": []}, {}))
            rec["camera"] = {"file": path, "overlay": overlay, "calc": calc,
                             "label": conf.get("label") or conf.get("id") or "camera"}
        except Exception:
            sys.excepthook(*sys.exc_info())
        try:                                                  # then the accident scene: both vehicles from outside
            self._ctest_scene_shot(fid, rec)
        except Exception:
            sys.excepthook(*sys.exc_info())
            self._ctest_flush_rec(rec)

    def _ctest_scene_shot(self, fid, rec):
        """The accident scene in 3D (the camera page): both vehicles from the side, from above and from the other
        one -> rec["scene"] = [{name, title, file, w, h, boxes}], then the record is saved."""
        import base64
        opt = {"id": fid, "other": rec.get("hit_id"), "w": 800, "quality": 80}

        def done(res):
            if rec.get("_saved") or getattr(self, "_closing", False):
                return
            try:
                if isinstance(res, dict) and res.get("views"):
                    d = os.path.join(cfg.LOG_DIR, "collision_images")
                    os.makedirs(d, exist_ok=True)
                    base = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{rec.get('test')}_{rec.get('n')}")
                    out = []
                    for v in res["views"]:
                        p = os.path.join(d, f"{base}_{v['name']}.jpg")
                        with open(p, "wb") as f:
                            f.write(base64.b64decode(v["jpeg"]))
                        out.append({"name": v["name"], "title": v["title"], "file": p, "w": v["w"], "h": v["h"],
                                    "boxes": v.get("boxes") or []})
                    rec["scene"] = out
                elif isinstance(res, dict) and res.get("err"):
                    print(f"[collision test] no accident scene for collision {rec.get('n')}: {res['err']}")
            except Exception:
                sys.excepthook(*sys.exc_info())
            self._ctest_flush_rec(rec)
        if getattr(self, "camera_view", None) is None:
            self._ctest_flush_rec(rec)
            return
        self.camera_view.page().runJavaScript(
            f"window.accidentShot ? window.accidentShot({json.dumps(opt)}) : null", done)

    def _ctest_other_info(self, fid, ft, ob, me, near):
        """The vehicle / obstacle the test AV collided with: what it is, its size, speed, heading, where each
        was hit (the AV's front on its rear / side / front), and -- another test AV -- its own state."""
        if ob is None:
            return {"label": str(near[2]), "id": str(near[1]), "kind": "object"}
        o = follow_test._obj(ob)
        x, y = follow_test._local(me, o["lat"], o["lon"])          # (forward, left of the AV)
        brg = math.degrees(math.atan2(y, x))
        where_on_truck = ("front" if abs(brg) <= 35 else "front-left corner" if 35 < brg <= 70 else
                          "front-right corner" if -70 <= brg < -35 else "left side" if brg > 0 else "right side")
        info = {"id": str(o["id"]), "label": str(o["label"]), "kind": o["kind"], "length_m": round(o["L"], 2),
                "width_m": round(o["W"], 2), "moving": bool(o["moving"]),
                "speed_kmh": round(o["speed"] * 3.6, 1), "on_truck": where_on_truck,
                "distance_m": round(math.hypot(x, y), 1), "bearing_deg": round(brg, 0)}
        if o.get("heading") is not None:
            rel = (float(o["heading"]) - float(me[2]) + 180.0) % 360.0 - 180.0
            info["heading_deg"] = round(float(o["heading"]), 0)
            info["rel_heading_deg"] = round(rel, 0)
            # the AV in the other's frame: which part of the other was hit
            a = math.radians(rel)                                    # (compass: clockwise; AV frame y: left)
            tx, ty = -x, -y                                          # (the AV, seen from the other: AV frame)
            fx = tx * math.cos(a) - ty * math.sin(a)                 # (along the other's heading)
            fy = tx * math.sin(a) + ty * math.cos(a)                 # (to the other's left)
            part = ("rear" if fx < -o["L"] / 4 else "front" if fx > o["L"] / 4 else
                    ("left side" if fy > 0 else "right side"))
            info["on_other"] = part
            info["type"] = ("rear-end (both the same way)" if abs(rel) <= 30 and part == "rear" else
                            "head-on" if abs(rel) >= 150 else
                            "side impact (crossing)" if 60 <= abs(rel) <= 120 else
                            "glancing / at an angle")
        if not o["moving"] or o["speed"] < 0.3:
            info["type"] = info.get("type") if o["moving"] else "it stood still (parked / static obstacle)"
            info["state"] = "standing"
        other_ft = (getattr(self, "follow_tests", None) or {}).get(o["id"])
        if other_ft:                                                 # another AV of the test
            c = other_ft["ctl"]
            members = (self.collision_tests.get(ft.get("convoy")) or {}).get("members") or []
            info.update(test_truck=True, truck_no=members.index(o["id"]) + 1 if o["id"] in members else None,
                        sensors=[s for s in follow_test.SENSORS_ALL if s in c.sensors], state=c.state,
                        top_kmh=round(c.v_max * 3.6, 1), stop_and_go=bool(c.sg))
        st = (getattr(self, "dynamic_objects", None) or {}).get(o["id"])
        if st is not None:                                           # a moving obstacle of the scene
            info["scene_object"] = True
            info["giving_way"] = bool(st.get("yielding"))
        return info

    def _ctest_verify(self, ft, rec, ob, why):
        """Why the collision happened -- each factor checked (rec["verify"]) and the main one (rec["cause"]):
        sensor failure (a sensor switched OFF that would have detected it in time in this climate), climate (it cut
        a switched-on sensor's range below the distance the AV needed to stop, which clear weather would have
        given; or the wet road's grip made the stop too long), the other obstacle / vehicle (moving into the AV,
        crossing / cutting in, hidden behind another), or the sensors' range / field of view for this speed even
        in clear weather."""
        ctl = ft["ctl"]
        clim = self.climate or {}
        hist = ft.get("v_hist") or []
        v_ref = max([x[1] for x in hist] + [rec["speed_kmh"] / 3.6])        # (its speed before it braked)
        need = v_ref * v_ref / (2.0 * max(0.5, ctl.a_full)) + follow_test.STOP_GAP_M
        need_dry = v_ref * v_ref / (2.0 * follow_test.A_FULL) + follow_test.STOP_GAP_M
        o = follow_test._obj(ob) if ob is not None else None
        rcs = follow_test.radar_rcs_db(o["kind"], o["W"]) if o else None
        static = bool(o and not o["moving"])
        cam = self._ctest_cams()[0]
        ranges = {"LiDAR": (follow_test.lidar_range(clim), follow_test.lidar_range(None)),
                  "camera": (follow_test.camera_range(clim, cam), follow_test.camera_range(None, cam)),
                  "radar": (follow_test.radar_range(clim, rcs_db=rcs, static=static),
                            follow_test.radar_range(None, rcs_db=rcs, static=static))}
        firsts = ctl.stats.get("first_seen") or []
        rec.update({
            "approach_kmh": round(v_ref * 3.6, 1), "need_m": round(need, 1), "need_dry_m": round(need_dry, 1),
            "ranges": {s: [round(a, 1), round(b, 1)] for s, (a, b) in ranges.items()},
            "why_all": dict(why),                       # (every sensor's reason -- also those switched off)
            "first_seen_m": float(firsts[-1]) if firsts and rec["kind"] == "detected too late" else None})
        import collision_panel                          # the cause, the check, the short reason, how to avoid it
        rec.update(collision_panel.classify(rec))

    # ---- V2V (collision testing only: v2v.py) ----
    V2V_VEHICLE_KINDS = ("car", "truck", "bus", "van", "vehicle", "trailer", "tractor", "lorry", "jeep", "auto")

    def _v2v_buildings(self):
        if getattr(self, "_v2v_bld", None) is None:
            try:
                self._v2v_bld = (osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE) or {}).get("buildings") or []
            except Exception:
                self._v2v_bld = []
        return self._v2v_bld

    def _ctest_v2v_step(self, ct, now):
        """The test's V2V once per tick (shared by its AVs): who sends (test AVs with V2V on, the share of the
        scene's vehicles that is connected), to whom (every test AV -- also those with V2V off, so a collision can
        say what V2V would have known), the channel; alerts / lost alerts into the receivers' logs."""
        ch = ct.get("v2v_ch")
        if ch is None or now - ct.get("v2v_t", 0.0) < 0.02:
            return
        ct["v2v_t"] = now
        senders, receivers, members = [], {}, set(ct["members"])
        for m in ct["members"]:
            f = self.follow_tests.get(m)
            if not f:
                continue
            c = f["ctl"]
            pose = self._route_pose(f["route"], f["s"])
            receivers[m] = (pose[0], pose[1])
            if c.v2v:
                held = now < f["hold_until"]
                sgb = bool(c.sg and c.sg.get("phase") == "brake")
                senders.append({"id": m, "label": str(self.vehicle_label(m)), "lat": pose[0], "lon": pose[1],
                                "hd": pose[2], "v": c.v, "a": c.a, "L": f["L"], "brake": held or sgb})
        pct = float((ct.get("v2v") or {}).get("connected_pct") or 0)
        if pct > 0:
            import v2v as v2v_mod
            prev = ct.setdefault("v2v_prev", {})
            for o in self._follow_objects("__v2v__"):
                if o[0] in members or not v2v_mod.connected(o[0], pct):
                    continue
                kind = str(o[6] if len(o) > 6 else "").lower()
                if not any(k in kind for k in self.V2V_VEHICLE_KINDS):
                    continue                              # (pedestrians, cones, barriers: no V2V)
                v = float(o[9] or 0.0) if len(o) > 9 else 0.0
                pv = prev.get(o[0])
                a = (v - pv[1]) / (now - pv[0]) if pv and now - pv[0] > 0.05 else 0.0
                if not pv or now - pv[0] > 0.05:
                    prev[o[0]] = (now, v)
                senders.append({"id": o[0], "label": str(o[1]), "lat": o[2], "lon": o[3],
                                "hd": o[8] if len(o) > 8 else None, "v": v, "a": a, "L": float(o[4] or 4.5)})
        ch.step(now, senders, receivers, self.climate)
        n0 = ct.get("v2v_ev_n", 0)
        for t_, rx, tx, kind, text in ch.events[n0:]:
            f = self.follow_tests.get(rx)
            if f and f["ctl"].v2v:
                f["ctl"]._note(now - f["t0"], "V2V: " + text + ("" if f["ctl"].v2v_brake or kind != "alert" else
                                                                " -- WARNING only (V2V does not brake)"))
        ct["v2v_ev_n"] = len(ch.events)

    def _ctest_v2v_dets(self, ct, fid, ft, me, s, horizon, now):
        """What V2V tells this AV: the connected vehicles in its lane ahead (from their reported positions /
        speeds; a brake alert: the speed they brake to soon) -> detections like the sensors' (sensor "V2V").
        Also kept for the AV even with V2V off (ft["v2v_ahead"]): what V2V would have told it."""
        import v2v as v2v_mod
        ch = ct.get("v2v_ch")
        if ch is None:
            return []
        ctl = ft["ctl"]
        msgs = ch.inbox(fid, now)
        # (lane matching as a V2V receiver does it: the reported position is off by the GNSS error -- a sender going
        #  the same way, within the lane + 1.5 x that error beside its road, is taken as in its lane)
        sigma = v2v_mod.GNSS.get((ct.get("v2v") or {}).get("gnss", "navic"), ("", 2.5))[1]
        tol = follow_test.CORRIDOR_HALF_M + 1.5 * sigma
        raw = [{"id": m["tx"], "label": m["label"], "lat": m["lat"], "lng": m["lon"], "_m": m} for m in msgs]
        out = []
        R = ft.get("route") or {}
        use = {str(m["tx"]): "behind it / not on its route ahead -- not used" for m in msgs}   # (detection details)
        for d in self._on_trail(ft["trail"], s, horizon, raw, R.get("ss")):
            m = d["_m"]
            # (its direction against the ROUTE's direction where it is placed -- an out-and-back route passes the
            #  same road twice: an AV behind going the same way lies on the way back too, going against it there)
            if R.get("trail"):
                a_ = self._route_pose(R, s + max(0.0, d["x"] - 1.0))
                b_ = self._route_pose(R, s + d["x"] + 1.0)
                road_hd = math.degrees(math.atan2((b_[1] - a_[1]) * math.cos(math.radians(a_[0])), b_[0] - a_[0])) % 360
            else:
                road_hd = me[2]
            hd = m["hd"] if m.get("hd") is not None else road_hd
            rel_deg = (hd - road_hd + 540.0) % 360.0 - 180.0
            v_al = m["v"] * math.cos(math.radians(rel_deg))
            if m["brake"]:
                v_al = max(0.0, v_al + min(0.0, m["a"]) * v2v_mod.ANTICIPATE_S)
            gap = d["x"] - ft["L"] / 2 - m["L"] / 2
            if abs(rel_deg) > 90.0:
                use[str(m["tx"])] = "coming the other way there -- not used"
                continue                                  # (coming the other way there: not in its lane ahead)
            y = 0.0 if abs(d["y"]) <= tol and abs(rel_deg) <= 35.0 else d["y"]
            use[str(m["tx"])] = ((f"IN ITS LANE {max(0.0, gap):.1f} m ahead -- "
                                  + ("used for braking" if ctl.v2v_brake else "warning only"))
                                 if abs(y) <= follow_test.CORRIDOR_HALF_M else
                                 f"{max(0.0, gap):.0f} m ahead but {abs(d['y']):.1f} m beside its lane (more than the "
                                 f"GNSS tolerance {tol:.1f} m) -- not used")
            out.append({"id": m["tx"], "label": m["label"], "x": d["x"], "y": y, "y_reported": d["y"],
                        "gap": max(0.0, gap), "v_rel": v_al - ctl.v, "age": m["age"], "delay": m["delay"],
                        "brake": m["brake"], "v": float(m["v"]), "sensor": "V2V"})   # (v: the sender's own speed)
        # the first V2V knowledge of each vehicle in its lane (an approach: reset after 3 s without it)
        seen = ft.setdefault("v2v_seen", {})
        lane = {d["id"]: d for d in out if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M}
        for i, d in lane.items():
            e = seen.get(i)
            if e is None or now - e["last"] > 3.0:
                e = seen[i] = {"first_t": now, "first_gap": d["gap"], "last": now, "gap": d["gap"], "brake": False}
            else:
                e.update(last=now, gap=d["gap"])
            if d["brake"] and not e.get("brake"):         # (it started braking: where V2V knew it then)
                e.update(brake_t=now, brake_gap=d["gap"])
            e["brake"] = bool(d["brake"])
        ft["v2v_ahead"] = sorted(lane.values(), key=lambda d: d["gap"])
        ft["v2v_n"] = len(msgs)
        ft["v2v_use"] = use
        return out

    def _v2v_ranges(self, ob_kind=None, moving=True):
        cam = self._ctest_cams()[0]
        clim = self.climate or {}
        rcs = follow_test.radar_rcs_db(ob_kind or "truck", 2.5)
        return {"LiDAR": (follow_test.lidar_range(clim), follow_test.lidar_range(None)),
                "camera": (follow_test.camera_range(clim, cam), follow_test.camera_range(None, cam)),
                "radar": (follow_test.radar_range(clim, rcs_db=rcs, static=not moving),
                          follow_test.radar_range(None, rcs_db=rcs, static=not moving))}

    V2V_CF_REACTION_S = 0.5      # without V2V: from a sensor's first sight to full braking (scan rate, confirming, the
                                 # brakes building up) -- the estimate of the impact without V2V uses it

    def _v2v_episode(self, fid, ft, t, now, near, me):
        """A collision PREVENTED by V2V (the proof for the results): the AV brakes for a vehicle it knows ONLY
        from V2V (none of its sensors detects it then), no collision follows, and its sensors saw it later -- if at
        all -- closer than it needed to stop from that speed. Then: what V2V told it and when, where each sensor
        first saw it or why not, and the impact speed without V2V (full braking only from where the sensors saw it)
        -> the test's "v2v_saves"."""
        ctl = ft["ctl"]
        ct = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy"))
        if not ct:
            return
        tg = ctl.target if ctl.target and t - ctl.target["t"] <= follow_test.HOLD_S else None
        by = (tg or {}).get("by") or {}
        sens_now = [s for s in follow_test.SENSORS_ALL if s in by]
        ep = ft.get("v2v_ep")
        if ep is None:
            det = next((d for d in ((ft.get("seen") or {}).get("raw") or {}).get("V2V") or []
                        if tg and str(d.get("id")) == str(tg["id"])), {}) if tg else {}
            v_lead = max(0.0, ctl.v + float((tg or {}).get("v_rel") or 0.0)) if tg else 0.0
            # a hazard known ONLY from V2V: the vehicle ahead stops / brakes hard (its brake alert), none of the
            # AV's sensors sees it -- without V2V the AV would know nothing ahead and drive at its top speed
            blk = ft.get("v2v_block")                           # (one record per hazard: it must drive off first)
            if blk and (not tg or str(tg["id"]) != blk or v_lead > 2.0):
                ft["v2v_block"] = blk = None if (not tg or v_lead > 2.0 or str(tg["id"]) != blk) else blk
            # a vehicle standing ahead counts only when the AV would reach it soon (not e.g. at the test's start,
            # where the one ahead is still pulling away from standstill): within ~6 s at the speed it closes in
            closing = ctl.v - v_lead
            soon = tg and "V2V" in by and closing > 1.0 and float(by["V2V"]) / closing < 6.0
            goal = ft.get("goal_m")                             # (the last loop: it stops at its own end anyway --
            if soon and goal is not None and goal - ft.get("dist", 0.0) <= float(by["V2V"]) + 5.0:   # nothing
                soon = False                                    #  to prevent before the one standing ahead)
            # (standing: the sender's own speed from its V2V message -- not the speed along our path, which reads
            #  ~0 where the road turns back, e.g. at a two-way route's turnaround)
            standing = (float(det["v"]) < 0.5) if det.get("v") is not None else v_lead < 0.5
            hazard = tg and "V2V" in by and not sens_now and ctl.v2v_brake and (det.get("brake") or (standing and soon)) \
                and max(ctl.v, ctl.v_max) - v_lead > 1.0 and ctl.v > 1.0 and str(tg["id"]) != blk
            if hazard:
                ob = next((o for o in (ft.get("seen") or {}).get("objs") or [] if str(o[0]) == str(tg["id"])), None)
                o = follow_test._obj(ob) if ob is not None else {"kind": "vehicle", "moving": True}
                v_cf = max(ctl.v, ctl.v_max)                      # (without V2V: its top speed, nothing known)
                v_c = max(0.0, v_cf - v_lead)
                need = (v_c * self.V2V_CF_REACTION_S + v_c * v_c / (2.0 * max(0.5, ctl.a_full))
                        + follow_test.STOP_GAP_M)
                try:
                    view, _tab = self._follow_sensor_view(fid)
                    if view:
                        view = dict(view, on=sorted(view.get("on") or []), hit=str(tg["id"]), span=max(30.0, by["V2V"] + 12),
                                    hit_label="KNOWN ONLY BY V2V", hit_col="#34D399",
                                    objs=[dict(x, det=sorted(x.get("det") or [])) for x in view.get("objs", [])],
                                    ego_label=str(self.vehicle_label(fid)))
                except Exception:
                    view = None
                ft["v2v_ep"] = {
                    "id": str(tg["id"]), "label": str(tg.get("label")), "t0": t, "last_same": t, "v0": ctl.v,
                    "v_cf": v_cf, "v_c": v_c, "v_lead": v_lead,
                    "v2v_gap": float(by["V2V"]), "true_gap0": near[0] if near and str(near[1]) == str(tg["id"]) else None,
                    "need": need, "a_full": ctl.a_full, "min_gap": 1e9, "min_ttc": None, "max_dec": 0.0,
                    "sensor_t": None, "sensor_gap": None, "sensor_by": [], "collided": False,
                    "brake_alert": bool(det.get("brake")), "age_ms": round(1000 * float(det.get("age") or 0)),
                    "delay_ms": round(1000 * float(det.get("delay") or 0)),
                    "sensors_on": [s for s in follow_test.SENSORS_ALL if s in ctl.sensors],
                    "ranges": {k: [round(a, 1), round(b, 1)] for k, (a, b) in
                               self._v2v_ranges(o["kind"], o["moving"]).items()},
                    "why": {s: (self._why_not(ft, s) if s in ctl.sensors else "switched OFF for this test")
                            for s in follow_test.SENSORS_ALL},
                    "lat": me[0], "lng": me[1], "view": view, "climate": (self.climate or {}).get("label", ""),
                    "other_kmh": round(max(0.0, ctl.v + float(tg.get("v_rel") or 0.0)) * 3.6, 1)}
            return
        same = bool(tg) and str(tg["id"]) == ep["id"]
        if same:
            ep["last_same"] = t
            ep["v_lead_min"] = min(ep.get("v_lead_min", ep["v_lead"]),
                                   max(0.0, ctl.v + float(tg.get("v_rel") or 0.0)) if tg.get("v_rel") is not None
                                   else ep["v_lead"])
            ep["brake_alert"] = ep["brake_alert"] or bool(next(
                (d.get("brake") for d in ((ft.get("seen") or {}).get("raw") or {}).get("V2V") or []
                 if str(d.get("id")) == ep["id"]), False))
        if near and str(near[1]) == ep["id"]:
            ep["min_gap"] = min(ep["min_gap"], float(near[0]))
            if near[0] <= 0.2:
                ep["collided"] = True
        if ctl.ttc is not None:
            ep["min_ttc"] = ctl.ttc if ep["min_ttc"] is None else min(ep["min_ttc"], ctl.ttc)
        ep["max_dec"] = max(ep["max_dec"], -float(ctl.a or 0.0))
        if same and sens_now and ep["sensor_t"] is None:
            ep["sensor_t"], ep["sensor_gap"], ep["sensor_by"] = t, float(min(by[s] for s in sens_now)), sens_now
        if ctl.v < 0.2:
            ep.setdefault("stop_t", t)
        else:
            ep.pop("stop_t", None)
        if not ((not same and t - ep["last_same"] > 1.5) or ("stop_t" in ep and t - ep["stop_t"] > 1.0)
                or t - ep["t0"] > 30.0):
            return
        ft["v2v_ep"] = None
        ft["v2v_block"] = ep["id"]
        if ep["collided"]:                                       # (it hit it anyway: not prevented)
            return
        # (without V2V: closing in at its top speed on the vehicle ahead at the slowest it went in this hazard --
        #  a stop: the whole top speed)
        a = ep["a_full"]
        v0 = ep["v_c"] = max(0.0, ep["v_cf"] - ep.get("v_lead_min", ep["v_lead"]))
        need = ep["need"] = (v0 * self.V2V_CF_REACTION_S + v0 * v0 / (2.0 * max(0.5, a)) + follow_test.STOP_GAP_M)
        if ep["sensor_gap"] is not None:
            d_s = ep["sensor_gap"]
        else:                                                    # (never seen: they would see it at their range)
            usable = [ep["ranges"][s][0] for s in ep["sensors_on"] if "field of view" not in ep["why"].get(s, "")]
            d_s = max(usable) if usable else 0.0
        if d_s >= need:
            return                                               # (the sensors alone would have managed)
        v_imp = math.sqrt(max(0.0, v0 * v0 - 2.0 * a * max(0.0, d_s - v0 * self.V2V_CF_REACTION_S)))
        if v_imp < 0.5:
            return
        saves = ct.setdefault("v2v_saves", [])
        on_txt = " + ".join(ep["sensors_on"]) or "no sensor"
        seen_txt = (f"{' + '.join(ep['sensor_by'])} saw it only at {ep['sensor_gap']:.0f} m" if ep["sensor_gap"]
                    is not None else f"{on_txt} never saw it (they reach ~{d_s:.0f} m here)")
        rec = {
            "n": len(saves) + 1, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "t": round(ep["t0"], 1),
            "lap": ft.get("lap_i") or ct.get("lap"), "truck": str(self.vehicle_label(fid)), "truck_id": fid,
            "other": ep["label"], "other_id": ep["id"], "climate": ep["climate"], "speed_kmh": round(ep["v0"] * 3.6, 1),
            "other_min_kmh": round(ep.get("v_lead_min", ep["v_lead"]) * 3.6, 1),
            "top_kmh": round(ep["v_cf"] * 3.6, 1), "closing_kmh": round(ep["v_c"] * 3.6, 1),
            "other_kmh": ep["other_kmh"], "v2v_gap": round(ep["v2v_gap"], 1), "brake_alert": ep["brake_alert"],
            "age_ms": ep["age_ms"], "delay_ms": ep["delay_ms"],
            "sensor_gap": None if ep["sensor_gap"] is None else round(ep["sensor_gap"], 1),
            "sensor_by": ep["sensor_by"], "sensor_s_later": None if ep["sensor_t"] is None
            else round(ep["sensor_t"] - ep["t0"], 1), "need_m": round(need, 1),
            "min_gap": round(ep["min_gap"], 1) if ep["min_gap"] < 1e8 else None,
            "min_ttc": None if ep["min_ttc"] is None else round(ep["min_ttc"], 2), "max_dec": round(ep["max_dec"], 1),
            "impact_kmh": round(v_imp * 3.6, 1), "sensors_on": ep["sensors_on"], "ranges": ep["ranges"],
            "why": ep["why"], "lat": ep["lat"], "lng": ep["lng"], "view": ep["view"],
            "link": (ct.get("v2v") or {}).get("link"), "v2v_label": __import__("v2v").label(ct.get("v2v")),
            "short": (f"V2V prevented a collision with {ep['label']} ({'brake alert' if ep['brake_alert'] else 'stopped'}"
                      f" {ep['v2v_gap']:.0f} m ahead, known only by V2V); {seen_txt} -- without V2V, at its "
                      f"{ep['v_cf'] * 3.6:.0f} km/h, it needed {need:.0f} m: ~{v_imp * 3.6:.0f} km/h impact")}
        saves.append(rec)
        # the 3D view / replay: a green beacon where it braked, with why V2V prevented it
        seen3d = (f"its {' + '.join(ep['sensor_by'])} saw it only at {ep['sensor_gap']:.0f} m" if ep["sensor_gap"]
                  is not None else "its sensors never saw it")
        try:
            self._y3d_event(
                "v2v_save", f"Collision prevented by V2V: {rec['truck']} braked for {ep['label']} -- {rec['short']}",
                ep["lat"], ep["lng"], t=ft["t0"] + ep["t0"],
                lines=[f"{rec['truck']} braked on the V2V {'brake alert' if ep['brake_alert'] else 'message'} of "
                       f"{ep['label']}, {ep['v2v_gap']:.0f} m ahead -- {seen3d}",
                       f"without V2V: needed {need:.0f} m to stop at {ep['v_cf'] * 3.6:.0f} km/h -> "
                       f"~{v_imp * 3.6:.0f} km/h impact"])
        except Exception:
            sys.excepthook(*sys.exc_info())
        ctl._note(t, "PREVENTED BY V2V: " + rec["short"])
        print(f"[collision test] {rec['truck']}: {rec['short']}")

    def _ctest_v2v_card(self, ct, m, f):
        """The card's V2V line: off / what it gets (vehicles heard, the one ahead, loss, delay, the last alert)."""
        ch = ct.get("v2v_ch")
        c = f["ctl"]
        if ch is None or not c.v2v:
            return {"on": False, "text": "V2V off" if ch is not None else "", "tip": "V2V switched off for this AV"}
        st = ch.summary(m)
        ahead = (f.get("v2v_ahead") or [None])[0]
        last = next((e for e in reversed(ch.events) if e[1] == m and e[3] in ("alert", "lost")), None)
        txt = (f"{f.get('v2v_n', 0)} heard"
               + (f" · {ahead['label']} {ahead['gap']:.0f} m" if ahead else "")
               + f" · loss {st['loss_pct']:.0f} %")
        tip = (f"V2V: {f.get('v2v_n', 0)} connected vehicle(s) heard now"
               + (f"; in its lane ahead: {ahead['label']} at {ahead['gap']:.1f} m (message {ahead['age'] * 1000:.0f} ms "
                  f"old{', BRAKING' if ahead['brake'] else ''})" if ahead else "")
               + f"\nreceived {st['received']}, lost {st['lost']} ({st['loss_pct']:.1f} %"
               + (f", {st['blocked']} by buildings" if st.get("blocked") else "") + ")"
               + (f", delay ~{st['delay_ms']:.0f} ms" if st.get("delay_ms") is not None else "")
               + f", brake alerts {st['alerts']}"
               + (f"\nlast: {last[4]} ({time.time() - last[0]:.0f} s ago)" if last else "")
               + ("" if c.v2v_brake else "\nV2V only warns: the AV brakes on its sensors"))
        if ahead and ahead["brake"]:
            txt = f"BRAKE ALERT · {ahead['label']} {ahead['gap']:.0f} m"
        return {"on": True, "text": txt, "tip": tip}

    def _ctest_v2v_record(self, ct, fid, ft, near_id, t_now):
        """V2V facts of a collision: on / reaction, the other connected?, how far ahead V2V first knew it in the
        lane, its brake alert (when, lost?), the link's loss / delay so far."""
        ch = ct.get("v2v_ch") if ct else None
        if ch is None:
            return None
        cfgv = ct.get("v2v") or {}
        ctl = ft["ctl"]
        other = self.follow_tests.get(near_id)
        import v2v as v2v_mod
        connected = bool(other and other["ctl"].v2v) or (
            not other and v2v_mod.connected(near_id, float(cfgv.get("connected_pct") or 0)))
        e = (ft.get("v2v_seen") or {}).get(str(near_id)) or (ft.get("v2v_seen") or {}).get(near_id)
        fresh = e is not None and t_now - e["last"] <= 3.0
        alert = lost = None
        for t_, rx, tx, kind, text in reversed(ch.events):
            if t_now - t_ > 15.0:
                break
            if rx == fid and str(tx) == str(near_id):
                if kind == "alert" and alert is None:
                    alert = round(t_now - t_, 2)
                if kind == "lost" and lost is None:
                    lost = round(t_now - t_, 2)
        return {"on": bool(ctl.v2v), "brake_mode": bool(ctl.v2v_brake), "link": cfgv.get("link"),
                "gnss": cfgv.get("gnss"), "label": v2v_mod.label(cfgv), "connected": connected,
                "first_gap": round(e["first_gap"], 1) if fresh else None,
                "first_s": round(t_now - e["first_t"], 2) if fresh else None,
                "brake_gap": round(e["brake_gap"], 1) if fresh and e.get("brake_t") and t_now - e["brake_t"] < 15
                else None,
                "brake_s": round(t_now - e["brake_t"], 2) if fresh and e.get("brake_t") and t_now - e["brake_t"] < 15
                else None,
                "alert_s": alert, "alert_lost_s": lost, "stats": ch.summary(fid)}

    # ---- loops, the end of the test and its results (summary, Reports) ----
    def _ctest_laps(self, cid):
        """The loop count: which loop is running; the end of a run on a route that ends elsewhere (all AVs start
        again from its start); the end of the test (the last loop done: the results summary)."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("finished") or ct.get("paused"):
            return
        fts = [self.follow_tests.get(m) for m in ct["members"]]
        fts = [f for f in fts if f]
        if not fts:
            return
        R, n, now = ct["route"], ct["loops"], time.time()
        t = now - ct["t0"]
        finished = False
        if R["loop"]:
            total = max(1.0, R["total"])
            own = {m: int(self.follow_tests[m].get("dist", 0.0) // total) + 1 for m in ct["members"]
                   if m in self.follow_tests}
            if n:
                own = {m: min(n, k) for m, k in own.items()}
            lap = min(own.values())
            if n:
                prev, ok = True, []
                for f in fts:                            # (an AV held a little behind the one before: done too)
                    left = (f.get("goal_m") or 0.0) - f.get("dist", 0.0)
                    d = left <= 0.05 or (prev and left < 30.0 and now >= f["hold_until"]
                                         and now - f.get("stand_since", now) >= 3.0)
                    ok.append(d)
                    prev = d
                finished = all(ok)
        else:
            lap = ct.get("run", 1)
            front = fts[0]
            if front["s"] >= R["end"] - front["L"] / 2 - 0.6 and \
                    all(now >= f["hold_until"] and now - f.get("stand_since", now) >= 2.0 for f in fts):
                if n and lap >= n:
                    finished = True
                else:
                    self._ctest_new_run(cid)
                    lap = ct["run"]
            own = {m: lap for m in ct["members"] if m in self.follow_tests}
        # each AV: into its next loop (that loop's settings from the plan; the front AV: the climate)
        for m, k in own.items():
            f = self.follow_tests[m]
            if k > f.get("lap_i", 1):
                self._ctest_close_loop(ct, m, f.get("lap_i", 1))
                self._ctest_enter_loop(cid, m, k)
        front = own.get(ct["members"][0], lap)
        if front != ct["lap"]:                              # (a loop starts when the front AV starts it)
            ct["lap_log"].append({"loop": front, "t0": round(t, 1), "t1": None, "a0": self._ctest_active(ct),
                                  "climate": (self.climate or {}).get("label", "?"),
                                  "settings": self._ctest_plan_text(ct, front)})
            ct["log"].append((t, f"LOOP {front}{f' of {n}' if n else ''} started"
                                 + (f" -- {ct['lap_log'][-1]['settings']}" if ct["lap_log"][-1]["settings"] else "")))
            ct["lap"] = front
        for e in ct["lap_log"]:                              # (... and ends when the last AV has done it)
            if e["t1"] is None and e["loop"] < lap:
                e["t1"] = round(t, 1)
        if finished:
            self._ctest_finish(cid)

    @staticmethod
    def _ctest_active(ct, now=None):
        """The test's running time (s): without its pauses (and up to its end once finished)."""
        now = ct.get("t_end") or now or time.time()
        paused = ct.get("paused_total", 0.0) + ((now - ct["paused_at"]) if ct.get("paused_at") else 0.0)
        return max(0.0, now - ct["t0"] - paused)

    def _ctest_progress(self, ct):
        """The progress bars of the test window: {loop: (fraction, text) | None, total: (fraction, text) | None}.
        Loop: the front AV through its loop (a route that ends elsewhere: through the run). Whole test: the last
        AV through all the loops (the test ends when it is done). Times without pauses; 'left' estimated from
        the time so far."""
        def dur(s):
            s = int(round(max(0.0, s)))
            return f"{s // 3600} h {s % 3600 // 60:02d} min" if s >= 3600 else \
                f"{s // 60} min {s % 60:02d} s" if s >= 60 else f"{s} s"
        R, n = ct["route"], ct["loops"]
        fts = [self.follow_tests.get(m) for m in ct["members"]]
        if not fts or fts[0] is None:
            return {}
        total = max(1.0, R["total"])
        f0 = fts[0]
        act = self._ctest_active(ct)
        k = f0.get("lap_i", 1)
        if R["loop"]:
            loop_f = (f0.get("dist", 0.0) - (k - 1) * total) / total
            all_f = (min(f.get("dist", 0.0) for f in fts if f) / (n * total)) if n else None
        else:
            s0 = ct["s0"][0] if ct.get("s0") else 0.0
            end = R["end"] - f0["L"] / 2 - 0.5
            loop_f = (f0["s"] - s0) / max(1.0, end - s0)
            all_f = ((ct.get("run", 1) - 1) + max(0.0, min(1.0, loop_f))) / n if n else None
        loop_f = max(0.0, min(1.0, loop_f))
        if ct.get("finished"):
            loop_f, all_f = 1.0, 1.0
        all_f = None if all_f is None else max(0.0, min(1.0, all_f))
        left = lambda frac, el: (" · done" if frac >= 0.999 else                          # noqa: E731
                                 f" · ~{dur(el * (1 - frac) / frac)} left" if frac > 0.02 and el > 5 else
                                 " · estimating ...")
        out = {}
        if n != 1:                                           # (looping: the current loop + the whole test)
            e = next((x for x in reversed(ct.get("lap_log") or []) if x.get("loop") == k), None)
            a0 = (e or {}).get("a0", 0.0)
            el = act - a0
            out["loop"] = (loop_f, f"{'Loop' if R['loop'] else 'Run'} {k}{f' / {n}' if n else ''} · "
                                   f"{loop_f:.0%} · {dur(el)}" + left(loop_f, el))
        if all_f is not None:
            out["total"] = (all_f, f"{'Whole test' if n != 1 else 'Test (single run)'} · {all_f:.0%} · "
                                   + (f"finished in {dur(act)}" if ct.get("finished") else dur(act) + left(all_f, act)))
        else:
            done = max(0, k - 1)
            out["total"] = (None, f"Whole test · {done} loop{'s' if done != 1 else ''} done · {dur(act)} (until you "
                                  "end it)")
        return out

    def _ctest_plan_of(self, ct, k):
        plan = ct.get("plan") or []
        return plan[min(k, len(plan)) - 1] if plan else None

    def _ctest_plan_text(self, ct, k):
        import collision_panel
        lp = self._ctest_plan_of(ct, k)
        if not lp:
            return ""
        base = [(s["top_kmh"],) for s in ct.get("setup") or []]
        return collision_panel.plan_text([lp], base).split(": ", 1)[-1]

    def _ctest_enter_loop(self, cid, m, k):
        """An AV starts loop k: its counts at the start are kept (the loop's results) and the loop's plan is set:
        top speed, sensors, stop & go -- and, for the front AV, the climate."""
        ct = self.collision_tests[cid]
        f = self.follow_tests.get(m)
        if not f:
            return
        ctl, now = f["ctl"], time.time()
        t = now - f["t0"]
        f["lap_i"], f["lmin_ttc"] = k, None
        lp = self._ctest_plan_of(ct, k)
        idx = ct["members"].index(m)
        if lp:
            if idx == 0 and lp.get("climate") and lp["climate"] != (self.climate or {}).get("id"):
                self.set_climate(lp["climate"])
            tv = (lp.get("trucks") or [])[idx] if idx < len(lp.get("trucks") or []) else None
            if tv:
                if abs(ctl.v_max * 3.6 - float(tv["kmh"])) > 0.4:
                    ctl.set_top_speed(t, float(tv["kmh"]))
                for s in follow_test.SENSORS_ALL:
                    if (s in ctl.sensors) != (s in tv["sensors"]):
                        self._follow_set_sensor(m, s, s in tv["sensors"])
                if ctl.v2v != ("V2V" in tv["sensors"]):          # (V2V per loop too)
                    ctl.set_v2v(t, "V2V" in tv["sensors"])
                sg = tv.get("sg")
                if sg:
                    ctl.stop_and_go(t, sg.get("decel", 3.0), sg.get("hold", 6.0), sg.get("repeat", 0.0),
                                    delay_s=sg.get("delay", 0.0))
                    f["plan_sg"] = True
                elif f.pop("plan_sg", False) and ctl.sg:      # (the plan's stop & go of the loop before: off)
                    ctl.stop_and_go_off(t)
            if k > 1 or idx == 0:
                ctl._note(t, f"LOOP {k}: {self._ctest_plan_text(ct, k) or 'settings as before'}")
        st = ctl.stats
        ct["loop_avs"].setdefault(k, {})[m] = {
            "t0": round(now - ct["t0"], 1), "dist0": f.get("dist", 0.0), "drive0": f.get("drive_t", 0.0),
            "skip0": f.get("skip_m", 0.0),
            "brakes0": st["brakes"], "full0": st["full_brakes"], "warn0": st["ttc_warnings"], "crit0": st["ttc_critical"],
            "coll0": st["collisions"], "kmh": round(ctl.v_max * 3.6, 1),
            "sensors": [s for s in follow_test.SENSORS_ALL if s in ctl.sensors] + (["V2V"] if ctl.v2v else []),
            "sg": bool(ctl.sg),
            "climate": (self.climate or {}).get("label", "?")}

    def _ctest_loop_values(self, ct, m, k, close=False):
        """An AV's results in loop k (so far, or -- close -- final): driven, average speed, brakings, TTC,
        collisions."""
        e = (ct.get("loop_avs") or {}).get(k, {}).get(m)
        f = self.follow_tests.get(m)
        if e is None:
            return None
        if e.get("closed") or f is None:
            return e
        st, ctl = f["ctl"].stats, f["ctl"]
        dist = f.get("dist", 0.0) - e["dist0"] - (f.get("skip_m", 0.0) - e.get("skip0", 0.0))   # (skipped: not driven)
        drive = f.get("drive_t", 0.0) - e["drive0"]
        out = dict(e, dist_m=round(dist, 1), avg_kmh=round(dist / drive * 3.6, 1) if drive > 1 else 0.0,
                   brakes=st["brakes"] - e["brakes0"], full_brakes=st["full_brakes"] - e["full0"],
                   ttc_warnings=st["ttc_warnings"] - e["warn0"], ttc_critical=st["ttc_critical"] - e["crit0"],
                   collisions=st["collisions"] - e["coll0"],
                   min_ttc=None if f.get("lmin_ttc") is None else round(f["lmin_ttc"], 2),
                   t1=round(time.time() - ct["t0"], 1), closed=close,
                   sensors_end=[s for s in follow_test.SENSORS_ALL if s in ctl.sensors])
        if close:
            ct["loop_avs"][k][m] = out
        return out

    def _ctest_close_loop(self, ct, m, k):
        self._ctest_loop_values(ct, m, k, close=True)

    def _ctest_new_run(self, cid):
        """A route that ends elsewhere, looped: every AV back to its start place, the next run."""
        ct = self.collision_tests[cid]
        R, now = ct["route"], time.time()
        ct["run"] = ct.get("run", 1) + 1
        for k, m in enumerate(ct["members"]):
            f = self.follow_tests.get(m)
            if not f:
                continue
            f["s"] = ct["s0"][k] if k < len(ct["s0"]) else ct["s0"][-1]
            f["contact"] = f["truth_prev"] = None
            f["radar_track"] = {}
            for key in ("pred", "stand_since"):
                f.pop(key, None)
            f["ctl"].v, f["ctl"].target = 0.0, None
            f["ctl"]._note(now - f["t0"], f"run {ct['run']}: back at the start of {R['name']}")
            pose = self._route_pose(R, f["s"])
            st = self.path_replays.get(m)
            if st is not None:
                st["points"], st["index"] = [pose], 1
            self._replay_move_marker(m, pose[0], pose[1], pose[2])

    def _ctest_finish(self, cid):
        """The last loop is done: the AVs stand and the test ends by itself -- as End test: the results are saved
        (when asked at the start), MQTT stops, the window closes, the map is put back as before the test and the
        results summary shows."""
        ct = self.collision_tests[cid]
        ct["finished"], ct["t_end"] = True, time.time()
        t = ct["t_end"] - ct["t0"]
        for e in ct["lap_log"]:
            if e["t1"] is None:
                e["t1"] = round(t, 1)
        for m in ct["members"]:
            f = self.follow_tests.get(m)
            if f:
                f["finished"] = True
                self._ctest_close_loop(ct, m, f.get("lap_i", 1))
        n = len(ct.get("collisions") or [])
        ct["log"].append((t, f"TEST FINISHED: {ct['lap']} loop{'s' if ct['lap'] != 1 else ''}, {n} collision"
                             f"{'s' if n != 1 else ''} -- results in the summary / Reports"))
        print(f"[collision test] finished: {ct['lap']} loop(s), {n} collision(s)")
        self._ctest_update(cid)
        # (after this timer tick -- the test's own timers are stopped there; End test meanwhile: nothing more to do)
        QTimer.singleShot(0, lambda c=cid: self.end_collision_test(c))

    def collision_reports_dir(self):
        return os.path.join(cfg.SITE_DIR, "reports", "collision_tests")

    def _ctest_report(self, ct, ended_by):
        """The results of a collision test as a dict (the summary, the saved report)."""
        import auth
        R, now = ct["route"], time.time()
        t_end = ct.get("t_end") or now
        n = ct["loops"]
        total = max(1.0, R["total"])
        trucks = []
        for k, m in enumerate(ct["members"]):
            f = self.follow_tests.get(m) or {}
            c = f.get("ctl")
            st = ct["setup"][k] if k < len(ct.get("setup") or []) else {}
            dist = float(f.get("dist", 0.0))
            if R["loop"]:
                loops_i = n if (f.get("finished") and n) else int(dist / total + 1e-6)   # (finished: all done)
                if n:
                    loops_i = min(n, loops_i)
            else:
                loops_i = ct.get("run", 1) - 1 + (1 if ct.get("finished") else 0)
            drive_t = float(f.get("drive_t", 0.0))
            dist = max(0.0, dist - float(f.get("skip_m", 0.0)))            # (loops skipped: not driven)
            trucks.append({
                "no": k + 1, "id": m, "name": str(self.vehicle_label(m)),
                "top_kmh": round(c.v_max * 3.6, 1) if c else st.get("top_kmh"),
                "top_kmh_start": st.get("top_kmh"), "gap_m": c.gap_set if c else st.get("gap_m"),
                "sensors_start": st.get("sensors") or [],
                "sensors_end": [s for s in follow_test.SENSORS_ALL if c and s in c.sensors],
                "loops": loops_i, "dist_m": round(dist, 1),
                "avg_kmh": round(dist / drive_t * 3.6, 1) if drive_t > 1 else 0.0,
                "max_kmh": round(float(f.get("v_top_seen", 0.0)) * 3.6, 1),
                "brakes": c.stats["brakes"] if c else 0, "full_brakes": c.stats["full_brakes"] if c else 0,
                "ttc_warnings": c.stats["ttc_warnings"] if c else 0, "ttc_critical": c.stats["ttc_critical"] if c else 0,
                "min_ttc": c.stats["min_ttc"] if c else None, "min_ttc_true": c.stats["min_ttc_true"] if c else None,
                "collisions": c.stats["collisions"] if c else 0,
                "v2v_start": bool(st.get("v2v")), "v2v_end": bool(c and c.v2v),
                "v2v": (ct["v2v_ch"].summary(m) if ct.get("v2v_ch") is not None and (st.get("v2v") or (c and c.v2v))
                        else None)})
        if R["loop"]:
            done = min([x["loops"] for x in trucks] or [0])
        else:
            done = ct.get("run", 1) - 1 + (1 if ct.get("finished") else 0)
        recs = list(ct.get("collisions") or [])
        loops = []
        for e in ct.get("lap_log") or []:                    # each loop: its settings, each AV's results in it
            k = e["loop"]
            tr = []
            for i, m in enumerate(ct["members"]):
                v = self._ctest_loop_values(ct, m, k)
                if v is None:
                    continue
                tr.append({"no": i + 1, "name": str(self.vehicle_label(m)), "kmh": v.get("kmh"),
                           "sensors": v.get("sensors"), "sg": v.get("sg"), "climate": v.get("climate"),
                           "dist_m": v.get("dist_m", 0.0), "avg_kmh": v.get("avg_kmh", 0.0),
                           "brakes": v.get("brakes", 0), "full_brakes": v.get("full_brakes", 0),
                           "ttc_warnings": v.get("ttc_warnings", 0), "ttc_critical": v.get("ttc_critical", 0),
                           "min_ttc": v.get("min_ttc"), "collisions": v.get("collisions", 0),
                           "done": bool(v.get("closed"))})
            loops.append(dict(e, trucks=tr, collisions=sum(1 for r in recs if r.get("lap") == k)))
        u = auth.current() or {}
        return {
            "kind": "collision", "test": ct.get("id"), "route": R["name"], "route_m": round(R["total"], 1),
            "loop_route": bool(R["loop"]), "drive_side": R.get("side"), "loops_planned": n, "loops_done": done,
            "loops_skipped": sum(1 for e in ct.get("lap_log") or [] if e.get("skipped")),
            "finished": bool(ct.get("finished")), "ended_by": ended_by,
            "started": ct.get("started"), "ended": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t_end)),
            "duration_s": round(t_end - ct["t0"], 1), "yard": cfg.ACTIVE_SITE,
            "project": cfg.site_project_name(cfg.ACTIVE_SITE),
            "user": (f"{u.get('name') or u.get('username')} ({u.get('username')})" if u.get("username") else ""),
            "climates": list(ct.get("climates") or []), "hold_s": ct.get("hold_s"),
            "trucks": trucks, "loops": loops, "plan": ct.get("plan"), "collisions": recs,
            "v2v": (dict(ct["v2v"], label=__import__("v2v").label(ct["v2v"]))
                    if ct.get("v2v") and any(x.get("v2v_start") or x.get("v2v_end") for x in trucks) else None),
            "v2v_saves": list(ct.get("v2v_saves") or []),
            "sensor_mode": "real" if ct.get("real") else "sim",
            "sensor_methods": ct.get("real_methods") if ct.get("real") else None,
            "result": "PASS" if not recs else "FAIL", "dir": ct.get("report_dir")}

    def _ctest_save_report(self, ct, ended_by, rep=None):
        """The results into this yard's reports/collision_tests/<route>_<date>_<time>/report.json (Reports page).
        rep: results made before (the summary's 'Save to Reports' after the test ended)."""
        import shutil
        rep = dict(rep) if rep is not None else self._ctest_report(ct, ended_by)
        ct["save"] = True                                    # (saved once: kept up to date until the test ends)
        d = ct.get("report_dir")
        if not d:
            stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(ct["t0"]))
            d = os.path.join(self.collision_reports_dir(), f"{re.sub(r'[^A-Za-z0-9_.-]+', '_', rep['route']).strip('_') or 'route'}_{stamp}")
            ct["report_dir"] = d
        os.makedirs(d, exist_ok=True)
        rep["dir"] = d
        recs = []                                            # (the camera images go with the report: self-contained)
        for r in rep["collisions"]:
            r = {k: v for k, v in r.items() if not k.startswith("_")}
            def keep(item):                                  # (an image into the report's images/ folder)
                f = (item or {}).get("file")
                if not f or not os.path.isabs(f) or not os.path.exists(f):
                    return item
                os.makedirs(os.path.join(d, "images"), exist_ok=True)
                try:
                    shutil.copy2(f, os.path.join(d, "images", os.path.basename(f)))
                    return dict(item, file=f"images/{os.path.basename(f)}")
                except OSError:
                    return item
            if r.get("camera"):
                r["camera"] = keep(r["camera"])
            if r.get("scene"):
                r["scene"] = [keep(v) for v in r["scene"]]
            recs.append(r)
        rep = dict(rep, collisions=recs, saved=time.strftime("%Y-%m-%d %H:%M:%S"))   # (when it was written)
        tmp = os.path.join(d, "report.json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(rep, f, default=str)
        os.replace(tmp, os.path.join(d, "report.json"))
        print(f"[collision test] results saved: {d}")
        return rep

    def show_collision_report(self, rep, save=None):
        """The results summary (a click on the collisions: each one's reason and sensor check). save: not saved yet
        -- a 'Save to Reports' button (save() -> the saved report: the summary shows again from it)."""
        import collision_panel
        from PyQt5.QtGui import QDesktopServices
        old = getattr(self, "_ctest_report_dlg", None)
        if old is not None:
            try:
                old.close()
            except RuntimeError:
                pass
        d = rep.get("dir")
        if d:                                                # (a saved report: its camera images in its folder)
            recs = []
            absf = lambda it: (dict(it, file=os.path.join(d, it["file"])) if it and it.get("file")   # noqa: E731
                               and not os.path.isabs(it["file"]) else it)
            for r in rep.get("collisions") or []:
                r = dict(r)
                if r.get("camera"):
                    r["camera"] = absf(r["camera"])
                if r.get("scene"):
                    r["scene"] = [absf(v) for v in r["scene"]]
                recs.append(r)
            rep = dict(rep, collisions=recs)
        dlg = collision_panel.CollisionReportDialog(self, rep, {
            "collisions": lambda recs, title, select=None: self.open_collision_history(recs, title, select=select),
            "folder": (lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(d))) if d else None,
            "save": (lambda: self._report_save_clicked(save)) if save is not None and not d else None,
            "show_save": self.show_v2v_save_on_map})
        dlg.setAttribute(Qt.WA_DeleteOnClose, True)
        self._ctest_report_dlg = dlg
        self.make_minimizable(dlg, dlg.windowTitle())
        dlg.show(); dlg.raise_(); dlg.activateWindow()
        return dlg

    def _report_save_clicked(self, save):
        """The summary's 'Save to Reports': saved, the summary again (now with its folder), the Reports list."""
        try:
            rep = save()
        except Exception as e:
            sys.excepthook(*sys.exc_info())
            QMessageBox.warning(self, "Collision testing", f"The results could not be saved:\n{e}")
            return
        if rep is None:
            return
        self.show_collision_report(rep)
        if getattr(self, "_current_nav", None) == "reports":
            self.refresh_reports("collision")

    def show_v2v_save_on_map(self, rec):
        """Where V2V prevented a collision: a numbered marker (popup: the proof in short)."""
        m = self.map_var_name
        html = (f"<b style='color:#059669'>Prevented by V2V</b> · {rec.get('time')}<br><b>{rec.get('truck')}</b> / "
                f"<b>{rec.get('other')}</b><br>{rec.get('short', '')}")
        self.browser.page().runJavaScript(
            self.COLLISION_MAP_JS + f"window.collisionMarker({m}, {json.dumps('v2v#' + str(rec.get('n')))}, "
            f"{rec['lat']}, {rec['lng']}, {json.dumps('V' + str(rec.get('n')))}, {json.dumps(html)}, true, null);")

    def show_collision_on_map(self, rec, focus=True):
        """A numbered red marker where the collision happened (popup: what / speed / reason; yellow: the other)."""
        m = self.map_var_name
        import collision_panel
        html = (f"<b>Collision {rec.get('n')}</b> · {rec.get('time')}<br>"
                f"<b style='color:#B91C1C'>{collision_panel.rec_short(rec)}</b><br>"
                f"<b>{rec.get('truck')}</b> × <b>{rec.get('hit')}</b><br>"
                f"{rec.get('speed_kmh')} km/h (other {rec.get('other_kmh')} km/h) · {rec.get('climate')}<br>"
                f"sensors on: {', '.join(rec.get('sensors') or []) or 'none'} · seen by: "
                f"{', '.join(f'{k} {v} m' for k, v in (rec.get('seen_by') or {}).items()) or 'none'}<br>"
                f"<i>{rec.get('reason')}</i>")
        key = f"{rec.get('test')}#{rec.get('n')}"
        self.browser.page().runJavaScript(
            self.COLLISION_MAP_JS + f"window.collisionMarker({m}, {json.dumps(key)}, {rec['lat']}, {rec['lng']}, "
            f"{json.dumps(str(rec.get('n')))}, {json.dumps(html)}, {json.dumps(bool(focus))}, "
            f"{json.dumps(rec.get('other'))});")

    def collision_history(self):
        """The saved collisions of this yard's collision tests (newest last)."""
        out = []
        try:
            with open(os.path.join(cfg.LOG_DIR, self.COLLISION_LOG), encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            out.append(json.loads(line))
                        except ValueError:
                            pass
        except OSError:
            pass
        return out

    def clear_collision_history(self):
        import shutil
        try:
            os.remove(os.path.join(cfg.LOG_DIR, self.COLLISION_LOG))
        except OSError:
            pass
        shutil.rmtree(os.path.join(cfg.LOG_DIR, "collision_images"), ignore_errors=True)   # (their camera images)
        self.browser.page().runJavaScript(f"window.clearCollisionMarkers && window.clearCollisionMarkers({self.map_var_name}, '');")

    # ---- sensor set-up for collision testing: simulated (object models) or real-world processing ----
    def sensor_mode(self):
        m = str(((cfg.APP_SETTINGS or {}).get("collision_sensors") or {}).get("mode", "sim"))
        return m if m in ("sim", "real") else "sim"

    @staticmethod
    def _real_methods_now():
        """{sensor: {"chosen", "used"}} of the real-world set-up (a not-integrated choice: the integrated one used)."""
        import sensor_mode as smod
        return {k: {"chosen": smod.method(k, v)[1], "used": smod.effective(k, v)[1],
                    "integrated": smod.method(k, v)[2]} for k, v in smod.real_methods().items()}

    def _update_sensor_mode_btn(self):
        import sensor_mode as smod
        b = getattr(self, "sensor_mode_btn", None)
        if b is None:
            return
        m = self.sensor_mode()
        text = f"Sensors: {smod.SHORT[m]}"
        self._top_texts = [(x, text if x is b else t) for x, t in getattr(self, "_top_texts", [])]
        if not getattr(self, "_top_compact", False):
            b.setText(text)
        b.setIcon(self._icon("fa5s.microchip", smod.COL[m]))

    def open_sensor_mode(self):
        import sensor_mode as smod
        import auth
        if not auth.collision_allowed():
            return
        dlg = smod.SensorModeDialog(self, self.sensor_mode())
        if dlg.exec_() != QDialog.Accepted:
            return
        cfg.save_app_settings_section("collision_sensors", {"mode": dlg.choice, "real_methods": dict(dlg.methods)})
        if dlg.choice == "real":
            off = [f"{k}: {smod.method(k, v)[1]}" for k, v in dlg.methods.items() if not smod.method(k, v)[2]]
            if off:
                QMessageBox.information(self, "Sensor set-up", "Not integrated yet -- the tests use the integrated "
                                        "mechanism instead:\n\n" + "\n".join(
                                            f"• {o}  →  {smod.effective(o.split(':')[0], dlg.methods[o.split(':')[0]])[1]}"
                                            for o in off))
        self._update_sensor_mode_btn()
        running = [ct for ct in (getattr(self, "collision_tests", None) or {}).values()]
        if running and any(bool(ct.get("real")) != (dlg.choice == "real") for ct in running):
            QMessageBox.information(self, "Sensor set-up", f"{smod.TITLE[dlg.choice]} is used for the collision "
                                    "tests started from now on -- the running test keeps its set-up.")

    def open_collision_info(self, topic=None):
        """The 'how collision testing works' window (one, kept: the methods chosen stay while the app runs)."""
        import collision_info
        import auth
        if not auth.collision_allowed():
            return
        dlg = getattr(self, "_collision_info_dlg", None)
        if dlg is None:
            dlg = self._collision_info_dlg = collision_info.InfoDialog(self)
        if topic:
            dlg.show_topic(topic)
        dlg.show(); dlg.raise_(); dlg.activateWindow()

    def open_v2v_saves(self, saves, title="Collisions prevented by V2V", select=0):
        """The collisions prevented by V2V (of a running test): the list of all, each one's proof one by one."""
        import collision_panel
        if not saves:
            return
        old = getattr(self, "_v2v_saves_dlg", None)
        if old is not None:
            try:
                old.close()
            except RuntimeError:
                pass
        dlg = collision_panel.V2VSavesDialog(self, list(saves), self.show_v2v_save_on_map, select=select, title=title)
        dlg.setAttribute(Qt.WA_DeleteOnClose, True)
        self._v2v_saves_dlg = dlg
        dlg.show(); dlg.raise_(); dlg.activateWindow()

    def open_collision_history(self, records=None, title="Collision history", select=None):
        """The collisions list: pick one -> its details (reason, each sensor, the check of the cause, bird's-eye
        snapshot) and its place on the map."""
        import collision_panel
        live = records is not None
        recs = records if live else self.collision_history()
        dlg = collision_panel.CollisionHistoryDialog(self, title, recs, select=select, callbacks={
            "show": lambda r: self.show_collision_on_map(r, focus=True),
            "show_all": lambda rs: [self.show_collision_on_map(r, focus=False) for r in rs],
            "hide_all": lambda: self.browser.page().runJavaScript(
                f"window.clearCollisionMarkers && window.clearCollisionMarkers({self.map_var_name}, '');"),
            "clear": (None if live else self.clear_collision_history)})
        self.make_minimizable(dlg, title)
        dlg.show()
        return dlg

    def _ctest_cams(self, configs=False):
        """Collision testing's cameras: the AV configuration's cameras "Used for: collision" (Vehicles window;
        a front camera by default) -- as camera models, or (configs=True) as configured."""
        now = time.time()
        cache = getattr(self, "_ctest_cam_cache", None)
        if cache is None or now - cache[0] > 2.0:
            confs = cfg.collision_cameras() or [cfg.default_collision_camera(VEHICLE_DIMENSIONS.get("tractor", {}))]
            cache = self._ctest_cam_cache = (now, confs, [follow_test.camera_model(c) for c in confs])
        return cache[1] if configs else cache[2]

    # ---- REAL-WORLD sensor processing (collision testing, top bar "Sensors: Real-world") ----
    @staticmethod
    def _real_state():
        """Per AV: a tracker per sensor + the latest measurements."""
        import real_sensors as rs
        return {"trk": {"camera": rs.Tracker("C", confirm=2, window=3, coast_s=1.2, gate_m=2.0),
                        "LiDAR": rs.Tracker("L", confirm=2, window=3, coast_s=0.6, gate_m=1.5),
                        "radar": rs.Tracker("R", confirm=3, window=4, coast_s=0.5, gate_m=1.2, static_age=8)},
                "cam_t": 0.0, "lidar_t": 0.0, "rnd": random.Random(11), "cam_n": 0, "lidar_n": 0}

    def _real_detect(self, fid, ft, me, L, objs, t, ctl):
        """This AV's sensors from their own measurements -> (LiDAR, camera, radar) detections (confirmed tracks,
        matched to the scene only to name them)."""
        import real_sensors as rs
        st = ft["real"]
        now = time.time()
        local = rs.scene_local(me, objs)
        lidar, cam, rad = [], [], []
        # LiDAR: the latest unlabelled cloud of the sensor page -> clusters -> tracks
        lc = (getattr(self, "_lidar_clouds", None) or {}).get(str(fid))
        if "LiDAR" in ctl.sensors:
            if lc and lc[0] > st["lidar_t"] and lc[0] > ft["t0"] + 1.2:
                st["lidar_t"] = lc[0]
                pts = rs.lidar_points(me, lc[1], lc[2])
                cl = rs.lidar_clusters(pts, L)
                st["trk"]["LiDAR"].update(t, [dict(c, y=c["l"]) for c in cl])
                st["lidar_raw"], st["lidar_pts"], st["lidar_n"] = cl, len(pts), st["lidar_n"] + 1
            if now - st["lidar_t"] < 0.8:
                lidar = rs.to_dets(st["trk"]["LiDAR"].confirmed(t), me, L, local, "LiDAR")
        # radar: one scan per step (beams, echoes, CFAR) -> clusters -> tracks
        if "radar" in ctl.sensors:
            near = [o for o in local if -o[4] < o[2] < 160 and abs(o[3]) < o[2] * 0.62 + o[5] + 3]
            pts = rs.radar_scan(me, L, near, self.climate, ctl.v, st["rnd"])
            cl = rs.radar_clusters(pts, L)
            st["trk"]["radar"].update(t, [dict(c, y=c["l"], v_rel=c["doppler"]) for c in cl])
            st["radar_raw"] = cl
            rad = rs.to_dets(st["trk"]["radar"].confirmed(t), me, L, local, "radar")
        # camera: tracks from the pictures processed in _real_cam_result
        if "camera" in ctl.sensors and now - st["cam_t"] < 1.5:      # (only CLASSIFIED ones are braked for: an
            cam = [d for d in rs.to_dets(st["trk"]["camera"].confirmed(t), me, L, local, "camera")   # 'object' of
                   if d.get("cls") not in (None, "object")]                                          # low confidence
            #                                                                                          is not)
            # fusion check: a STANDING object only the camera reports needs the LiDAR or radar (if on) to have
            # something there too -- a real stopped vehicle always gives a radar echo, a picture artefact at the
            # roadside does not (otherwise the AV would wait behind it for ever). Moving ones stand alone.
            others = lidar + rad
            if others or "LiDAR" in ctl.sensors or "radar" in ctl.sensors:
                kept, dropped = [], 0
                for d in cam:
                    standing = abs(float(d.get("trk_v") or 0.0) + ctl.v) < 1.0 or ctl.v < 0.5
                    if standing and not any(abs(o["gap"] - d["gap"]) < 3.0 + 0.15 * d["gap"] and
                                            _metres_between(o["lat"], o["lng"], d["lat"], d["lng"]) < 4.0 + 0.1 * d["gap"]
                                            for o in others):
                        dropped += 1
                        continue
                    kept.append(d)
                cam = kept
                st["cam_unconfirmed"] = dropped
        return lidar, cam, rad

    def _real_cam_tick(self, cid):
        """One AV's camera picture after the other (real-world mode): rendered by the camera page, processed in
        _real_cam_result."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or getattr(self, "camera_view", None) is None or getattr(self, "_closing", False):
            return
        if time.time() - getattr(self, "_rcam_busy", 0.0) < 1.5:
            return
        trucks = [m for m in ct["members"] if m in self.follow_tests and self.follow_tests[m].get("real")
                  and "camera" in self.follow_tests[m]["ctl"].sensors]
        if not trucks:
            return
        conf = self._ctest_cams(configs=True)[0]
        cam_keys = ("x_left_cm", "y_cm", "z_cm", "yaw_deg", "pitch_deg", "hfov_deg", "vfov_deg", "origin_height_m")
        cam = {k_: conf[k_] for k_ in cam_keys if conf.get(k_) is not None}
        opts = [{"id": fid, "w": 320, "quality": 85, "boxes": False, "cam": cam} for fid in trucks]
        self._rcam_busy = time.time()
        self.camera_view.page().runJavaScript(
            f"window.frontCamShots ? window.frontCamShots({json.dumps(opts)}) : null",
            lambda res: self._real_cam_results(res))

    def _real_cam_results(self, res):
        self._rcam_busy = 0.0
        for r in res if isinstance(res, list) else []:
            if isinstance(r, dict) and r.get("id") is not None:
                self._real_cam_result(r["id"], r)

    def _real_cam_result(self, fid, res):
        import base64
        import real_camera
        ft = (getattr(self, "follow_tests", None) or {}).get(fid)
        if not ft or not ft.get("real") or getattr(self, "_closing", False):
            return
        if not isinstance(res, dict) or not res.get("jpeg"):
            return
        try:
            img = real_camera.decode_jpeg(base64.b64decode(res["jpeg"]))
            if img is None:
                return
            dets, _dbg = real_camera.detect(img, res)
        except Exception:
            sys.excepthook(*sys.exc_info())
            return
        st = ft["real"]
        st["trk"]["camera"].update(time.time() - ft["t0"], dets)
        st["cam_t"], st["cam_n"], st["cam_raw"] = time.time(), st["cam_n"] + 1, dets

    def _camera_overlay_real(self, fid, shot, conf):
        """Real-world mode: the detections the camera finds IN THIS PICTURE (green: its ground-contact line and
        distance), the true positions faint (for comparison) + how the distance was worked out."""
        import base64
        import real_camera
        ft = self.follow_tests[fid]
        W, H, fy = shot["w"], shot["h"], shot["fy"]
        horizon = H / 2 - fy * math.tan(math.radians(shot.get("pitch_deg", 3)))
        label = conf.get("label") or "camera"
        dets = []
        try:
            img = real_camera.decode_jpeg(base64.b64decode(shot["jpeg"]))
            dets, _d = real_camera.detect(img, shot) if img is not None else ([], {})
        except Exception:
            sys.excepthook(*sys.exc_info())
        boxes = []
        for b in shot.get("boxes") or []:                           # (the truth, faint: what is really there)
            if 1 < b["dist"] < 80:
                boxes.append({k: b[k] for k in ("x0", "y0", "x1", "y1")} | {"col": "#64748B", "dashed": True,
                                                                             "lines": [f"real {b['dist']:.1f} m"]})
        for d in dets:
            hpx = max(8.0, 2.2 * fy / max(1.0, d["x"]))
            boxes.append({"x0": d["u0"], "x1": d["u1"], "y1": d["v"], "y0": d["v"] - hpx, "col": "#22C55E",
                          "lines": [f"{d['cls']} {d['conf']:.0%}", f"{d['x']:.1f} m"]})
        cam_on = "camera" in ft["ctl"].sensors
        banner = None if dets else ("CAMERA SWITCHED OFF" if not cam_on else "Nothing found in this picture")
        overlay = {"w": W, "h": H, "boxes": boxes, "banner": banner, "banner_col": "#EF4444" if banner else None,
                   "horizon": horizon, "caption": f"{label} · REAL-WORLD processing: found in the picture (green), "
                                                  f"true positions dashed grey"}
        calc = {"camera": f"{label} -- real-world: what the picture shows"}
        lane = [d for d in dets if abs(d["y"]) <= follow_test.CORRIDOR_HALF_M + 0.5]
        if not lane:
            calc.update(title="Real-world camera: nothing in its lane in this picture", lines=[
                ("road", "d = h_cam / tan(angle below the horizon)", "where an obstacle stands on the road")],
                note="Road colours are learned from the bottom of the picture; where the road stops for good, an "
                     "obstacle stands. Low contrast (fog, night, rain) -> not found.")
            return overlay, calc
        d = lane[0]
        ang = math.degrees(math.atan((d["v"] - H / 2) / fy)) + shot.get("pitch_deg", 3)
        real_d = None
        for b in shot.get("boxes") or []:
            if b["x0"] - 4 <= (d["u0"] + d["u1"]) / 2 <= b["x1"] + 4:
                real_d = b["dist"] if real_d is None else min(real_d, b["dist"])
        lines = [("base", f"ground contact at row {d['v']} (horizon {horizon:.0f})", f"{ang:.2f}° below"),
                 ("road", f"d = h_cam / tan(angle) = {shot['cam_h']:.2f} m / tan({ang:.2f}°)", f"{d['x']:.1f} m"),
                 ("gap", f"− lens to the front {shot.get('lens_front_m', 0):.2f} m", f"{d['gap']:.1f} m")]
        if real_d is not None:
            lines.append(("real", "distance in the 3D yard (for comparison)", f"{real_d:.1f} m"))
        calc.update(title=f"Real-world camera: {d['cls']} {d['conf']:.0%}, {d['width_m']:.1f} m wide -- found in the "
                          "picture", lines=lines,
                    note="Not from the scene: the road / obstacle split per pixel column, the obstacle's ground contact "
                         "and the camera's height and tilt (flat road). The name in the cards comes from matching the "
                         "track to the real object afterwards (for the reports).")
        return overlay, calc

    def _route_tick(self, follower_id):
        """One step of an AV on the route: perceive (LiDAR scan + camera / radar models), brake or
        drive on, ground truth (the nearest object REALLY in its lane ahead: TTC, collision)."""
        ft = (getattr(self, "follow_tests", None) or {}).get(follower_id)
        if not ft:
            return
        now = time.time()
        dt = min(0.5, max(0.01, now - ft["last"]))
        ft["last"] = now
        t = now - ft["t0"]
        R, ctl, L = ft["route"], ft["ctl"], ft["L"]
        trail, ss = R["trail"], R["ss"]
        s = ft["s"]
        horizon = min(R["end"], s + 150.0)
        me = self._route_pose(R, s)
        objs = self._follow_objects(follower_id)
        hidden = []
        if ft.get("real"):                                # REAL-WORLD: each sensor from its own measurements
            try:
                lidar, cam, rad = self._real_detect(follower_id, ft, me, L, objs, t, ctl)
            except Exception:
                sys.excepthook(*sys.exc_info())
                lidar, cam, rad = [], [], []
        else:                                             # simulated: the models on the scene's objects
            fresh = getattr(self, "_lidar_dets_t", 0)
            lidar = [dict(d, label=str(self.vehicle_label(d["id"])))
                     for d in self.lidar_detections(follower_id)] if now - fresh < 0.6 and fresh > ft["t0"] + 1.2 else []
            cam = follow_test.cameras_detect(me, L, objs, self.climate, self._ctest_cams(), hidden=hidden)
            rad = follow_test.radar_detect(me, L, objs, self.climate, ego_v=ctl.v,      # scan by scan, tracked
                                           track=ft.setdefault("radar_track", {}), t=t)
        grip = follow_test.road_grip(self.climate)
        if abs(grip - ctl.grip) > 0.01:
            ctl.grip, ctl.a_full = grip, follow_test.A_FULL * grip
            ctl._note(t, f"climate {(self.climate or {}).get('label', '?')}: road grip {grip:.0%} "
                         f"(full brake {ctl.a_full:.1f} m/s²)")
        if ft.get("real"):                                # (measured points: no box centres / lengths from the scene)
            import real_sensors as rs_
            on_tr = {k: [dict(d, y_route=d.get("y"), y=rs_.lane_offset(d)) if d.get("y") is not None else d
                         for d in self._path_gaps(self._on_trail(trail, s, horizon, v, ss), me, L, None)]
                     for k, v in (("LiDAR", lidar), ("camera", cam), ("radar", rad))}
        else:
            on_tr = {"LiDAR": self._on_trail(trail, s, horizon, self._box_centres(lidar, objs), ss),
                     "camera": self._on_trail(trail, s, horizon, cam, ss),
                     "radar": self._on_trail(trail, s, horizon, rad, ss)}
            len_of = {str(o[0]): float(o[4] or 4.5) for o in objs}
            for k in on_tr:                               # (beyond a U-turn: the distance along its road)
                on_tr[k] = self._path_gaps(on_tr[k], me, L, len_of if k != "LiDAR" else None)
            # the radar's Doppler is the speed along the line of sight -- in a bend a truck ahead driving across the
            # view looked stopped; the tracker's estimate of a target on its road is its speed along that road
            speed_of = {str(o[0]): float(o[9] or 0.0) for o in objs if len(o) > 9}
            on_tr["radar"] = [dict(d, v_rel=round(speed_of[str(d["id"])] - ctl.v, 2), v_radial=d.get("v_rel"))
                              if str(d.get("id")) in speed_of and abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M
                              and d.get("v_rel") is not None else d for d in on_tr["radar"]]
        v2v_dets = []                                     # V2V (collision testing): the connected vehicles ahead
        ct_ = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy"))
        if ct_ is not None and ct_.get("v2v_ch") is not None:
            try:
                self._ctest_v2v_step(ct_, now)
                v2v_dets = self._ctest_v2v_dets(ct_, follower_id, ft, me, s, horizon, now)
            except Exception:
                sys.excepthook(*sys.exc_info())
        predicted = self._predicted_target(ft, me, objs, on_tr, t)
        ctl.perceive(t, on_tr["LiDAR"], on_tr["camera"], radar_dets=on_tr["radar"], predicted=predicted,
                     v2v_dets=v2v_dets if ctl.v2v else None)
        on_tr["V2V"] = v2v_dets if ctl.v2v else []
        ft["seen"] = {"me": me, "objs": objs, "raw": {"LiDAR": lidar, "camera": cam, "radar": rad,
                                                       "V2V": v2v_dets if ctl.v2v else []}, "lane": on_tr,
                      "hidden": {h["id"]: h["by"] for h in hidden}, "s_lead": horizon}
        noted = ft.setdefault("hidden_noted", set())
        in_lane = {d["id"] for d in self._on_trail(trail, s, horizon, hidden, ss)
                   if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M + 1.0}
        for h in hidden:
            if h["id"] in in_lane and h["id"] not in noted and "camera" in ctl.sensors:
                noted.add(h["id"])
                others = [x for x in ("LiDAR", "radar") if x in ctl.sensors]
                ctl._note(t, f"camera: {h['label']} is HIDDEN behind {h['by']} (occlusion) -- "
                             + (f"only the {' / '.join(others)} can see it" if others else "not seen at all"))
        noted &= {h["id"] for h in hidden} | in_lane
        at_end = not R["loop"] and s >= R["end"] - L / 2 - 0.5
        goal = ft.get("goal_m")
        done = ft.get("finished") or (goal is not None and ft["dist"] >= goal - 0.05)
        v = ctl.step(t, dt, hold=now < ft["hold_until"])
        if done:
            n_l = int(round((goal or 0) / max(1.0, R["total"])))
            ctl.v, v, ctl.state = 0.0, 0.0, (f"finished: {n_l} loop{'s' if n_l != 1 else ''} done" if goal
                                             else "finished")
        elif at_end:
            ctl.v, v, ctl.state = 0.0, 0.0, "at the end of the route"
        s_prev = s
        s = min(s + v * dt, R["end"] - L / 2 - 0.5)
        if goal is not None and ft["dist"] + (s - s_prev) > goal:      # (the last loop: it stops where it started)
            s = s_prev + max(0.0, goal - ft["dist"])
        hist = ft.setdefault("v_hist", [])
        hist.append((t, v))
        while hist and hist[0][0] < t - 4.0:
            hist.pop(0)
        if v > 0.05:
            ft["drive_t"] = ft.get("drive_t", 0.0) + dt
        ft["v_top_seen"] = max(ft.get("v_top_seen", 0.0), v)
        if ctl.ttc is not None and ctl.ttc <= follow_test.TTC_WARN_S + 1.0 and \
                (ft.get("lmin_ttc") is None or ctl.ttc < ft["lmin_ttc"]):
            ft["lmin_ttc"] = ctl.ttc                             # (this loop's lowest TTC -- close calls, as the test's)
        self._y3d_near_miss(follower_id, ft, ctl, me)
        # ground truth: the nearest object really in its lane ahead (the AVs of the test, other vehicles, obstacles)
        L_of = {str(o[0]): (o[1], o[4]) for o in objs}
        truth = []
        for d in self._on_trail(trail, s, horizon, [{"id": o[0], "lat": o[2], "lng": o[3]} for o in objs], ss):
            if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M:
                label, Lo = L_of.get(str(d["id"]), (d["id"], 4.5))
                truth.append((d["x"] - L / 2 - float(Lo or 4.5) / 2, str(d["id"]), str(label)))
        near = min(truth) if truth else None
        contact = ft.get("contact")
        if contact is not None:
            if near and near[1] == contact and near[0] <= 1.0:
                s = min(s, s_prev)                              # (still touching what it ran into: it stays)
                ctl.v = v = 0.0
            else:
                ft["contact"] = None
        prev = ft.get("truth_prev")
        closing = 0.0
        if near and prev and prev[0] == near[1] and t > prev[1]:
            closing = 0.5 * prev[3] + 0.5 * (prev[2] - near[0]) / (t - prev[1])
        ft["truth_prev"] = (near[1], t, near[0], closing) if near else None
        ctl.truth(near[0] if near else 1e9, closing if near else 0.0)
        ft["true_gap"] = near[0] if near else None
        ft["near_id"], ft["near_label"] = (near[1], near[2]) if near else (None, None)
        if near and near[0] <= 0.2 and now >= ft["hold_until"] and v > 0.05 and ft.get("contact") != near[1]:
            tg = ctl.target if ctl.target and t - ctl.target["t"] <= follow_test.HOLD_S else None
            by = (tg or {}).get("by") or {}
            ft["snap"] = {"t": t, "speed": v * 3.6, "lidar": by.get("LiDAR"), "camera": by.get("camera"),
                          "radar": by.get("radar"), "points": (tg or {}).get("points"), "seen": bool(tg)}
            try:
                self._ctest_record_collision(follower_id, ft, near, v, me, objs, t)
            except Exception:
                sys.excepthook(*sys.exc_info())
            ctl.collision(t, near[2], near[0])
            ft["contact"] = near[1]
            ft["hold_until"] = now + max(0.5, ft["hold_s"])
            s = max(s_prev, min(s, s + near[0]))                # (it stops where the bodies touch: gap 0, no
            other = self.follow_tests.get(near[1])              #  overlap -- not a step back, which left a gap)
            if other:                                           # an AV of the test: hit from behind
                other["hold_until"] = max(other["hold_until"], now + max(0.5, ft["hold_s"]))
                other["ctl"]._note(now - other["t0"], f"HIT FROM BEHIND by {self.vehicle_label(follower_id)} "
                                                      f"at {v * 3.6:.0f} km/h -- stands {ft['hold_s']:g} s")
            elif near[1] in self.path_replays:
                self._hold_av(near[1], ft["hold_s"])
            text = f"Collision: {self.vehicle_label(follower_id)} x {near[2]}"
            self._y3d_event("collision", text, me[0], me[1])
            self.browser.page().runJavaScript(
                f"window.__accMap = {self.map_var_name};" + ACCIDENT_JS +
                f"window.showAccident({me[0]}, {me[1]}, {json.dumps(text)}, 8000);")
        if ft.get("convoy") and getattr(ctl, "v2v", False):   # (collision testing: did V2V prevent one here?)
            try:
                self._v2v_episode(follower_id, ft, t, now, near, me)
            except Exception:
                sys.excepthook(*sys.exc_info())
        ft["dist"] = ft.get("dist", 0.0) + max(0.0, s - s_prev)
        if (s - s_prev) / dt > 0.05:                         # (standing: by how it really moved -- not the speed it
            ft.pop("stand_since", None)                      #  wanted while pressed against what it ran into)
        else:
            ft.setdefault("stand_since", now)
        if R["loop"] and s >= R["total"]:
            s -= R["total"]
        ft["s"] = s
        pose = self._route_pose(R, s)
        st = self.path_replays.get(follower_id)
        if st is not None:
            st["points"] = [pose]
            st["index"] = 1
        self._replay_move_marker(follower_id, pose[0], pose[1], pose[2])

    PREDICT_S = 4.0                                       # a target out of sight in a bend: predicted this long

    def _predicted_target(self, ft, me, objs, on_tr, t):
        """Track prediction: the target ahead went out of the field of view of every switched-on sensor (a sharp
        bend: the radar sees ±30°, the camera ±45°, the LiDAR ~15 m) -- the tracker follows it along the road for
        PREDICT_S seconds (else the AV sped up in every bend and braked again). Not when it is in view and simply
        not detected (weather, sensors off): then it is lost."""
        ctl = ft["ctl"]
        tg = ctl.target
        seen = {str(d.get("id")) for dl in on_tr.values() for d in dl}
        if tg and str(tg["id"]) in seen:
            ft["pred"] = {"id": str(tg["id"]), "t": t, "label": tg.get("label")}
            return []
        p = ft.get("pred")
        if not p or t - p["t"] > self.PREDICT_S or not ctl.sensors:
            return []
        ob = next((o for o in objs if str(o[0]) == p["id"]), None)
        if ob is None:
            return []
        x, y = follow_test._local(me, ob[2], ob[3])
        ang = abs(math.degrees(math.atan2(y, x)))
        dist = math.hypot(x, y)
        fov = {"camera": self._ctest_cams()[0]["hfov_deg"] / 2, "radar": follow_test.FRONT_RADAR["hfov_deg"] / 2}
        in_view = [s for s in ctl.sensors
                   if (s in fov and ang <= fov[s]) or (s == "LiDAR" and dist <= follow_test.lidar_range(self.climate))]
        if in_view:                                         # it IS in view: missed by the sensors -- no prediction
            return []
        d = self._on_trail(ft["trail"], ft["s"], ft["s"] + 150.0, [{"id": ob[0], "lat": ob[2], "lng": ob[3]}],
                           (ft.get("route") or {}).get("ss"))
        if not d or abs(d[0].get("y", 99)) > follow_test.CORRIDOR_HALF_M:
            return []
        gap = d[0]["x"] - ft["L"] / 2 - float(ob[4] or 4.5) / 2
        return [{"id": ob[0], "label": p.get("label") or ob[1], "gap": max(0.0, gap), "x": d[0]["x"], "y": d[0]["y"],
                 "sensor": "predicted"}]

    @staticmethod
    def _box_centres(dets, objs):
        """LiDAR detections at the object's box centre (the points are on its near side -- an AV coming the other
        way in the next lane looked like it was in this lane): the tracker's box fit."""
        centre = {str(o[0]): (o[2], o[3]) for o in objs}
        out = []
        for d in dets or []:
            c = centre.get(str(d.get("id")))
            out.append(dict(d, lat=c[0], lng=c[1]) if c else d)
        return out

    @staticmethod
    def _path_gaps(dets, me, ego_len=4.94, len_of=None):
        """An object on its road further along than in a straight line (past a U-turn / a bend): its gap is the
        distance along the road -- the sensors measure straight across, the AV has to drive the road. len_of
        (camera / radar models, measured from the object's centre): an object on its road gets the along-road gap
        bumper to bumper."""
        out = []
        for d in dets or []:
            if d.get("lat") is None or d.get("x") is None:
                out.append(d)
                continue
            if len_of and str(d.get("id")) in len_of and abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M + 1.0:
                g = d["x"] - ego_len / 2 - len_of[str(d["id"])] / 2
                out.append(dict(d, gap=max(0.0, g), gap_sensor=d["gap"]))
                continue
            straight = _metres_between(me[0], me[1], d["lat"], d["lng"])
            extra = d["x"] - straight
            out.append(dict(d, gap=d["gap"] + extra, gap_sensor=d["gap"]) if extra > 0.05 else d)
        return out

    def _ctest_window(self, cid, geometry=None):
        import collision_panel
        ct = self.collision_tests[cid]
        trucks = [(m, f"AV {k + 1}" + (" · front" if k == 0 else ""), str(self.vehicle_label(m)))
                  for k, m in enumerate(ct["members"])]
        title = f"Collision testing -- {ct['route']['name']}"
        w = collision_panel.CollisionTestWindow(self, title, trucks, route=ct["route"]["name"], callbacks={
            "camera": lambda i: self._ctest_cam_pick(cid, i),
            "follow2d": lambda vid: self._toggle_follow_2d(vid),
            "follow3d": lambda vid: self._toggle_follow_3d(vid),
            "speed": lambda vid, kmh: self._ctest_speed(cid, vid, kmh),
            "stopgo": lambda vid: self._ctest_stop_go(cid, vid),
            "stopgo_off": lambda vid: self._ctest_stop_go(cid, vid, off=True),
            "sensor": lambda vid, name, on: self._follow_set_sensor(vid, name, on),
            "details": lambda vid: self._ctest_pick(cid, vid),
            "shown": lambda s: self._ctest_shown(cid, s),
            "cont": lambda: [self._follow_continue(m) for m in list(self.collision_tests.get(cid, {}).get("members", []))],
            "pause": lambda: self.pause_collision_test(cid),
            "skip": lambda: self.skip_collision_loop(cid),
            "restart": lambda: self.restart_collision_test(cid),
            "end": lambda: self.end_collision_test(cid),
            "minimize": lambda: self.minimize_to_tray(ct["window"], title),
            "dock": lambda: self._ctest_dock(cid),
            "collisions": lambda: self.open_collision_history(ct.setdefault("collisions", []),
                                                              f"Collisions -- {ct['route']['name']}"),
            "v2v_saves": lambda: self.open_v2v_saves(ct.get("v2v_saves") or [],
                                                     f"Collisions prevented by V2V -- {ct['route']['name']}"),
            "dock_height": lambda h: self._ctest_dock_height(cid, h),
            "mqtt": lambda: self._ctest_mqtt(cid),
            "mqtt_settings": lambda: self._ctest_mqtt(cid, True),
            "results": lambda: self.show_collision_report(
                self._ctest_report(ct, "finished" if ct.get("finished") else "running"))})
        w.finished.connect(lambda *_a: self.end_collision_test(cid) if cid in (getattr(self, "collision_tests", None) or {})
                           else None)
        ct["window"] = w
        w.details.set_cameras([c.get("label") or c.get("id") or "camera" for c in self._ctest_cams(configs=True)],
                              ct.get("cam_sel", 0))
        for key, c in w.details.show_cb.items():
            c.blockSignals(True); c.setChecked(key in ct["shown"]); c.blockSignals(False)
        w.details._shown_changed()
        if ct.get("picked"):
            w.details.set_av(str(self.vehicle_label(ct["picked"])))
        self.make_minimizable(w, title)
        if geometry is not None:
            w.setGeometry(geometry)
            ct["float_geo"] = geometry
        if getattr(self, "_ctest_docked_pref", False):   # (fitted to the main panel last time: again)
            self._ctest_dock(cid, True)
        else:
            w.show()
        self._ctest_update(cid)

    def _ctest_dock(self, cid, on=None):
        """'Fit to main panel': the collision-test panel at the bottom of the main window, above the bottom bar --
        the map / 2D / 3D view shrinks to make room (both visible at once; the divider can be dragged). Again: a
        window of its own."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("window") is None:
            return
        self._panel_dock(ct["window"], ct, on)

    def _panel_dock(self, w, store, on=None):
        """A CollisionTestWindow (live test or replay) fitted to the main panel (on) or floating again (off);
        store: a dict that keeps its floating geometry ("float_geo")."""
        on = (not w.docked) if on is None else bool(on)
        ct = store
        tray = getattr(self, "window_tray", None)
        if tray is not None and tray.has(w):
            tray.remove(w)
        if on:
            if w.isWindow() and w.isVisible():
                ct["float_geo"] = w.geometry()
            w.hide()
            w.setWindowFlags(Qt.Widget)
            self.main_vsplit.addWidget(w)
            self.main_vsplit.setCollapsible(self.main_vsplit.indexOf(w), False)
            w.setMinimumHeight(170)
            w.set_docked(True)
            w.show()

            def refit():                                     # (the splitter lays it out once shown: size it then)
                try:
                    if w.docked:
                        w._fit(w.details.isVisible())
                except RuntimeError:
                    pass
            QTimer.singleShot(0, refit)
        else:
            w.hide()
            w.setMinimumHeight(0)
            w.setParent(self, Qt.Dialog)
            w.set_docked(False)
            self.make_minimizable(w, w.windowTitle())
            if ct.get("float_geo") is not None:
                w.setGeometry(ct["float_geo"])
            w.show()
            w._fit(w.details.isVisible())
            w.raise_(); w.activateWindow()
        self._ctest_docked_pref = on
        print(f"[collision test] panel {'fitted to the main panel' if on else 'floating'}")

    def _ctest_dock_height(self, cid, want):
        """The fitted panel's height: what it needs, at most 60 % of the main area (the map keeps the rest)."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        self._panel_dock_height((ct or {}).get("window"), want)

    def _panel_dock_height(self, w, want):
        try:
            if w is None or not w.docked:
                return
        except RuntimeError:
            return
        sp = self.main_vsplit
        i = sp.indexOf(w)
        if i < 0:
            return
        total = sum(sp.sizes())
        if total <= 0:
            QTimer.singleShot(50, lambda: self._panel_dock_height(w, want))
            return
        h = max(170, min(int(want), int(total * 0.6)))
        sizes = [0] * len(sp.sizes())
        sizes[0], sizes[i] = total - h, h
        sp.setSizes(sizes)

    def _ctest_pick(self, cid, vid):
        """The AV whose detection details are shown under the cards (None: closed)."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct:
            return
        if vid is not None and vid == ct.get("picked"):      # (the same AV's button again: the details close)
            vid = None
        ct["picked"] = vid if vid in ct["members"] else None
        ct.pop("cam_err", None)
        ct["window"].details.set_av(str(self.vehicle_label(vid)) if ct["picked"] else None)
        ct["window"].details.set_camera(None, None, None)
        self._ctest_cam_live_update()
        self._ctest_update(cid)
        self._ctest_camera(cid)

    def _ctest_cam_pick(self, cid, index):
        """Which collision testing camera the details show (several: Vehicles window, "Used for: collision")."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if ct:
            ct["cam_sel"] = max(0, int(index))
            ct["cam_busy"] = 0
            self._ctest_camera(cid)

    def _ctest_shown(self, cid, shown):
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if ct:
            ct["shown"] = set(shown)
            self._ctest_cam_live_update()
            if ct.get("window") is not None:
                self._ctest_update(cid)

    def _ctest_cam_live_update(self):
        """The camera page gets live positions while a collision test shows a front camera image."""
        live = any((ct.get("picked") and "camera" in ct.get("shown", ())) or ct.get("real") for ct in
                   (getattr(self, "collision_tests", None) or {}).values())     # (real-world: every AV's camera)
        if live != getattr(self, "_ctest_cam_live", False):
            self._ctest_cam_live = live
            if live:
                self.open_camera_view(show=False)
            else:
                self._after_camera_panel_change()

    def _ctest_speed(self, cid, vid, kmh):
        f = (self.follow_tests or {}).get(vid)
        if f:
            f["ctl"].set_top_speed(time.time() - f["t0"], kmh)

    def _ctest_stop_go(self, cid, vid, off=False):
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        f = (self.follow_tests or {}).get(vid)
        if not ct or not f:
            return
        if off:
            f["ctl"].stop_and_go_off(time.time() - f["t0"])
        else:
            v = self._stop_go_ask(vid, ct.get("window"))
            if v:
                f["ctl"].stop_and_go(time.time() - f["t0"], *v)
        self._ctest_update(cid)

    def end_collision_test(self, cid, quiet=False, keep_avs=False, report=True):
        """End a collision test: its results are saved (Reports) and -- not quiet -- the results summary shows."""
        ct = (getattr(self, "collision_tests", None) or {}).pop(cid, None)
        if not ct:
            return None
        closing = getattr(self, "_closing", False)
        if closing:                                          # (the app quits: no camera image will come any more)
            for r in ct.get("collisions") or []:
                self._ctest_flush_rec(r)
        rep = None
        if report:                                           # (before the AVs' tests go: their counts)
            how = "app closed" if closing else "finished" if ct.get("finished") else "ended"
            try:                                             # (a few seconds without a collision: not kept; "save
                keep = ct.get("report_dir") or (ct.get("save", True) and   # the results?" No at the start: not kept)
                                                (ct.get("collisions") or time.time() - ct["t0"] >= 10.0))
                rep = self._ctest_save_report(ct, how) if keep else self._ctest_report(ct, how)
            except Exception:
                sys.excepthook(*sys.exc_info())
        if ct.get("replay") is not None:                     # "Save this test for replay?" Yes: the recording kept
            try:
                self._ctest_save_replay(ct, "app closed" if closing else "finished" if ct.get("finished")
                                        else "restarted" if not report else "ended")
            except Exception:
                sys.excepthook(*sys.exc_info())
        for k in ("timer", "cam_timer", "rcam_timer", "pub_timer"):
            if ct.get(k) is not None:
                ct[k].stop(); ct[k].deleteLater()
                ct[k] = None
        if ct.get("hw_pub") is not None:                     # (hardware: the last message -- ended, stop)
            try:
                ct["hw_pub"].close(self._ctest_pub_states(ct))
                print(f"[collision test] publishing ended ({ct['hw_pub'].sent} messages)")
            except Exception:
                sys.excepthook(*sys.exc_info())
            ct["hw_pub"] = None
        for m in ct["members"]:                              # (the yard's AVs: put back as before -- below)
            self.end_follow_test(m, quiet=quiet or m in ct["temp"] or (not keep_avs and m in ct.get("before", {})),
                                 whole_convoy=False)
        if not getattr(self, "_closing", False):
            self._ctest_clear_map(cid)                       # (route + collision markers; Collision history shows them again)
        if ct.get("window") is not None:
            w = ct["window"]
            w.close()
            if getattr(w, "docked", False):                  # (fitted to the main panel: out of it, the map gets the room)
                w.hide()
                w.setParent(None)
                w.deleteLater()
        if not keep_avs:
            for t in ct["temp"]:                             # (AVs made for the test)
                self._ctest_remove_av(t)
            self._ctest_restore(ct)                          # (the map as before the test: AVs, climate)
        self._ctest_cam_live_update()
        if not quiet:
            print("[collision test] ended")
        if rep is not None and not quiet and not closing:
            self.show_collision_report(rep, save=None if rep.get("dir") else
                                       (lambda r=rep, c=ct: self._ctest_save_report(c, r.get("ended_by"), rep=r)))
            if getattr(self, "_current_nav", None) == "reports":
                self.refresh_reports("collision")
        return ct

    def pause_collision_test(self, cid):
        """Pause / resume: all the AVs stand still."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("finished"):
            return
        fts = [self.follow_tests[m] for m in ct["members"] if m in self.follow_tests]
        pause = not any(f.get("paused") for f in fts)
        if pause:                                            # (paused time does not count in the progress times)
            ct["paused_at"] = time.time()
        elif ct.get("paused_at"):
            ct["paused_total"] = ct.get("paused_total", 0.0) + time.time() - ct.pop("paused_at")
        for f in fts:
            f["paused"] = pause
            if pause:
                f["timer"].stop()
            else:
                f["last"] = time.time()
                f["timer"].start(FOLLOW_STEP_MS)
        ct["paused"] = pause
        self._ctest_update(cid)

    def skip_collision_loop(self, cid):
        """Quick test: the current loop ends now. A loop route: every AV moves on (keeping its gaps) until the last
        one is just into the next loop; a route that ends elsewhere: all start the next run. The last loop: the test
        finishes. The distance jumped is not counted as driven (results)."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("finished") or ct.get("paused") or ct.get("loops", 1) == 1:
            return
        fts = [self.follow_tests.get(m) for m in ct["members"]]
        fts = [f for f in fts if f]
        if not fts:
            return
        R, n, now = ct["route"], ct["loops"], time.time()
        k = fts[0].get("lap_i", 1) if R["loop"] else ct.get("run", 1)
        for e in reversed(ct.get("lap_log") or []):
            if e.get("loop") == k:
                e["skipped"] = True
                if "SKIPPED" not in (e.get("settings") or ""):
                    e["settings"] = "SKIPPED" + (f" · {e['settings']}" if e.get("settings") else "")
                break
        ct["log"].append((now - ct["t0"], f"LOOP {k} SKIPPED (Skip loop)"
                          + (" -- the last loop: test finished" if n and k >= n else "")))
        print(f"[collision test] loop {k} skipped")
        if n and k >= n:
            self._ctest_finish(cid)
            return
        if R["loop"]:
            total = max(1.0, R["total"])
            delta = k * total + 0.5 - fts[-1].get("dist", 0.0)
            if delta > 0:
                for f in fts:
                    f["dist"] = f.get("dist", 0.0) + delta
                    f["skip_m"] = f.get("skip_m", 0.0) + delta
                    s = f["s"] + delta
                    while s >= total:
                        s -= total
                    f["s"] = s
        else:
            self._ctest_new_run(cid)
        for m in ct["members"]:
            f = self.follow_tests.get(m)
            if not f:
                continue
            f["contact"] = f["truth_prev"] = None
            f["hold_until"] = 0.0
            f["radar_track"] = {}
            for key in ("pred", "stand_since"):
                f.pop(key, None)
            f["ctl"].target = None
            pose = self._route_pose(R, f["s"])
            st = self.path_replays.get(m)
            if st is not None:
                st["points"], st["index"] = [pose], 1
            self._replay_move_marker(m, pose[0], pose[1], pose[2])
        self._ctest_laps(cid)
        self._ctest_update(cid)

    def restart_collision_test(self, cid):
        """Again from the start of the route (each AV's current top speed, gap and sensors)."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct:
            return
        members = []
        for m in ct["members"]:
            f = self.follow_tests.get(m)
            if f:
                members.append((m, f["ctl"].v_max * 3.6, f["ctl"].gap_set,
                                set(f["ctl"].sensors) | ({"V2V"} if f["ctl"].v2v else set())))
        geo = ct["window"].geometry() if ct.get("window") is not None else None
        if getattr(ct.get("window"), "docked", False):     # (fitted to the main panel: its floating place)
            geo = ct.get("float_geo")
        if ct.get("pub_timer") is not None:                  # (publishing goes on with the same connection)
            ct["pub_timer"].stop()
        hw_pub = ct.pop("hw_pub", None)
        self.end_collision_test(cid, quiet=True, keep_avs=True, report=False)
        if ct.get("plan"):                                   # (a plan: every AV as the setup had it, loop 1 sets it)
            members = [(m, s["top_kmh"], s["gap_m"], set(s["sensors"]) | ({"V2V"} if s.get("v2v") else set()))
                       for m, s in zip(ct["members"], ct["setup"])]
            if ct.get("climate0"):
                self.set_climate(ct["climate0"])
        self.start_collision_test(ct["route"]["name"], members, ct["hold_s"], temp=ct["temp"], geometry=geo,
                                  picked=ct.get("picked"), shown=ct.get("shown"), drive_side=ct["route"].get("side"),
                                  loops=ct.get("loops", 1), plan=ct.get("plan"), v2v=ct.get("v2v"),
                                  real=ct.get("real"), publish=ct.get("publish"), hw_pub=hw_pub,
                                  save=ct.get("save", True), before=ct.get("before"),
                                  replay=ct.get("replay") is not None)

    def _ctest_gap_ahead(self, fid):
        """(gap m, label) to what is ahead of this AV in its lane (None: nothing)."""
        f = self.follow_tests[fid]
        if f.get("true_gap") is None:
            return None, None
        return f["true_gap"], f.get("near_label") or "?"

    def _ctest_sstat_safe(self, ft):
        try:
            return self._ctest_sensor_status(ft)
        except Exception:
            sys.excepthook(*sys.exc_info())
            return {}

    def _ctest_sensor_status(self, ft):
        """Each sensor's state for the card's icons: {key: (state, tip)} -- state one of
        off · full (sees the vehicle ahead well) · low (sees it, weak: few LiDAR points, radar coasting / weak echo,
        old V2V message) · partial (camera: only 'object', no type -- or it sees another object, not the vehicle
        ahead) · none (the vehicle ahead is within its clear-weather reach but it does not see it) · far (beyond its
        reach even in clear weather) · idle (nothing in the lane ahead)."""
        ctl = ft["ctl"]
        seen = ft.get("seen") or {}
        lane = seen.get("lane") or {}
        near_id = ft.get("near_id")
        gap = ft.get("true_gap")
        lab = ft.get("near_label") or "the vehicle ahead"
        clim = self.climate or {}
        try:
            cam0 = self._ctest_cams()[0]
        except Exception:
            cam0 = follow_test.FRONT_CAMERA
        reach = {"camera": follow_test.camera_range(None, cam0), "LiDAR": follow_test.lidar_range(None),
                 "radar": follow_test.radar_range(None), "V2V": 450.0}
        now_r = {"camera": follow_test.camera_range(clim, cam0), "LiDAR": follow_test.lidar_range(clim),
                 "radar": follow_test.radar_range(clim)}
        out = {}
        for key in follow_test.SENSORS_ALL + ("V2V",):
            on = ctl.v2v if key == "V2V" else key in ctl.sensors
            if not on:
                out[key] = ("off", f"{key}: switched OFF")
                continue
            dets = [d for d in (lane.get(key) or []) if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M]
            rng = f" (reach here ~{now_r[key]:.0f} m, clear weather ~{reach[key]:.0f} m)" if key in now_r else ""
            if near_id is None:
                out[key] = ("idle", f"{key}: on -- nothing in its lane ahead to detect")
                continue
            d = next((x for x in dets if str(x.get("id")) == str(near_id)), None)
            if d is not None:
                g = float(d.get("gap") or 0)
                if key == "LiDAR" and int(d.get("points") or 99) < 10:
                    out[key] = ("low", f"LiDAR: sees {lab} at {g:.1f} m, but only {d.get('points')} laser points "
                                       f"(weak){rng}")
                elif key == "radar" and (d.get("coasting") or float(d.get("pd") if d.get("pd") is not None else 1) < 0.7):
                    out[key] = ("low", f"Radar: {lab} at {g:.1f} m, weak echo"
                                       + (" (missed this scan, kept)" if d.get("coasting") else
                                          f" (detected {float(d['pd']):.0%} of scans)") + rng)
                elif key == "V2V" and float(d.get("age") or 0) > 0.15:
                    out[key] = ("low", f"V2V: {lab} at {g:.1f} m from a message {float(d['age']) * 1000:.0f} ms old")
                elif key == "camera" and d.get("cls") == "object":
                    out[key] = ("partial", f"Camera: sees something at {g:.1f} m but cannot tell what it is "
                                           f"(confidence {float(d.get('conf') or 0):.0%}){rng}")
                else:
                    extra = (f", {d.get('points')} points" if key == "LiDAR" and d.get("points") else
                             f", {d.get('cls')} {float(d.get('conf') or 0):.0%}" if key == "camera" and d.get("cls") else "")
                    out[key] = ("full", f"{key}: sees {lab} at {g:.1f} m{extra} -- OK")
                continue
            if dets:
                o = min(dets, key=lambda x: x.get("gap", 1e9))
                out[key] = ("partial", f"{key}: sees {o.get('label') or o.get('id')} at {float(o.get('gap') or 0):.1f} m"
                                       f", NOT {lab} ({gap:.1f} m ahead){rng}")
                continue
            if gap is not None and gap > reach[key]:
                out[key] = ("far", f"{key}: {lab} is {gap:.0f} m ahead -- beyond its reach (~{reach[key]:.0f} m) even "
                                   "in clear weather")
                continue
            why = ""
            if key == "V2V":
                why = " -- no fresh message from it (not connected, lost, or blocked)"
            elif key == "camera" and str(near_id) in {str(k) for k in (seen.get("hidden") or {})}:
                why = " -- hidden behind another vehicle"
            elif key in now_r and gap is not None and gap > now_r[key]:
                why = f" -- the weather cuts its reach to ~{now_r[key]:.0f} m"
            out[key] = ("none", f"{key}: does NOT see {lab} ({gap:.1f} m ahead){why}{rng}")
        return out

    def _ctest_update(self, cid):
        """The window: every card and the picked AV's details -- 3 times a second."""
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("window") is None:
            return
        try:
            self._ctest_laps(cid)
        except Exception:
            sys.excepthook(*sys.exc_info())
        if cid not in self.collision_tests:
            return
        lbl = (self.climate or {}).get("label", "?")
        if ct["climates"][-1:] != [lbl]:
            ct["climates"].append(lbl)
        now = time.time()
        cards, held_any, coll, full = {}, False, 0, None
        for m in ct["members"]:
            f = self.follow_tests.get(m)
            if not f:
                continue
            c = f["ctl"]
            held = now < f["hold_until"]
            held_any |= held
            coll += c.stats["collisions"]
            if "FULL" in c.state and full is None:
                full = m
            tg = c.target if c.target and (now - f["t0"]) - c.target["t"] <= follow_test.HOLD_S else None
            by = (tg or {}).get("by") or {}
            lo = c.stats["min_ttc"]
            gap, ahead = self._ctest_gap_ahead(m)
            cards[m] = {"speed": c.v * 3.6, "brake": self._follower_brake(m), "set": c.v_max * 3.6, "sg": bool(c.sg),
                        "gap": gap, "ahead": ahead, "set_gap": c.gap_set, "stop": follow_test.STOP_GAP_M,
                        "held": held, "state": "stopped (collision)" if held else c.state,
                        "ttc": (c.ttc, c.ttc_true, "--" if lo is None else f"{lo:.1f} s"),
                        "sensors": set(c.sensors), "det": {s: by.get(s) for s in follow_test.SENSORS_ALL + ("V2V",)},
                        "v2v": self._ctest_v2v_card(ct, m, f),
                        "sstat": self._ctest_sstat_safe(f),
                        "collisions": c.stats["collisions"], "brakes": c.stats["brakes"], "full": c.stats["full_brakes"]}
            k = ct["seen"].get(m, 0)
            for t, text in c.log[k:]:
                ct["log"].append((t, f"{self.vehicle_label(m)}: {text}"))
            ct["seen"][m] = len(c.log)
        n_l, lap, R = ct["loops"], ct["lap"], ct["route"]
        if ct.get("finished"):
            lap_text = ("single run done" if n_l == 1 else f"{lap} / {n_l} loops done")
        elif n_l == 1:
            lap_text = "single run"
        else:
            lap_text = f"Loop {lap}" + (f" / {n_l}" if n_l else " · until ended")
        tip = []
        for k, m in enumerate(ct["members"]):
            f = self.follow_tests.get(m)
            if f and R["loop"]:
                d = f.get("dist", 0.0)
                tip.append(f"AV {k + 1}: loop {int(d // max(1.0, R['total'])) + 1}, "
                           f"{(d % max(1.0, R['total'])) / max(1.0, R['total']):.0%} of it · {d / 1000:.2f} km")
            elif f:
                tip.append(f"AV {k + 1}: run {ct.get('run', 1)}, {max(0.0, f['s']) / max(1.0, R['end']):.0%} of the "
                           f"route · {f.get('dist', 0.0) / 1000:.2f} km")
        if ct.get("finished"):
            status, scol = "FINISHED", "#22C55E"
        elif held_any:
            status, scol = "COLLISION", "#EF4444"
        elif ct.get("paused"):
            status, scol = "PAUSED", "#94A3B8"
        elif full:
            status, scol = f"FULL BRAKE: {self.vehicle_label(full)}", "#EF4444"
        else:
            n = len(ct["members"])
            status, scol = f"running · {n} AV{'s' if n != 1 else ''} on {ct['route']['name']}", "#22C55E"
        clim = (f"{(self.climate or {}).get('label', '?')} · camera ~{follow_test.camera_range(self.climate, self._ctest_cams()[0]):.0f} m"
                f" · LiDAR ~{follow_test.lidar_range(self.climate):.0f} m · radar ~{follow_test.radar_range(self.climate):.0f}"
                f" m · grip {follow_test.road_grip(self.climate):.0%}")
        f3d = getattr(self, "_follow_3d", None) if self.yard3d_view is not None and self.yard3d_view.isVisible() else None
        pk = ct.get("picked")
        details = self._detect_data(pk) if pk in self.follow_tests else None
        view = {
            "status": status, "status_col": scol, "climate": clim, "cards": cards, "collisions": coll,
            "held": held_any, "paused": bool(ct.get("paused")), "log": ct["log"], "picked": pk, "details": details,
            "lap": lap_text, "lap_tip": "\n".join(tip), "finished": bool(ct.get("finished")),
            "mode": "real" if ct.get("real") else "sim",
            "mode_tip": "\n".join(f"{k}: {v['used']}" + ("" if v["integrated"] else f"  (chosen: {v['chosen']} -- "
                                                                                    "not integrated)")
                                  for k, v in (ct.get("real_methods") or {}).items()) if ct.get("real") else "",
            "v2v_saves": len(ct.get("v2v_saves") or []) if ct.get("v2v_ch") is not None and any(
                (self.follow_tests.get(x) or {}).get("ctl") is not None and self.follow_tests[x]["ctl"].v2v
                for x in ct["members"]) else None,
            "progress": self._ctest_progress(ct),
            "pub": ct["hw_pub"].summary() if ct.get("hw_pub") is not None else None,
            "pub_on": ct.get("hw_pub") is not None,
            "can_skip": ct.get("loops", 1) != 1,
            "pub_tip": ("Publishing to hardware (MQTT) -- " + f"{ct['publish']['host']}:{ct['publish']['port']}\n"
                        + "\n".join(f"AV {n}: {__import__('hw_publish').topic_of(ct['publish'], n)}"
                                    + (f"  ·  {m['kmh']:.0f} km/h, brake {m['brake_pct']}% ({m['brake_mode']}), "
                                       f"{m['status']}" if (m := ct['hw_pub'].last.get(n)) else "")
                                    for n in ct["publish"]["trucks"])) if ct.get("hw_pub") is not None else "",
            "note": "The test is finished: it ends now -- the results summary opens and the map is put back as "
                    "before the test" if ct.get("finished") else
                    "Held after a collision: look at the cards and the detection details -- Continue now to go on"
                    if held_any else "",
            "f2d": getattr(self, "_follow_2d", None), "f3d": f3d}
        ct["window"].update_view(view)
        rec = ct.get("replay")
        if rec is not None:                                  # (saved for replay: this view + the AVs' details)
            try:
                dets = {}
                for m in rec.need_details(now, ct["members"], pk):
                    if m == pk:
                        dets[m] = details
                    elif m in self.follow_tests:
                        dets[m] = self._detect_data(m)
                rec.add_window(now, view, dets)
            except Exception:
                sys.excepthook(*sys.exc_info())

    def _why_not(self, ft, sensor):
        """Why a sensor does not detect what is in its lane ahead (the detection details)."""
        c = self.climate or {}
        gap, label = ft.get("true_gap"), ft.get("near_label")
        if gap is None:
            return "nothing in its lane ahead"
        what = f"{label} at {max(0.0, gap):.1f} m"
        st = ft.get("real")
        if st:                                            # real-world processing: what the sensor's data showed
            if sensor == "camera":
                raw = st.get("cam_raw") or []
                lane = [d for d in raw if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M]
                return (f"{what}: not found in the latest picture"
                        + (f" -- it found {len(raw)} other object(s) there" if raw else
                           " -- too little contrast against the road (fog / rain / night) or too far")
                        + ("" if not lane else "; in its lane: " + ", ".join(f"{d['cls']} {d['conf']:.0%} at {d['x']:.0f} m" for d in lane[:2])
                           + " (unclassified ones are not braked for)")
                        + (f"; {st['cam_unconfirmed']} standing camera-only object(s) not confirmed by LiDAR / radar "
                           "-- ignored" if st.get("cam_unconfirmed") else ""))
            if sensor == "LiDAR":
                n = st.get("lidar_pts")
                return (f"{what}: no point cluster on it in the latest scan ({n if n is not None else '?'} points "
                        "ahead after ground removal; fog / rain points filtered as noise)")
            if sensor == "radar":
                return f"{what}: no confirmed echo track (too weak, or standing and not confirmed yet)"
        vis = float(c.get("visibility_m") or 4500)
        cond = []
        if vis < 1000:
            cond.append(f"visibility {vis:.0f} m")
        if c.get("day") is False:
            cond.append("night")
        p = c.get("precip") or {}
        if p.get("type") in ("rain", "snow") and p.get("rate"):
            cond.append(f"{'heavy ' if p['rate'] > 0.6 else ''}{p['type']}")
        weather = f" ({', '.join(cond)})" if cond else ""
        ob0 = next((o for o in (ft.get("seen") or {}).get("objs", []) if str(o[0]) == str(ft.get("near_id"))), None)
        me = (ft.get("seen") or {}).get("me")
        if ob0 is not None and me is not None and sensor in ("camera", "radar"):     # (a bend: out of its view)
            x, y = follow_test._local(me, ob0[2], ob0[3])
            half = (self._ctest_cams()[0]["hfov_deg"] if sensor == "camera" else follow_test.FRONT_RADAR["hfov_deg"]) / 2
            ang = math.degrees(math.atan2(y, x))
            if abs(ang) > half:
                return (f"{what}: outside its field of view (±{half:.0f}°) -- it is {abs(ang):.0f}° to the "
                        f"{'left' if ang > 0 else 'right'} in the bend")
        if sensor == "camera":
            by = next((v for k, v in ((ft.get("seen") or {}).get("hidden") or {}).items() if str(k) == str(ft.get("near_id"))), None)
            if by:
                return f"{what}: hidden behind {by} (occlusion)"
            rng = follow_test.camera_range(self.climate, self._ctest_cams()[0])
            return f"{what}: beyond the camera's range in {c.get('label', 'this climate')}{weather}: ~{rng:.0f} m"
        if sensor == "LiDAR":
            rng = follow_test.lidar_range(self.climate)
            return (f"{what}: too few laser returns -- {c.get('label', 'the weather')}{weather} absorbs them; it "
                    f"sees ~{rng:.0f} m" if rng < 14.5 else f"{what}: beyond the LiDAR's range (~{rng:.0f} m)")
        ob = next((follow_test._obj(o) for o in (ft.get("seen") or {}).get("objs", [])
                   if str(o[0]) == str(ft.get("near_id"))), None)
        if ob is None:
            rng = follow_test.radar_range(self.climate)
            return f"{what}: too weak an echo (~{rng:.0f} m for a moving truck in {c.get('label', 'this climate')})"
        rcs = follow_test.radar_rcs_db(ob["kind"], ob["W"])
        rng = follow_test.radar_range(self.climate, rcs_db=rcs, static=not ob["moving"])
        loss = follow_test.radar_losses_db(self.climate, max(1.0, gap))
        why = []
        if rcs < 5:
            why.append(f"small radar cross-section ({rcs:+.0f} dBsm)")
        if not ob["moving"]:
            why.append("standing still: partly filtered as ground clutter")
        if loss >= 1.0:
            why.append(f"{c.get('label', 'weather')}: −{loss:.1f} dB (rain / snow attenuation, wet radome, spray)")
        return (f"{what}: echo too weak -- a {ob['kind']} is detected only up to ~{rng:.0f} m here"
                + (f" ({'; '.join(why)})" if why else ""))

    def _detect_data(self, fid, clim=""):
        """The detection details of one AV: each sensor's result (or why not), TTC, sensor view,
        table."""
        ft = self.follow_tests[fid]
        ctl, now = ft["ctl"], time.time()
        held = now < ft["hold_until"]
        snap = ft.get("snap") if held else None
        tg = ctl.target if ctl.target and (now - ft["t0"]) - ctl.target["t"] <= follow_test.HOLD_S else None
        route = "route" in ft
        real = ft.get("true_gap") if route else ft.get("true_gap", 0.0)
        ref = ft.get("near_id") if route else ft["leader"]
        by = ({"LiDAR": snap["lidar"], "camera": snap["camera"], "radar": snap.get("radar")} if snap
              else (tg or {}).get("by")) or {}
        is_ref = bool(snap) or (bool(tg) and str(tg.get("id")) == str(ref))
        other = "" if is_ref or not tg else f" ({tg['label']})"
        sn = ft.get("seen") or {}
        cam_d = next((d for d in (sn.get("raw") or {}).get("camera", []) if tg and str(d["id"]) == str(tg["id"])), None)
        li, ca, ra = by.get("LiDAR"), by.get("camera"), by.get("radar")
        v_rel = (tg or {}).get("v_rel")
        err = (lambda x: (x - real) if is_ref and real is not None else None)
        view, table = self._follow_sensor_view(fid)
        return {
            "sensors_on": set(ctl.sensors), "real": real,
            "ahead": (ft.get("near_label") if route else str(self.vehicle_label(ft["leader"]))) or "--",
            "lidar": (li, f"{(snap or tg or {}).get('points') or '?'} laser points on it{other}", err(li))
            if li is not None else None,
            "cam": (ca, (f"classified: {cam_d.get('cls')} {cam_d.get('conf', 0):.0%}" if cam_d else "") + other,
                    err(ca)) if ca is not None else None,
            "radar": (ra, (f"relative speed {round(v_rel * 3.6) or 0:+d} km/h (Doppler)" if v_rel is not None else "")
                      + (lambda r: (f" · SNR {r['margin_db']:+.0f} dB over threshold, detected {r['pd']:.0%} of scans"
                                    if r.get("margin_db") is not None else
                                    f" · track {r.get('track')}: {r.get('points', '?')} echo points, strongest "
                                    f"{r.get('power_db', 0):.0f} dB" + (" (coasting)" if r.get("coasting") else ""))
                         if r else "")(next((d for d in (sn.get("raw") or {}).get("radar", [])
                                             if tg and str(d["id"]) == str(tg["id"])), None))
                      + other, err(ra)) if ra is not None else None,
            "why": dict({s: self._why_not(ft, s) for s in follow_test.SENSORS_ALL} if route else {},
                        V2V=self._v2v_why(ft) if route else ""),
            "v2v": self._v2v_tile(ft, tg, is_ref, err) if route else None,
            "v2v_msgs": self._v2v_messages(fid, ft) if route else None,
            "v2v_on": bool(getattr(ctl, "v2v", False)),
            "ttc": (ctl.ttc, ctl.ttc_true, ctl.stats["min_ttc"], ctl.stats["min_ttc_true"],
                    ctl.stats["ttc_warnings"], ctl.stats["ttc_critical"]),
            "view": view, "table": table}

    def _v2v_messages(self, fid, ft):
        """The detection details' 'V2V messages' tab: what this AV sends, every message it holds now (all its
        fields, used or why not), the counts, the latest events."""
        import v2v as v2v_mod
        ct = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy")) or {}
        ch = ct.get("v2v_ch")
        ctl = ft["ctl"]
        on = bool(getattr(ctl, "v2v", False))
        out = {"on": on, "link": v2v_mod.label(ct.get("v2v") or {}) if ch is not None else "", "rows": [],
               "events": [], "sent": None, "stats": None}
        if ch is None:
            return out
        now = time.time()
        tl = ch.tx_log.get(fid) or ch.tx_log.get(str(fid))
        if tl and tl.get("last"):
            m = tl["last"]
            out["sent"] = {"n": tl["n"], "alerts": tl["alerts"], "age": now - m["t"], "v": m["v"], "a": m["a"],
                           "hd": m.get("hd"), "brake": m["brake"], "L": m["L"], "lat": m["lat"], "lon": m["lon"],
                           "err": m.get("err_m")}
        if on:
            out["stats"] = ch.summary(fid)
            use = ft.get("v2v_use") or {}
            me = ((ft.get("seen") or {}).get("me"))
            for m in sorted(ch.inbox(fid, now), key=lambda x: x.get("dist", 0)):
                f_, l_ = follow_test._local(me, m["lat"], m["lon"]) if me else (None, None)
                out["rows"].append({
                    "from": str(m["label"]), "kind": "BRAKE ALERT" if m.get("alert") else "state (BSM / CAM)",
                    "age_ms": 1000 * m["age"], "delay_ms": 1000 * m["delay"], "dist": m.get("dist"),
                    "ahead": f_, "left": l_, "v": m["v"], "a": m["a"], "hd": m.get("hd"), "brake": m["brake"],
                    "L": m["L"], "err": m.get("err_m"), "use": use.get(str(m["tx"]), "--")})
            for t, m in reversed((ch.rx_log.get(fid) or [])[-12:]):
                out["events"].append(f"{t - ft['t0']:6.1f} s  received {'BRAKE ALERT' if m.get('alert') else 'state'} "
                                     f"from {m['label']} · {m['delay'] * 1000:.0f} ms radio delay · {m['dist']:.0f} m "
                                     f"away · {m['v'] * 3.6:.0f} km/h" + (" · BRAKING" if m["brake"] else ""))
            for t, rx, tx, kind, text in ch.events[-30:]:
                if rx == fid and kind == "lost":
                    out["events"].insert(0, f"{t - ft['t0']:6.1f} s  {text}")
        try:                                             # heavy traffic: channel load, the app's own cost
            out["load"] = ch.load_info(fid, now)
            out["perf"] = ch.perf_info(now)
        except Exception:
            sys.excepthook(*sys.exc_info())
        # one message field by field: the one it uses (else the nearest received, else its own last sent)
        inbox = sorted(ch.inbox(fid, now), key=lambda x: x.get("dist", 0)) if on else []
        use = ft.get("v2v_use") or {}
        pick = next((m for m in inbox if str(use.get(str(m["tx"]), "")).startswith("IN ITS LANE")), None) or \
            (inbox[0] if inbox else None)
        how = "received"
        if pick is None and tl and tl.get("last"):
            pick, how = tl["last"], "sent"
        if pick is not None:
            fmt = {"tx": str(pick.get("label") or pick.get("tx")), "t": time.strftime("%H:%M:%S", time.localtime(
                pick["t"])) + f".{int(pick['t'] * 1000) % 1000:03d}", "lat": f"{pick['lat']:.6f}",
                   "lon": f"{pick['lon']:.6f}", "hd": "--" if pick.get("hd") is None else f"{pick['hd']:.0f}",
                   "v": f"{pick['v']:.1f} ({pick['v'] * 3.6:.0f} km/h)", "a": f"{pick['a']:+.1f}",
                   "brake": "YES" if pick.get("brake") else "no", "L": f"{pick['L']:.1f}",
                   "alert": "BRAKE ALERT" if pick.get("alert") else "state"}
            out["example"] = {"how": how, "from": fmt["tx"],
                              "bytes": v2v_mod.ALERT_BYTES if pick.get("alert") else v2v_mod.MSG_BYTES,
                              "fields": [(nm, fmt.get(k, "--"), unit, mean) for k, nm, unit, mean in v2v_mod.MSG_FIELDS],
                              "extra": ({"age_ms": 1000 * pick.get("age", 0.0), "delay_ms": 1000 * pick["delay"],
                                         "dist": pick.get("dist"), "err": pick.get("err_m"),
                                         "use": use.get(str(pick["tx"]), "--")} if how == "received" else
                                        {"err": pick.get("err_m")})}
        return out

    def _v2v_tile(self, ft, tg, is_ref, err):
        """The detection details' V2V tile: (distance, what the message says, error to the real gap) | None."""
        ctl = ft["ctl"]
        if not getattr(ctl, "v2v", False):
            return None
        dets = ((ft.get("seen") or {}).get("raw") or {}).get("V2V") or []
        lane = [d for d in dets if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M]
        d = next((x for x in lane if tg and str(x["id"]) == str(tg["id"])), None) or (min(lane, key=lambda x: x["gap"])
                                                                                    if lane else None)
        if d is None:
            return None
        v_other = max(0.0, ctl.v + float(d.get("v_rel") or 0.0)) * 3.6
        txt = (f"{d['label']}: message {1000 * float(d.get('age') or 0):.0f} ms old (radio delay "
               f"{1000 * float(d.get('delay') or 0):.0f} ms) · its speed {v_other:.0f} km/h"
               + (" · BRAKE ALERT" if d.get("brake") else "")
               + f" · {ft.get('v2v_n', 0)} vehicle(s) heard"
               + ("" if ctl.v2v_brake else " · warns only"))
        e = (d["gap"] - ft["true_gap"]) if ft.get("true_gap") is not None and ft.get("near_id") is not None and \
            str(ft["near_id"]) == str(d["id"]) else None
        return (float(d["gap"]), txt, e)

    def _v2v_why(self, ft):
        """Why V2V gives nothing about what is in its lane ahead: off / not connected / lost / out of range."""
        ctl = ft["ctl"]
        if not getattr(ctl, "v2v", False):
            return "V2V switched off for this AV"
        nid, lab = ft.get("near_id"), ft.get("near_label")
        if nid is None:
            return "no vehicle in its lane ahead"
        ct = (getattr(self, "collision_tests", None) or {}).get(ft.get("convoy")) or {}
        other = self.follow_tests.get(nid)
        import v2v as v2v_mod
        connected = bool(other and other["ctl"].v2v) or (
            not other and v2v_mod.connected(nid, float((ct.get("v2v") or {}).get("connected_pct") or 0)))
        if not connected:
            return f"{lab} is not connected -- it sends no V2V messages"
        heard = any(str(d.get("id")) == str(nid) for d in ((ft.get("seen") or {}).get("raw") or {}).get("V2V") or [])
        return (f"{lab}: its messages put it beside its lane (GNSS position error) -- not taken as ahead" if heard else
                f"{lab}: no fresh message (lost / out of range / a building in the way)")

    # ---- the picked AV's front camera image (rendered on the Camera View page) ----
    def _ctest_camera(self, cid):
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or ct.get("window") is None or not ct["window"].isVisible():
            return
        fid = ct.get("picked")
        if not fid or "camera" not in ct.get("shown", ()) or fid not in self.follow_tests:
            return
        if ct.get("cam_busy") and time.time() - ct["cam_busy"] < 3.0:
            return
        if getattr(self, "camera_view", None) is None:
            self._ctest_cam_live_update()
            return
        ct["cam_busy"] = time.time()
        confs = self._ctest_cams(configs=True)
        conf = confs[min(ct.get("cam_sel", 0), len(confs) - 1)]
        cam_keys = ("x_left_cm", "y_cm", "z_cm", "yaw_deg", "pitch_deg", "hfov_deg", "vfov_deg", "origin_height_m")
        opt = {"id": fid, "w": 640, "quality": 74, "cam": {k: conf[k] for k in cam_keys if conf.get(k) is not None}}

        def shoot(objects, c=cid, f=fid):
            # the positions of this moment go to the 3D pages first, then the shot (same page queue: in order)
            try:
                self._send_yard3d_dynamic(objects)
            except Exception:
                sys.excepthook(*sys.exc_info())
            if getattr(self, "camera_view", None) is not None:
                self.camera_view.page().runJavaScript(
                    f"window.frontCamShot ? window.frontCamShot({json.dumps(opt)}) : null",
                    lambda res: self._ctest_camera_result(c, f, res))
        if self.map_var_name:
            self.browser.page().runJavaScript(self._objects_js(), shoot)

    def _ctest_camera_result(self, cid, fid, res):
        import base64
        ct = (getattr(self, "collision_tests", None) or {}).get(cid)
        if not ct or getattr(self, "_closing", False):
            return
        ct["cam_busy"] = 0
        w = ct.get("window")
        if w is None or ct.get("picked") != fid or fid not in self.follow_tests:
            return
        if not isinstance(res, dict) or not res.get("jpeg"):
            msg = (res or {}).get("err") if isinstance(res, dict) else None
            w.details.set_camera(None, {"banner": f"camera: {msg or 'the camera page is loading ...'}"}, None)
            return
        pix = w.camera_pixmap(base64.b64decode(res["jpeg"]))
        confs = self._ctest_cams(configs=True)
        conf = confs[min(ct.get("cam_sel", 0), len(confs) - 1)]
        overlay, calc = self._camera_overlay(fid, res, conf)
        w.details.set_camera(pix, overlay, calc)
        if ct.get("replay") is not None:                     # (saved for replay: the image + its boxes / working)
            try:
                ct["replay"].add_camera(time.time(), fid, res["jpeg"], overlay, calc)
            except Exception:
                sys.excepthook(*sys.exc_info())

    def _camera_overlay(self, fid, shot, conf):
        """Boxes on the camera image: the camera's detections (class, confidence, distance from the image) and
        what it misses (why) + how the distance is worked out (calc: {camera, title, lines, note})."""
        ft = self.follow_tests[fid]
        if ft.get("real"):
            return self._camera_overlay_real(fid, shot, conf)
        ctl, sn = ft["ctl"], ft.get("seen") or {}
        cam_on = "camera" in ctl.sensors
        model = follow_test.camera_model(conf)
        label = conf.get("label") or "camera"
        dets = {str(d["id"]): d for d in (sn.get("raw") or {}).get("camera", [])}
        lane = {str(d["id"]) for d in (sn.get("lane") or {}).get("camera", [])
                if abs(d.get("y", 99)) <= follow_test.CORRIDOR_HALF_M}
        hidden = {str(k): v for k, v in (sn.get("hidden") or {}).items()}
        near_id = str(ft.get("near_id")) if ft.get("near_id") is not None else None
        fy, H, W = shot["fy"], shot["h"], shot["w"]
        horizon = H / 2 - fy * math.tan(math.radians(shot.get("pitch_deg", 3)))
        rng = follow_test.camera_range(self.climate, model)
        clim = (self.climate or {}).get("label", "this climate")
        boxes, main = [], None
        for b in sorted(shot.get("boxes") or [], key=lambda b: -b["dist"]):
            oid = str(b["id"])
            if b["dist"] > 120:
                continue
            h_px = max(1.0, b["y1"] - b["y0"])
            est = fy * b["h_m"] / h_px                                # d = f * H / h
            xy = {k: b[k] for k in ("x0", "y0", "x1", "y1")}
            if cam_on and oid in dets:
                d = dets[oid]
                boxes.append(dict(xy, col="#22C55E", lines=[f"{d.get('cls', 'object')} {d.get('conf', 0):.0%}",
                                                            f"{est:.1f} m"]))
                if main is None or oid == near_id or (main[0]["id"] != near_id and b["dist"] < main[0]["dist"]):
                    main = (b, d, est)
            elif oid in hidden and (oid in lane or oid == near_id):
                boxes.append(dict(xy, col="#F59E0B", dashed=True, lines=[f"hidden behind {hidden[oid]}"]))
            elif oid == near_id or oid in lane:
                boxes.append(dict(xy, col="#EF4444", dashed=True,
                                  lines=["camera OFF" if not cam_on else "NOT detected", f"real {b['dist']:.1f} m"]))
        banner, bcol = None, None
        if not cam_on:
            banner, bcol = "CAMERA SWITCHED OFF -- the AV does not use this image", "#EF4444"
        elif main is None and near_id is not None:
            banner, bcol = f"Nothing detected -- {self._why_not(ft, 'camera')}", "#EF4444"
        overlay = {"w": W, "h": H, "boxes": boxes, "banner": banner, "banner_col": bcol, "horizon": horizon,
                   "caption": f"{label} · {model['hfov_deg']:.0f}° · f = {fy:.0f} px · reach ~{rng:.0f} m in {clim}"}
        calc = {"camera": f"{label} -- what it sees and detects"}
        if main is None:
            calc.update(title="How the camera measures distance", lines=[
                ("size", "d = f · H / h", "focal length × real height / box height"),
                ("road", "d = f · h_cam / (y_bottom − y_horizon)", "where the box stands on the road")],
                note="Nothing detected now -- the AV brakes only on its other sensors." if near_id else
                     "Nothing in its lane ahead.")
            return overlay, calc
        b, d, est = main
        h_px = b["y1"] - b["y0"]
        if b.get("clipped"):                                   # (cut by the image edge: too close to measure)
            calc.update(title=f"{self.vehicle_label(b['id'])}: {d.get('cls', 'object')} {d.get('conf', 0):.0%} -- "
                              "too close to measure from the image", lines=[
                ("real", "distance in the 3D yard", f"{b['dist']:.1f} m")],
                note="The object fills / leaves the image (its box is cut by the image edge): its height in pixels "
                     "no longer gives the distance -- the LiDAR and radar measure it directly.")
            return overlay, calc
        lines = [("size", f"d = f·H/h = {fy:.0f} px × {b['h_m']:.1f} m / {h_px:.0f} px", f"{est:.1f} m")]
        if not b.get("clipped") and b["y1"] - horizon > 2:
            est2 = fy * shot["cam_h"] / (b["y1"] - horizon)
            lines.append(("road", f"d = f·h_cam/(y_b − y_h) = {fy:.0f} × {shot['cam_h']:.1f} m / "
                                  f"({b['y1']:.0f} − {horizon:.0f}) px", f"{est2:.1f} m"))
        lines.append(("real", "distance in the 3D yard", f"{b['dist']:.1f} m"))
        calc.update(title=f"Distance from the image · {self.vehicle_label(b['id'])}: {d.get('cls', 'object')} "
                          f"{d.get('conf', 0):.0%}", lines=lines,
                    note=f"f = focal length in pixels ({model['hfov_deg']:.0f}° lens), H = the class's real height, "
                         f"h = box height; the dashed line is the horizon. Confidence drops far away and in poor "
                         f"visibility.")
        return overlay, calc


    def _follower_brake(self, follower_id):
        """(text, colour) of an AV's brake state in a follow test / convoy."""
        ft = self.follow_tests[follower_id]
        ctl = ft["ctl"]
        if time.time() < ft["hold_until"]:
            return "stopped · collision", "#EF4444"
        if "FULL" in ctl.state:
            return f"FULL BRAKE {-ctl.a:.1f} m/s²" + (" (AEB)" if "AEB" in ctl.state else ""), "#EF4444"
        if ctl.sg and ctl.sg.get("phase") in ("brake", "hold"):
            return ctl.state, "#F59E0B"
        if ctl.a <= -follow_test.BRAKE_LOG:
            return f"braking {-ctl.a:.1f} m/s²", "#F59E0B"
        if ctl.v < 0.2:
            return "stopped", "#94A3B8"
        return "no brake", "#22C55E"

    def _follow_sensor_view(self, follower_id):
        """The window's sensor view (bird's eye) and detections table of one AV."""
        ft = self.follow_tests[follower_id]
        sn, ctl = ft.get("seen"), ft["ctl"]
        if not sn:
            return None, []
        me, now = sn["me"], time.time()
        raw = {s: {str(d["id"]): d for d in sn["raw"][s]} for s in sn["raw"]}
        tg = ctl.target if ctl.target and (now - ft["t0"]) - ctl.target["t"] <= follow_test.HOLD_S else None
        ss = (ft.get("route") or {}).get("ss")
        on_road = {str(d["id"]): d for d in self._on_trail(ft["trail"], ft["s"], sn["s_lead"] + 2.0,
                                                           [{"id": o[0], "lat": o[2], "lng": o[3]} for o in sn["objs"]],
                                                           ss=ss)}
        objs, rows = [], []
        for o in sn["objs"]:
            ob = follow_test._obj(o)
            oid = str(ob["id"])
            x, y = follow_test._local(me, ob["lat"], ob["lon"])
            if x < -20 or x > 170 or abs(y) > 90:
                continue
            tr = on_road.get(oid)
            if oid == str(ft["leader"]) and "route" not in ft:
                lane, gap = True, ft.get("true_gap", x - ft["L"])
            else:
                lane = bool(tr) and abs(tr["y"]) <= follow_test.CORRIDOR_HALF_M
                gap = (tr["x"] if lane else math.hypot(x, y)) - ft["L"] / 2 - ob["L"] / 2   # (along its road / straight)
            det = {s for s in follow_test.SENSORS_ALL if s in ctl.sensors and oid in raw.get(s, {})}
            if getattr(ctl, "v2v", False) and oid in raw.get("V2V", {}):
                det.add("V2V")                            # (known from its V2V messages)
            objs.append({"id": oid, "label": ob["label"], "kind": ob["kind"], "x": x, "y": y, "L": ob["L"], "W": ob["W"],
                         "rel_h": (ob["heading"] - me[2]) if ob["heading"] is not None else 0.0, "det": det,
                         "lane": lane, "gap": max(0.0, gap), "hidden": oid in {str(k) for k in sn["hidden"]},
                         "target": bool(tg) and str(tg["id"]) == oid})
            if x <= 0 or gap > 100:
                continue
            cells = {}
            for s in follow_test.SENSORS_ALL:
                d = raw.get(s, {}).get(oid)
                if s not in ctl.sensors:
                    cells[s] = ("OFF", "#64748B")
                elif d is not None:
                    more = (f"{d.get('points', 0)} pts" if s == "LiDAR" else
                            f"{d.get('cls', '?')} {d.get('conf', 0):.0%}" if s == "camera" else
                            f"{round(d.get('v_rel', 0) * 3.6) or 0:+d} km/h rel."
                            + (f" · Pd {d['pd']:.0%}" if d.get("pd") is not None else ""))
                    cells[s] = (f"{d['gap']:.1f} m · {more}", {"LiDAR": "#22D3EE", "camera": "#F59E0B",
                                                               "radar": "#C084FC"}[s])
                elif s == "camera" and oid in {str(k) for k in sn["hidden"]}:
                    by = next((v for k, v in sn["hidden"].items() if str(k) == oid), "?")
                    cells[s] = (f"hidden by {by}", "#F59E0B")
                else:
                    cells[s] = ("not detected" if lane else "--", "#EF4444" if lane else "#64748B")
            vd = raw.get("V2V", {}).get(oid)                 # (V2V: what its messages say -- collision testing)
            if not getattr(ctl, "v2v", False):
                cells["V2V"] = ("OFF", "#64748B")
            elif vd is not None:
                cells["V2V"] = (f"{vd['gap']:.1f} m · {1000 * float(vd.get('age') or 0):.0f} ms"
                                + (" · BRAKING" if vd.get("brake") else ""), "#34D399")
            else:
                cells["V2V"] = ("no message" if lane else "--", "#F59E0B" if lane else "#64748B")
            missed = lane and not any(oid in raw.get(s, {}) for s in ctl.sensors) and vd is None
            rows.append({"obj": f"{ob['label']} ({ob['kind']})", "real": f"{max(0.0, gap):.1f} m",
                         "LiDAR": cells["LiDAR"], "camera": cells["camera"], "radar": cells["radar"],
                         "V2V": cells["V2V"],
                         "lane": ("IN LANE" + (" -- MISSED" if missed else ""), "#EF4444" if missed else "#E5E7EB")
                         if lane else ("beside", "#64748B"), "bold": lane, "_gap": gap})
        rows.sort(key=lambda r: (not r["bold"], r["_gap"]))
        lane_pts, last = [], None
        if ss:
            import bisect
            near_q = ft["trail"][max(0, bisect.bisect_left(ss, ft["s"] - 3) - 1):bisect.bisect_right(ss, sn["s_lead"]) + 1]
        else:
            near_q = ft["trail"]
        for q in near_q:
            if ft["s"] - 3 <= q[3] <= sn["s_lead"] and (last is None or q[3] - last >= 1.0):
                lane_pts.append(follow_test._local(me, q[0], q[1]))
                last = q[3]
        cam_m = self._ctest_cams()[0] if "route" in ft else follow_test.FRONT_CAMERA
        view = {"objs": objs, "lane": lane_pts, "lane_half": follow_test.CORRIDOR_HALF_M, "ego_L": ft["L"],
                "on": set(ctl.sensors),
                "ranges": {"LiDAR": follow_test.lidar_range(self.climate),
                           "camera": follow_test.camera_range(self.climate, cam_m),
                           "radar": follow_test.radar_range(self.climate)},
                "fov": {"camera": cam_m["hfov_deg"], "radar": follow_test.FRONT_RADAR["hfov_deg"]}}
        return view, rows[:14]


    # =====================================================
    # Replay a saved path (txt) for an AV
    # =====================================================
    def offer_path_replay(self, vehicle_id):
        """Asks which saved path file the AV should follow, then replays it."""
        filename, _ = QFileDialog.getOpenFileName(
            self, f"Select the saved path for truck {vehicle_id}",
            os.getcwd(), "Saved paths (*.txt);;All files (*)"
        )
        if not filename:
            return          # cancelled -- the AV simply stays where it is
        self.start_path_replay(vehicle_id, filename)

    def _add_routed_av(self, vehicle_id, drive_mode, route_name, speed_kmh=None):
        """Adds a new AV (no position yet), then starts it on its route. Its position comes from the route's
        points."""
        number = vehicle_id
        vehicle_id = cfg.av_id(number)
        data = {"type": "truck", "avId": vehicle_id, "rover": vehicle_id, "number": number,
                "name": f"AV {number}", "driveMode": "Auto Drive"}
        item = QListWidgetItem(data["name"])
        data.update(latitude=None, longitude=None, locationType=None, locationId=None)
        item.setData(Qt.UserRole, data)
        self._style_av_item(item, True)
        self.av_list.addItem(item)
        self.save_vehicles()

        # deferred so the drop event finishes before the route starts
        def go():
            self.start_route(vehicle_id, route_name)
            if speed_kmh:
                self.set_av_speed(vehicle_id, speed_kmh)
        QTimer.singleShot(0, go)

    def start_route(self, vehicle_id, route_name):
        """Starts an AV on one of the hard-coded routes in SAVED_PATHS."""
        try:
            points = load_route(route_name)
        except (OSError, KeyError, ValueError, TypeError) as e:
            QMessageBox.warning(
                self, "Cannot Load Route",
                f"Route '{route_name}' could not be loaded:\n{e}\n\n"
                "Check SAVED_PATHS near the top of shipyard.py."
            )
            return
        src = SAVED_PATHS.get(route_name)
        meta = cfg.route_meta(src) if isinstance(src, str) else {}   # a route saved from a drawn path: its step, loop
        self._begin_replay(vehicle_id, points, route_name, interval_ms=int(meta.get("interval_ms", 0) or 0) or None,
                           loop=str(meta.get("loop", "0")) == "1")

    def start_path_replay(self, vehicle_id, filename):
        """Starts an AV on any saved path file (picked with the file dialog)."""
        try:
            points = parse_saved_path_file(filename)
        except OSError as e:
            QMessageBox.warning(self, "Cannot Read Path", f"Could not open the file:\n{e}")
            return
        self._begin_replay(vehicle_id, points, filename)

    def _begin_replay(self, vehicle_id, points, filename, interval_ms=None, loop=False):
        """
        Starts a LOCAL-ONLY simulation of a saved path.

        It is completely separate from the live filtered feed: it has its own
        marker + route line on the map, and it never calls
        handle_filtered_vehicle_update / update_truck_marker, never publishes
        drive_info (MQTT or log file), never touches camera detection or the
        3 m proximity alerts. Both can run at the same time.
        """
        if not points:
            QMessageBox.warning(
                self, "Empty Path",
                f"No positions were found in:\n{filename}\n\n"
                "Each line needs  lat=...  |  lng=...  |  heading=..."
            )
            return

        if not self.map_var_name:
            QMessageBox.information(self, "Map not ready",
                                    "The map is still loading. Try again in a moment.")
            return

        self.stop_path_replay(vehicle_id)

        # the AV leaves its parked place: its parked image goes
        self.remove_marker(vehicle_id)

        self._replay_draw_start(vehicle_id, points, filename)

        # distance driven up to each point -- for the LiDAR 3D details panel
        cum = [0.0]
        for a, b in zip(points, points[1:]):
            cum.append(cum[-1] + _metres_between(a[0], a[1], b[0], b[1]))

        timer = QTimer(self)
        timer.timeout.connect(lambda vid=vehicle_id: self._path_replay_tick(vid))
        self.path_replays[vehicle_id] = {
            "points": points, "index": 0, "timer": timer,
            "file": filename, "busy": False, "cum": cum, "loop": bool(loop),
            "interval_ms": int(interval_ms or PATH_REPLAY_INTERVAL_MS),
            "label": filename if filename in SAVED_PATHS else os.path.basename(filename),
        }
        print(f"[path replay] {vehicle_id}: {len(points)} points from {filename} (local only)")

        self._path_replay_tick(vehicle_id)          # first point right away
        if vehicle_id in self.path_replays:
            timer.start(int(interval_ms or PATH_REPLAY_INTERVAL_MS))

    @staticmethod
    def _replay_popup_html(vehicle_id, lat, lon):
        """Popup for an AV that is driving a saved route: id + live lat/long."""
        return (f"<b>Truck: {vehicle_id}</b>"
                f"<br>Lat: {lat:.6f}<br>Lng: {lon:.6f}")

    def _is_auto_drive(self, vehicle_id):
        """Only 'Auto Drive' AVs carry the LiDAR (map circle + 3D view)."""
        _list, _item, payload = self.find_list_item_by_vehicle_id(vehicle_id)
        return bool(payload) and payload.get("type") == "truck" \
            and payload.get("driveMode", "Auto Drive") == "Auto Drive"

    def _replay_draw_start(self, vehicle_id, points, route_label=None):
        """(Re)creates this vehicle's replay layers: dashed full route + marker."""
        vid = json.dumps(vehicle_id)
        latlngs = [[p[0], p[1]] for p in points]
        first = points[0]
        fp_kind = "tractor" if self._is_auto_drive(vehicle_id) else "tractor_manual"   # colour
        js = f"""
        (function(){{
            window.replayLayers = window.replayLayers || {{}};
            var old = window.replayLayers[{vid}];
            if (old) {{ old.forEach(function(l){{ {self.map_var_name}.removeLayer(l); }}); }}

            var line = L.polyline({json.dumps(latlngs)}, {{
                color: "#F97316", weight: 3, opacity: 0.8, dashArray: "8 6", interactive: false
            }}).addTo({self.map_var_name});

            var svg = {json.dumps(REPLAY_TRUCK_SVG)};
            var icon = L.divIcon({{
                html: '<div style="width:64px;height:64px;display:flex;align-items:center;'
                      + 'justify-content:center;transform:rotate(' + ({first[2]} - 90) + 'deg) scale(' + (window.iconScale ? window.iconScale() : 1) + ');">'
                      + svg + '</div>',
                className: "", iconSize: [64, 64], iconAnchor: [32, 32]
            }});
            var marker = L.marker([{first[0]}, {first[1]}], {{
                icon: icon, interactive: true, zIndexOffset: 900,
                title: {vid}
            }}).addTo({self.map_var_name});
            marker.bindPopup({json.dumps(self._replay_popup_html(vehicle_id, first[0], first[1]))});
            marker.on('contextmenu', function(ev) {{                // path / follow / stop
                if (window.bridge && window.bridge.vehicleMenu) {{
                    if (ev && ev.originalEvent) L.DomEvent.stop(ev);
                    window.bridge.vehicleMenu({vid});
                }}
            }});
            marker._rotation = {first[2]} - 90;
            var nose = {LIDAR_NOSE_PX_REPLAY};
            if (window.footprintIcon) {{                   // real-size tractor, front = heading
                marker._fpHeading = {first[2]}; marker._fpLabel = {vid}; marker._fpKind = {json.dumps(fp_kind)};
                marker.setIcon(window.footprintIcon(marker._fpKind, {first[2]}, {first[0]}, {vid}));
                nose = {{ m: {VEHICLE_DIMENSIONS["tractor"]["length"] / 2} }};   // LiDAR at the real front
            }}

            // LiDAR only on AV
            var lidar = ({json.dumps(self._is_auto_drive(vehicle_id))} && window.makeLidar)
                        ? window.makeLidar({first[0]}, {first[1]}, {first[2]}, marker, nose) : [];
            window.replayLayers[{vid}] = [line, marker].concat(lidar);   // removed together with the route
        }})();
        """
        self.browser.page().runJavaScript(js)

    def _replay_move_marker(self, vehicle_id, lat, lon, heading):
        vid = json.dumps(vehicle_id)
        js = f"""
        (function(){{
            var layers = window.replayLayers && window.replayLayers[{vid}];
            if (!layers) return;
            var marker = layers[1];
            marker.setLatLng([{lat}, {lon}]);
            marker.setPopupContent({json.dumps(self._replay_popup_html(vehicle_id, lat, lon))});
            marker._rotation = {heading} - 90;
            if (layers.length > 2 && window.moveLidar) {{
                window.moveLidar(layers.slice(2), {lat}, {lon}, {heading});
            }}
            if (marker._fpHeading != null && window.footprintIcon) {{
                marker._fpHeading = {heading};
                marker.setIcon(window.footprintIcon(marker._fpKind || 'tractor', {heading}, {lat}, marker._fpLabel));
                return;
            }}
            var el = marker.getElement();
            if (el) {{
                var svg = {json.dumps(REPLAY_TRUCK_SVG)};
                el.innerHTML = '<div style="width:64px;height:64px;display:flex;align-items:center;'
                    + 'justify-content:center;transform:rotate(' + ({heading} - 90) + 'deg) scale(' + (window.iconScale ? window.iconScale() : 1) + ');">'
                    + svg + '</div>';
            }}
        }})();
        """
        if getattr(self, "_follow_2d", None) == vehicle_id:          # the 2D map follows this AV
            js += f"\n{self.map_var_name}.panTo([{lat}, {lon}], {{animate: true, duration: 0.25}});"
        self.browser.page().runJavaScript(js)
        self._push_lidar_scene(vehicle_id, lat, lon, heading)

    def _path_replay_tick(self, vehicle_id):
        state = self.path_replays.get(vehicle_id)
        if not state or state["busy"]:
            return

        if "rate" in state:                             # stop and go: slower / stopped / on again (fractional steps)
            self._stop_go_update(vehicle_id, state)
            n = len(state["points"])
            at = float(max(0, state["index"] - 1))
            pos = state.get("pos", at)
            if abs(pos - at) > 1.5:                      # (index moved without the rate -- restart / convoy start /
                pos = at                                 #  driven at full speed before the stop and go): from here
            pos += state["rate"]
            if pos >= n - 1:
                if state.get("loop") and n > 1:
                    pos -= n - 1
                else:
                    pos = n - 1.0
            state["pos"] = pos
            i = int(pos)
            f = pos - i
            a, b = state["points"][i], state["points"][min(i + 1, n - 1)]
            lat, lon, heading = a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2]
            state["index"] = i + 1
            state["busy"] = True
            try:
                self._replay_move_marker(vehicle_id, lat, lon, heading)
            finally:
                state["busy"] = False
            if not state.get("loop") and pos >= n - 1:
                print(f"[path replay] {vehicle_id}: finished")
                self.stop_path_replay(vehicle_id, keep_on_map=True)
            return

        if state["index"] >= len(state["points"]):
            if state.get("loop") and len(state["points"]) > 1:
                state["index"] = 0                    # a drawn path driven again and again (there and back)
            else:
                print(f"[path replay] {vehicle_id}: finished")
                self.stop_path_replay(vehicle_id, keep_on_map=True)
                return

        lat, lon, heading = state["points"][state["index"]]
        state["index"] += 1

        # Local drawing only -- nothing is published or logged here.
        state["busy"] = True
        try:
            self._replay_move_marker(vehicle_id, lat, lon, heading)
        finally:
            state["busy"] = False

    def stop_path_replay(self, vehicle_id, keep_on_map=False):
        state = self.path_replays.pop(vehicle_id, None)
        if state:
            state["timer"].stop()
            state["timer"].deleteLater()
        if keep_on_map and state:
            # route ended: the AV stays on the map, and stays viewable in LiDAR 3D
            self._finished_routes[vehicle_id] = state
        else:
            self._finished_routes.pop(vehicle_id, None)

        if keep_on_map or not self.map_var_name:
            return
        vid = json.dumps(vehicle_id)
        self.browser.page().runJavaScript(f"""
        (function(){{
            var layers = window.replayLayers && window.replayLayers[{vid}];
            if (layers) {{
                layers.forEach(function(l){{ {self.map_var_name}.removeLayer(l); }});
                delete window.replayLayers[{vid}];
            }}
        }})();
        """)

    def show_av_menu(self, position, lst=None):
        lst = lst or self.av_list
        item = lst.itemAt(position)
        if item is None:
            return

        vehicle = item.data(Qt.UserRole)
        vehicle_id = vehicle.get("avId")

        menu = QMenu(self)   # parented, so it gets the app's dark menu style
        self._common_object_actions(menu, "truck", vehicle_id)          # 2D / 3D, hide and stop, restart
        menu.addSeparator()
        info_action = menu.addAction("Information")
        route_menu = menu.addMenu("Follow route")
        route_actions = {route_menu.addAction(name): name for name in SAVED_PATHS}
        replay_action = menu.addAction("Choose another path file...")
        stop_action = None
        lidar_action = None
        if vehicle_id in self.path_replays or vehicle_id in self._finished_routes:
            lidar_action = menu.addAction("Show in LiDAR 3D")
        if vehicle_id in self.path_replays:
            stop_action = menu.addAction("Stop simulation")
        placed = vehicle.get("latitude") is not None or vehicle_id in self.path_replays \
            or vehicle_id in self._finished_routes
        path_action = follow3d_action = follow2d_action = None
        menu.addSeparator()
        self._av_test_actions(menu, vehicle_id, vehicle, routes=False)    # ("Follow route" above)
        if placed:                                        # its own path drawn on the map; follow it
            path_action = menu.addAction(self._icon("fa5s.route", "#F97316"), "Draw a path to drive ...")
            menu.addAction(self._icon("fa5s.map-signs", "#22D3EE"), "Path from source to destination (roads) ...",
                           lambda v=vehicle_id: self.draw_av_path(v, auto=True))
            follow3d_action = menu.addAction(self._icon("fa5s.video", "#60A5FA"), "Follow in 3D")
            follow2d_action = menu.addAction(self._icon("fa5s.crosshairs", "#60A5FA"), "Follow on the 2D map")
        remove_action = None
        if vehicle.get("latitude") is not None or vehicle_id in self.path_replays:
            remove_action = menu.addAction("Remove from map")
        delete_action = menu.addAction("Delete")

        action = menu.exec_(lst.viewport().mapToGlobal(position))

        if action is None:
            return
        if action == delete_action:
            self.delete_vehicle(vehicle, lst, item)
        elif remove_action is not None and action == remove_action:
            self.unplace_vehicle(vehicle_id)
        elif action == info_action:
            self.show_vehicle_info(vehicle)
        elif action in route_actions:
            self.start_route(vehicle_id, route_actions[action])
        elif action == replay_action:
            self.offer_path_replay(vehicle_id)
        elif lidar_action is not None and action == lidar_action:
            self.open_lidar_3d_view(vehicle_id)
        elif stop_action is not None and action == stop_action:
            self.stop_path_replay(vehicle_id)
        elif path_action is not None and action == path_action:
            self.draw_av_path(vehicle_id)
        elif follow3d_action is not None and action == follow3d_action:
            self.follow_in_3d(vehicle_id)
        elif follow2d_action is not None and action == follow2d_action:
            self.follow_on_2d(vehicle_id)


    def show_vehicle_info(self, vehicle):
        vehicle_id = vehicle.get("avId")
        text = f"{self.vehicle_label(vehicle_id)}\n{vehicle_id}"
        if vehicle.get("latitude") is not None:
            text += f"\n\nOn the map at {vehicle['latitude']:.6f}, {vehicle['longitude']:.6f}"
        else:
            text += "\n\nNot yet placed on the map."
        dims = VEHICLE_DIMENSIONS[self._vehicle_kind(vehicle.get("type"), vehicle)]
        text += (f"\n\n{dims.get('label', 'AV')}\nLength : {dims['length']:g} m\nWidth : {dims['width']:g} m"
                 f"\nHeight : {dims['height']:g} m")
        if "front_overhang" in dims:
            text += (f"\nFront overhang : {dims['front_overhang']:g} m"
                     f"\nRear overhang : {dims.get('rear_overhang', 0):g} m")
        QMessageBox.information(self, "AV Information", text)

    def unplace_vehicle(self, vehicle_id):
        """Takes an AV off the map (route stopped) but keeps it in its list."""
        lst, item, payload = self.find_list_item_by_vehicle_id(vehicle_id)
        if item is None:
            return
        self.stop_path_replay(vehicle_id)
        self._finished_routes.pop(vehicle_id, None)
        self.remove_marker(vehicle_id)
        payload = dict(payload)
        payload.update({"latitude": None, "longitude": None, "locationType": None, "locationId": None})
        item.setData(Qt.UserRole, payload)
        self.save_vehicles()

    def delete_vehicle(self, vehicle, list_widget, item):
        vehicle_id = vehicle.get("avId")
        self.stop_path_replay(vehicle_id)
        self._finished_routes.pop(vehicle_id, None)
        self.remove_marker(vehicle_id)
        list_widget.takeItem(list_widget.row(item))
        self.save_vehicles()

    def enable_child_drag_support(self):
        for child in self.browser.findChildren(QWidget):
            child.setAcceptDrops(True)


    def find_list_item_by_vehicle_id(self, vehicle_id):
        lst = self.av_list
        for i in range(lst.count()):
            item = lst.item(i)
            payload = item.data(Qt.UserRole)
            if payload.get("avId") == vehicle_id:
                return lst, item, payload
        return None, None, None

    def handle_av_drop(self, x, y, payload):
        if not self.map_var_name:
            return
        js = f"{self.map_var_name}.containerPointToLatLng([{x}, {y}]);"
        self.browser.page().runJavaScript(
            js, lambda result: self.on_latlng_resolved(result, payload)
        )


    def on_latlng_resolved(self, result, payload):
        """Something dropped on the 2D map: an obstacle, a new AV (its id, optional route) or an AV from the list."""
        if not result:
            return
        lat = result.get("lat")
        lng = result.get("lng")
        if lat is None or lng is None:
            return
        if payload.get("category") == "unknown":
            self.on_unknown_object_dropped(lat, lng, payload)
            return
        if payload.get("type") != "truck":
            QMessageBox.warning(self, "Invalid Drop", "Unknown item dropped.")
            return
        is_new = payload.get("new", False)
        new_values = None
        if is_new:
            dialog = NewAVDialog(self)
            if dialog.exec_() != QDialog.Accepted:
                return
            vehicle_id, drive_mode = dialog.get_values()
            chosen_route = dialog.get_route()
            if not vehicle_id:
                QMessageBox.warning(self, "Invalid AV ID", "The AV ID cannot be empty.")
                return
            if self.find_list_item_by_vehicle_id(vehicle_id)[2] or \
                    self.find_list_item_by_vehicle_id(cfg.av_id(vehicle_id))[2]:
                QMessageBox.warning(self, "Duplicate ID", f"An AV with ID '{vehicle_id}' already exists.")
                return
            if chosen_route:
                self._add_routed_av(vehicle_id, drive_mode, chosen_route, dialog.get_speed())
                return
            new_values = (vehicle_id, drive_mode)
        self._place_on_road("truck", lat, lng, payload, is_new, new_values)

    def on_unknown_object_dropped(self, lat, lng, payload):
        object_type = payload.get("type")
        icon_file = UNKNOWN_OBJECT_ICONS.get(object_type)

        if icon_file is None:
            QMessageBox.warning(self, "Invalid Drop", "Unknown item dropped.")
            return

        is_new = payload.get("new", False)

        autonomous = False
        if is_new:
            dialog = NewUnknownObjectDialog(self, object_type, allow_auto=self.map_yard and object_type != "pedestrian")

            if dialog.exec_() != QDialog.Accepted:
                return

            object_id, mode = dialog.get_values()
            autonomous = dialog.autonomous() if hasattr(dialog, "autonomous") else False

            if not object_id:
                QMessageBox.warning(self, "Invalid ID", "Object ID cannot be empty.")
                return

            _, duplicate = self.find_unknown_item_by_id(object_id)
            if duplicate:
                QMessageBox.warning(
                    self, "Duplicate ID", f"An object with ID '{object_id}' already exists."
                )
                return
        else:
            object_id = payload.get("objectId")
            mode = payload.get("mode", "Static")
            if not object_id:
                return

        label = f"{object_type.replace('_', ' ').title()} {object_id}"

        if mode == "Dynamic":
            self._begin_dynamic_unknown_object(object_id, object_type, icon_file, lat, lng, label)
            if self._pending_dynamic_object is not None:
                self._pending_dynamic_object["autonomous"] = autonomous
        else:
            self._place_static_unknown_object(object_id, object_type, icon_file, lat, lng, label)

    def _place_static_unknown_object(self, object_id, object_type, icon_file, lat, lng, label):
        self._create_unknown_marker_js(object_id, icon_file, lat, lng, label)

        list_item = QListWidgetItem(label)
        list_item.setData(Qt.UserRole, {
            "type": object_type, "objectId": object_id, "mode": "static",
            "latitude": lat, "longitude": lng,
        })
        self.unknown_list.addItem(list_item)

        self.save_unknown_objects()

    def _begin_dynamic_unknown_object(self, object_id, object_type, icon_file, lat, lng, label):
        self._pending_dynamic_object = {
            "objectId": object_id, "type": object_type, "icon": icon_file, "label": label,
        }

        self.browser.page().runJavaScript(f"window.startPathDrawing({lat}, {lng});")

        self.finish_path_button.setEnabled(True)
        self.path_status_label.setText(
            f"Click the map to draw a path for {label}, then press Finish Path."
        )

    def finish_path_drawing(self):
        if not self._pending_dynamic_object:
            return

        self.browser.page().runJavaScript(
            "window.currentPathPoints || [];", self._on_path_points_resolved
        )

    def _on_path_points_resolved(self, points):
        pending = self._pending_dynamic_object
        self._pending_dynamic_object = None

        self.browser.page().runJavaScript(
            "if(window.stopPathDrawing){ window.stopPathDrawing(); }"
        )
        self.finish_path_button.setEnabled(False)
        self.path_status_label.setText("")

        if not pending:
            return

        if not points or len(points) < 2:
            QMessageBox.warning(
                self, "Path Too Short",
                "Draw at least two points on the map for a dynamic path."
            )
            return

        object_id = pending["objectId"]
        object_type = pending["type"]
        icon_file = pending["icon"]
        label = pending["label"]

        path = [{"lat": p[0], "lon": p[1]} for p in points]

        self._create_unknown_marker_js(object_id, icon_file, path[0]["lat"], path[0]["lon"], label)

        list_item = QListWidgetItem(label + ("  (autonomous)" if pending.get("autonomous") else ""))
        list_item.setData(Qt.UserRole, {
            "type": object_type, "objectId": object_id, "mode": "dynamic",
            "latitude": path[0]["lat"], "longitude": path[0]["lon"], "path": path,
            **({"autonomous": True} if pending.get("autonomous") else {}),
        })
        self.unknown_list.addItem(list_item)

        self.save_unknown_objects()
        self._start_dynamic_object_timer(object_id, object_type, path)

    @staticmethod
    def _default_speed_kmh(object_type):
        return DYNAMIC_OBJECT_DEFAULT_SPEED_KMH.get(object_type, DYNAMIC_OBJECT_FALLBACK_SPEED_KMH)

    @staticmethod
    def _max_speed_kmh(object_type):
        return DYNAMIC_OBJECT_MAX_SPEED_KMH.get(object_type, DYNAMIC_OBJECT_FALLBACK_MAX_SPEED_KMH)

    @staticmethod
    def _speed_step_m(speed_kmh):
        """Metres moved per timer tick at this speed."""
        return speed_kmh / 3.6 * DYNAMIC_OBJECT_STEP_MS / 1000.0

    class _StepTimer:
        """A moving obstacle's on / off switch (the QTimer interface the code uses): ONE shared timer
        moves every active obstacle (_dynamic_tick) -- a timer per obstacle made the app hang with many."""

        def __init__(self):
            self.active = False

        def start(self, _ms=None):
            self.active = True

        def stop(self):
            self.active = False

        def isActive(self):
            return self.active

        def deleteLater(self):
            self.active = False

    def _start_dynamic_object_timer(self, object_id, object_type, path, speed_kmh=None):
        existing = self.dynamic_objects.get(object_id)
        if existing:
            existing["timer"].stop()

        # every obstacle moves at a real, constant speed (km/h) along its path
        speed_kmh = min(float(speed_kmh or self._default_speed_kmh(object_type)),
                        self._max_speed_kmh(object_type))
        path = self._keep_lane_path(object_id, object_type, path)
        dense_path = self._densify_path_by_distance(path, self._speed_step_m(speed_kmh))

        timer = self._StepTimer()
        _item, payload = self.find_unknown_item_by_id(object_id)
        self.dynamic_objects[object_id] = {
            "path": dense_path, "index": 0, "timer": timer, "type": object_type,
            "raw_path": list(path), "speed_kmh": speed_kmh,
            "autonomous": bool((payload or {}).get("autonomous")),     # brakes for what it detects (map yards)
        }
        timer.start()
        if getattr(self, "_dyn_master", None) is None:
            self._dyn_master = QTimer(self)
            self._dyn_master.timeout.connect(self._dynamic_tick)
            self._dyn_master.start(DYNAMIC_OBJECT_STEP_MS)

    YIELD_AHEAD_S = 1.5                                    # obstacles keep out of where a test AV is in this long

    def _ctest_av_zones(self):
        """The collision-test AVs as the scene's obstacles see them: each AV's footprint plus the road it covers
        in the next YIELD_AHEAD_S seconds (+2 m). Moving obstacles do not step into it -- they give way (pedestrians
        and cars no longer walk / drive into an AV), so a collision counted is the AV's own failure."""
        if not getattr(self, "collision_tests", None) or cfg.APP_SETTINGS.get("obstacles_give_way") is False:
            return []
        zones = []
        for fid, ft in (getattr(self, "follow_tests", None) or {}).items():
            if "route" not in ft:
                continue
            st = self.path_replays.get(fid)
            if not st or not st.get("points"):
                continue
            lat, lng, hd = st["points"][0][:3]
            ext = max(0.0, ft["ctl"].v) * self.YIELD_AHEAD_S + 2.0
            la, lo = self._shift_right(lat, lng, (hd - 90.0) % 360.0, ext / 2.0)       # (forward by ext / 2)
            zones.append((la, lo, hd, ft["L"] + ext, 2.6, (lat, lng, hd, ft["L"], 2.6)))   # (+ the body itself)
        return zones

    def _keep_lane_path(self, object_id, object_type, path):
        """A vehicle whose path was drawn on a road's centre line (map yards, OpenStreetMap roads) drives in its lane:
        the path moved LANE_OFFSET_M to the drive side (left in India) of its direction -- so oncoming traffic on a
        two-way road passes instead of meeting head-on (an out-and-back path comes back in the other lane). Paths off
        the centre lines (already in a lane, footways, yards without roads) and pedestrians are kept as drawn. Only
        the driven path changes; the saved path stays as drawn."""
        if object_type == "pedestrian" or len(path) < 3 or str(object_id).startswith("TRF-") \
                or cfg.APP_SETTINGS.get("traffic_keep_lane") is False:
            return path
        try:
            if not self._road_lines():
                return path
            if not self._on_road_centre(path, samples=8):
                return path                                    # (not on a road's centre line)
            d = LANE_OFFSET_M if self._drive_side() == "left" else -LANE_OFFSET_M
            shifted = self._lane_offset([(p["lat"], p["lon"], 0.0, 0.0) for p in path], d)
            out = [{"lat": q[0], "lon": q[1]} for q in shifted]
            if len(out) < 2:
                return path
            if _metres_between(path[-1]["lat"], path[-1]["lon"], path[0]["lat"], path[0]["lon"]) < 1.0:
                out.append(dict(out[0]))                       # a closed path: back to its start in the lane
            return out
        except Exception as e:                                 # (never stop an obstacle over this)
            print(f"[obstacles] {object_id}: keep-lane skipped ({e})")
            return path

    def _dynamic_tick(self):
        """One step of every moving obstacle; their markers are moved with one JavaScript call."""
        self._js_moves = []
        self._fp_grid = self._footprint_grid()
        self._truck_zones = self._ctest_av_zones()
        try:
            for oid, st in list(self.dynamic_objects.items()):
                if st["timer"].isActive():
                    self._advance_dynamic_object(oid)
        finally:
            self._fp_grid = None
            moves, self._js_moves = self._js_moves, None
            if moves:
                self.browser.page().runJavaScript(
                    "(function(M){if(!window.unknownMarkers)return;M.forEach(function(a){var m=window.unknownMarkers[a[0]];"
                    "if(!m)return;m.setLatLng([a[1],a[2]]);m._heading=a[3];var el=m.getElement();"
                    "if(el){var i=el.querySelector('div');if(i)i.style.transform='rotate('+a[3]+'deg)';}});})("
                    + json.dumps(moves) + ");")

    def set_dynamic_object_speed(self, object_id, speed_kmh, save=True):
        """Change a moving obstacle's speed; it carries on from where it is now."""
        state = self.dynamic_objects.get(object_id)
        if not state:
            return
        speed_kmh = max(DYNAMIC_OBJECT_MIN_SPEED_KMH,
                        min(self._max_speed_kmh(state["type"]), float(speed_kmh)))
        if abs(speed_kmh - state["speed_kmh"]) < 1e-6:
            return

        here = state["path"][state["index"]]
        dense = self._densify_path_by_distance(state["raw_path"], self._speed_step_m(speed_kmh))
        # continue from the point on the new path that is closest to the current
        # position, searching from the same fraction of the trip so a path that
        # crosses itself doesn't make the obstacle jump to the other crossing
        frac = state["index"] / max(1, len(state["path"]) - 1)
        guess = int(frac * (len(dense) - 1))
        window = range(max(0, guess - 3), min(len(dense), guess + 4))
        state["index"] = min(window, key=lambda i: (dense[i]["lat"] - here["lat"]) ** 2
                                                   + (dense[i]["lon"] - here["lon"]) ** 2)
        state["path"] = dense
        state["speed_kmh"] = speed_kmh

        # remember it with the object so it survives a restart
        item, payload = self.find_unknown_item_by_id(object_id)
        if item is not None:
            payload = dict(payload)
            payload["speed_kmh"] = speed_kmh
            item.setData(Qt.UserRole, payload)
            if save:
                self.save_unknown_objects()

    @staticmethod
    def _densify_path_by_distance(path, step_m):
        """Like _densify_path, but places a point every `step_m` metres
        along each segment, so movement speed is constant no matter how
        long the segment is."""
        if len(path) < 2:
            return list(path)

        dense = [path[0]]
        for i in range(len(path) - 1):
            a, b = path[i], path[i + 1]
            dy = (b["lat"] - a["lat"]) * 111320.0
            dx = (b["lon"] - a["lon"]) * 111320.0 * math.cos(math.radians(a["lat"]))
            dist = math.hypot(dx, dy)
            n = max(1, int(round(dist / step_m)))   # round, not floor: keeps the speed true
            for s_i in range(1, n + 1):
                t = s_i / float(n)
                dense.append({
                    "lat": a["lat"] + (b["lat"] - a["lat"]) * t,
                    "lon": a["lon"] + (b["lon"] - a["lon"]) * t,
                })
        return dense

    def _advance_dynamic_object(self, object_id):
        """One step of a moving obstacle along its path.
        Collisions OFF (default): it avoids the other obstacles -- swerves sideways (up to 3.5 m,
        pedestrians 2 m) around them or waits when there is no room.
        Collisions ON: it keeps its path; touching another obstacle is an accident (both stop
        for OBSTACLE_ACCIDENT_HOLD_S, a marker shows where)."""
        state = self.dynamic_objects.get(object_id)
        if not state or not state["path"]:
            return
        now = time.monotonic()
        if state.get("crash_until", 0) > now:              # stopped after an accident
            return

        prev_point = state["path"][state["index"]]
        nxt = (state["index"] + 1) % len(state["path"])
        point = state["path"][nxt]
        dlat = point["lat"] - prev_point["lat"]
        dlon = point["lon"] - prev_point["lon"]
        travel = math.degrees(math.atan2(dlon * math.cos(math.radians(point["lat"])), dlat)) % 360 \
            if (dlat or dlon) else state.get("travel", 0.0)
        L, W = state.get("dims") or self._obstacle_footprint(object_id, state["type"])
        state["dims"] = (L, W)
        others = self._other_obstacle_footprints(object_id)
        off = state.get("offset", 0.0)
        # traffic-scenario vehicles (TRF-...) always drive like traffic: keep their distance, queue, pass --
        # "Collisions" (accidents) is for the obstacles placed for that test
        traffic = str(object_id).startswith("TRF-")
        if state.get("autonomous") and self._auto_vehicle_must_stop(state, prev_point, travel, L, W, others, object_id):
            state["auto_stopped"] = True                   # an autonomous vehicle: stands for what it detects
            return
        state["auto_stopped"] = False

        if not self.obstacle_collisions or traffic:
            # avoid: back towards the path when free, else further aside, else wait
            limit = 2.0 if state["type"] == "pedestrian" else 3.5
            relax = math.copysign(max(0.0, abs(off) - 0.3), off)
            cands = [relax, off]
            side = 1.0 if off >= 0 else -1.0
            for k in range(1, 8):
                for sgn in (side, -side):
                    o = off + sgn * 0.5 * k
                    if abs(o) <= limit:
                        cands.append(o)
            chosen = None
            for o in cands:
                lat_o, lon_o = self._shift_right(point["lat"], point["lon"], travel, o)
                if not self._footprint_hits((lat_o, lon_o, travel, L, W), others, margin=0.4):
                    chosen = (o, lat_o, lon_o)
                    break
            if chosen is None:
                state["wait"] = state.get("wait", 0) + 1
                if state["wait"] * DYNAMIC_OBJECT_STEP_MS < 6000:
                    return                                 # no room: wait for the other one
                chosen = (off,) + self._shift_right(point["lat"], point["lon"], travel, off)   # stuck 6 s: go on
            state["wait"] = 0
            off, lat_d, lon_d = chosen
        else:
            off = math.copysign(max(0.0, abs(off) - 0.3), off)      # back onto its path
            lat_d, lon_d = self._shift_right(point["lat"], point["lon"], travel, off)

        zones = getattr(self, "_truck_zones", None)
        if zones:                                          # give way to the collision-test AVs
            cur = state.get("pose")
            in_zone = bool(cur) and any(self._rects_overlap(cur, z, margin=0.3) for z in zones)

            def blocked(la, lo):
                # never into an AV's body; into the road just ahead of it only when not already standing there
                # (an obstacle ahead in the AV's lane drives on, out of its way)
                r = (la, lo, travel, L, W)
                return any(self._rects_overlap(r, z[5], margin=0.4) for z in zones) or \
                    (not in_zone and any(self._rects_overlap(r, z, margin=0.3) for z in zones))
            if blocked(lat_d, lon_d):
                # step aside (as around other obstacles) and pass the AV; no room: wait for it
                limit = 2.0 if state["type"] == "pedestrian" else 3.5
                side = 1.0 if off >= 0 else -1.0
                found = None
                for k in range(1, 8):
                    for sgn in (side, -side):
                        o = off + sgn * 0.5 * k
                        if abs(o) > limit:
                            continue
                        la, lo = self._shift_right(point["lat"], point["lon"], travel, o)
                        if not blocked(la, lo) and not self._footprint_hits((la, lo, travel, L, W), others, margin=0.4):
                            found = (o, la, lo)
                            break
                    if found:
                        break
                if found is None:
                    state["yielding"] = True               # (it would step in front of / into an AV: it waits)
                    return
                off, lat_d, lon_d = found
        state["yielding"] = False
        state["index"], state["offset"], state["travel"] = nxt, off, travel
        state["pose"] = (lat_d, lon_d, travel, L, W)
        heading = 0 if state["type"] == "pedestrian" else travel     # a person icon stays upright
        self._move_unknown_marker_js(object_id, lat_d, lon_d, heading)

        if self.obstacle_collisions and not traffic:
            self._check_accidents(object_id, state, others)


    def _auto_vehicle_must_stop(self, state, here, travel, L, W, others, object_id=None):
        """An autonomous vehicle (Obstacles, map yards): something in its lane ahead that it DETECTS and that is
        closer than its stopping distance + 3 m -> it stands. Detected = by its own roof LiDAR (the simulated scan,
        climate included -- the 3D sensor page) or its front camera (climate range). What it does not detect it
        does not stop for (then it can run into it -- an accident with Collisions on)."""
        v = float(state.get("speed_kmh") or 10.0) / 3.6
        need = v * v / (2.0 * 3.0) + 3.0                       # (gap: bumper to bumper)
        ego = (here["lat"], here["lon"], travel)
        cam_rng = follow_test.camera_range(self.climate)
        for o in others:
            x, y = follow_test._local(ego, o[1], o[2])
            if x <= 0 or abs(y) > (W + o[5]) / 2 + 0.3:
                continue
            gap = x - L / 2 - o[4] / 2
            if gap < need and gap < cam_rng:                    # the front camera sees it
                return True
        if object_id is not None and time.time() - getattr(self, "_lidar_dets_t", 0) < 0.8:
            for d in self.lidar_detections(object_id):           # its own LiDAR (x forward, y left of it)
                if d.get("x", 0) > 0 and abs(d.get("y", 0)) <= W / 2 + 1.3 and d["gap"] < need:
                    return True
        return False

    # ---------------- obstacle footprints: avoidance / accidents ----------------
    def _obstacle_footprint(self, object_id, object_type):
        """(length, width) in metres of an obstacle (its own dimensions, else its type's)."""
        d = self._obstacle_dims(object_id) or self._obstacle_default_dims(object_type)
        return float(d.get("length") or 4.5), float(d.get("width") or 1.8)

    @staticmethod
    def _shift_right(lat, lon, heading, metres):
        if not metres:
            return lat, lon
        h = math.radians(heading)
        re_, rn = math.cos(h), -math.sin(h)               # unit vector to the right of the heading
        return (lat + rn * metres / 111320.0,
                lon + re_ * metres / (111320.0 * math.cos(math.radians(lat))))

    def _other_obstacle_footprints(self, object_id):
        """(id, lat, lon, heading, L, W, moving) of every other obstacle on the map."""
        grid = getattr(self, "_fp_grid", None)
        if grid is not None:                               # (in _dynamic_tick: only the ones nearby)
            st = self.dynamic_objects.get(object_id) or {}
            ref = st.get("pose") or (st.get("path") or [{}])[st.get("index", 0) if st.get("path") else 0]
            lat, lon = (ref[0], ref[1]) if isinstance(ref, tuple) else (ref.get("lat"), ref.get("lon"))
            if lat is not None:
                ci, cj = int(lat // self.FP_CELL_DEG), int(lon // self.FP_CELL_DEG)
                return [f for di in (-1, 0, 1) for dj in (-1, 0, 1)
                        for f in grid.get((ci + di, cj + dj), ()) if f[0] != object_id]
        out = []
        hidden = self._hidden_objects()
        for oid, st in self.dynamic_objects.items():
            if oid != object_id and st.get("pose") and oid not in hidden:
                out.append((oid,) + tuple(st["pose"]) + (True,))
        return out + [f for f in self._static_footprints() if f[0] != object_id and f[0] not in self.dynamic_objects]

    FP_CELL_DEG = 0.0004                                   # ~44 m: obstacles are compared with their neighbours only

    def _footprint_grid(self):
        grid = {}
        hidden = self._hidden_objects()
        for oid, st in self.dynamic_objects.items():
            if st.get("pose") and oid not in hidden:
                f = (oid,) + tuple(st["pose"]) + (True,)
                grid.setdefault((int(f[1] // self.FP_CELL_DEG), int(f[2] // self.FP_CELL_DEG)), []).append(f)
        for f in self._static_footprints():
            if f[0] not in self.dynamic_objects:
                grid.setdefault((int(f[1] // self.FP_CELL_DEG), int(f[2] // self.FP_CELL_DEG)), []).append(f)
        return grid

    def _static_footprints(self):
        """The parked obstacles' footprints -- read from the list only when it changed (reading every item at
        every step of every moving obstacle made the app hang with many obstacles)."""
        if getattr(self, "_static_fp", None) is None:
            self._hook_unknown_list()
            fps = []
            self._static_fp_kind = {}
            for i in range(self.unknown_list.count()):
                p = self.unknown_list.item(i).data(Qt.UserRole) or {}
                if p.get("latitude") is None or p.get("objectId") in self._hidden_objects():
                    continue
                self._static_fp_kind[p.get("objectId")] = p.get("type")
                d = self._obstacle_default_dims(p.get("type"))
                d.update({k: v for k, v in (p.get("dimensions") or {}).items() if k in d})
                fps.append((p.get("objectId"), p["latitude"], p["longitude"], float(p.get("heading") or 0.0),
                            float(d.get("length") or 4.5), float(d.get("width") or 1.8), False))
            self._static_fp = fps
        return self._static_fp

    @staticmethod
    def _rects_overlap(a, b, margin=0.0):
        """Separating-axis test of two rectangles (lat, lon, heading, L, W[, ...]) in metres."""
        kx = 111320.0 * math.cos(math.radians(a[0]))
        dx, dy = (b[1] - a[1]) * kx, (b[0] - a[0]) * 111320.0
        ra, rb = math.hypot(a[3], a[4]) / 2, math.hypot(b[3], b[4]) / 2
        if math.hypot(dx, dy) > ra + rb + 2 * margin:      # far apart: no need for the full test
            return False
        axes = []
        for r in (a, b):
            h = math.radians(r[2])
            axes.append(((math.sin(h), math.cos(h)), (math.cos(h), -math.sin(h))))
        for fwd, right in axes:
            for ax in (fwd, right):
                dist = abs(dx * ax[0] + dy * ax[1])
                ext = 0.0
                for r, (rf, rr) in ((a, axes[0]), (b, axes[1])):
                    ext += abs(rf[0] * ax[0] + rf[1] * ax[1]) * r[3] / 2 + abs(rr[0] * ax[0] + rr[1] * ax[1]) * r[4] / 2
                if dist > ext + 2 * margin:
                    return False
        return True

    def _footprint_hits(self, rect, others, margin=0.0):
        return any(self._rects_overlap(rect, o[1:6], margin) for o in others)

    def _check_accidents(self, object_id, state, others):
        pairs = self._accident_pairs
        mine = state["pose"]
        for o in others:
            key = tuple(sorted((object_id, o[0])))
            touching = self._rects_overlap(mine, o[1:6])
            if key in pairs:
                if not self._rects_overlap(mine, o[1:6], margin=1.0):
                    pairs.discard(key)                     # apart again: they can crash again later
                continue
            if not touching:
                continue
            pairs.add(key)
            until = time.monotonic() + OBSTACLE_ACCIDENT_HOLD_S
            state["crash_until"] = until
            if o[6] and o[0] in self.dynamic_objects:
                self.dynamic_objects[o[0]]["crash_until"] = until
            self.accident_count += 1
            lat, lon = (mine[0] + o[1]) / 2, (mine[1] + o[2]) / 2
            text = f"Accident: {object_id} x {o[0]}"
            print(f"[obstacles] {text} at {lat:.6f}, {lon:.6f}")
            self.browser.page().runJavaScript(
                f"window.__accMap = {self.map_var_name};" + ACCIDENT_JS + f"window.showAccident({lat}, {lon}, {json.dumps(text)}, "
                              f"{int(OBSTACLE_ACCIDENT_HOLD_S * 1000) + 4000});")
            if hasattr(self, "_refresh_scenario_status"):
                self._refresh_scenario_status(refill=False)

    def set_obstacle_collisions(self, on):
        """'Collisions' check-box (Obstacles and Scenarios pages): ON = obstacles crossing each other
        crash (accidents), OFF = they avoid each other."""
        self.obstacle_collisions = bool(on)
        for cb in getattr(self, "collision_checks", []):
            if cb.isChecked() != self.obstacle_collisions:
                cb.blockSignals(True); cb.setChecked(self.obstacle_collisions); cb.blockSignals(False)
        if not on:                                         # end every accident stop
            for st in self.dynamic_objects.values():
                st.pop("crash_until", None)
            self._accident_pairs.clear()
        print(f"[obstacles] collisions {'ON (accidents)' if on else 'OFF (avoid each other)'}")

    def _collision_checkbox(self):
        cb = QCheckBox("Collisions (accidents)")
        cb.setCursor(Qt.PointingHandCursor)
        cb.setToolTip("Ticked: moving obstacles keep to their paths and crash when they meet "
                      f"(both stop {OBSTACLE_ACCIDENT_HOLD_S:g} s, a marker shows the accident).\n"
                      "Not ticked: they avoid each other -- swerve aside or wait.")
        cb.setChecked(self.obstacle_collisions)
        cb.toggled.connect(self.set_obstacle_collisions)
        self.collision_checks = getattr(self, "collision_checks", []) + [cb]
        return cb


    def stop_dynamic_object(self, object_id):
        state = self.dynamic_objects.get(object_id)
        if state:
            state["timer"].stop()
        self._refresh_speed_control()     # keep the Stop / Resume button in step

    def resume_dynamic_object(self, object_id):
        state = self.dynamic_objects.get(object_id)
        if state and not state["timer"].isActive():
            state["timer"].start(DYNAMIC_OBJECT_STEP_MS)
        self._refresh_speed_control()

    def toggle_dynamic_object(self, object_id):
        """Double-click on a moving obstacle: stop it; double-click again: resume it.
        Static objects are not in self.dynamic_objects, so a double-click does nothing."""
        state = self.dynamic_objects.get(object_id)
        if not state:
            return
        if state["timer"].isActive():
            self.stop_dynamic_object(object_id)
        else:
            self.resume_dynamic_object(object_id)

    UNKNOWN_ICON_BASE_PX = {"van.png": 46, "bus.png": 72, "truck_trailer.png": 90}   # long vehicles drawn longer

    def _create_unknown_marker_js(self, object_id, icon_file, lat, lon, label):
        base = next((px for name, px in self.UNKNOWN_ICON_BASE_PX.items() if str(icon_file).endswith(name)), 40)
        js = f"""
        (function() {{
            window.unknownMarkers = window.unknownMarkers || {{}};

            var m = L.marker(
                [{lat}, {lon}], {{ title: {json.dumps(label)} }}
            ).addTo({self.map_var_name});
            m._iconUrl = "{icon_file}";
            m._baseSize = {base};
            m._heading = 0;
            if (window.applyUnknownIconScale) {{
                window.applyUnknownIconScale(m);
            }} else {{
                m.setIcon(L.divIcon({{
                    html: '<div><img src="{icon_file}" width="40" height="40"></div>',
                    className: "", iconSize: [40, 40], iconAnchor: [20, 20]
                }}));
            }}

            m.bindPopup({json.dumps(label)});

            m.on('contextmenu', function(e) {{             // right-click: its menu (2D / 3D, hide, restart ...)
                if (e && e.originalEvent) {{ L.DomEvent.stop(e); }}
                if (window.bridge && window.bridge.objectMenu) {{ window.bridge.objectMenu({json.dumps(object_id)}, 'object'); }}
            }});
            // double-click: stop a moving object, double-click again: resume it
            m.on('dblclick', function(e) {{
                if (e.originalEvent) {{ L.DomEvent.stop(e.originalEvent); }}   // no map zoom
                if (window.bridge) {{
                    window.bridge.toggleDynamicObject({json.dumps(object_id)});
                }}
            }});

            window.unknownMarkers[{json.dumps(object_id)}] = m;
        }})();
        """
        self.browser.page().runJavaScript(js)


    def _move_unknown_marker_js(self, object_id, lat, lon, heading=0):
        if getattr(self, "_js_moves", None) is not None:       # (in _dynamic_tick: sent together)
            self._js_moves.append([object_id, lat, lon, heading])
            return
        js = f"""
        if(window.unknownMarkers && window.unknownMarkers[{json.dumps(object_id)}]){{
            var m = window.unknownMarkers[{json.dumps(object_id)}];
            m.setLatLng([{lat}, {lon}]);
            m._heading = {heading};
            var el = m.getElement();
            if (el) {{
                var inner = el.querySelector('div');
                if (inner) {{ inner.style.transform = 'rotate({heading}deg)'; }}
            }}
        }}
        """
        self.browser.page().runJavaScript(js)

    def _remove_unknown_marker_js(self, object_id):
        js = f"""
        (function() {{
            if(window.unknownMarkers && window.unknownMarkers[{json.dumps(object_id)}]){{
                {self.map_var_name}.removeLayer(window.unknownMarkers[{json.dumps(object_id)}]);
                delete window.unknownMarkers[{json.dumps(object_id)}];
            }}
        }})();
        """
        self.browser.page().runJavaScript(js)

    def _hook_unknown_list(self):
        """Caches over the obstacle list (an id index, the parked footprints): dropped when the list changes.
        Scanning the list for every obstacle -- 3D feed, sizes, moving -- made the app hang with many obstacles."""
        if getattr(self, "_unknown_hooked", False):
            return
        m = self.unknown_list.model()

        def changed(*_a):
            self._static_fp = None
            self._unknown_idx = None
        for sig in (m.rowsInserted, m.rowsRemoved, m.dataChanged, m.modelReset, m.rowsMoved):
            sig.connect(changed)
        self._unknown_hooked = True

    def find_unknown_item_by_id(self, object_id):
        self._hook_unknown_list()
        idx = getattr(self, "_unknown_idx", None)
        if idx is None:
            idx = {}
            for i in range(self.unknown_list.count()):
                item = self.unknown_list.item(i)
                oid = (item.data(Qt.UserRole) or {}).get("objectId")
                if oid is not None and oid not in idx:
                    idx[oid] = item
            self._unknown_idx = idx
        item = idx.get(object_id)
        if item is not None:
            payload = item.data(Qt.UserRole)
            if payload and payload.get("objectId") == object_id:
                return item, payload
            self._unknown_idx = None                      # (out of step: look again)
            for i in range(self.unknown_list.count()):
                item = self.unknown_list.item(i)
                payload = item.data(Qt.UserRole)
                if payload and payload.get("objectId") == object_id:
                    return item, payload
        return None, None

    def _selected_moving_object_ids(self):
        ids = []
        for item in self.unknown_list.selectedItems():
            object_id = (item.data(Qt.UserRole) or {}).get("objectId")
            if object_id in self.dynamic_objects:
                ids.append(object_id)
        return ids

    def _refresh_speed_control(self):
        """Show the obstacle card (stop/resume + speed) only while moving
        obstacle(s) are selected; otherwise show a short hint."""
        if not hasattr(self, "obstacle_card"):
            return
        ids = self._selected_moving_object_ids()
        self.obstacle_card.setVisible(bool(ids))
        self.obstacle_hint.setVisible(not ids)
        if not ids:
            return
        if len(ids) == 1:
            item, _ = self.find_unknown_item_by_id(ids[0])
            self.speed_title.setText(item.text() if item else ids[0])
        else:
            self.speed_title.setText(f"{len(ids)} moving obstacles")

        # stop/resume: "Stop" while any of them moves, "Resume" when all are stopped
        moving = any(self.dynamic_objects[o]["timer"].isActive() for o in ids)
        self.movement_toggle_btn.setText("  Stop" if moving else "  Resume")
        self.movement_toggle_btn.setIcon(self._icon("fa5s.pause" if moving else "fa5s.play",
                                                    "#111111"))
        self.movement_toggle_btn.setProperty("moving", moving)
        self._repolish(self.movement_toggle_btn)
        self.movement_state_chip.setText("MOVING" if moving else "STOPPED")
        self.movement_state_chip.setProperty("moving", moving)
        self._repolish(self.movement_state_chip)

        # speed range: the lowest limit among the selected types
        max_kmh = min(self._max_speed_kmh(self.dynamic_objects[o]["type"]) for o in ids)
        speed = min(self.dynamic_objects[ids[0]]["speed_kmh"], max_kmh)
        for w in (self.speed_slider, self.speed_spin):
            w.blockSignals(True)
        self.speed_slider.setRange(int(DYNAMIC_OBJECT_MIN_SPEED_KMH * 2), int(max_kmh * 2))
        self.speed_spin.setRange(DYNAMIC_OBJECT_MIN_SPEED_KMH, max_kmh)
        self.speed_spin.setValue(speed)
        self.speed_slider.setValue(int(round(speed * 2)))
        for w in (self.speed_slider, self.speed_spin):
            w.blockSignals(False)
        self.speed_range_label.setText(
            f"Speed range {DYNAMIC_OBJECT_MIN_SPEED_KMH:g} - {max_kmh:g} km/h")

    def toggle_selected_movement(self):
        """The single Stop / Resume button for the selected moving obstacle(s)."""
        ids = self._selected_moving_object_ids()
        if not ids:
            return
        if any(self.dynamic_objects[o]["timer"].isActive() for o in ids):
            for o in ids:
                self.stop_dynamic_object(o)
        else:
            for o in ids:
                self.resume_dynamic_object(o)

    def _on_speed_control_changed(self, speed_kmh):
        self.speed_slider.blockSignals(True)
        self.speed_slider.setValue(int(round(speed_kmh * 2)))
        self.speed_slider.blockSignals(False)
        for object_id in self._selected_moving_object_ids():
            self.set_dynamic_object_speed(object_id, speed_kmh, save=False)
        self._speed_save_timer.start(500)

    def show_unknown_menu(self, position):
        item = self.unknown_list.itemAt(position)
        if item is None:
            return
        self.obstacle_context_menu((item.data(Qt.UserRole) or {}).get("objectId"),
                                   self.unknown_list.viewport().mapToGlobal(position))

    def obstacle_context_menu(self, object_id, global_pos=None):
        """An obstacle's menu -- the Obstacles list, the 2D map and the 3D view (right-click)."""
        from PyQt5.QtGui import QCursor
        item, payload = self.find_unknown_item_by_id(object_id)
        if item is None:
            return
        state = self.dynamic_objects.get(object_id)

        menu = QMenu(self)   # parented, so it gets the app's dark menu style
        t = menu.addAction(item.text()); t.setEnabled(False)
        self._common_object_actions(menu, "object", object_id)
        menu.addSeparator()
        info_action = menu.addAction(self._icon("fa5s.info-circle", "#A1A1AA"), "Information")
        dims_action = menu.addAction(self._icon("fa5s.ruler-combined", "#A1A1AA"), "Dimensions...")

        move_action = None
        speed_action = None
        if payload.get("mode") == "dynamic" and state is not None:
            if state["timer"].isActive():
                move_action = menu.addAction(self._icon("fa5s.pause", "#FBBF24"), "Stop Movement")
            else:
                move_action = menu.addAction(self._icon("fa5s.play", "#22C55E"), "Resume Movement")
            speed_action = menu.addAction(self._icon("fa5s.tachometer-alt", "#60A5FA"),
                                          f"Change Speed...  ({state['speed_kmh']:g} km/h)")

        menu.addSeparator()
        delete_action = menu.addAction(self._icon("fa5s.trash-alt", "#EF4444"), "Delete")

        action = menu.exec_(global_pos or QCursor.pos())

        if speed_action is not None and action == speed_action:
            speed, ok = QInputDialog.getDouble(
                self, "Change Speed", f"Speed of {item.text()} (km/h):",
                state["speed_kmh"], DYNAMIC_OBJECT_MIN_SPEED_KMH,
                self._max_speed_kmh(state["type"]), 1)
            if ok:
                self.set_dynamic_object_speed(object_id, speed)
                self._refresh_speed_control()
        elif action == delete_action:
            self.delete_unknown_object(payload, item)
        elif action == info_action:
            self.show_unknown_object_info(payload)
        elif action == dims_action:
            self.edit_obstacle_dimensions(item)
        elif move_action is not None and action == move_action:
            self.toggle_dynamic_object(object_id)

    def show_unknown_object_info(self, payload):
        object_id = payload.get("objectId")
        object_type = payload.get("type", "").replace("_", " ").title()
        mode = payload.get("mode", "static").title()

        text = f"{object_id}\n\nType : {object_type}\nMode : {mode}"

        if payload.get("mode") == "dynamic":
            text += f"\nPath points : {len(payload.get('path', []))}"
            state = self.dynamic_objects.get(object_id)
            if state:
                text += f"\nSpeed : {state['speed_kmh']:g} km/h"

        labels = dict(OBSTACLE_FIELD_LABELS)
        labels.update(OBSTACLE_TYPES.get(payload.get("type"), {}).get("field_labels", {}))
        dims = self._obstacle_dims(object_id)
        if dims:
            text += "\n\nDimensions" + ("" if payload.get("dimensions") else " (defaults)")
            for key, value in dims.items():
                text += f"\n{labels.get(key, key)} : {value:g} m"

        QMessageBox.information(self, "Object Information", text)

    # ---------------- obstacle dimensions ((i) on the Obstacles page) ----------------
    @staticmethod
    def _obstacle_default_dims(object_type):
        return dict(OBSTACLE_TYPES.get(object_type, {}).get("dimensions", {}))

    def _obstacle_dims(self, object_id):
        """This obstacle's dimensions: type defaults overridden by any saved values."""
        _item, payload = self.find_unknown_item_by_id(object_id)
        if not payload:
            return {}
        dims = self._obstacle_default_dims(payload.get("type"))
        dims.update({k: v for k, v in (payload.get("dimensions") or {}).items() if k in dims})
        return dims

    def edit_obstacle_dimensions(self, item):
        if item is None:
            return
        payload = item.data(Qt.UserRole) or {}
        object_type = payload.get("type")
        defaults = self._obstacle_default_dims(object_type)
        if not defaults:
            QMessageBox.information(self, "Obstacle dimensions",
                                    f"No default dimensions configured for '{object_type}'.")
            return
        dlg = ObstacleDimensionsDialog(item.text(), object_type,
                                       self._obstacle_dims(payload.get("objectId")), defaults, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        payload = dict(payload)
        values = dlg.values()
        if all(abs(values[k] - float(defaults[k])) < 1e-9 for k in defaults):
            payload.pop("dimensions", None)          # back to the defaults: keep the file clean
        else:
            payload["dimensions"] = values
        item.setData(Qt.UserRole, payload)
        self.save_unknown_objects()
        print(f"[obstacle] {payload.get('objectId')} dimensions -> {self._obstacle_dims(payload.get('objectId'))}")

    def delete_unknown_object(self, payload, item, save=True):
        object_id = payload.get("objectId")

        state = self.dynamic_objects.pop(object_id, None)
        if state:
            state["timer"].stop()

        self._remove_unknown_marker_js(object_id)

        row = self.unknown_list.row(item)
        self.unknown_list.takeItem(row)

        if save:
            self.save_unknown_objects()

    # ---------------- Reports page: the saved collision test results ----------------

    def list_collision_reports(self):
        """This site's saved collision test results (newest first): [summary + {"dir"}]."""
        import auth
        base = self.collision_reports_dir()
        out = []
        if not os.path.isdir(base):
            return out
        me = (auth.current() or {}).get("username")
        mine_only = bool(me) and not auth.is_admin()       # (administrators: everyone's tests; the others: their own)
        for n in os.listdir(base):
            d = os.path.join(base, n)
            try:
                with open(os.path.join(d, "report.json"), encoding="utf-8") as f:
                    rep = json.load(f)
            except (OSError, ValueError):
                continue
            if mine_only and not str(rep.get("user") or "").endswith(f"({me})"):
                continue
            recs = rep.get("collisions") or []
            saved = rep.get("saved") or _file_time(os.path.join(d, "report.json"))   # (older reports: the file's)
            out.append({"kind": "collision", "name": n, "dir": d, "title": rep.get("route", n),
                        "created": rep.get("started") or saved, "ended": rep.get("ended"), "saved": saved,
                        "route": rep.get("route"),
                        "n": len(recs), "_rep": {k: rep.get(k) for k in ("loops_planned", "loops_done")},
                        "duration_s": rep.get("duration_s"),
                        "avs": [t.get("name") for t in rep.get("avs") or rep.get("trucks") or []],
                        "user": rep.get("user"),
                        "climates": rep.get("climates") or [], "ended_by": rep.get("ended_by"),
                        "replay": os.path.exists(os.path.join(d, "replay.json.gz"))})
        return sorted(out, key=lambda m: m.get("created") or "", reverse=True)

    def _build_reports_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        group = QGroupBox("Collision test reports")
        gl = QVBoxLayout(group)
        gl.setSpacing(8)
        hint = QLabel("The collision tests' results of this site: loops, collisions, why (climate, obstacle / "
                      "vehicle, sensor range / speed) and how to avoid them. Click a report to open its summary; "
                      "the play icon replays a test saved for replay.")
        hint.setObjectName("obstacleHint")
        hint.setWordWrap(True)
        gl.addWidget(hint)
        self.report_list = QListWidget()
        self.report_list.setObjectName("scenarioList")
        self.report_list.setMinimumHeight(260)
        self.report_list.setWordWrap(True)
        self.report_list.itemClicked.connect(self._open_report_item)
        self.report_list.setToolTip("Click a report to open it")
        gl.addWidget(self.report_list, 1)
        self.report_status = QLabel("")
        self.report_status.setObjectName("obstacleHint")
        self.report_status.setWordWrap(True)
        self.report_status.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)   # (long paths: not wider)
        gl.addWidget(self.report_status)
        row = QHBoxLayout(); row.setSpacing(8)
        # (open / its folder / delete: the icons on each report's row)
        for txt, fn, tip in (("Refresh", lambda: self.refresh_reports(), "Read the reports folder again"),
                             ("Open reports folder", lambda: (self.report_list.clearSelection(),
                                                              self.report_list.setCurrentItem(None),
                                                              self._open_report_folder()),
                              "The folder of all the collision test reports")):
            b = QPushButton(txt)
            b.setObjectName("stopObjectButton")
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            row.addWidget(b)
        gl.addLayout(row)
        lay.addWidget(group, 1)
        return page

    def refresh_reports(self, kind=None):
        """The collision test reports (newest first)."""
        if not hasattr(self, "report_list"):
            return
        import collision_panel
        try:
            items = self.list_collision_reports()
        except Exception as e:
            items = []
            self.report_status.setText(f"Could not read the reports: {type(e).__name__}: {e}")
        self.report_list.clear()
        col = {"PASS": "#4ADE80", "FAIL": "#F87171"}
        for m in items:
            rep = m.pop("_rep")
            n = m["n"]
            text = (f"{'PASS' if not n else 'FAIL'}  ·  {n} collision{'s' if n != 1 else ''}  ·  {m['route']}  ·  "
                    f"{collision_panel.loops_text(rep)}\nStarted {m['created']}"
                    + (f"  ·  ended {_same_day(m['ended'], m['created'])}" if m.get("ended") else "")
                    + (f"  ·  saved {_same_day(m['saved'], m['created'])}" if m.get("saved") else "")
                    + f"\n{collision_panel._dur(m['duration_s'])}"
                    f"  ·  {len(m['avs'])} AV{'s' if len(m['avs']) != 1 else ''}  ·  "
                    f"{' → '.join(m['climates'])}" + (f"  ·  {m['user']}" if m.get("user") else "")
                    + ("  ·  ▶ replay" if m.get("replay") else ""))
            tip = ", ".join(str(x) for x in m["avs"]) + "\n" + m["dir"] + (
                "\n▶ Saved for replay: the play icon on the row plays it back (window, 2D map, 3D view)"
                if m.get("replay") else "")
            it = QListWidgetItem(text)
            it.setData(Qt.UserRole, dict(m))
            it.setToolTip(tip)
            it.setForeground(QColor(col["FAIL" if n else "PASS"]))
            self.report_list.addItem(it)
        where = self.collision_reports_dir()
        if not items:
            self.report_status.setText(
                f"No collision test report yet ({_wrap_path(where)}). A collision test (top bar: Collision Testing) "
                "saves its results here when it finishes / ends.")
        else:
            self.report_status.setText(f"{len(items)} report(s) in {_wrap_path(where)}")

    def _open_report_item(self, item):
        m = item.data(Qt.UserRole) or {}
        d = m.get("dir")
        if not d or not os.path.isdir(d):
            QMessageBox.warning(self, "Reports", "This report is not there any more.")
            self.refresh_reports()
            return
        try:
            with open(os.path.join(d, "report.json"), encoding="utf-8") as f:
                rep = json.load(f)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Reports", f"Could not open the report:\n{type(e).__name__}: {e}")
            return
        rep["dir"] = d
        rep.setdefault("saved", _file_time(os.path.join(d, "report.json")))   # (older reports: the file's time)
        self.show_collision_report(rep)

    def _selected_report(self):
        it = self.report_list.currentItem()
        return (it.data(Qt.UserRole) or {}) if it is not None else None

    def _open_report_folder(self):
        from PyQt5.QtGui import QDesktopServices
        m = self._selected_report()
        d = (m or {}).get("dir") or self.collision_reports_dir()
        os.makedirs(d, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(d))

    def _delete_report(self):
        m = self._selected_report()
        if not m:
            QMessageBox.information(self, "Reports", "Select a report first.")
            return
        if QMessageBox.question(self, "Delete report", f"Delete this report for good?\n\n{m.get('name')}\n{m['dir']}") \
                != QMessageBox.Yes:
            return
        try:
            import shutil
            shutil.rmtree(m["dir"])
        except Exception as e:
            QMessageBox.warning(self, "Delete report", f"{type(e).__name__}: {e}")
        self.refresh_reports()

    # ---------------- Routes page: the saved routes; new ones without an AV ----------------
    def _build_routes_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        group = QGroupBox("Saved routes")
        gl = QVBoxLayout(group)
        gl.setSpacing(8)
        hint = QLabel("Routes any AV can drive: right-click an AV -> Drive a route, New AV -> Route, Collision "
                      "Testing. New route: from a source to a destination along the roads, or drawn point by point.")
        hint.setObjectName("obstacleHint")
        hint.setWordWrap(True)
        gl.addWidget(hint)
        new = QPushButton("  New route ...")
        new.setIcon(self._icon("fa5s.plus", "#111111"))
        new.setStyleSheet("QPushButton { background: #FBBF24; color: #111111; font-weight: 700; border-radius: 6px; "
                          "padding: 6px 10px; } QPushButton::menu-indicator { subcontrol-position: right center; }")
        new.setCursor(Qt.PointingHandCursor)
        nm = QMenu(new)
        nm.addAction(self._icon("fa5s.map-signs", "#22D3EE"), "From a source to a destination (along the roads) ...",
                     lambda: self.new_route("auto"))
        nm.addAction(self._icon("fa5s.route", "#F97316"), "Draw it on the map (point by point) ...",
                     lambda: self.new_route("draw"))
        new.setMenu(nm)
        gl.addWidget(new)
        self.route_list = QListWidget()
        self.route_list.setObjectName("scenarioList")
        self.route_list.setWordWrap(True)
        self.route_list.setToolTip("Each route's buttons: show on the map, drive it with a truck, rename, update its "
                                   "path, delete. Double-click: show it on the map")
        self.route_list.itemDoubleClicked.connect(lambda it: self.show_route_on_map(it.data(Qt.UserRole)))
        gl.addWidget(self.route_list, 1)
        self.route_status = QLabel("")
        self.route_status.setObjectName("obstacleHint")
        self.route_status.setWordWrap(True)
        # (a long folder path must not widen the side panel -- every page there got as wide and was cut off)
        self.route_status.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        gl.addWidget(self.route_status)
        self.route_list.setMinimumHeight(160)
        lay.addWidget(group, 1)
        return page

    def _route_file_info(self, name):
        """(length m, loop, header text) of a saved route (cached by its file's time)."""
        import road_router
        src = SAVED_PATHS.get(name)
        if src is None:
            return None, False, ""
        key = src if isinstance(src, str) else f"(built in) {name}"
        path = (src if os.path.isabs(src) else os.path.join(os.path.dirname(os.path.abspath(__file__)), src)) \
            if isinstance(src, str) else None
        mt = os.path.getmtime(path) if path and os.path.exists(path) else 0
        cache = getattr(self, "_route_info_cache", None)
        if cache is None:
            cache = self._route_info_cache = {}
        if cache.get(key, (None,))[0] != mt or key not in cache:
            head = ""
            if path and os.path.exists(path):
                with open(path, encoding="utf-8") as f:
                    first = f.readline()
                head = first.strip("# \n") if first.startswith("#") else ""
            try:
                pts = [(p[0], p[1]) for p in load_route(name)]
            except Exception:
                pts = []
            L = sum(road_router.dist(a, b) for a, b in zip(pts, pts[1:]))
            loop = str((cfg.route_meta(path) if path else {}).get("loop", "0")) == "1"
            cache[key] = (mt, L, loop, head, pts)
        _mt, L, loop, head, _pts = cache[key]
        return L, loop, head

    def _route_points(self, name):
        src = SAVED_PATHS.get(name)
        key = src if isinstance(src, str) else f"(built in) {name}"
        self._route_file_info(name)
        return self._route_info_cache.get(key, (0, 0, 0, "", []))[4]

    def refresh_routes(self):
        if not hasattr(self, "route_list"):
            return
        SAVED_PATHS.clear()
        SAVED_PATHS.update(cfg.site_routes())
        cur = self._picked_route()
        self.route_list.clear()
        for name in SAVED_PATHS:
            L, loop, head = self._route_file_info(name)
            src = head.split("| from ", 1)[1] if "| from " in head else ""
            it = QListWidgetItem()
            it.setData(Qt.UserRole, name)
            it.setToolTip(str(SAVED_PATHS.get(name)))
            self.route_list.addItem(it)
            w = self._route_row(name, f"{(L or 0) / 1000:.2f} km · "
                                      f"{'a loop (back to its start)' if loop else 'one way'}"
                                      + (f" · {src}" if src else ""), isinstance(SAVED_PATHS.get(name), str))
            it.setSizeHint(QSize(max(200, self.route_list.viewport().width() - 4), 58))   # (+ the theme's padding)
            self.route_list.setItemWidget(it, w)
            if name == cur:
                self.route_list.setCurrentItem(it)
        self.route_status.setText(f"{len(SAVED_PATHS)} route(s) in {_wrap_path(cfg.ROUTES_DIR)}" if SAVED_PATHS else
                                  "No route yet: New route ...")

    def _route_row(self, name, info, own):
        """One route in the Routes list: its name and length on the left, its actions as icons on the right (show
        on the map, drive with an AV, rename, update the path, delete). own: a route file (built-in routes can
        only be shown / driven)."""
        w = QWidget()
        w.setAttribute(Qt.WA_TranslucentBackground, True)
        h = QHBoxLayout(w)
        h.setContentsMargins(6, 4, 4, 4)
        h.setSpacing(3)
        from html import escape as html_escape
        from PyQt5.QtGui import QFont, QFontMetrics
        # (one line each, shortened to the panel's width -- the whole text is the row's tooltip)
        avail = max(120, self.route_list.viewport().width() - 5 * 31 - 30)
        fb = QFont(self.route_list.font()); fb.setBold(True)
        fs = QFont(self.route_list.font()); fs.setPixelSize(11)
        nm = QFontMetrics(fb).elidedText(name, Qt.ElideRight, avail)
        inf = QFontMetrics(fs).elidedText(info, Qt.ElideRight, avail)
        txt = QLabel(f"<b>{html_escape(nm)}</b><br><span style='color:#9CA3AF; font-size:11px'>"
                     f"{html_escape(inf)}</span>")
        txt.setTextFormat(Qt.RichText)
        txt.setToolTip(f"{name}\n{info}")
        txt.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        txt.setAttribute(Qt.WA_TransparentForMouseEvents, True)   # (a click on it: the row is picked)
        h.addWidget(txt, 1)
        for icon, col, tip, fn, ok in (
                ("fa5s.map-marked-alt", "#FBBF24", "Show on the map (start green, end red)",
                 lambda: self.show_route_on_map(name), True),
                ("fa5s.truck", "#22D3EE", "Drive it with a truck of the yard ...", self._drive_picked_route, True),
                ("fa5s.pen", "#3B82F6", "Rename ...", self._rename_picked_route, own),
                ("fa5s.draw-polygon", "#F97316", "Update its path: click the new points on the map (along the roads "
                                                 "through them, or exactly as drawn), then Finish path",
                 self._update_picked_route, own),
                ("fa5s.trash-alt", "#F87171", "Delete the route for good (asks first)", self._delete_picked_route,
                 own)):
            b = QToolButton()
            b.setIcon(self._icon(icon, col))
            b.setIconSize(QSize(15, 15))
            b.setFixedSize(28, 28)
            b.setAutoRaise(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(tip if ok else tip + " -- not for a built-in route")
            b.setEnabled(ok)
            b.setStyleSheet("QToolButton { border: 1px solid transparent; border-radius: 5px; background: transparent; }"
                            "QToolButton:hover { border-color: #4B5563; background: rgba(255,255,255,0.08); }")
            b.clicked.connect(lambda _c=False, f=fn: (self._pick_route(name), f()))
            h.addWidget(b, 0, Qt.AlignVCenter)
        return w

    def _pick_route(self, name):
        for i in range(self.route_list.count()):
            it = self.route_list.item(i)
            if it.data(Qt.UserRole) == name:
                self.route_list.setCurrentItem(it)
                return

    def _update_picked_route(self):
        """Update path: the route is shown, then its new points are clicked on the map -> Finish path -> along the
        roads through them (or as drawn) -> saved under the same name."""
        name = self._picked_route()
        if not name or not isinstance(SAVED_PATHS.get(name), str):
            return
        self.show_route_on_map(name)
        self.new_route("draw")
        self._route_redraw = name
        self._show_path_bar(f"Update the path of '{name}': click its new points on the map, from its start to its "
                            "end (the current path is shown in yellow). Then Finish path.")

    def _picked_route(self):
        it = self.route_list.currentItem() if hasattr(self, "route_list") else None
        return it.data(Qt.UserRole) if it is not None else None

    def show_route_on_map(self, name):
        """A saved route on the map: the line, its start (green) and end (red); the map moves to it."""
        if not name or name not in SAVED_PATHS:
            return
        pts = self._route_points(name)
        if len(pts) < 2:
            QMessageBox.information(self, "Routes", f"The route '{name}' has no points.")
            return
        step = max(1, len(pts) // 600)
        p = [[round(a, 7), round(b, 7)] for a, b in pts[::step]] + [[round(pts[-1][0], 7), round(pts[-1][1], 7)]]
        m = self.map_var_name
        self.browser.page().runJavaScript(f"""
        (function(){{
            (window.routeShown||[]).forEach(function(l){{ {m}.removeLayer(l); }});
            var p = {json.dumps(p)};
            var ls = [L.polyline(p, {{color: '#FBBF24', weight: 5, opacity: 0.9}}).addTo({m}).bindTooltip({json.dumps(name)}),
                      L.circleMarker(p[0], {{radius: 8, color: '#fff', weight: 2, fillColor: '#16A34A', fillOpacity: 1}})
                        .bindTooltip('Start: ' + {json.dumps(name)}).addTo({m}),
                      L.circleMarker(p[p.length - 1], {{radius: 7, color: '#fff', weight: 2, fillColor: '#DC2626',
                                                        fillOpacity: 1}}).bindTooltip('End').addTo({m})];
            window.routeShown = ls;
            try {{ {m}.fitBounds(L.polyline(p).getBounds(), {{padding: [40, 40]}}); }} catch (e) {{}}
            setTimeout(function(){{ (window.routeShown||[]).forEach(function(l){{ {m}.removeLayer(l); }});
                                    window.routeShown = []; }}, 30000);
        }})();""")
        self.status_message(f"Route '{name}' on the map (30 s)", 6000)

    def _drive_picked_route(self):
        name = self._picked_route()
        if not name:
            QMessageBox.information(self, "Routes", "Select a route first.")
            return
        trucks = []
        lst = self.av_list
        for i in range(lst.count()):
            p = lst.item(i).data(Qt.UserRole) or {}
            if p.get("avId") and not p.get("collisionTest"):
                trucks.append((str(self.vehicle_label(p["avId"])), p["avId"]))
        if not trucks:
            QMessageBox.information(self, "Routes", "No truck in this yard yet.")
            return
        lab, ok = QInputDialog.getItem(self, f"Drive '{name}'", "Truck:", [t[0] for t in trucks], 0, False)
        if ok:
            self.start_route(dict(trucks)[lab], name)

    def _rename_picked_route(self):
        name = self._picked_route()
        src = SAVED_PATHS.get(name) if name else None
        if not isinstance(src, str):
            return
        new, ok = QInputDialog.getText(self, "Rename route", "New name:", text=name)
        new = (new or "").strip().replace("|", "/")
        if not ok or not new or new == name:
            return
        if new in SAVED_PATHS:
            QMessageBox.warning(self, "Rename route", f"A route '{new}' exists already.")
            return
        with open(src, encoding="utf-8") as f:
            lines = f.readlines()
        if lines and lines[0].startswith("# route:"):
            head = lines[0].split("|", 1)
            lines[0] = f"# route: {new} |" + (head[1] if len(head) > 1 else "\n")
        dst = os.path.join(cfg.ROUTES_DIR, re.sub(r"[^A-Za-z0-9_.-]+", "_", new) + ".txt")
        with open(dst, "w", encoding="utf-8") as f:
            f.writelines(lines)
        if os.path.abspath(dst) != os.path.abspath(src):
            os.remove(src)
        self.refresh_routes()

    def _delete_picked_route(self):
        name = self._picked_route()
        src = SAVED_PATHS.get(name) if name else None
        if not isinstance(src, str):
            QMessageBox.information(self, "Routes", "Select a route first.")
            return
        if QMessageBox.question(self, "Delete route", f"Delete the route '{name}' for good?\n\n{src}") != QMessageBox.Yes:
            return
        os.remove(src)
        self.refresh_routes()

    # ---- a new route without an AV ----
    FREE_DRAW_JS = """
    window.startFreeDrawing = function (check) {
        window.stopPathDrawing();
        window.currentPathPoints = [];
        window.drawLayer = L.layerGroup().addTo(%(m)s);
        window.drawPolyline = null;
        window.pathDrawClickHandler = function (e) {
            var pts = window.currentPathPoints, q = [e.latlng.lat, e.latlng.lng];
            pts.push(q);
            L.circleMarker(e.latlng, {radius: pts.length === 1 ? 8 : 5, color: '#fff', weight: pts.length === 1 ? 2 : 1,
                                      fillColor: pts.length === 1 ? '#16A34A' : '#9b59b6', fillOpacity: 1})
                .bindTooltip(pts.length === 1 ? 'Source / start' : 'Point ' + pts.length).addTo(window.drawLayer);
            if (window.drawPolyline) window.drawLayer.removeLayer(window.drawPolyline);
            window.drawPolyline = L.polyline(pts, {color: '#9b59b6', weight: 3, dashArray: '6,6'}).addTo(window.drawLayer);
        };
        %(m)s.on('click', window.pathDrawClickHandler);
    };"""

    def new_route(self, how):
        """Routes page -> New route: "auto" (click a source and a destination: along the roads), "draw" (click every
        point). At the end: its name -> saved for every AV."""
        if self._ui_ready and getattr(self, "drawer_open", False) and not getattr(self, "drawer_pinned", False):
            self._close_drawer()                              # (the map free to click / to show the preview)
        self._route_redraw = None                             # (a new route -- Update path sets it after this)
        if how == "auto" and self._router() is None:
            QMessageBox.information(self, "New route", "This yard has no roads from OpenStreetMap yet: Update 3D (top "
                                                       "bar) downloads them -- or draw the route point by point.")
            return
        self._pending_av_path = "__route__"
        self._pending_path_auto = how == "auto"
        self._pending_dynamic_object = None
        self.browser.page().runJavaScript(self.FREE_DRAW_JS % {"m": self.map_var_name}
                                          + f"window.startFreeDrawing({json.dumps(how == 'draw')});")
        self._show_path_bar("New route: click the SOURCE, then the DESTINATION (and any via points between them, in "
                            "order) -- it follows the roads. Then Finish." if how == "auto" else
                            "New route: click its points on the map, from its start to its end. Then Finish.")

    def _new_route_drawn(self, points, auto):
        """Finish path of a new route (or of Update path: the route's new points, saved under its name)."""
        replace = getattr(self, "_route_redraw", None)
        self._route_redraw = None
        if not points or len(points) < 2:
            QMessageBox.warning(self, "New route", "Click at least a start and an end on the map.")
            return
        # drawn: along the roads through the clicked points (source, via, destination) or exactly as drawn
        self._route_path_dialog(None, points, drawn=not auto, replace=replace)

    def _build_scenarios_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        group = QGroupBox("Obstacle scenarios")
        gl = QVBoxLayout(group)
        gl.setSpacing(8)
        hint = QLabel("Click a scenario (or its ▶) to place its obstacles -- the obstacles on the map are replaced. "
                      "Your own scenarios also have update (save the map's obstacles into it) and delete icons. Add "
                      "more obstacles on the Obstacles page and save them as a new scenario.")
        hint.setObjectName("obstacleHint")
        hint.setWordWrap(True)
        gl.addWidget(hint)
        self.scenario_list = QListWidget()
        self.scenario_list.setObjectName("scenarioList")
        self.scenario_list.setMinimumHeight(170)
        self.scenario_list.setMaximumHeight(300)        # the buttons below always stay in view
        self.scenario_list.itemClicked.connect(self._on_scenario_clicked)
        self.scenario_list.currentRowChanged.connect(lambda _r: self._update_scenario_buttons())
        gl.addWidget(self.scenario_list)
        self.scenario_status = QLabel("")
        self.scenario_status.setObjectName("obstacleHint")
        self.scenario_status.setWordWrap(True)
        gl.addWidget(self.scenario_status)
        gl.addWidget(self._collision_checkbox())

        row1 = QHBoxLayout(); row1.setSpacing(8)
        self.scenario_save_btn = QPushButton("Save current as new...")
        self.scenario_save_btn.setObjectName("stopObjectButton")
        self.scenario_save_btn.setToolTip("Save the obstacles on the map (positions, paths, speeds, "
                                          "dimensions) as a new scenario")
        self.scenario_save_btn.clicked.connect(self.save_current_as_scenario)
        row1.addWidget(self.scenario_save_btn, 1)
        # (place / update / delete: the icons on each scenario's row)
        self.scenario_clear_btn = QPushButton("Clear obstacles")
        self.scenario_clear_btn.setObjectName("stopObjectButton")
        self.scenario_clear_btn.setToolTip("Remove every obstacle from the map")
        self.scenario_clear_btn.clicked.connect(self.clear_all_unknown_objects)
        row1.addWidget(self.scenario_clear_btn, 1)
        gl.addLayout(row1)
        for b in (self.scenario_save_btn, self.scenario_clear_btn):
            b.setCursor(Qt.PointingHandCursor)
        lay.addWidget(group)
        lay.addStretch(1)

        self.scenarios = []
        self.active_scenario = None          # name of the scenario last placed
        self._active_signature = None        # obstacles right after it was placed (to see edits)
        self._scenario_timer = QTimer(self)   # keeps the "modified" state in the list up to date
        self._scenario_timer.timeout.connect(self._refresh_scenario_status)
        self._scenario_timer.start(1500)
        QTimer.singleShot(0, self._load_scenarios)
        return page

    def _load_scenarios(self):
        self.scenarios = obstacle_scenarios.load(cfg.SCENARIOS_FILE)
        defaults = [s for s in self.scenarios if s.get("default")]
        if defaults and any(s.get("version", 1) < obstacle_scenarios.DEFAULTS_VERSION for s in defaults):
            # newer default scenarios: rebuild them, keep the user's own scenarios
            own = [s for s in self.scenarios if not s.get("default")]
            self.scenarios = self._default_scenarios() + own
            obstacle_scenarios.save(cfg.SCENARIOS_FILE, self.scenarios)
            print("[scenarios] default scenarios rebuilt (version "
                  f"{obstacle_scenarios.DEFAULTS_VERSION}); {len(own)} own scenario(s) kept")
        if not self.scenarios:                           # first time in this yard: make the defaults
            self.scenarios = self._default_scenarios()
            current = self._current_obstacles()
            if current:                                  # keep what is on the map now
                self.scenarios.append(obstacle_scenarios.make("Saved obstacles", current))
                self.active_scenario = "Saved obstacles"
                self._active_signature = self._obstacles_signature(current)
            obstacle_scenarios.save(cfg.SCENARIOS_FILE, self.scenarios)
        self._fill_scenario_list()

    def _default_scenarios(self):
        routes = []
        for name in SAVED_PATHS:
            try:
                routes.append(load_route(name))
            except Exception as e:
                print(f"[scenarios] route {name} not usable: {e}")
        # yard roads / footways from OpenStreetMap ("Update 3D"), so obstacles cover the whole map
        osm = osm_surroundings.load(cfg.OSM_SURROUNDINGS_FILE) or {}
        roads = [r["line"] for r in osm.get("roads", [])
                 if r.get("kind") in ("service", "tertiary", "unclassified", "residential", "secondary")]
        footways = [r["line"] for r in osm.get("roads", []) if r.get("kind") in ("footway", "path", "pedestrian")]
        fallback_path = self._generate_random_path if getattr(self, "dynamic_zones", None) else None
        fallback_point = self._generate_random_open_point if getattr(self, "dynamic_zones", None) else None
        defaults = obstacle_scenarios.build_defaults(routes, _nowhere, self.site_info["bounds"],
                                                     roads, footways, fallback_path, fallback_point)
        # traffic scenarios (light ... very heavy): cars / outer trucks on every drivable road, in their lane
        drivable = [(r["line"], r.get("width")) for r in osm.get("roads", [])
                    if r.get("kind") not in ("footway", "path", "steps", "cycleway", "pedestrian", "track")]
        defaults += obstacle_scenarios.build_traffic(drivable, _nowhere, self.site_info["bounds"])
        for s in defaults:
            print(f"[scenarios] default '{s['name']}': {obstacle_scenarios.summary(s)} "
                  f"({len(routes)} routes, {len(roads)} roads, {len(footways)} footways)")
        return defaults

    def _current_obstacles(self):
        return [dict(self.unknown_list.item(i).data(Qt.UserRole) or {}) for i in range(self.unknown_list.count())]

    @staticmethod
    def _obstacles_signature(obstacles):
        return json.dumps(sorted((o.get("objectId"), o.get("mode"), round(o.get("latitude") or 0, 7),
                                  round(o.get("longitude") or 0, 7), len(o.get("path") or []),
                                  o.get("speed_kmh"), json.dumps(o.get("dimensions") or {}, sort_keys=True))
                                 for o in obstacles))

    def _scenario_modified(self):
        return self.active_scenario is not None and \
            self._obstacles_signature(self._current_obstacles()) != self._active_signature

    def _fill_scenario_list(self, select=None):
        lst = self.scenario_list
        cur = select or (lst.currentItem().data(Qt.UserRole) if lst.currentItem() else None)
        lst.blockSignals(True)
        lst.clear()
        modified = self._scenario_modified()
        for s in self.scenarios:
            active = s["name"] == self.active_scenario
            text = f"{s['name']}   ·   {obstacle_scenarios.summary(s)}"
            if active:
                text += "   (on the map" + (", modified)" if modified else ")")
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, s["name"])
            icon = "fa5s.check-circle" if active else ("fa5s.star" if s.get("default") else "fa5s.bookmark")
            item.setIcon(self._icon(icon, "#4ADE80" if active else "#FBBF24" if s.get("default") else "#93C5FD"))
            item.setToolTip(("Default scenario" if s.get("default") else "Saved scenario")
                            + f"\nCreated {s.get('created', '')}\n{obstacle_scenarios.summary(s)}")
            if active:
                f = item.font(); f.setBold(True); item.setFont(f)
            lst.addItem(item)
            if s["name"] == cur:
                lst.setCurrentItem(item)
        lst.blockSignals(False)
        self._update_scenario_buttons()
        self._refresh_scenario_status(refill=False)

    def _selected_scenario(self):
        it = self.scenario_list.currentItem()
        name = it.data(Qt.UserRole) if it else None
        return next((s for s in self.scenarios if s["name"] == name), None)

    def _update_scenario_buttons(self):
        self.scenario_list.viewport().update()               # (its row icons: update / delete for own scenarios)

    def _refresh_scenario_status(self, refill=True):
        if not hasattr(self, "scenario_status"):
            return
        obs = self._current_obstacles()
        moving = sum(1 for o in obs if o.get("mode") == "dynamic")
        txt = f"On the map: {len(obs)} obstacle(s), {moving} moving"
        if self.obstacle_collisions:
            txt += f"  --  accidents: {self.accident_count}"
        if self.active_scenario:
            modified = self._scenario_modified()
            txt += f"  --  scenario '{self.active_scenario}'" + (" (modified, not saved)" if modified else "")
            if refill and modified != getattr(self, "_shown_modified", None):
                self._shown_modified = modified
                self._fill_scenario_list()
                return
        self.scenario_status.setText(txt)

    def _on_scenario_clicked(self, item):
        name = item.data(Qt.UserRole)
        scenario = next((s for s in self.scenarios if s["name"] == name), None)
        if scenario is None:
            return
        if name == self.active_scenario and not self._scenario_modified():
            return                                       # already on the map
        current = self._current_obstacles()
        unsaved = current and (self.active_scenario is None or self._scenario_modified())
        if unsaved:
            box = QMessageBox(self)
            box.setWindowTitle("Scenarios")
            box.setText(f"Replace the {len(current)} obstacle(s) on the map with scenario '{name}'?")
            box.setInformativeText("They are not saved as a scenario yet.")
            save_b = box.addButton("Save them first...", QMessageBox.ActionRole)
            replace_b = box.addButton("Replace", QMessageBox.DestructiveRole)
            box.addButton(QMessageBox.Cancel)
            box.exec_()
            if box.clickedButton() == save_b:
                if not self.save_current_as_scenario():
                    return
            elif box.clickedButton() != replace_b:
                self._fill_scenario_list()
                return
        self.apply_scenario(scenario)

    def apply_scenario(self, scenario):
        """Removes every obstacle from the map and places the scenario's obstacles."""
        while self.unknown_list.count():
            it = self.unknown_list.item(0)
            self.delete_unknown_object(it.data(Qt.UserRole) or {}, it, save=False)
        placed = 0
        for o in scenario.get("obstacles", []):
            if self._add_obstacle_from_payload(o):
                placed += 1
        self.save_unknown_objects()
        self.active_scenario = scenario["name"]
        self._active_signature = self._obstacles_signature(self._current_obstacles())
        self._shown_modified = False
        self._update_nav_counts()
        self._fill_scenario_list(select=scenario["name"])
        print(f"[scenarios] '{scenario['name']}' placed: {placed} obstacle(s)")

    def _add_obstacle_from_payload(self, payload):
        p = dict(payload)
        oid, typ = p.get("objectId"), p.get("type")
        icon = UNKNOWN_OBJECT_ICONS.get(typ)
        lat, lon = p.get("latitude"), p.get("longitude")
        if not oid or icon is None or lat is None or lon is None:
            return False
        if self.find_unknown_item_by_id(oid)[0] is not None:     # never two obstacles with one id
            return False
        label = f"{typ.replace('_', ' ').title()} {oid}"
        self._create_unknown_marker_js(oid, icon, lat, lon, label)
        item = QListWidgetItem(label)
        item.setData(Qt.UserRole, p)
        self.unknown_list.addItem(item)
        if p.get("mode") == "dynamic" and p.get("path") and len(p["path"]) >= 2:
            self._start_dynamic_object_timer(oid, typ, p["path"], p.get("speed_kmh"))
        return True

    def _ask_scenario_name(self, title, default=""):
        name, ok = QInputDialog.getText(self, title, "Scenario name:", text=default)
        name = (name or "").strip()
        if not ok or not name:
            return None
        return name

    def save_current_as_scenario(self):
        """Saves the obstacles on the map as a new scenario (shown in the list)."""
        current = self._current_obstacles()
        if not current:
            QMessageBox.information(self, "Scenarios", "There are no obstacles on the map to save.")
            return False
        n = len([s for s in self.scenarios if not s.get("default")]) + 1
        name = self._ask_scenario_name("Save scenario", f"Scenario {n}")
        if not name:
            return False
        existing = next((s for s in self.scenarios if s["name"].lower() == name.lower()), None)
        if existing is not None:
            if existing.get("default"):
                QMessageBox.warning(self, "Scenarios", f"'{existing['name']}' is a default scenario -- choose another name.")
                return False
            if QMessageBox.question(self, "Scenarios", f"Replace the saved scenario '{existing['name']}'?") \
                    != QMessageBox.Yes:
                return False
            self.scenarios.remove(existing)
        self.scenarios.append(obstacle_scenarios.make(name, current))
        obstacle_scenarios.save(cfg.SCENARIOS_FILE, self.scenarios)
        self.active_scenario = name
        self._active_signature = self._obstacles_signature(current)
        self._shown_modified = False
        self._fill_scenario_list(select=name)
        return True

    def update_selected_scenario(self):
        s = self._selected_scenario()
        if not s or s.get("default"):
            return
        current = self._current_obstacles()
        if not current:
            QMessageBox.information(self, "Scenarios", "There are no obstacles on the map to save.")
            return
        if QMessageBox.question(self, "Scenarios", f"Overwrite '{s['name']}' with the {len(current)} obstacle(s) "
                                                   "on the map?") != QMessageBox.Yes:
            return
        s.update(obstacle_scenarios.make(s["name"], current))
        obstacle_scenarios.save(cfg.SCENARIOS_FILE, self.scenarios)
        self.active_scenario = s["name"]
        self._active_signature = self._obstacles_signature(current)
        self._shown_modified = False
        self._fill_scenario_list(select=s["name"])

    def delete_selected_scenario(self):
        s = self._selected_scenario()
        if not s or s.get("default"):
            return
        if QMessageBox.question(self, "Scenarios", f"Delete the scenario '{s['name']}'?\n"
                                                   "(The obstacles on the map stay.)") != QMessageBox.Yes:
            return
        self.scenarios.remove(s)
        obstacle_scenarios.save(cfg.SCENARIOS_FILE, self.scenarios)
        if self.active_scenario == s["name"]:
            self.active_scenario = None
            self._active_signature = None
        self._fill_scenario_list()

    def save_unknown_objects(self):
        objects = []
        for i in range(self.unknown_list.count()):
            item = self.unknown_list.item(i)
            objects.append(item.data(Qt.UserRole))

        with open(self.unknown_objects_file, "w") as f:
            json.dump({"objects": objects}, f, indent=4)

    def load_unknown_objects(self):
        if not os.path.exists(self.unknown_objects_file):
            return

        with open(self.unknown_objects_file, "r") as f:
            data = json.load(f)

        for obj in data.get("objects", []):
            object_id = obj.get("objectId")
            object_type = obj.get("type")

            if not object_id or not object_type:
                continue

            label = f"{object_type.replace('_', ' ').title()} {object_id}"
            list_item = QListWidgetItem(label)
            list_item.setData(Qt.UserRole, obj)
            self.unknown_list.addItem(list_item)

    def restore_unknown_markers(self):
        for i in range(self.unknown_list.count()):
            item = self.unknown_list.item(i)
            payload = item.data(Qt.UserRole)

            object_id = payload.get("objectId")
            object_type = payload.get("type")
            icon_file = UNKNOWN_OBJECT_ICONS.get(object_type)

            lat = payload.get("latitude")
            lon = payload.get("longitude")

            if icon_file is None or lat is None or lon is None or object_id is None:
                continue

            label = f"{object_type.replace('_', ' ').title()} {object_id}"
            self._create_unknown_marker_js(object_id, icon_file, lat, lon, label)

            if payload.get("mode") == "dynamic" and payload.get("path"):
                self._start_dynamic_object_timer(object_id, object_type, payload["path"],
                                                 payload.get("speed_kmh"))

    def handle_vehicle_moved(self, vehicle_id, lat, lng):
        list_widget, item, payload = self.find_list_item_by_vehicle_id(vehicle_id)
        if payload is None:
            return
        if lat == 0 and lng == 0:
            self.delete_vehicle(payload, list_widget, item)
            return
        self._move_on_road(vehicle_id, lat, lng, payload, item)

    def remove_vehicle_from_map(self, vehicle_id):
        list_widget, item, payload = self.find_list_item_by_vehicle_id(vehicle_id)
        if payload is None:
            return
        payload["latitude"] = None
        payload["longitude"] = None
        payload["locationId"] = None
        payload["locationType"] = None
        item.setData(Qt.UserRole, payload)
        self.save_vehicles()
        print(vehicle_id, "removed from map")

    def snap_marker_back(self, vehicle_id, payload):
        lat = payload.get("latitude")
        lng = payload.get("longitude")
        if lat is None or lng is None:
            return

        js = f"""
        if(window.vehicleMarkers && window.vehicleMarkers[{json.dumps(vehicle_id)}]){{
            window.vehicleMarkers[{json.dumps(vehicle_id)}].setLatLng([{lat}, {lng}]);
        }}
        """
        self.browser.page().runJavaScript(js)

    def restore_vehicle_markers(self):
        for i in range(self.av_list.count()):
            self._restore_single_marker(self.av_list.item(i).data(Qt.UserRole), AV_ICON_PATH, "avId")

    def _restore_single_marker(self, payload, icon_file, id_key):
        lat = payload.get("latitude")
        lng = payload.get("longitude")
        vehicle_id = payload.get(id_key)

        if lat is None or lng is None or vehicle_id is None:
            return

        js_marker = f"""
        (function() {{
            var vehicleIcon = L.icon({{
                iconUrl: {json.dumps(icon_file)}, iconSize: [45,45], iconAnchor: [22,22]
            }});

            var m = L.marker(
                [{lat}, {lng}],
                {{ title: {json.dumps(self.vehicle_label(vehicle_id))}, icon: vehicleIcon, draggable: true }}
            ).addTo({self.map_var_name});

            m.bindPopup({json.dumps(self._vehicle_popup_html(vehicle_id))});

            window.vehicleMarkers = window.vehicleMarkers || {{}};
            window.vehicleMarkers[{json.dumps(vehicle_id)}] = m;

            m.on('dragend', function(e) {{
                var newPos = e.target.getLatLng();
                if (window.bridge) {{
                    window.bridge.vehicleMoved({json.dumps(vehicle_id)}, newPos.lat, newPos.lng);
                }}
            }});

            m.on('contextmenu', function(ev) {{
                if (window.bridge && window.bridge.vehicleMenu) {{     // the app's menu: path, follow, remove
                    if (ev && ev.originalEvent) L.DomEvent.stop(ev);
                    window.bridge.vehicleMenu({json.dumps(vehicle_id)});
                    return;
                }}
                if (confirm("Remove this vehicle?")) {{
                    {self.map_var_name}.removeLayer(m);
                    delete window.vehicleMarkers[{json.dumps(vehicle_id)}];
                    if (window.bridge) {{
                        window.bridge.removeVehicleFromMap({json.dumps(vehicle_id)});
                    }}
                }}
            }});

            window.registerVehicleSlot(
                {json.dumps(vehicle_id)}, [], {json.dumps(icon_file)},
                {json.dumps(self._vehicle_kind(payload.get("type"), payload))},
                {float(payload.get("heading") or 0.0)}
            );
        }})();
        """
        self.browser.page().runJavaScript(js_marker)

    @staticmethod
    def _read_json_list(path, key):
        if not os.path.exists(path):
            return None
        with open(path, "r") as f:
            return json.load(f).get(key, [])

    def load_vehicles(self):
        """This site's AVs: sites/<site>/data/avs.json (each: id = its topic <site>_<project>_<number>, name,
        number, and -- placed on the map -- position, heading and the path drawn for it)."""
        saved = self._read_json_list(cfg.AVS_FILE, "avs") or []
        for av in saved:
            if not av.get("avId"):
                continue
            number = str(av.get("number") or cfg.av_number(av["avId"]))
            item = QListWidgetItem(av.get("name") or av["avId"])
            item.setData(Qt.UserRole, {
                "type": "truck", "avId": av["avId"], "rover": av.get("rover") or av["avId"],
                "number": number, "name": av.get("name", ""), "driveMode": "Auto Drive",
                "latitude": av.get("latitude"), "longitude": av.get("longitude"),
                "locationType": av.get("locationType"), "locationId": av.get("locationId"),
                **{k: av[k] for k in ("heading", "path", "pathSpeedKmh", "pathLoop") if k in av}})
            self._style_av_item(item, True)
            self.av_list.addItem(item)

    def save_vehicles(self):
        """The site's AVs -> sites/<site>/data/avs.json (the AVs made for a collision test only are not kept)."""
        avs = []
        for i in range(self.av_list.count()):
            d = dict(self.av_list.item(i).data(Qt.UserRole) or {})
            if d.get("collisionTest"):
                continue
            avs.append(d)
        os.makedirs(os.path.dirname(cfg.AVS_FILE), exist_ok=True)
        with open(cfg.AVS_FILE, "w", encoding="utf-8") as f:
            json.dump({"avs": avs}, f, indent=4)

    def remove_marker(self, vehicle_id):
        js = f"""
        (function(){{
            if(window.vehicleMarkers && window.vehicleMarkers[{json.dumps(vehicle_id)}]){{
                {self.map_var_name}.removeLayer(window.vehicleMarkers[{json.dumps(vehicle_id)}]);
                delete window.vehicleMarkers[{json.dumps(vehicle_id)}];
            }}
        }})();
        """
        self.browser.page().runJavaScript(js)


    # ---------------- broker connect / disconnect (top-bar button) ----------------
    # ---------------- 3D LiDAR view ----------------
    def open_lidar_3d_view(self, vehicle_id=None):
        """'LiDAR View' check-box / header 'LiDAR 3D' button (vehicle_id None) or a
        AV's 'Show in LiDAR 3D': the LiDAR view in a panel inside the map area
        (bottom-right corner at first; drag the title bar to move, edges to resize)."""
        if self.lidar_view is None:
            self.lidar_view = LidarView3D(self._lidar_targets)
            self.lidar_view.targetChanged.connect(self._repush_lidar_scene)
            self.lidar_panel = FloatingPanel("LiDAR 3D view", self.lidar_view,
                                             self._icon("fa5s.cube", "#FBBF24"), self.map_host)
            self.lidar_panel.closed.connect(lambda: self.lidar_panel_cb.setChecked(False))
            self.lidar_panel.place_in_corner("bottom-right")
        if not self.lidar_panel.isVisible():
            self.lidar_panel.show()
            self.lidar_panel.keep_inside()
        self.lidar_panel.raise_()
        if not self.lidar_panel_cb.isChecked():
            self.lidar_panel_cb.blockSignals(True)
            self.lidar_panel_cb.setChecked(True)
            self.lidar_panel_cb.blockSignals(False)
        if vehicle_id is not None:
            self.lidar_view.select_target(vehicle_id)
        else:
            self.lidar_view.refresh_targets()
        # show the AV right away instead of waiting for its next position
        self._repush_lidar_scene(self.lidar_view.current_target())

    def _repush_lidar_scene(self, key):
        last = self._lidar_last.get(str(key))
        if last is not None:
            self._push_lidar_scene(key, *last)
        elif self.lidar_view is not None and getattr(self.lidar_view, "_waiting_for", None) != key:
            # switched to an AV without data yet: say so instead of the old scene
            self.lidar_view._waiting_for = key
            self.lidar_view.view.page().runJavaScript(
                "['details','info'].forEach(function(id){var e=document.getElementById(id);"
                "if(e) e.textContent='waiting for truck data...';});")

    def _lidar_refresh_tick(self):
        v = self.lidar_view
        if v is not None and v.isVisible():
            self._repush_lidar_scene(v.current_target())

    def _lidar_targets(self):
        # only the AVs have a LiDAR
        items = []
        for vid in list(self.path_replays.keys()):
            if self._is_auto_drive(vid):
                items.append((f"{vid} (selected route)", str(vid)))
        for vid in list(self._finished_routes.keys()):
            if vid not in self.path_replays and self._is_auto_drive(vid):
                items.append((f"{vid} (arrived)", str(vid)))
        return items


    def _lidar_details(self, key, lat, lon, heading):
        """Rows for the 3D view's details panel + the nearby part of the route."""
        position = f"{lat:.6f}, {lon:.6f}"
        heading_txt = f"{heading % 360:.0f}° {_compass(heading)}"
        state = self.path_replays.get(key) or self._finished_routes.get(key)
        if state is None:
            # live AV: speed from the previous live position (only recomputed when
            # a new position arrives -- the 3D view also refreshes in between)
            now = time.time()
            prev = self._lidar_live_prev
            if prev is None or (prev[0], prev[1]) != (lat, lon):
                if prev is not None and now - prev[2] > 0.05:
                    kmh = _metres_between(prev[0], prev[1], lat, lon) / (now - prev[2]) * 3.6
                    self._lidar_live_speed = f"{kmh:.1f} km/h"
                self._lidar_live_prev = (lat, lon, now)
            details = {"title": "Live truck", "rows": [
                ["Source", "Network packets"],
                ["Speed", self._lidar_live_speed],
                ["Heading", heading_txt],
                ["Position", position],
                ["Last update", datetime.now().strftime("%H:%M:%S")],
            ]}
            return details, [], 0

        points, cum = state["points"], state["cum"]
        n = len(points)
        idx = max(0, min(n - 1, state["index"] - 1))      # point the AV is on now
        interval = PATH_REPLAY_INTERVAL_MS / 1000.0
        step = cum[idx] - cum[idx - 1] if idx > 0 and key in self.path_replays else 0.0
        progress = 100.0 * (idx + 1) / n
        details = {"title": f"Truck {key}", "progress": progress, "rows": [
            ["Route", state["label"]],
            ["Status", "Arrived" if idx >= n - 1 else "Following route"],
            ["Progress", f"{idx + 1} / {n} points ({progress:.0f} %)"],
            ["Driven", f"{cum[idx]:.0f} m"],
            ["Remaining", f"{cum[-1] - cum[idx]:.0f} m"],
            ["Speed", f"{step / interval * 3.6:.1f} km/h"],
            ["Time left", _fmt_duration((n - 1 - idx) * interval)],
            ["Heading", heading_txt],
            ["Position", position],
        ] + self._lidar_detection_rows(key)}
        start = max(0, idx - 40)
        route = [[p[0], p[1]] for p in points[start:idx + 150]]
        return details, route, idx - start

    def _push_lidar_scene(self, key, lat, lon, heading):
        """Send this AV's surroundings to the 3D window (only if it is open and shows this AV)."""
        key = str(key)
        self._lidar_last[key] = (lat, lon, heading)
        v = self.lidar_view
        if v is not None:
            v._waiting_for = None
        if v is None or not v.isVisible() or v.current_target() != key or not self.map_var_name:
            return
        details, route, split = self._lidar_details(key, lat, lon, heading)
        m = self.map_var_name
        js = f"""
        (function() {{
            var c = L.latLng({lat}, {lon}), out = [];
            function add(id, mk, kind, hd, dims) {{
                if (!mk || !mk.getLatLng) return;
                var q = mk.getLatLng(), d = {m}.distance(c, q);
                if (d > 45 || d < 1.0) return;          // beyond the roof LiDAR's 30 m (+ object size), or the truck itself
                out.push({{ id: id, label: (mk.options && mk.options.title) || id, kind: kind,
                            lat: q.lat, lng: q.lng, heading: hd || 0, dist: d, dims: dims || null }});
            }}
            Object.keys(window.unknownMarkers || {{}}).forEach(function(k) {{
                add(k, window.unknownMarkers[k], 'object', window.unknownMarkers[k]._heading); }});
            Object.keys(window.vehicleMarkers || {{}}).forEach(function(k) {{
                var g = (window.vehicleGeom || {{}})[k] || {{}};     // real type + slot heading
                add(k, window.vehicleMarkers[k], 'vehicle', g.heading || 0, g.kind); }});
            Object.keys(window.replayLayers || {{}}).forEach(function(k) {{
                var mk = window.replayLayers[k][1];
                add('route:' + k, mk, 'truck', ((mk && mk._rotation) || 0) + 90, 'tractor'); }});
            return JSON.stringify(out);
        }})();
        """
        self.browser.page().runJavaScript(
            js, lambda res: v.set_scene(key, lat, lon, heading, self._with_obstacle_sizes(res),
                                        details, route, split))

    def _with_obstacle_sizes(self, objects_json):
        """Adds each placed obstacle's own dimensions (defaults or edited with the
        (i) button) to the object list sent to the 3D LiDAR view."""
        try:
            objects = json.loads(objects_json) if objects_json else []
        except (TypeError, ValueError):
            return objects_json
        for o in objects:
            if o.get("kind") != "object":
                continue
            dims = self._obstacle_dims(o.get("id"))
            if dims.get("length") and dims.get("width") and dims.get("height"):
                o["size"] = {"l": dims["length"], "w": dims["width"], "h": dims["height"],
                             "gc": dims.get("ground_clearance", 0.0)}
        return json.dumps(objects)

    def toggle_map_maximized(self):
        """Collapse / restore the left area (sidebar + pages) so the map fills the window."""
        hide = self.left_area.isVisible()
        self.left_area.setVisible(not hide)
        self.collapse_map_btn.setIcon(
            self._icon("fa5s.chevron-right" if hide else "fa5s.chevron-left", "white")
        )

    def toggle_map_immersive(self):
        """Hide header + footer + left area (map only) or bring them back."""
        entering = self.header_bar.isVisible()
        if entering:
            self._close_drawer(animate=False)
        self.header_bar.setVisible(not entering)
        self.footer_bar.setVisible(not entering)
        self.left_area.setVisible(not entering)
        self.maximize_map_btn.setIcon(
            self._icon("fa5s.compress" if entering else "fa5s.expand", "white")
        )
        self.collapse_map_btn.setIcon(
            self._icon("fa5s.chevron-right" if entering else "fa5s.chevron-left", "white")
        )


    def delete_selected_vehicles(self):
        """Deletes every selected AV of the list in one click."""
        items = self.av_list.selectedItems()
        if not items:
            QMessageBox.information(self, "No Selection", "Select one or more AVs first.")
            return
        if QMessageBox.question(self, "Delete Selected", f"Delete {len(items)} selected AV(s)?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        for item in items:
            self.delete_vehicle(item.data(Qt.UserRole), self.av_list, item)

    def clear_all_vehicles(self):
        """Removes every AV -- markers, list entries and the saved avs.json."""
        if self.av_list.count() == 0:
            QMessageBox.information(self, "Nothing to Clear", "There are no AVs.")
            return
        if QMessageBox.question(self, "Clear All AVs", f"Delete ALL {self.av_list.count()} AV(s)?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        while self.av_list.count() > 0:
            item = self.av_list.item(0)
            self.delete_vehicle(item.data(Qt.UserRole), self.av_list, item)


    def delete_selected_unknown_objects(self):
        """Deletes every currently-selected row in the Unknown Objects list
        in one click, instead of one-by-one."""
        items = self.unknown_list.selectedItems()

        if not items:
            QMessageBox.information(self, "No Selection", "Select one or more objects first.")
            return

        answer = QMessageBox.question(
            self, "Delete Selected",
            f"Delete {len(items)} selected object(s)?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return

        for item in items:
            payload = item.data(Qt.UserRole)
            self.delete_unknown_object(payload, item)

    def clear_all_unknown_objects(self):
        """Removes every car/outer_truck/pedestrian currently placed --
        markers, timers, list entries, and the saved unknown.json."""
        if self.unknown_list.count() == 0:
            QMessageBox.information(self, "Nothing to Clear", "No objects are currently placed.")
            return

        answer = QMessageBox.question(
            self, "Clear All Objects",
            f"Remove ALL {self.unknown_list.count()} placed object(s) from the map?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return

        while self.unknown_list.count() > 0:
            item = self.unknown_list.item(0)
            payload = item.data(Qt.UserRole)
            self.delete_unknown_object(payload, item)


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()     # (the long jobs run in their own processes)
    import crash_guard
    crash_guard.install()                # a Python error in a Qt callback is logged, not a crash
    crash_guard.use_angle()              # Windows: Direct3D (ANGLE), not the graphics driver's OpenGL
    enable_high_dpi()   # must run before QApplication is created
    app = QApplication(sys.argv)
    from screen_utils import install_wheel_guard
    install_wheel_guard(app)
    app.setStyleSheet(load_app_stylesheet())

    window = MapWindow()
    window.showMaximized()

    code = app.exec_()
    crash_guard.shutdown_qt(app)         # web views deleted while Qt runs (they crashed the app on exit)
    sys.exit(code)