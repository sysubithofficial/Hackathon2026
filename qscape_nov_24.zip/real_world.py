"""Satellite imagery of the yard for the 3D "Real world" view.

The Esri World Imagery map tiles around the yard (its bounds + a margin) are downloaded once,
stitched into chunk images of 8 x 8 tiles (2048 x 2048 px JPEG) and kept in
sites/<yard>/data/imagery/ with an index.json (each chunk's north / south / west / east), so the
view works offline afterwards. "Update imagery" downloads them again.

Imagery: Esri, Maxar, Earthstar Geographics, and the GIS User Community -- shown in the 3D view
while it is used (Esri's terms of use apply).
"""
import json
import math
import os
import shutil
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from PyQt5.QtCore import QRect, QUrl
from PyQt5.QtGui import QColor, QImage, QPainter

import site_config as cfg

TILE_URL = "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
ATTRIBUTION = "Imagery © Esri, Maxar, Earthstar Geographics, and the GIS User Community"
USER_AGENT = "yard-yard-simulation/1.0"
ZOOM = 19                        # ~0.22 m / pixel at 42° N
MARGIN_M = 300.0                 # imagery around the yard bounds
CHUNK = 8                        # tiles per chunk side (8 x 256 = 2048 px)
MAX_TILES = 3000                 # larger areas use zoom 18


def imagery_dir():
    return os.path.join(cfg.DATA_DIR, "imagery")


def _tile_xy(lat, lng, z):
    n = 2 ** z
    x = (lng + 180.0) / 360.0 * n
    y = (1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n
    return x, y


def _tile_lat(y, z):
    return math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / 2 ** z))))


def _tile_lng(x, z):
    return x / 2 ** z * 360.0 - 180.0


def plan(bounds, margin_m=MARGIN_M, zoom=ZOOM):
    """(zoom, x0, y0, x1, y1) tile range (inclusive) covering bounds [[s, w], [n, e]] + margin."""
    (s, w), (n, e) = bounds
    dlat = margin_m / 111320.0
    dlng = margin_m / (111320.0 * math.cos(math.radians((s + n) / 2)))
    while True:
        x0, y0 = _tile_xy(n + dlat, w - dlng, zoom)
        x1, y1 = _tile_xy(s - dlat, e + dlng, zoom)
        r = (zoom, int(x0), int(y0), int(x1), int(y1))
        if (r[3] - r[1] + 1) * (r[4] - r[2] + 1) <= MAX_TILES or zoom <= 16:
            return r
        zoom -= 1


def load_index():
    """The cached imagery of the active yard: {"key", "attribution", "chunks": [{url, n, s, w, e}]} or None."""
    path = os.path.join(imagery_dir(), "index.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            idx = json.load(f)
    except (OSError, ValueError):
        return None
    chunks = []
    for c in idx.get("chunks", []):
        p = os.path.join(imagery_dir(), c["file"])
        if os.path.exists(p):
            chunks.append(dict(c, url=QUrl.fromLocalFile(p).toString()))
    if not chunks:
        return None
    return {"key": f"{cfg.ACTIVE_SITE}:{idx.get('created', '')}", "attribution": idx.get("attribution", ATTRIBUTION),
            "zoom": idx.get("zoom"), "chunks": chunks}


class Download:
    """Downloads + stitches in a background thread; poll .done / .progress / .error / .cancel()."""

    def __init__(self, bounds):
        self.bounds = bounds
        self.progress = (0, 1)
        self.done = False
        self.error = None
        self._cancel = False
        threading.Thread(target=self._run, daemon=True).start()

    def cancel(self):
        self._cancel = True

    def _fetch(self, z, x, y):
        for attempt in range(3):
            if self._cancel:
                return None
            try:
                req = urllib.request.Request(TILE_URL.format(z=z, x=x, y=y), headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(req, timeout=20) as r:
                    return r.read()
            except Exception:
                time.sleep(0.5 * (attempt + 1))
        return None

    def _run(self):
        try:
            z, x0, y0, x1, y1 = plan(self.bounds)
            tiles = [(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)]
            self.progress = (0, len(tiles))
            data, n_done, failed = {}, 0, 0
            with ThreadPoolExecutor(max_workers=8) as pool:
                for (x, y), raw in zip(tiles, pool.map(lambda t: self._fetch(z, *t), tiles)):
                    if self._cancel:
                        raise RuntimeError("cancelled")
                    data[(x, y)] = raw
                    failed += raw is None
                    n_done += 1
                    self.progress = (n_done, len(tiles))
            if failed > len(tiles) * 0.2:
                raise RuntimeError(f"{failed} of {len(tiles)} imagery tiles could not be downloaded "
                                   f"(no internet / the imagery server is blocked?)")
            tmp = imagery_dir() + ".new"
            shutil.rmtree(tmp, ignore_errors=True)
            os.makedirs(tmp)
            chunks = []
            for cy in range(y0, y1 + 1, CHUNK):
                for cx in range(x0, x1 + 1, CHUNK):
                    nx, ny = min(CHUNK, x1 + 1 - cx), min(CHUNK, y1 + 1 - cy)
                    img = QImage(nx * 256, ny * 256, QImage.Format_RGB32)
                    img.fill(QColor(90, 94, 88))
                    p = QPainter(img)
                    for ty in range(ny):
                        for tx in range(nx):
                            raw = data.get((cx + tx, cy + ty))
                            if raw:
                                t = QImage.fromData(raw)
                                if not t.isNull():
                                    p.drawImage(QRect(tx * 256, ty * 256, 256, 256), t)
                    p.end()
                    name = f"z{z}_{cx}_{cy}.jpg"
                    img.save(os.path.join(tmp, name), "JPEG", 88)
                    chunks.append({"file": name, "n": _tile_lat(cy, z), "s": _tile_lat(cy + ny, z),
                                   "w": _tile_lng(cx, z), "e": _tile_lng(cx + nx, z)})
            with open(os.path.join(tmp, "index.json"), "w", encoding="utf-8") as f:
                json.dump({"source": TILE_URL, "attribution": ATTRIBUTION, "zoom": z, "bounds": self.bounds,
                           "margin_m": MARGIN_M, "created": time.strftime("%Y-%m-%d %H:%M:%S"), "chunks": chunks},
                          f, indent=2)
            shutil.rmtree(imagery_dir(), ignore_errors=True)
            os.replace(tmp, imagery_dir())
        except Exception as e:
            self.error = str(e)
        finally:
            self.done = True
