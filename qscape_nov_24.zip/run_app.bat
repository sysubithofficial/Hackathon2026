@echo off
rem Q-SCAPE -- start the app on Windows from its own .venv (made once by setup_app.bat / setup_app.sh).
cd /d "%~dp0"
set PYTHONNOUSERSITE=1
if not exist .venv\Scripts\python.exe (echo No .venv here -- run setup_app.bat once. & pause & exit /b 1)
.venv\Scripts\python.exe main.py %*
