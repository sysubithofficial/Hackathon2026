"""Follow test: an AV follows a manual truck at a set gap and brakes ONLY on what its sensors detect.

Purpose: testing how the climate (fog, rain, snow, night ...) affects the detection of the vehicles ahead. The
follower drives along the leader's trail (where the leader has driven). Its speed comes from its perception:

  - LiDAR: the simulated LiDAR scan of the 3D sensor page (yard3d.html lidarDetect -- the climate's extinction,
    noise and false returns included): an object counts when enough points land on it;
  - front camera: a forward camera (the truck's own perception cameras look back at the trailer), modelled here:
    an object is seen when it is inside the field of view and closer than the camera's detection range in this
    climate (about half the visibility, shorter at night and in heavy rain / snow).

  - front radar: modelled here (FRONT_RADAR): long range, hardly affected by fog, measures the relative speed
    (Doppler), no object type; pedestrians / standing objects are seen closer.

Sensors: any of LiDAR / camera / radar, switched on / off while it drives (Follower.set_sensor); with several the
nearest of what any sees is used (fusion) -- to show what each sensor and fusion adds; all off: it sees nothing.
Convoy: several AVs, each following the one ahead (the app chains Followers).
The camera does not see through vehicles: an object hidden behind a nearer one is not detected (occlusion);
small objects (pedestrians) are seen closer. The LiDAR scan has occlusion and its blind zone built in.
Road grip (road_grip): rain / snow / fog wet the road -- the full brake is weaker (heavy rain ~70 %, snow ~60 %).
TTC (time to collision) = gap / closing speed: from what it perceives and from the real gap (ground truth); the
lowest of the test is kept, warnings below TTC_WARN_S / TTC_CRIT_S go into the log.

The nearest object in the follower's lane ahead (the leader, but also any other vehicle / obstacle) is the target.
With a target the follower keeps the set gap, slows down with the target and brakes -- up to a full brake --
when it closes in. Without a target it drives on at its set speed: in a climate where the leader is not detected
in time it does not brake, and runs into it (counted as a collision). Every braking / collision goes into the log.
"""
import math

A_FULL = 6.0                  # m/s^2: full brake of the follower
A_COMFORT = 2.0               # m/s^2: normal braking; more than this = an emergency brake
ACCEL = 1.0                   # m/s^2: speeding up
STOP_GAP_M = 3.0              # the gap it brakes for at the latest (bumper to bumper)
CORRIDOR_HALF_M = 2.2         # its lane: objects this far left / right of its centre line count
HOLD_S = 0.6                  # a detection is used this long (LiDAR detections come 4 times a second)
GAP_GAIN = 0.35               # 1/s: how fast it closes / opens the gap to the set one
SPEED_GAIN = 1.0              # 1/s: how fast it reaches the speed it wants (within ACCEL / A_COMFORT)
BRAKE_LOG = 1.5               # m/s^2: decelerating harder than this is logged as a braking
REPORT_RANGE_M = 70.0         # LiDAR detections asked for during the test
FRONT_CAMERA = {"hfov_deg": 90.0, "max_range_m": 80.0, "visibility_share": 0.5, "night": 0.45,
                "precip_loss": 0.3}
# front radar (77 GHz long-range automotive radar), a physical model (radar_snr_db / radar_detect):
#  - signal-to-noise from the radar equation: SNR = SNR_ref + (RCS - RCS_ref) - 40 log10(R / R_ref) - losses;
#    calibrated so a AV (RCS ~20 dBsm) is detected half of the scans at max_range_m in clear air;
#  - radar cross-section by object: AV / trailer ~20 dBsm, car ~10, van ~13, pedestrian ~-5, small obstacle ~0;
#    objects never seen moving (parked, standing) lose clutter_static_db (the stationary-clutter filter);
#  - rain: two-way specific attenuation gamma = k * R_mm_h^alpha dB/km (ITU-R P.838, 77 GHz: k 1.1, alpha 0.72),
#    rain backscatter raising the noise floor, a wet radome (water film on the cover) -- heavy rain ~5-8 dB in all;
#    spray: behind a AV on a wet road, its spray cloud costs a few dB more;
#  - snow: wet snow attenuation + snow / slush on the radome (the classic radar blockage) -- heavy snow ~8-12 dB;
#  - fog: cloud water attenuation is tiny at 77 GHz (~0.4 dB/km per g/m^3) -- fog hardly matters;
#  - each scan an object is detected with probability Pd(SNR) (no hard range edge), range noise grows as the
#    SNR falls; a tracker confirms a target after `confirm` hits of the last `window` scans and coasts it a short
#    while when missed -- far / weak targets flicker and are confirmed late;
#  - it sees past a vehicle ahead (the beam bounces under it) -- almost no occlusion; distance + relative speed
#    (Doppler), no object type.
FRONT_RADAR = {"hfov_deg": 60.0, "max_range_m": 120.0, "ref_rcs_dbsm": 20.0, "pd_slope_db": 1.6,
               "rcs_dbsm": {"truck": 20.0, "trailer": 21.0, "car": 10.0, "van": 13.0, "bus": 18.0,
                            "pedestrian": -5.0, "cyclist": -2.0, "object": 3.0},
               "clutter_static_db": 6.0, "rain_k": 1.1, "rain_alpha": 0.72, "rain_mm_h_max": 60.0,
               "rain_clutter_db": 2.5, "radome_rain_db": 3.0, "spray_db": 3.0, "spray_range_m": 35.0,
               "snow_db_per_km": 6.0, "radome_snow_db": 8.0, "fog_db_per_km": 0.2,
               "confirm": 2, "window": 3, "coast_s": 0.35, "range_noise_m": 0.08, "occluded_share": 0.95}
TTC_WARN_S = 3.0              # time to collision: a warning below this ...
TTC_CRIT_S = 1.5              # ... critical below this: an emergency brake (AEB) on what it perceives
OCCLUDED_SHARE = 0.7          # the camera: an object hidden this much (of its width) behind a nearer one is not seen
SENSORS_ALL = ("LiDAR", "camera", "radar")
SENSOR_MODES = {"all": ("LiDAR", "camera", "radar"), "fusion": ("LiDAR", "camera"), "lidar": ("LiDAR",),
                "camera": ("camera",), "radar": ("radar",)}
SENSOR_MODE_TEXT = {"all": "LiDAR + camera + radar (fusion)", "fusion": "LiDAR + camera (fusion)",
                    "lidar": "LiDAR only", "camera": "camera only", "radar": "radar only"}


def sensors_text(sensors):
    """'LiDAR + camera (fusion)', 'radar only', 'ALL SENSORS OFF' ..."""
    s = [n for n in SENSORS_ALL if n in (sensors or ())]
    if not s:
        return "ALL SENSORS OFF"
    return " + ".join(s) + (" (fusion)" if len(s) > 1 else " only")


def sensor_mode_of(sensors):
    """The SENSOR_MODES key of a set of sensors ('custom' if none fits)."""
    return next((k for k, v in SENSOR_MODES.items() if set(v) == set(sensors or ())), "custom")


def road_grip(climate):
    """The road's grip in this climate (share of the dry braking: climates.json "road_grip", else wet / snow):
    heavy rain ~0.7, light rain ~0.88, snow ~0.6, fog (wet surface) 0.9, dry 1.0."""
    c = climate or {}
    if c.get("road_grip") is not None:
        return max(0.2, min(1.0, float(c["road_grip"])))
    p = c.get("precip") or {}
    rate = float(p.get("rate") or 0)
    if p.get("type") == "rain":
        return 1.0 - 0.3 * rate
    if p.get("type") == "snow":
        return 1.0 - 0.5 * rate
    if float(c.get("visibility_m") or 4500) < 200:      # fog: a damp road
        return 0.9
    return 1.0


def camera_range(climate, cam=FRONT_CAMERA):
    """How far the front camera detects a vehicle in this climate (m)."""
    c = climate or {}
    r = min(cam["max_range_m"], cam["visibility_share"] * float(c.get("visibility_m") or 4500))
    if c.get("day") is False:
        r *= cam["night"]                              # headlights only
    p = c.get("precip") or {}
    if p.get("type") in ("rain", "snow"):
        r *= 1.0 - cam["precip_loss"] * float(p.get("rate") or 0)
    return max(2.0, r)


def lidar_range(climate, lidar_max_m=15.0):
    """How far the LiDAR still gets enough returns from a vehicle in this climate (~2 % of the returns left)."""
    ext = float(((climate or {}).get("lidar") or {}).get("extinction_per_m") or 0)
    return lidar_max_m if ext <= 0 else min(lidar_max_m, math.log(50.0) / (2.0 * ext))


def radar_losses_db(climate, r, radar=FRONT_RADAR, spray=False):
    """The weather's two-way loss (dB) for a target r metres away: rain (ITU-R P.838 attenuation + backscatter
    noise + wet radome), snow (attenuation + radome), fog (cloud water), road spray behind a AV in rain;
    climates.json "radar": {"extra_loss_db"} adds to it."""
    c = climate or {}
    p = c.get("precip") or {}
    rate = max(0.0, min(1.0, float(p.get("rate") or 0)))
    loss = float((c.get("radar") or {}).get("extra_loss_db") or 0.0)
    if p.get("type") == "rain" and rate > 0:
        mm_h = rate * radar["rain_mm_h_max"]
        gamma = radar["rain_k"] * mm_h ** radar["rain_alpha"]               # dB/km, one way
        loss += 2.0 * gamma * r / 1000.0 + (radar["rain_clutter_db"] + radar["radome_rain_db"]) * rate
        if spray:
            loss += radar["spray_db"] * rate
    elif p.get("type") == "snow" and rate > 0:
        loss += 2.0 * radar["snow_db_per_km"] * rate * r / 1000.0 + radar["radome_snow_db"] * rate
    vis = float(c.get("visibility_m") or 4500)
    if vis < 1000:                                                        # fog: liquid water ~ 1 / visibility
        loss += 2.0 * radar["fog_db_per_km"] * min(3.0, 200.0 / max(5.0, vis)) * r / 1000.0
    return loss


def radar_rcs_db(kind, width=2.5, radar=FRONT_RADAR):
    """Radar cross-section (dBsm) of an object by its kind (size for unknown obstacles)."""
    k = str(kind or "").lower()
    table = radar["rcs_dbsm"]
    for key in table:
        if key in k:
            return table[key]
    if "trailer" in k or "truck" in k:
        return table["truck"]
    return table["object"] if float(width or 2.5) < 1.5 else table["car"]


def radar_margin_db(r, rcs_db, climate, radar=FRONT_RADAR, static=False, spray=False):
    """Signal-to-noise over the detection threshold (dB): 0 = detected in half of the scans."""
    m = (rcs_db - radar["ref_rcs_dbsm"]) - 40.0 * math.log10(max(1.0, r) / radar["max_range_m"])
    m -= radar_losses_db(climate, r, radar, spray)
    if static:
        m -= radar["clutter_static_db"]
    return m


def radar_pd(margin_db, radar=FRONT_RADAR):
    """Detection probability per scan from the SNR margin."""
    return 1.0 / (1.0 + math.exp(-margin_db / radar["pd_slope_db"]))


def radar_range(climate, radar=FRONT_RADAR, rcs_db=None, static=False):
    """How far the radar detects a target half of the scans (m): a moving AV by default."""
    rcs = radar["ref_rcs_dbsm"] if rcs_db is None else rcs_db
    share = ((climate or {}).get("radar") or {}).get("range_share")
    lo, hi = 1.0, 400.0
    if radar_margin_db(lo, rcs, climate, radar, static) < 0:
        return lo
    for _ in range(40):
        mid = (lo + hi) / 2
        if radar_margin_db(mid, rcs, climate, radar, static) > 0:
            lo = mid
        else:
            hi = mid
    return lo * (float(share) if share is not None else 1.0)


def detect_range(climate, lidar_max_m=15.0):
    """The farther of the two sensors (an autonomous vehicle sees a vehicle ahead from here)."""
    return max(camera_range(climate), lidar_range(climate, lidar_max_m))


def _local(ego, lat, lon):
    """(forward, left) metres of a point in the ego AV's frame (ego = (lat, lon, heading deg))."""
    kx = 111320.0 * math.cos(math.radians(ego[0]))
    e, n = (lon - ego[1]) * kx, (lat - ego[0]) * 111320.0
    h = math.radians(ego[2])
    fwd = e * math.sin(h) + n * math.cos(h)
    left = -e * math.cos(h) + n * math.sin(h)
    return fwd, left


def _obj(o):
    """An object tuple (id, label, lat, lon, length, width[, kind, moving, heading, speed m/s]) -> a dict."""
    return {"id": o[0], "label": o[1], "lat": o[2], "lon": o[3], "L": float(o[4] or 4.5), "W": float(o[5] or 2.5),
            "kind": o[6] if len(o) > 6 and o[6] else "vehicle", "moving": bool(o[7]) if len(o) > 7 else True,
            "heading": o[8] if len(o) > 8 else None, "speed": float(o[9] or 0.0) if len(o) > 9 else 0.0}


def _fov_detect(ego, ego_len, objects, rng, hfov_deg, reach, occluded_share, sensor, hidden=None, extra=None,
                yaw_deg=0.0):
    """What a sensor (field of view, range, facing yaw_deg: 0 = ahead, + = to the left) detects: reach(object
    dict, gap) = the share of `rng` this object is seen at; an object hidden (occluded_share of its width) behind
    a nearer one is not seen."""
    half = math.radians(hfov_deg) / 2
    yaw = math.radians(yaw_deg or 0.0)
    cy, sy = math.cos(yaw), math.sin(yaw)
    cand = []
    for o in objects:
        ob = _obj(o)
        x, y = _local(ego, ob["lat"], ob["lon"])
        if x * cy + y * sy <= 0:                                   # (behind the sensor)
            continue
        gap = x - ego_len / 2 - ob["L"] / 2
        ang = (math.atan2(y, x) - yaw + math.pi) % (2 * math.pi) - math.pi
        if gap > rng * reach(ob, gap) or abs(ang) > half:
            continue
        w2 = max(0.3, ob["W"] / 2)
        cand.append((x, ang - math.atan2(w2, x), ang + math.atan2(w2, x), y, gap, ob))
    cand.sort(key=lambda c: c[0])
    out, seen = [], []
    for x, a0, a1, y, gap, ob in cand:
        by, cover = None, 0.0
        for sx, s0, s1, slabel in seen:                                # nearer objects in front of it
            if sx < x - 0.5:
                c = max(0.0, min(a1, s1) - max(a0, s0)) / max(1e-6, a1 - a0)
                if c > cover:
                    cover, by = c, slabel
        seen.append((x, a0, a1, ob["label"]))
        if cover >= occluded_share:
            if hidden is not None:
                hidden.append({"id": ob["id"], "label": ob["label"], "by": by, "lat": ob["lat"], "lng": ob["lon"],
                               "x": x, "y": y})
            continue
        d = {"id": ob["id"], "label": ob["label"], "gap": max(0.0, gap), "x": x, "y": y, "sensor": sensor,
             "lat": ob["lat"], "lng": ob["lon"], "kind": ob["kind"]}
        if extra:
            d.update(extra(ob, gap, rng * reach(ob, gap)))
        out.append(d)
    return out


def camera_detect(ego, ego_len, objects, climate, cam=FRONT_CAMERA, hidden=None):
    """objects = [(id, label, lat, lon, length, width[, kind ...])] -> detections of the front camera, like the
    LiDAR's: {id, label, gap (bumper to the object's back), x (forward), y (left), sensor, kind, cls, conf}.
    The camera classifies (cls = the object's type, conf = confidence: lower far away / in poor visibility -- below
    50 % it is only an 'object'). Small objects are seen closer (a pedestrian at ~55 % of the range of a vehicle);
    an object hidden behind a nearer one (OCCLUDED_SHARE of its width) is not seen -- listed in `hidden` as
    {id, label, by (label), lat, lng, x, y}."""
    def reach(ob, _gap):
        return min(1.0, 0.4 + 0.6 * min(1.0, ob["W"] / 2.5))         # (a pedestrian ~0.55, a vehicle 1)

    def classify(ob, gap, r):
        conf = max(0.25, min(0.99, 1.0 - 0.75 * gap / max(1.0, r)))
        return {"conf": round(conf, 2), "cls": ob["kind"] if conf >= 0.5 else "object"}
    return _fov_detect(ego, ego_len, objects, camera_range(climate, cam), cam["hfov_deg"], reach, OCCLUDED_SHARE,
                       "camera", hidden, classify, yaw_deg=cam.get("yaw_deg", 0.0))


def camera_model(c):
    """A configured camera (truck_cameras.json: hfov_deg, yaw_deg, max_range_m) as the camera model's dict."""
    m = dict(FRONT_CAMERA)
    for k in ("hfov_deg", "yaw_deg", "max_range_m"):
        if (c or {}).get(k) is not None:
            m[k] = float(c[k])
    m["id"], m["label"] = (c or {}).get("id", "front"), (c or {}).get("label", "Front camera")
    return m


def cameras_detect(ego, ego_len, objects, climate, cams, hidden=None):
    """Several cameras (collision testing): what any of them detects (the nearest of each object), `hidden` from
    the first (front) one."""
    best = {}
    for i, cam in enumerate(cams or [FRONT_CAMERA]):
        for d in camera_detect(ego, ego_len, objects, climate, cam, hidden if i == 0 else None):
            d["camera"] = cam.get("label", "camera")
            b = best.get(d["id"])
            if b is None or d["gap"] < b["gap"]:
                best[d["id"]] = d
    return list(best.values())


def radar_detect(ego, ego_len, objects, climate, ego_v=0.0, radar=FRONT_RADAR, hidden=None, track=None, t=None,
                 rnd=None):
    """Detections of the front radar: like camera_detect, + v_rel (the object's speed minus its own along its road,
    m/s: the Doppler), rcs_db, margin_db (SNR over the threshold), pd (detection probability per scan); no type.
    track (a dict kept per AV) + t: scan by scan -- each object detected with probability pd, confirmed after
    `confirm` of the last `window` scans, coasted coast_s when missed, range noise growing as the SNR falls.
    Without track: detected when pd >= 0.5 (deterministic)."""
    import random
    rnd = rnd or random
    cand = _fov_detect(ego, ego_len, objects, 400.0, radar["hfov_deg"], lambda ob, gap: 1.0,
                       radar["occluded_share"], "radar", hidden,
                       lambda ob, gap, r: {"_ob": ob})
    # road spray: a moving AV close ahead throws a spray cloud on a wet road (it and what is behind it)
    spray_at = min((d["gap"] for d in cand if d["_ob"]["moving"] and d["_ob"]["kind"] in ("truck", "trailer")
                    and d["gap"] <= radar["spray_range_m"]), default=None)
    out, now = [], t
    for d in cand:
        ob = d.pop("_ob")
        rcs = radar_rcs_db(ob["kind"], ob["W"], radar)
        r = max(1.0, d["x"])
        margin = radar_margin_db(r, rcs, climate, radar, static=not ob["moving"],
                                 spray=spray_at is not None and d["gap"] >= spray_at - 0.1)
        pd = radar_pd(margin, radar)
        v = ob["speed"]
        if ob["heading"] is not None:
            v *= math.cos(math.radians(ob["heading"] - ego[2]))
        d.update(v_rel=round(v - float(ego_v), 2), rcs_db=round(rcs, 1), margin_db=round(margin, 1), pd=round(pd, 2),
                 rcs="low" if rcs < 5 else "high")
        if track is None:
            if pd >= 0.5:
                out.append(d)
            continue
        st = track.setdefault(d["id"], {"hits": [], "last": None})
        st["touch"] = now
        hit = rnd.random() < pd
        st["hits"] = (st["hits"] + [hit])[-radar["window"]:]
        if hit:
            st["last"] = now
            sigma = min(1.5, radar["range_noise_m"] * (1.0 + 10 ** (-margin / 10.0)))
            st["gap"] = max(0.0, d["gap"] + rnd.gauss(0.0, sigma))
            st["seen"] = now
        confirmed = sum(st["hits"]) >= radar["confirm"] or (st.get("conf") and st["last"] is not None
                                                           and now - st["last"] <= radar["coast_s"])
        st["conf"] = confirmed
        if confirmed and st["last"] is not None:
            coasting = not hit
            out.append(dict(d, gap=st.get("gap", d["gap"]), coasting=coasting))
    if track is not None:                                     # forget objects not seen for a while
        for k in [k for k, st in track.items() if now - (st.get("touch") or now) > 3.0]:
            del track[k]
    return out


class Follower:
    """The follower's perception + speed control (time in seconds, speeds in m/s)."""

    def __init__(self, gap_m, max_kmh, sensors="fusion", grip=1.0):
        self.gap_set = float(gap_m)
        self.v_max = float(max_kmh) / 3.6
        self.v = 0.0
        self.target = None            # {id, label, gap, t, sensors, v_lead}
        self.state = "starting"
        self.a = 0.0
        self.log = []                 # (time, text)
        self._brake = None            # the braking in progress: {t, d0, v0, sensors, a_max}
        self.stats = {"brakes": 0, "full_brakes": 0, "collisions": 0, "first_seen": [], "min_ttc": None,
                      "min_ttc_true": None, "ttc_warnings": 0, "ttc_critical": 0}
        self.sg = None                # its own stop and go: {phase brake/hold/run, decel, hold, repeat, until, next}
        if isinstance(sensors, str):  # a SENSOR_MODES key, or the sensors themselves (switched on / off live)
            self.sensors = set(SENSOR_MODES.get(sensors, SENSOR_MODES["fusion"]))
        else:
            self.sensors = {s for s in sensors if s in SENSORS_ALL}
        self.sensor_mode = sensor_mode_of(self.sensors)
        self.grip = max(0.2, min(1.0, float(grip)))
        self.a_full = A_FULL * self.grip                  # (a wet / snowy road: a longer braking distance)
        self.ttc = None               # time to collision from what it perceives (s) -- None: not closing in
        self.ttc_true = None          # ... from the real gap / closing speed (ground truth)
        self._ttc_level = 0           # 0 ok, 1 warning, 2 critical (the log notes each step once per approach)
        self.v2v = False              # V2V (collision testing, v2v.py): the messages of connected vehicles ahead
        self.v2v_brake = True         #   are a detection (False: they only warn, the AV brakes on its sensors)

    def set_v2v(self, t, on):
        """V2V on / off while it drives (collision testing)."""
        if bool(on) != self.v2v:
            self.v2v = bool(on)
            self._note(t, f"V2V switched {'ON' if on else 'OFF'}")

    def set_sensor(self, t, name, on):
        """Switch one sensor on / off while it drives (all off: it detects nothing -- and runs into what is ahead)."""
        if name not in SENSORS_ALL or (name in self.sensors) == bool(on):
            return
        (self.sensors.add if on else self.sensors.discard)(name)
        self.sensor_mode = sensor_mode_of(self.sensors)
        self._note(t, f"{name} switched {'ON' if on else 'OFF'} -- it now brakes on: {sensors_text(self.sensors)}")

    def set_top_speed(self, t, kmh):
        self.v_max = max(0.5, float(kmh)) / 3.6
        self._note(t, f"top speed set to {kmh:g} km/h")

    def stop_and_go(self, t, decel=3.0, hold_s=6.0, repeat_s=0.0, delay_s=0.0):
        """It stops on its own (whatever its sensors see), stands `hold_s`, drives on -- again every `repeat_s`.
        delay_s: the first stop this long from now (a loop of a collision test: some way into the loop)."""
        self.sg = {"phase": "brake", "decel": float(decel), "hold": float(hold_s), "repeat": float(repeat_s)}
        if delay_s and delay_s > 0:
            self.sg.update(phase="run", next=t + float(delay_s))
        self._note(t, f"stop and go: {'stopping' if not delay_s else f'stops in {delay_s:g} s'} "
                      f"({'at once' if not decel else f'{decel:g} m/s²'}), stands {hold_s:g} s"
                      + (f", again every {repeat_s:g} s" if repeat_s else ""))

    def stop_and_go_off(self, t):
        if self.sg:
            self.sg = None
            self._note(t, "stop and go off: drives on")

    def _stop_go(self, t, dt, a):
        """The acceleration with its own stop and go on top of the sensors' (it never drives faster than they allow)."""
        sg = self.sg
        if sg["phase"] == "run":
            if t < sg["next"]:
                return a
            sg["phase"] = "brake"
        if sg["phase"] == "brake":
            if not sg["decel"]:
                self.v = 0.0
            a = min(a, -sg["decel"]) if sg["decel"] else 0.0
            self.state = "stop and go: braking"
            if self.v + a * dt <= 0.02:
                sg["phase"], sg["until"] = "hold", t + sg["hold"]
            return a
        if sg["phase"] == "hold":
            self.v = 0.0
            self.state = f"stop and go: stands {max(0.0, sg['until'] - t):.0f} s"
            if t >= sg["until"]:
                if sg["repeat"]:
                    sg["phase"], sg["next"] = "run", t + sg["repeat"]
                else:
                    self.sg = None
                self._note(t, "stop and go: drives on")
            return 0.0
        return a

    @staticmethod
    def _in_lane(d):
        return d.get("x", 0) > 0 and abs(d.get("y", 0)) <= CORRIDOR_HALF_M

    def perceive(self, t, lidar_dets, camera_dets, exclude=(), radar_dets=None, predicted=None, v2v_dets=None):
        """The nearest object in the lane ahead, from the LiDAR, the camera and the radar (switched on ones, fused).
        predicted: the tracker's prediction of a target that left every sensor's field of view in a bend (it is
        followed a short while along the road -- not when the sensors simply do not see it).
        v2v_dets: connected vehicles ahead from their V2V messages (gap from their reported position, v_rel from
        their reported speed -- on a brake alert already the speed they are braking to); used with self.v2v."""
        best = {}
        for sensor, dets in (("LiDAR", lidar_dets or []), ("camera", camera_dets or []), ("radar", radar_dets or []),
                             ("V2V", v2v_dets or []), ("predicted", predicted or [])):
            if sensor == "V2V":
                if not (self.v2v and self.v2v_brake):
                    continue
            elif sensor not in self.sensors and sensor != "predicted":   # (the sensor mode: LiDAR only / camera ...)
                continue
            if sensor == "predicted" and any(d.get("id") in best for d in dets):
                continue
            for d in dets:
                if d.get("id") in exclude or not self._in_lane(d):
                    continue
                b = best.get(d["id"])
                by = dict(b["by"]) if b else {}
                by[sensor] = min(float(d["gap"]), by.get(sensor, 1e9))       # each sensor's own distance
                if b is None or d["gap"] < b["gap"]:
                    best[d["id"]] = {"id": d["id"], "label": d.get("label") or d["id"], "gap": float(d["gap"]),
                                     "sensors": {sensor} | (b["sensors"] if b else set()),
                                     "points": d.get("points") or (b or {}).get("points"), "by": by,
                                     "v_rel": (b or {}).get("v_rel")}
                else:
                    b["sensors"].add(sensor)
                    b["by"] = by
                    b["points"] = b.get("points") or d.get("points")
                if sensor in ("radar", "V2V") and d.get("v_rel") is not None:
                    best[d["id"]]["v_rel"] = float(d["v_rel"])           # (the radar: Doppler; V2V: its own speed)
        if not best:
            if self.target and t - self.target["t"] > HOLD_S:
                self._lost = (self.target["id"], t)
                self.target = None
            return self.target
        near = min(best.values(), key=lambda d: d["gap"])
        prev = self.target
        # (its speed from the change of the gap only when the same sensors measure it -- a switch between sensors /
        #  the prediction changes the gap by itself, not because it moves)
        same = prev and prev["id"] == near["id"] and t > prev["t"] and prev.get("sensors") == near["sensors"]
        if near.get("v_rel") is not None:                                  # radar: its speed straight away (Doppler)
            near["v_lead"] = max(0.0, self.v + near["v_rel"])
        elif prev and prev["id"] == near["id"] and not same:
            near["v_lead"] = prev.get("v_lead", self.v)
        elif same:
            closing = (prev["gap"] - near["gap"]) / (t - prev["t"])           # how fast the gap shrinks
            v_lead = max(0.0, self.v - closing)
            near["v_lead"] = 0.6 * prev.get("v_lead", v_lead) + 0.4 * v_lead
        else:
            near["v_lead"] = self.v if prev is None else prev.get("v_lead", self.v)
        if not (prev and prev["id"] == near["id"]):
            lost = getattr(self, "_lost", None)
            again_soon = prev is None and lost and lost[0] == near["id"] and t - lost[1] < 2.0
            if (prev is None or prev["id"] != near["id"]) and not again_soon:   # (no note for a flicker)
                self.stats["first_seen"].append(round(near["gap"], 1))
                self._note(t, f"detects {near['label']} at {near['gap']:.1f} m ({' + '.join(sorted(near['sensors']))})")
        near["t"] = t
        self.target = near
        return near

    def step(self, t, dt, hold=False):
        """The next speed (m/s) and what it is doing."""
        tg = self.target if self.target and t - self.target["t"] <= HOLD_S else None
        if hold:                                                     # after a collision
            self.v, self.a, self.state = 0.0, 0.0, "stopped (collision)"
            return self.v
        if tg is None:
            want = self.v_max
            a = max(-A_COMFORT, min(ACCEL, SPEED_GAIN * (want - self.v)))
            self.state = "no vehicle detected -- driving on"
            self.ttc = None
        else:
            v_lead = tg.get("v_lead", 0.0)
            d = tg["gap"] - (self.v - v_lead) * max(0.0, t - tg["t"])      # (since the detection)
            room = d - STOP_GAP_M
            closing = self.v - v_lead
            self._update_ttc(t, max(0.0, d) / closing if closing > 0.3 else None, tg["label"])
            if closing > 0 and room <= 0.1:
                a_req = self.a_full * 2
            elif closing > 0:
                a_req = closing * closing / (2.0 * room)
            else:
                a_req = 0.0
            if self.ttc is not None and self.ttc < TTC_CRIT_S:              # AEB: critical TTC -> full brake
                a = -self.a_full
                self.state = f"FULL BRAKE (AEB, TTC {self.ttc:.1f} s)"
            elif a_req >= A_COMFORT:
                a = -min(self.a_full, a_req * 1.15)                         # (the road's grip: at most a_full)
                self.state = "FULL BRAKE" if a_req >= 0.8 * self.a_full else "braking"
            else:
                want = max(0.0, min(self.v_max, v_lead + GAP_GAIN * (d - self.gap_set)))
                a = max(-A_COMFORT, min(ACCEL, SPEED_GAIN * (want - self.v)))
                self.state = ("stopped behind " if self.v < 0.2 and want < 0.2 else "following ") + tg["label"] + \
                    (" (predicted: out of sight in the bend)" if tg.get("sensors") == {"predicted"} else "")
            self._track_brake(t, a, d, tg)
        if self.sg:
            a = self._stop_go(t, dt, a)
        self.v = max(0.0, min(self.v_max, self.v + a * dt))
        self.a = a
        return self.v

    def _update_ttc(self, t, ttc, label):
        """TTC from what it perceives: kept as the lowest of the test, noted once per approach when it falls below
        TTC_WARN_S / TTC_CRIT_S."""
        self.ttc = ttc
        if ttc is None or ttc > TTC_WARN_S + 1.0:
            self._ttc_level = 0                                   # (the approach is over: notes again next time)
            return
        if self.stats["min_ttc"] is None or ttc < self.stats["min_ttc"]:
            self.stats["min_ttc"] = ttc
        level = 2 if ttc < TTC_CRIT_S else 1 if ttc < TTC_WARN_S else 0
        if level > self._ttc_level:
            self._ttc_level = level
            key = "ttc_critical" if level == 2 else "ttc_warnings"
            self.stats[key] += 1
            self._note(t, f"TTC {'CRITICAL' if level == 2 else 'warning'}: {ttc:.1f} s to {label} "
                          f"(perceived, {self.v * 3.6:.0f} km/h)")

    def truth(self, gap, closing):
        """The real gap / closing speed (m, m/s) to the nearest object in its lane -> the true TTC (lowest kept)."""
        self.ttc_true = gap / closing if closing > 0.3 and gap >= 0 else None
        if self.ttc_true is not None and self.ttc_true < TTC_WARN_S + 1.0 and \
                (self.stats["min_ttc_true"] is None or self.ttc_true < self.stats["min_ttc_true"]):
            self.stats["min_ttc_true"] = self.ttc_true

    def _track_brake(self, t, a, d, tg):
        """A braking (an event in the log) = decelerating harder than BRAKE_LOG; gap keeping is not one."""
        if a <= -BRAKE_LOG:
            if self._brake is None:
                self._brake = {"t": t, "d0": d, "v0": self.v, "sensors": set(tg["sensors"]), "a_max": -a}
                self.stats["brakes"] += 1
            else:
                self._brake["a_max"] = max(self._brake["a_max"], -a)
                self._brake["sensors"] |= tg["sensors"]
        elif self._brake is not None and (self.v < 0.2 or a >= -0.5):
            b, self._brake = self._brake, None
            full = b["a_max"] >= 0.8 * self.a_full
            if not full and self.v >= 0.2 and (t - b["t"] < 1.0 or (b["v0"] - self.v) * 3.6 < 5.0):
                self.stats["brakes"] -= 1                 # a short correction of the gap, not a braking
                return
            self.stats["full_brakes"] += int(full)
            end = f"stopped {d:.1f} m behind" if self.v < 0.2 else f"slowed to {self.v * 3.6:.0f} km/h, {d:.1f} m behind"
            self._note(t, f"{'FULL brake' if full else 'braked'} from {b['v0'] * 3.6:.0f} km/h at {b['d0']:.1f} m "
                          f"({' + '.join(sorted(b['sensors']))}), up to {b['a_max']:.1f} m/s², {end} {tg['label']}")

    def collision(self, t, leader_label, true_gap_was):
        self.stats["collisions"] += 1
        seen = self.target is not None and t - self.target["t"] <= HOLD_S
        why = ("detected too late" if seen else
               f"it was NOT detected ({' / '.join(sorted(self.sensors))})" if self.sensors else
               "it was NOT detected -- ALL its sensors were switched OFF")
        if seen and self.grip < 0.95:
            why += f" -- wet / slippery road: braking only {self.a_full:.1f} m/s² (grip {self.grip:.0%})"
        self._note(t, f"COLLISION with {leader_label} at {self.v * 3.6:.0f} km/h -- {why}")
        self.v, self.target, self._brake = 0.0, None, None
        self.ttc = self.ttc_true = None

    def _note(self, t, text):
        self.log.append((t, text))
