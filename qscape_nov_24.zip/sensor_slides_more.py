"""More step-by-step pictures for the info window (registered into sensor_slides.DECKS):

  * V2V: how OUR app simulates the radio (no radio waves: a message is a data record; the channel checks distance,
    buildings, chance of loss and delay) -- inserted into the V2V deck, and the other links (cellular V2N, DSRC,
    standard messages + signing, roadside units).
  * The other options of each sensor (YOLO, stereo depth, lane detection, PointPillars, DBSCAN, radar FFT, 4D radar,
    Kalman tracking, early fusion, MPC, driver warning): how each would work, ending with what adding it would take.
  * "In real life ↔ in our app" as the last step of the simulated decks.

Plain words for people who are not engineers; schematic pictures on the 800-wide canvas; animated with
sensor_slides.ph() (the clock restarts at every step).
"""
import math

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QPainterPath, QPen, QPolygonF

import sensor_slides as S
from sensor_graphics import (AMBER, COL, GREEN, MUTED, OTHER, OURS, RED, TXT, _arrow, _c, _chip, _dim, _fog, _mark,
                             _road, _text, _vehicle, draw_icon)

HL = S.HL
G = COL["V2V"]


def _a(col, al):
    return _c(col, max(0.0, min(1.0, al))).name(QColor.HexArgb)


def _antenna(p, x, y, col=G):
    p.save(); p.setPen(QPen(_c(col), 2)); p.drawLine(QPointF(x, y), QPointF(x, y - 16))
    p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawEllipse(QPointF(x, y - 18), 3.5, 3.5); p.restore()


def _picture(p, X0, Y0, W, H, objs=True):
    """A small camera picture: sky, ground, road in perspective, a truck ahead (+ a car, a person). -> positions."""
    hz = Y0 + H * 0.42
    p.save(); p.setClipRect(QRectF(X0, Y0, W, H))
    p.setPen(Qt.NoPen); p.setBrush(_c("#BFD3E6")); p.drawRect(QRectF(X0, Y0, W, hz - Y0))
    p.setBrush(_c("#8D9A7E")); p.drawRect(QRectF(X0, hz, W, Y0 + H - hz))
    cx = X0 + W * 0.5
    road = QPolygonF([QPointF(cx - 18, hz), QPointF(cx + 18, hz), QPointF(X0 + W * 0.95, Y0 + H),
                      QPointF(X0 + W * 0.05, Y0 + H)])
    p.setBrush(_c("#4B5563")); p.drawPolygon(road)
    out = {}
    if objs:
        tb = Y0 + H * 0.74                                    # truck (rear view)
        tw = W * 0.2
        p.setBrush(_c("#F59E0B")); p.drawRect(QRectF(cx - tw / 2 + 4, tb - H * 0.3, tw - 8, H * 0.18))
        p.setBrush(_c("#1E3A8A")); p.drawRect(QRectF(cx - tw / 2, tb - H * 0.13, tw, H * 0.1))
        p.setBrush(_c("#0B0F17")); p.drawRect(QRectF(cx - tw / 2 + 3, tb - H * 0.04, 10, H * 0.04))
        p.drawRect(QRectF(cx + tw / 2 - 13, tb - H * 0.04, 10, H * 0.04))
        out["truck"] = QRectF(cx - tw / 2, tb - H * 0.3, tw, H * 0.3)
        cw = W * 0.09                                         # car on the left, further away
        cb = Y0 + H * 0.56
        p.setBrush(_c("#DC2626")); p.drawRoundedRect(QRectF(cx - W * 0.27, cb - H * 0.08, cw, H * 0.08), 3, 3)
        out["car"] = QRectF(cx - W * 0.27, cb - H * 0.08, cw, H * 0.08)
        px = X0 + W * 0.82                                    # person on the right
        p.setBrush(_c("#111827")); p.drawEllipse(QPointF(px, Y0 + H * 0.55), 3.5, 3.5)
        p.drawRect(QRectF(px - 3, Y0 + H * 0.57, 6, H * 0.12))
        out["person"] = QRectF(px - 6, Y0 + H * 0.5, 12, H * 0.2)
    p.restore()
    p.setPen(QPen(_c("#334155"), 1.5)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(X0, Y0, W, H))
    out["horizon"] = hz
    return out


def _box(p, r, col, label, al=1.0):
    p.save(); p.setPen(QPen(_c(col, al), 2)); p.setBrush(Qt.NoBrush); p.drawRect(r); p.restore()
    if label:
        _text(p, r.x(), r.y() - 3, label, _a(col, al), 10, True, w=160)


def _cloud(p, cx, cy, w, h, col="#94A3B8"):
    p.save(); p.setPen(QPen(_c(col), 1.5)); p.setBrush(_c(col, 0.12))
    path = QPainterPath()
    for dx, dy, r in ((-0.3, 0.1, 0.3), (0, -0.1, 0.36), (0.3, 0.1, 0.3), (0, 0.2, 0.3)):
        path.addEllipse(QPointF(cx + dx * w, cy + dy * h), r * w, r * h * 1.4)
    p.drawPath(path.simplified()); p.restore()


def _tower(p, x, y, col="#7DD3FC"):
    p.save(); p.setPen(QPen(_c(col), 2))
    p.drawLine(QPointF(x, y), QPointF(x - 14, y + 60)); p.drawLine(QPointF(x, y), QPointF(x + 14, y + 60))
    p.drawLine(QPointF(x - 9, y + 38), QPointF(x + 9, y + 38)); p.drawLine(QPointF(x - 5, y + 20), QPointF(x + 5, y + 20))
    p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawEllipse(QPointF(x, y), 4, 4); p.restore()


# ------------------------------------------------------------------ V2V: the radio, as simulated in our app
def _v2v_radio(p, s):
    """s 1..6: real life (radio waves) → our app (a data record + the channel) → distance → buildings → chance of
    loss → delay + inbox."""
    if s == 1:                                            # real life: bits → radio waves → bits
        _road(p, 150, 220)
        _vehicle(p, QRectF(560, 168, 150, 34), OTHER, "Truck_auto_1 (sends)")
        _vehicle(p, QRectF(60, 168, 100, 34), OURS, "our truck")
        _antenna(p, 640, 168); _antenna(p, 110, 168)
        _text(p, 640, 70, "1 0 1 1 0 0 1 0 …", HL, 13, True, Qt.AlignCenter, 200)
        _text(p, 640, 88, "its message as bits", MUTED, 10, False, Qt.AlignCenter, 200)
        _text(p, 110, 70, "1 0 1 1 0 0 1 0 …", G, 13, True, Qt.AlignCenter, 200)
        _text(p, 110, 88, "decoded back", MUTED, 10, False, Qt.AlignCenter, 200)
        path = QPainterPath()                             # the radio wave travelling to the left (animated)
        sh = S.ph(1.0) * 2 * math.pi
        for i in range(0, 421):
            x = 615 - i
            y = 130 + 11 * math.sin(i / 9.0 + sh)
            (path.moveTo if i == 0 else path.lineTo)(QPointF(x, y))
        p.setPen(QPen(_c(G), 2.2)); p.setBrush(Qt.NoBrush); p.drawPath(path)
        _arrow(p, QPointF(220, 130), QPointF(140, 140), G, 1.6, 8)
        _text(p, 400, 30, "IN REAL LIFE: the V2V unit turns the message into RADIO WAVES (5.9 GHz)", TXT, 13, True,
              Qt.AlignCenter, 760)
        _text(p, 400, 104, "every vehicle around can hear them (broadcast)", G, 11, True, Qt.AlignCenter, 400)
        return
    if s == 2:                                            # our app: a record handed to the channel
        _vehicle(p, QRectF(620, 170, 150, 34), OTHER, "Truck_auto_1")
        _vehicle(p, QRectF(20, 170, 100, 34), OURS, "our truck")
        box = QRectF(250, 40, 300, 150)
        p.setPen(QPen(_c("#93C5FD"), 2)); p.setBrush(_c("#93C5FD", 0.08)); p.drawRoundedRect(box, 12, 12)
        _text(p, 400, 58, "THE CHANNEL — Python code in this PC", "#93C5FD", 12, True, Qt.AlignCenter, 290)
        for i, t in enumerate(("① close enough?  (distance)", "② a building in the way?", "③ lost by chance?",
                               "④ delay → waits in a queue")):
            _text(p, 270, 84 + i * 24, t, _a(TXT, S._appear(i, 0.3)), 12, True, w=270)
        f = S.ph(3.2)
        if f < 0.4:
            S._packet(p, QPointF(660, 165), QPointF(552, 115), f / 0.4, G)
        elif f < 0.6:
            S._packet(p, QPointF(552, 115), QPointF(250, 115), (f - 0.4) / 0.2, G)
        else:
            S._packet(p, QPointF(248, 115), QPointF(110, 165), (f - 0.6) / 0.4, G)
        _text(p, 690, 96, "a data record:\nid, time, position,\nspeed, brake …", G, 11, True, Qt.AlignCenter, 170)
        _text(p, 400, 14, "IN OUR APP: NO RADIO WAVES — the message is a data record and the CHANNEL decides",
              HL, 13, True, Qt.AlignCenter, 780)
        _text(p, 400, 222, "delivered (and when) or lost — for every message and every receiver, 10 times a second",
              MUTED, 11, False, Qt.AlignCenter, 760)
        return
    if s == 3:                                            # ① distance
        c = QPointF(330, 140)
        p.setPen(Qt.NoPen)
        for k in range(12):                               # (the fading zone near the edge)
            f = 0.7 + 0.3 * k / 11
            p.setBrush(_c(AMBER, 0.035))
            p.drawEllipse(c, 300 * f, 95 * f)
        p.setPen(QPen(_c(G), 2)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, 300, 95)
        p.setPen(QPen(_c(MUTED), 1.4, Qt.DashLine)); p.drawEllipse(c, 100, 32)
        S._rings(p, c, G, 300, n=3, period=2.2, sy=95 / 300)
        _vehicle(p, QRectF(c.x() - 30, c.y() - 10, 60, 20), OTHER, "")
        _text(p, c.x(), c.y() + 18, "sender", TXT, 10, True, Qt.AlignCenter, 80)
        for x, y, ok, lab in ((470, 140, True, "250 m: delivered"), (585, 165, None, "380 m: fades —\nmore loss"),
                              (700, 70, False, "520 m: too far → lost")):
            _vehicle(p, QRectF(x - 22, y - 8, 44, 16), OURS, "")
            _mark(p, x, y - 20, ok, 9)
            _text(p, x, y + 24, lab, GREEN if ok else AMBER if ok is None else RED, 10, True, Qt.AlignCenter, 150)
        _text(p, 330, 28, "open road ~450 m", G, 11, True, Qt.AlignCenter, 200)
        _text(p, 330, 108, "behind buildings ~150 m", MUTED, 10, False, Qt.AlignCenter, 200)
        _text(p, 400, 246, "① DISTANCE: within the radio's reach? (PC5 ~450 m; the last 30 % fade out)", HL, 12,
              True, Qt.AlignCenter, 780)
        return
    if s == 4:                                            # ② buildings: line of sight
        for (a, b, bld, ok) in (((60, 70), (330, 200), QRectF(160, 105, 80, 60), False),
                                ((470, 70), (750, 200), QRectF(640, 40, 90, 50), True)):
            p.setPen(QPen(_c("#64748B"), 1.5)); p.setBrush(_c("#334155")); p.drawRect(bld)
            _text(p, bld.center().x(), bld.center().y() - 4, "building", MUTED, 10, True, Qt.AlignCenter, 90)
            pa, pb = QPointF(*a), QPointF(*b)
            p.setPen(QPen(_c(GREEN if ok else RED), 2, Qt.DashLine)); p.drawLine(pa, pb)
            _vehicle(p, QRectF(a[0] - 26, a[1] - 9, 52, 18), OTHER, "")
            _vehicle(p, QRectF(b[0] - 26, b[1] - 9, 52, 18), OURS, "")
            f = S.ph(2.0)
            if ok:
                S._packet(p, pa, pb, f, G)
                _mark(p, b[0], b[1] - 24, True, 9)
                _text(p, 610, 150, "clear line → normal reach", GREEN, 12, True, w=180)
            else:
                S._packet(p, pa, pb, min(f, 0.42), G if f < 0.42 else RED)
                _mark(p, 200, 135, False, 11)
                _text(p, 230, 222, "the line crosses a building outline\n→ reach only ~150 m and +60 % loss", RED,
                      11, True, Qt.AlignCenter, 330)
        _text(p, 400, 18, "② BUILDINGS: the straight line between the two trucks is tested against the map's "
                          "building outlines", HL, 12, True, Qt.AlignCenter, 780)
        return
    if s == 5:                                            # ③ chance of loss
        x = 20
        for t, col in (("1 % always", MUTED), ("+ loss set in the setup (5 %)", AMBER), ("+ heavy rain ~3 %", "#7DD3FC"),
                       ("+ busy channel 0–15 %", "#FB923C")):
            x += _chip(p, x, 40, t, col, 12) + 8
        _text(p, x + 4, 56, "≈ 6 % lost", RED, 14, True, w=150)
        n = 20
        shown = int(S.ph(6.0) * (n + 6))
        for i in range(min(n, shown)):
            cx = 40 + i * 37
            lost = i in (6, 15)
            S._packet(p, QPointF(cx, 120), QPointF(cx, 120), 0, RED if lost else G)
            if lost:
                _mark(p, cx, 146, False, 8)
            else:
                _mark(p, cx, 146, True, 8)
        _text(p, 400, 14, "③ CHANCE: for every message and receiver a random number decides — like rolling a dice",
              HL, 12, True, Qt.AlignCenter, 780)
        _text(p, 400, 186, "here 2 of 20 messages are lost — the receiver simply misses them; the next one comes "
                           "0.1 s later", TXT, 12, False, Qt.AlignCenter, 760)
        _text(p, 400, 222, "A lost BRAKE ALERT is logged (Detection details → V2V messages).", MUTED, 11, False,
              Qt.AlignCenter, 760)
        return
    # s == 6: ④ delay + inbox
    X = lambda ms: 60 + 6 * ms                          # noqa: E731  (0 .. 120 ms)
    y = 76
    p.setPen(QPen(_c(MUTED), 1.4)); p.drawLine(QPointF(X(0), y), QPointF(X(115), y))
    for ms in range(0, 120, 20):
        p.drawLine(QPointF(X(ms), y - 4), QPointF(X(ms), y + 4))
        _text(p, X(ms), y + 18, f"{ms} ms", MUTED, 10, False, Qt.AlignCenter, 60)
    for ms in (0, 100):
        p.setPen(QPen(_c("#93C5FD"), 2)); p.drawLine(QPointF(X(ms), y - 22), QPointF(X(ms), y + 4))
        _text(p, X(ms), y - 34, "our truck looks", "#93C5FD", 10, True, Qt.AlignCenter, 100)
    f = S.ph(3.0)
    S._packet(p, QPointF(X(0), y), QPointF(X(24), y), min(1.0, f * 2.2), G)
    _text(p, X(24) + 70, y - 22, "arrives after 24 ms\n(20 ± 8 ms)", G, 10, True, Qt.AlignCenter, 140)
    box = QRectF(60, 132, 680, 90)
    p.setPen(QPen(_c("#93C5FD"), 1.6)); p.setBrush(_c("#93C5FD", 0.07)); p.drawRoundedRect(box, 10, 10)
    _text(p, 76, 150, "OUR TRUCK'S INBOX — only the latest message of each sender", "#93C5FD", 12, True, w=600)
    _mark(p, 90, 178, True, 9)
    _text(p, 106, 184, "Truck_auto_1 · age 0.02 s · fresh → used (distance, speed, brake)", TXT, 12, False, w=600)
    _mark(p, 90, 204, False, 9)
    _text(p, 106, 210, "Truck_auto_7 · age 0.45 s · older than delay + 0.3 s → not used", TXT, 12, False, w=600)
    _text(p, 400, 14, "④ DELAY: it is held in a queue until its arrival time; the truck reads its inbox every 100 ms",
          HL, 12, True, Qt.AlignCenter, 780)


V2V_RADIO_CAPS = [
    "The radio in our app · in real life the V2V unit sends RADIO WAVES (5.9 GHz) that every vehicle around hears",
    "The radio in our app · NO radio waves: the message is a data record — the CHANNEL (Python) decides what happens",
    "The radio in our app · ① distance: within ~450 m on the open road (~150 m behind buildings), fading at the edge",
    "The radio in our app · ② buildings: is the straight line between the trucks blocked by a building outline?",
    "The radio in our app · ③ chance: a random draw per message — base + setup loss + rain + busy channel",
    "The radio in our app · ④ delay: delivered ~20 ms later; the truck reads only the latest, fresh messages"]


# ------------------------------------------------------------------ V2V: the other links / options
def _v2n(p, s):
    _road(p, 180, 236)
    _vehicle(p, QRectF(600, 192, 140, 30), OTHER, "Truck_auto_1")
    _vehicle(p, QRectF(40, 192, 100, 30), OURS, "our truck")
    _tower(p, 560, 70); _tower(p, 220, 70)
    _cloud(p, 390, 50, 150, 44)
    _text(p, 390, 48, "operator network", "#94A3B8", 11, True, Qt.AlignCenter, 150)
    pts = [QPointF(660, 188), QPointF(560, 72), QPointF(390, 50), QPointF(220, 72), QPointF(90, 188)]
    for a, b in zip(pts, pts[1:]):
        _arrow(p, a, b, _a("#7DD3FC", 0.45), 1.6, 8, dashed=True)
    f = S.ph(3.0)
    if s == 1:
        S._packet(p, pts[0], pts[1], min(1.0, f * 1.6), G)
    else:
        k = min(3, int(f * 4)); S._packet(p, pts[k], pts[k + 1], f * 4 - k, G)
    if s == 1:
        _text(p, 400, 14, "CELLULAR (4G / 5G): the message goes UP to the mobile tower …", HL, 13, True,
              Qt.AlignCenter, 780)
    if s >= 2:
        _text(p, 400, 14, "… through the operator's network and DOWN to the other truck: ~90 ms ± 40 ms", HL, 13,
              True, Qt.AlignCenter, 780)
    if s >= 3:
        v = 40 / 3.6
        _text(p, 30, 128, f"PC5 direct ~20 ms → at 40 km/h the truck moves {v * 0.02:.1f} m before it knows", G, 11,
              True, w=360)
        _text(p, 30, 156, f"Cellular ~90 ms → {v * 0.09:.1f} m — a little later, but no building blocks it "
                          "(~3 % loss)", "#7DD3FC", 11, True, w=360)


def _dsrc(p, s):
    if s == 1:
        _road(p, 110, 190)
        _vehicle(p, QRectF(560, 132, 140, 34), OTHER, "sender")
        _vehicle(p, QRectF(80, 132, 100, 34), OURS, "")
        S._rings(p, QPointF(630, 132), G, 420, n=3, period=1.8, a0=100, span=160, sy=0.5)
        _text(p, 400, 30, "DSRC / IEEE 802.11p: Wi-Fi based radio, direct between vehicles (5.9 GHz, ~300 m)", HL,
              13, True, Qt.AlignCenter, 780)
        _text(p, 400, 226, "the older V2V radio — used like PC5, but the channel is shared differently", MUTED, 11,
              False, Qt.AlignCenter, 760)
        return
    _text(p, 400, 18, "LISTEN BEFORE TALK: a radio sends only when it hears the channel quiet" if s == 2 else
          "MANY VEHICLES: two start at the same moment → both messages are destroyed", HL, 13, True,
          Qt.AlignCenter, 780)
    X = lambda t: 110 + t * 6.5                          # noqa: E731
    rows = [("Truck A", [(5, 18)]), ("Truck B", [(20, 33)] if s == 2 else [(40, 53)]),
            ("Truck C", [(36, 49)] if s == 2 else [(40, 53)])]
    cur = S.ph(4.0) * 100
    for i, (n, slots) in enumerate(rows):
        y = 60 + i * 50
        _text(p, 20, y + 16, n, TXT, 12, True, w=90)
        p.setPen(QPen(_c("#334155"), 1)); p.drawLine(QPointF(X(0), y + 20), QPointF(X(100), y + 20))
        for a, b in slots:
            if cur < a:
                continue
            clash = s == 3 and i > 0
            col = RED if clash else G
            p.setPen(Qt.NoPen); p.setBrush(_c(col, 0.8)); p.drawRoundedRect(QRectF(X(a), y + 6, X(min(b, cur)) - X(a),
                                                                                    28), 5, 5)
        if s == 2 and i == 1 and cur > 10:
            _text(p, X(10), y + 46, "B waits: A is sending", AMBER, 10, True, w=200)
    p.setPen(QPen(_c(HL), 1.5)); p.drawLine(QPointF(X(cur), 50), QPointF(X(cur), 210))
    _text(p, 400, 228, "with many vehicles the channel is busy: more waiting and more collisions → messages lost",
          MUTED, 11, False, Qt.AlignCenter, 760)


def _v2v_std(p, s):
    rec = QRectF(30, 50, 220, 150)
    p.setPen(QPen(_c("#93C5FD"), 1.6)); p.setBrush(_c("#93C5FD", 0.08)); p.drawRoundedRect(rec, 10, 10)
    _text(p, 140, 66, "our app today: plain data", "#93C5FD", 11, True, Qt.AlignCenter, 210)
    _text(p, 44, 92, "{ id: 'Truck_auto_1',\n  lat: 8.558421,\n  lon: 76.882541,\n  speed: 5.6, brake: true }",
          TXT, 11, False, w=200)
    if s >= 2:
        _arrow(p, QPointF(256, 125), QPointF(300, 125), MUTED, 2, 9)
        r2 = QRectF(306, 50, 210, 150)
        p.setPen(QPen(_c(AMBER), 1.6)); p.setBrush(_c(AMBER, 0.08)); p.drawRoundedRect(r2, 10, 10)
        _text(p, 411, 66, "encoded: ASN.1 bytes", AMBER, 11, True, Qt.AlignCenter, 200)
        hexs = "30 82 01 2A 80 01 02\n81 04 05 1F 9A 3C 82\n02 00 A9 83 01 01 84\n03 0E 2C 41 ..."
        _text(p, 320, 92, hexs, _a(TXT, S._appear(0, 0.2)), 12, True, w=190)
        _text(p, 411, 176, "SAE J2735 BSM / ETSI CAM", MUTED, 10, False, Qt.AlignCenter, 200)
    if s >= 3:
        _arrow(p, QPointF(522, 125), QPointF(566, 125), MUTED, 2, 9)
        r3 = QRectF(572, 50, 200, 150)
        p.setPen(QPen(_c(GREEN), 1.6)); p.setBrush(_c(GREEN, 0.08)); p.drawRoundedRect(r3, 10, 10)
        _text(p, 672, 66, "signed (IEEE 1609.2)", GREEN, 11, True, Qt.AlignCenter, 190)
        p.setPen(QPen(_c(GREEN), 2.4)); p.setBrush(Qt.NoBrush)    # a padlock
        p.drawArc(QRectF(656, 84, 32, 30), 0, 180 * 16)
        p.setBrush(_c(GREEN, 0.3)); p.drawRoundedRect(QRectF(650, 98, 44, 32), 4, 4)
        _text(p, 672, 150, "receiver checks the\nsignature → trusted", TXT, 11, True, Qt.AlignCenter, 190)
        _mark(p, 740, 112, True if S.ph(2.0) < 0.5 else False, 10)
        _text(p, 400, 226, "a faked or changed message fails the check (✕) and is dropped", MUTED, 11, False,
              Qt.AlignCenter, 760)
    caps = {1: "TODAY: our app passes the message as plain data — the safety logic is tested, not the encoding",
            2: "STANDARD: the message is packed into compact bytes everyone understands",
            3: "SECURITY: it is signed with a certificate; the receiver verifies before trusting it"}
    _text(p, 400, 18, caps.get(s, ""), HL, 12, True, Qt.AlignCenter, 780)


def _rsu(p, s):
    p.setPen(QPen(_c("#64748B"), 1.5)); p.setBrush(_c("#334155")); p.drawRect(QRectF(60, 40, 300, 120))
    _text(p, 210, 96, "building", MUTED, 12, True, Qt.AlignCenter, 120)
    _road(p, 160, 220, x0=0, x1=800, lanes=1)
    p.setPen(Qt.NoPen); p.setBrush(_c("#1E293B")); p.drawRect(QRectF(370, 20, 60, 140))
    _vehicle(p, QRectF(386, 36, 28, 60), OTHER, "", cab=False)
    _vehicle(p, QRectF(120, 176, 100, 28), OURS, "our truck")
    _text(p, 590, 18, "ROADSIDE UNIT (V2I)", HL, 13, True, Qt.AlignCenter, 360)
    if s == 1:
        p.setPen(QPen(_c(RED), 2, Qt.DashLine)); p.drawLine(QPointF(400, 66), QPointF(170, 190))
        _mark(p, 300, 128, False, 11)
        _text(p, 560, 60, "around the corner: the building\nblocks the direct radio", RED, 12, True, w=240)
    else:
        p.setPen(QPen(_c("#93C5FD"), 3)); p.drawLine(QPointF(470, 160), QPointF(470, 100))
        p.setBrush(_c("#93C5FD")); p.drawRect(QRectF(460, 88, 20, 14))
        _text(p, 520, 96, "roadside unit (RSU)", "#93C5FD", 12, True, w=200)
        f = S.ph(2.4)
        if f < 0.5:
            S._packet(p, QPointF(400, 66), QPointF(470, 92), f * 2, G)
        else:
            S._packet(p, QPointF(470, 92), QPointF(170, 186), (f - 0.5) * 2, G)
        _text(p, 560, 140, "it sees both streets and relays the\nmessage (+ signal / hazard info)", G, 12, True, w=240)
    _text(p, 400, 240, "Not needed for collision testing today (the trucks follow each other on one road).", MUTED,
          11, False, Qt.AlignCenter, 760)


# ------------------------------------------------------------------ camera options
def _yolo(p, s):
    X0, Y0, W, H = 20, 30, 430, 220
    pos = _picture(p, X0, Y0, W, H)
    if s == 2:                                            # the network looks at a grid of cells
        p.setPen(QPen(_c("#FFFFFF", 0.35), 1))
        for k in range(1, 8):
            p.drawLine(QPointF(X0 + W * k / 8, Y0), QPointF(X0 + W * k / 8, Y0 + H))
            p.drawLine(QPointF(X0, Y0 + H * k / 8), QPointF(X0 + W, Y0 + H * k / 8))
        i = int(S.ph(4.0) * 64)
        p.setPen(QPen(_c(HL), 2.4)); p.setBrush(_c(HL, 0.2))
        p.drawRect(QRectF(X0 + W * (i % 8) / 8, Y0 + H * (i // 8) / 8, W / 8, H / 8))
    if s >= 3:
        for k, (n, lab, col) in enumerate((("truck", "truck 0.91", GREEN), ("car", "car 0.84", "#60A5FA"),
                                           ("person", "person 0.62", AMBER))):
            _box(p, pos[n].adjusted(-3, -3, 3, 3), col, lab + (f"  #{k + 1}" if s >= 5 else ""), S._appear(k, 0.3))
    if s >= 4:
        tr = pos["truck"]
        p.setPen(QPen(_c("#38BDF8"), 1.2, Qt.DashLine)); p.drawLine(QPointF(X0, pos["horizon"]),
                                                                    QPointF(X0 + W, pos["horizon"]))
        _arrow(p, QPointF(tr.right() + 14, pos["horizon"]), QPointF(tr.right() + 14, tr.bottom()), HL, 1.6, 7,
               both=True)
    rx = 470
    lines = {1: ["INPUT: the camera picture", "(from the 3D view, ~640 × 640 pixels,", "5–10 pictures a second)"],
             2: ["A NEURAL NETWORK looks at the", "whole picture at once — a grid of", "cells, each asks: is something here?"],
             3: ["OUTPUT: a box + a class + a", "confidence for every object it", "recognises (it can miss / be wrong)"],
             4: ["DISTANCE is NOT given: estimated", "from the box's bottom edge on the", "road (camera height + angle) ±5–15 %"],
             5: ["NAMES are not given: a tracker", "keeps #1, #2 … over the pictures;", "matched to the scene for the reports"]}
    for i, t in enumerate(lines.get(s, [])):
        _text(p, rx, 60 + i * 22, t, HL if i == 0 else TXT, 13 if i == 0 else 12, i == 0, w=320)
    _text(p, rx, 160, "Today the camera uses geometry on the scene's\nobjects (Simulated) or picture processing "
                      "(Real-world).", MUTED, 11, w=320)


def _depth(p, s):
    if s == 1:
        _vehicle(p, QRectF(20, 100, 90, 40), OURS, "")
        for y in (106, 134):
            draw_icon(p, "camera", QRectF(100, y - 9, 18, 18), COL["camera"])
        _vehicle(p, QRectF(560, 96, 140, 48), OTHER, "truck ahead")
        for y in (106, 134):
            p.setPen(QPen(_c(COL["camera"], 0.7), 1.4)); p.drawLine(QPointF(118, y), QPointF(560, 120))
        _arrow(p, QPointF(90, 106), QPointF(90, 134), HL, 1.4, 6, both=True)
        _text(p, 40, 160, "baseline\n0.5 m", HL, 11, True, w=80)
        _text(p, 400, 30, "TWO CAMERAS side by side, a known distance apart (like our two eyes)", HL, 13, True,
              Qt.AlignCenter, 760)
        return
    if s >= 2:
        for k, (x, sh, lab) in enumerate(((30, 0, "left picture"), (300, -22, "right picture"))):
            pos = _picture(p, x, 40, 240, 140)
            _text(p, x + 120, 200, lab, MUTED, 11, True, Qt.AlignCenter, 200)
        p.setPen(QPen(_c(HL), 1.6, Qt.DashLine))
        p.drawLine(QPointF(150, 120), QPointF(150, 190)); p.drawLine(QPointF(420, 120), QPointF(420, 190))
        anim = 22 * (0.5 - 0.5 * math.cos(S.T * 2))
        _arrow(p, QPointF(398 + 22 - anim, 186), QPointF(420, 186), HL, 1.6, 6)
        _text(p, 400, 18, "The same point appears SHIFTED between the two pictures — the disparity (pixels)", HL, 12,
              True, Qt.AlignCenter, 780)
    if s >= 3:
        _text(p, 560, 60, "Distance =\nfocal length × baseline\n÷ disparity", TXT, 13, True, w=230)
        _text(p, 560, 130, "1000 px × 0.5 m ÷ 20 px\n= 25 m", GREEN, 13, True, w=230)
        _text(p, 560, 180, "near: big shift (precise)\nfar: tiny shift (rough)", MUTED, 11, w=230)


def _lane(p, s):
    X0, Y0, W, H = 20, 30, 430, 220
    pos = _picture(p, X0, Y0, W, H, objs=False)
    hz, cx = pos["horizon"], X0 + W / 2
    p.setPen(QPen(_c("#F8FAFC"), 3, Qt.DashLine))
    p.drawLine(QPointF(cx, hz + 4), QPointF(cx, Y0 + H))
    p.setPen(QPen(_c("#F8FAFC"), 3))
    p.drawLine(QPointF(cx - 14, hz + 2), QPointF(X0 + W * 0.1, Y0 + H)); p.drawLine(QPointF(cx + 14, hz + 2),
                                                                                QPointF(X0 + W * 0.9, Y0 + H))
    if s >= 2:
        g = S.ph(2.0)
        p.setPen(QPen(_c(HL, 0.5 + 0.5 * g), 4))
        p.drawLine(QPointF(cx - 14, hz + 2), QPointF(X0 + W * 0.1, Y0 + H)); p.drawLine(QPointF(cx, hz + 4),
                                                                                    QPointF(cx, Y0 + H))
    if s >= 3:
        lane = QPolygonF([QPointF(cx - 14, hz + 2), QPointF(cx, hz + 4), QPointF(cx, Y0 + H),
                          QPointF(X0 + W * 0.1, Y0 + H)])
        p.setPen(Qt.NoPen); p.setBrush(_c(GREEN, 0.22)); p.drawPolygon(lane)
        p.setBrush(_c("#DC2626")); p.drawRoundedRect(QRectF(cx - 60, Y0 + H * 0.6, 40, 20), 3, 3)
        _mark(p, cx - 40, Y0 + H * 0.6 - 14, True, 8)
        p.setBrush(_c("#2563EB")); p.drawRoundedRect(QRectF(cx + 30, Y0 + H * 0.62, 40, 20), 3, 3)
        _mark(p, cx + 50, Y0 + H * 0.62 - 14, False, 8)
    rx = 470
    t = {1: ["THE PICTURE with lane markings", "(they are not drawn in our 3D scene yet)"],
         2: ["EDGES of the white lines are found", "and joined into straight lines (Hough)"],
         3: ["THE LANE between the lines decides", "which objects are 'ahead': the red car ✓,", "the blue one is beside ✕"]}
    for i, x in enumerate(t.get(s, [])):
        _text(p, rx, 60 + i * 22, x, HL if i == 0 else TXT, 13 if i == 0 else 12, i == 0, w=320)
    _text(p, rx, 160, "Today the lane is known: the route's path ± 2.2 m.", MUTED, 11, w=320)


# ------------------------------------------------------------------ LiDAR options
def _pts(seed, cx, cy, w, h, n):
    import random
    r = random.Random(seed)
    return [(cx + r.uniform(-w / 2, w / 2), cy + r.uniform(-h / 2, h / 2)) for _ in range(n)]


TRUCK_PTS = _pts(1, 470, 90, 130, 30, 46)
CAR_PTS = _pts(2, 300, 170, 60, 26, 24)
PERSON_PTS = _pts(3, 620, 190, 10, 10, 8)
POLE_PTS = _pts(4, 160, 60, 8, 8, 6)


def _dots(p, pts, col, r=2.4):
    p.setPen(Qt.NoPen); p.setBrush(_c(col))
    for x, y in pts:
        p.drawEllipse(QPointF(x, y), r, r)


def _pointpillars(p, s):
    _vehicle(p, QRectF(20, 120, 90, 32), OURS, "our truck")
    grey = "#CBD5E1"
    allp = TRUCK_PTS + CAR_PTS + PERSON_PTS + POLE_PTS
    if s == 1:
        sw = S.ph(2.0) * 800
        _dots(p, [q for q in allp if q[0] < sw + 40], grey)
        _text(p, 400, 238, "THE POINT CLOUD: thousands of points, nobody says what they are", HL, 13, True,
              Qt.AlignCenter, 760)
        return
    p.setPen(QPen(_c("#334155"), 1))
    for gx in range(120, 800, 20):
        p.drawLine(QPointF(gx, 30), QPointF(gx, 220))
    for gy in range(30, 221, 20):
        p.drawLine(QPointF(120, gy), QPointF(800, gy))
    cells = {(int((x - 120) // 20), int((y - 30) // 20)) for x, y in allp}
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"], 0.3))
    for i, j in cells:
        p.drawRect(QRectF(120 + i * 20, 30 + j * 20, 20, 20))
    _dots(p, allp, grey, 1.8)
    if s == 2:
        _text(p, 400, 238, "A BIRD'S-EYE GRID: the points in each cell form a 'pillar'", HL, 13, True,
              Qt.AlignCenter, 760)
    if s >= 3:
        for k, (r, lab, col) in enumerate(((QRectF(400, 70, 142, 40), "truck 0.93", GREEN),
                                           (QRectF(266, 154, 70, 34), "car 0.88", "#60A5FA"),
                                           (QRectF(610, 180, 22, 22), "person 0.55", AMBER))):
            _box(p, r, col, lab, S._appear(k, 0.3))
        _text(p, 400, 238, "THE NETWORK outputs 3D boxes with a class — the pole is not an object", HL, 13, True,
              Qt.AlignCenter, 760)


def _dbscan(p, s):
    _vehicle(p, QRectF(20, 120, 90, 32), OURS, "our truck")
    groups = [(TRUCK_PTS, GREEN), (CAR_PTS, "#60A5FA"), (PERSON_PTS, AMBER), (POLE_PTS, "#C084FC")]
    if s == 1:
        _dots(p, sum((g for g, _c_ in groups), []), "#CBD5E1")
        _text(p, 400, 238, "THE POINTS (ground already removed) — which belong together?", HL, 13, True,
              Qt.AlignCenter, 760)
        return
    f = min(1.0, S.ph(3.0) * 1.5) if s == 2 else 1.0
    for k, (pts, col) in enumerate(groups):
        n = int(len(pts) * f)
        p.setPen(QPen(_c(col, 0.5), 1))
        for a, b in zip(pts[:n], pts[1:n]):
            if math.hypot(a[0] - b[0], a[1] - b[1]) < 60:
                p.drawLine(QPointF(*a), QPointF(*b))
        _dots(p, pts[:n], col)
        _dots(p, pts[n:], "#CBD5E1")
    if s == 2:
        _text(p, 400, 238, "Points closer than ~0.5 m to a neighbour join its group (DBSCAN)", HL, 13, True,
              Qt.AlignCenter, 760)
    if s >= 3:
        for pts, col in groups:
            xs, ys = [q[0] for q in pts], [q[1] for q in pts]
            _box(p, QRectF(min(xs) - 4, min(ys) - 4, max(xs) - min(xs) + 8, max(ys) - min(ys) + 8), col, "")
        _dim(p, 110, min(q[0] for q in TRUCK_PTS), 128, "nearest point")
        _text(p, 400, 238, "Each group gets a box; its nearest point = the distance. No class (truck? pole?) and close "
                           "objects can merge", HL, 12, True, Qt.AlignCenter, 780)


# ------------------------------------------------------------------ radar options
def _radar_fft(p, s):
    if s <= 2:
        x0, y0, w, h = 60, 40, 420, 170
        p.setPen(QPen(_c(MUTED), 1.4)); p.drawLine(QPointF(x0, y0 + h), QPointF(x0 + w, y0 + h))
        p.drawLine(QPointF(x0, y0), QPointF(x0, y0 + h))
        _text(p, x0 + w - 40, y0 + h + 16, "time", MUTED, 11, w=60)
        _text(p, x0 - 50, y0 + 4, "freq.", MUTED, 11, w=50)
        for k in range(3):                               # the chirps (saw-tooth)
            a = x0 + k * 130
            p.setPen(QPen(_c(COL["radar"]), 2.4)); p.drawLine(QPointF(a, y0 + h - 10), QPointF(a + 110, y0 + 20))
            if s == 2:
                p.setPen(QPen(_c("#F0ABFC"), 2, Qt.DashLine)); p.drawLine(QPointF(a + 22, y0 + h - 10),
                                                                          QPointF(a + 132, y0 + 20))
        m = S.ph(2.0)
        px = x0 + m * 110
        p.setPen(Qt.NoPen); p.setBrush(_c(HL)); p.drawEllipse(QPointF(px, y0 + h - 10 - m * (h - 30)), 5, 5)
        if s == 2:
            _arrow(p, QPointF(x0 + 70, y0 + 82), QPointF(x0 + 70, y0 + 106), HL, 1.6, 6, both=True)
            _text(p, x0 + 78, y0 + 98, "Δf", HL, 13, True, w=40)
        t = {1: ["THE RADAR SENDS A 'CHIRP'", "a wave whose frequency rises", "quickly (77 GHz, tens of µs)"],
             2: ["THE ECHO COMES BACK LATER", "(dashed): the frequency gap Δf", "tells the distance — the bigger,", "the farther"]}
        for i, x in enumerate(t[s]):
            _text(p, 510, 70 + i * 22, x, HL if i == 0 else TXT, 13 if i == 0 else 12, i == 0, w=280)
        return
    gx, gy, cw, chh = 60, 30, 26, 20                       # range-Doppler map
    import random
    rnd = random.Random(9)
    peaks = {(9, 3): 1.0, (5, 6): 0.8, (12, 5): 0.42}
    for i in range(16):
        for j in range(9):
            v = peaks.get((i, j), rnd.uniform(0.02, 0.25))
            if (i, j) not in peaks and any(abs(i - a) + abs(j - b) == 1 for a, b in peaks):
                v = max(v, 0.38)
            p.setPen(Qt.NoPen); p.setBrush(_c(COL["radar"], v)); p.drawRect(QRectF(gx + i * cw, gy + j * chh, cw - 1,
                                                                                      chh - 1))
    _text(p, gx + 8 * cw, gy + 9 * chh + 16, "distance →", MUTED, 11, False, Qt.AlignCenter, 120)
    _text(p, gx - 52, gy + 4.5 * chh, "speed", MUTED, 11, False, w=50)
    if s >= 4:
        for k, ((i, j), v) in enumerate(peaks.items()):
            ok = v > 0.5
            p.setPen(QPen(_c(GREEN if ok else RED), 2.2)); p.setBrush(Qt.NoBrush)
            r = 14 + 4 * math.sin(S.T * 4)
            p.drawEllipse(QPointF(gx + i * cw + cw / 2, gy + j * chh + chh / 2), r, r)
    t = {3: ["AN FFT turns the echoes into a", "RANGE-DOPPLER MAP: each target", "is a bright spot (distance, speed)"],
         4: ["CFAR keeps the spots clearly", "brighter than their surroundings", "→ detections (green); the weak one", "is noise (red)"]}
    for i, x in enumerate(t[s]):
        _text(p, 510, 70 + i * 22, x, HL if i == 0 else TXT, 13 if i == 0 else 12, i == 0, w=280)


def _radar_4d(p, s):
    _road(p, 200, 214, x1=800, lanes=1)
    _text(p, 400, 18, "SIDE VIEW" + (": hundreds of points per scan, each with its HEIGHT" if s == 1 else
                                     ": height tells a bridge above the road from a vehicle on it"), HL, 13, True,
          Qt.AlignCenter, 780)
    p.setPen(Qt.NoPen); p.setBrush(_c(OURS)); p.drawRoundedRect(QRectF(20, 150, 90, 50), 4, 4)
    p.setBrush(_c(OTHER)); p.drawRoundedRect(QRectF(330, 140, 160, 60), 4, 4)
    p.setBrush(_c("#475569")); p.drawRect(QRectF(560, 60, 200, 22)); p.drawRect(QRectF(570, 82, 14, 118))
    p.drawRect(QRectF(736, 82, 14, 118))
    S._rings(p, QPointF(110, 170), COL["radar"], 220, n=4, period=2.0, a0=-25, span=50)
    _dots(p, _pts(5, 335, 170, 6, 56, 18), HL, 2.6)
    _dots(p, _pts(6, 650, 70, 170, 10, 22), HL, 2.6)
    if s >= 2:
        _mark(p, 410, 124, True, 10)
        _text(p, 410, 104, "at road height → obstacle", GREEN, 11, True, Qt.AlignCenter, 220)
        _mark(p, 660, 44, None, 10)
        _text(p, 660, 104, "5 m up → a bridge:\ndrive under it", AMBER, 11, True, Qt.AlignCenter, 220)


# ------------------------------------------------------------------ fusion options
def _kalman(p, s):
    _road(p, 60, 200, lanes=1)
    _vehicle(p, QRectF(20, 114, 90, 32), OURS, "our truck")
    c0 = QPointF(330, 130)
    p.setPen(QPen(_c("#F472B6"), 2)); p.setBrush(_c("#F472B6", 0.18)); p.drawEllipse(c0, 34, 16)
    _text(p, 330, 160, "estimate now", "#F472B6", 11, True, Qt.AlignCenter, 140)
    if s >= 2:
        f = min(1.0, S.ph(2.5) * 1.5) if s == 2 else 1.0
        c1 = QPointF(330 + 160 * f, 130)
        p.setPen(QPen(_c(HL), 1.8, Qt.DashLine)); p.setBrush(_c(HL, 0.08)); p.drawEllipse(c1, 34 + 22 * f, 16 + 12 * f)
        _arrow(p, QPointF(366, 130), QPointF(max(370, c1.x() - 40), 130), HL, 1.6, 8)
        _text(p, c1.x(), 88, "predicted 0.1 s later\n(less sure: bigger)", HL, 11, True, Qt.AlignCenter, 180)
    if s >= 3:
        _dots(p, [(500, 126)], COL["LiDAR"], 5); _text(p, 520, 196, "LiDAR (precise)", COL["LiDAR"], 10, True, w=120)
        _dots(p, [(470, 140)], COL["radar"], 5); _text(p, 410, 196, "radar (rough)", COL["radar"], 10, True, w=100)
        p.setPen(QPen(_c(GREEN), 2.4)); p.setBrush(_c(GREEN, 0.2)); p.drawEllipse(QPointF(494, 129), 22, 11)
        _text(p, 640, 124, "updated: pulled more\ntowards the LiDAR", GREEN, 11, True, w=160)
    t = {1: "Each object is a TRACK: where it is + how fast, with how sure we are (the oval)",
         2: "PREDICT: where it will be next — the oval grows (less sure)",
         3: "MEASURE + UPDATE: new measurements pull it, weighted by each sensor's accuracy"}
    _text(p, 400, 18, t[s], HL, 13, True, Qt.AlignCenter, 780)


def _early_fusion(p, s):
    pos = _picture(p, 20, 30, 430, 220)
    tr = pos["truck"]
    if s >= 1:
        _dots(p, _pts(7, tr.center().x(), tr.center().y(), tr.width() * 0.9, tr.height() * 0.8, 40), COL["LiDAR"], 2.2)
        _dots(p, _pts(8, 235, 230, 400, 30, 30), _a(COL["LiDAR"], 0.6), 1.6)
    if s >= 2:
        _arrow(p, QPointF(456, 140), QPointF(500, 140), MUTED, 2, 9)
        r = QRectF(506, 100, 120, 80)
        p.setPen(QPen(_c("#F472B6"), 2)); p.setBrush(_c("#F472B6", 0.12)); p.drawRoundedRect(r, 10, 10)
        _text(p, 566, 124, "ONE\nNETWORK", "#F472B6", 13, True, Qt.AlignCenter, 110)
        _arrow(p, QPointF(630, 140), QPointF(668, 140), MUTED, 2, 9)
        _text(p, 730, 120, "truck 0.95\n13.2 m", GREEN, 13, True, Qt.AlignCenter, 120)
        _box(p, tr.adjusted(-3, -3, 3, 3), GREEN, "", S._appear(1))
    t = {1: "LiDAR POINTS are projected INTO the camera picture: colour + depth per point",
         2: "ONE NETWORK detects on both together → objects with class and distance"}
    _text(p, 400, 18, t[s], HL, 13, True, Qt.AlignCenter, 780)


# ------------------------------------------------------------------ braking options
def _mpc(p, s):
    x0, y0, w, h = 60, 40, 520, 170
    p.setPen(QPen(_c(MUTED), 1.4)); p.drawLine(QPointF(x0, y0 + h), QPointF(x0 + w, y0 + h))
    p.drawLine(QPointF(x0, y0), QPointF(x0, y0 + h))
    _text(p, x0 + w - 60, y0 + h + 16, "next 5 s", MUTED, 11, w=80)
    _text(p, x0 - 52, y0 + 4, "speed", MUTED, 11, w=50)
    off = (S.ph(2.0) * 40) if s == 3 else 0
    path = QPainterPath()
    for i in range(0, 101):
        t = i / 100
        v = 0.85 - 0.6 * (1 / (1 + math.exp(-(t - 0.45) * 9)))
        pt = QPointF(x0 + off + t * (w - 40), y0 + h - v * h)
        (path.moveTo if i == 0 else path.lineTo)(pt)
    p.setPen(QPen(_c(GREEN), 2.6)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    if s >= 2:
        p.setPen(Qt.NoPen); p.setBrush(_c(RED, 0.12)); p.drawRect(QRectF(x0, y0, w, 22))
        _text(p, x0 + 8, y0 + 15, "speed limit / comfort", RED, 10, True, w=200)
        p.setBrush(_c(AMBER, 0.12)); p.drawRect(QRectF(x0 + w * 0.6, y0 + h - 30, w * 0.4, 30))
        _text(p, x0 + w * 0.62, y0 + h - 12, "keep the gap: stop before the truck", AMBER, 10, True, w=220)
    if s >= 3:
        p.setPen(QPen(_c(HL), 3)); p.drawLine(QPointF(x0 + off, y0 + h - 0.85 * h),
                                              QPointF(x0 + off + 30, y0 + h - 0.84 * h))
        _text(p, x0 + off + 6, y0 + 32, "apply only this", HL, 11, True, w=140)
    t = {1: ["EVERY 0.1 s it plans the speed", "for the next ~5 s (the green curve)"],
         2: ["WITHIN LIMITS: comfort, the gap,", "braking and the road grip"],
         3: ["IT APPLIES ONLY THE FIRST STEP,", "then plans again (the window moves on)"]}
    for i, x in enumerate(t[s]):
        _text(p, 600, 70 + i * 22, x, HL if i == 0 else TXT, 13 if i == 0 else 12, i == 0, w=200)


def _fcw(p, s):
    _road(p, 120, 190, lanes=1)
    v = 40 / 3.6
    react = v * 1.2
    _vehicle(p, QRectF(20, 138, 90, 34), OURS, "our truck")
    _vehicle(p, QRectF(620, 136, 150, 38), OTHER, "stopped truck")
    if s >= 1:
        on = S.ph(0.8) < 0.5
        r = QRectF(40, 30, 220, 60)
        p.setPen(QPen(_c(AMBER), 2)); p.setBrush(_c(AMBER, 0.35 if on else 0.08)); p.drawRoundedRect(r, 10, 10)
        _text(p, 150, 50, "⚠ BRAKE!", "#FFFFFF" if on else AMBER, 18, True, Qt.AlignCenter, 200)
        _text(p, 150, 108, "dashboard warning (TTC < 2.5 s)", AMBER, 11, True, Qt.AlignCenter, 260)
    if s >= 2:
        f = min(1.0, S.ph(2.4) * 1.3) if s == 2 else 1.0     # (the truck rolling on while the driver reacts)
        _arrow(p, QPointF(110, 202), QPointF(110 + react * 9 * max(0.05, f), 202), HL, 2, 8)
        _text(p, 110, 222, f"{react:.0f} m driven before the driver brakes (1.2 s)", HL, 12, True, w=400)
    if s >= 3:
        x = 330
        for k, (lab, d, col) in enumerate((("automatic (AEB)", v * v / (2 * 6.0), GREEN),
                                           ("driver (warning only)", react + v * v / (2 * 6.0), RED))):
            y = 34 + k * 34
            _text(p, x, y + 14, lab, col, 11, True, w=160)
            p.setPen(Qt.NoPen); p.setBrush(_c(col, 0.8)); p.drawRect(QRectF(x + 160, y, d * 9 * S._appear(k, 0.3), 18))
            _text(p, x + 166 + d * 9, y + 14, f"{d:.0f} m", col, 11, True, w=60)
    t = {1: "Time to collision below ~2.5 s: a WARNING for the driver — the truck does not brake itself",
         2: "The driver needs ~1.2 s to react — meanwhile the truck keeps driving",
         3: "So the stopping distance is longer than with automatic braking"}
    _text(p, 400, 246, t[s], HL, 12, True, Qt.AlignCenter, 780)


# ------------------------------------------------------------------ real life ↔ our app (last step of a deck)
VS = {
    "camera": [("A lens and an image sensor: software analyses the real picture",
                "No picture is analysed: geometry on the scene's list of objects"),
               ("Fog, rain and night lower the picture's contrast", "Range = ½ the visibility (a formula)"),
               ("Software can miss objects or see false ones", "Inside the range = always seen, never a false one"),
               ("One camera cannot measure distance: it is estimated", "Exact distance from the positions"),
               ("It never knows names — only 'a truck'", "The name comes from the scene (Truck_auto_1)")],
    "lidar": [("Laser pulses; the light's travel time gives the distance",
               "Rays traced through the 3D scene (three.js) — the same idea"),
              ("Fog and rain scatter the light; false points close by", "Return chance e^(−2 × fog × distance) + false "
                                                                        "points near the sensor"),
              ("Software must group the points into objects", "Each point is counted on the object it hit (known)"),
              ("Dark or wet surfaces send back fewer points", "Every surface reflects the same")],
    "radar": [("77 GHz radio waves; echoes from metal surfaces", "No waves: a formula per object (radar equation)"),
              ("Echo strength jumps; ghosts from guard rails", "A detection chance per scan, no ghosts"),
              ("The Doppler shift of the echo gives the speed", "The speed is taken from the scene (what Doppler would "
                                                              "measure)"),
              ("Rain weakens it a little, fog hardly", "Rain loss in dB (ITU-R P.838), fog ~0")],
    "fusion": [("Must work out which detections are the same object (by position)",
                "The same object is known by its scene id (perfect)"),
               ("Weighs each sensor by its accuracy (filters)", "The nearest distance wins"),
               ("Predicts where objects go (cut-ins)", "Only the nearest object in the lane")],
    "brake": [("Brake pressure needs ~0.3–0.5 s to build up", "The braking acts at once"),
              ("A loaded truck brakes weaker", "The same braking for any load; grip set by the climate"),
              ("It may also steer around", "Braking only")],
    "v2v": [("Radio waves at 5.9 GHz carry the bits (PC5 sidelink)",
             "No waves: each message is a data record passed inside the PC"),
            ("The signal weakens with distance; reflections and fading", "A reach limit (~450 m) + more loss near the "
                                                                        "edge"),
            ("Buildings block or reflect the signal", "The straight line is tested against the map's building outlines"),
            ("Messages collide when many vehicles send", "Loss % drawn at random + a busy-channel formula"),
            ("Messages are encoded (ASN.1) and signed", "Plain data; the signature check is only counted")],
    "v2v_v2n": [("Up to the mobile tower, through the operator's network, down again",
                 "Delay ~90 ms ± 40 ms drawn per message"),
                ("Coverage holes, network load", "3 % loss; a little more delay with many vehicles"),
                ("Buildings do not matter much (the network relays it)", "No building test for cellular")],
}
VS_CAP = "In real life ↔ in our app: what the real sensor does and what our simulation does instead"


def _with_vs(entry, rows):
    h, caps, fn = entry
    n = len(caps)
    return (max(h, 262), caps + [VS_CAP], lambda p, s, f=fn, n=n, r=rows: S._vs(p, r) if s == n + 1 else f(p, s))


def _deck(fn, caps, h=262, integrate=True):
    """A deck of an option not in our app: its steps + 'what adding it would take'."""
    n = len(caps)
    return (h, caps + (["Not in our app yet: what adding it would take (complexity, time, what it needs)"]
                       if integrate else []),
            lambda p, s, f=fn, n=n: S._integrate(p) if s == n + 1 else f(p, s))


def register(decks):
    """Add the decks of this module to sensor_slides.DECKS (and extend the simulated ones)."""
    h, caps, fn = decks["v2v"]                       # V2V: story 1-4, the radio in our app 5-10, messages 11-14, vs 15
    story, msgs = caps[:4], caps[4:]
    decks["v2v"] = (262, story + V2V_RADIO_CAPS + msgs,
                    lambda p, s, f=fn: f(p, s) if s <= 4 else _v2v_radio(p, s - 4) if s <= 10 else f(p, s - 6))
    for k in ("camera", "lidar", "radar", "fusion", "brake", "v2v"):
        decks[k] = _with_vs(decks[k], VS[k])
    decks["v2v_v2n"] = _with_vs((262, ["Cellular (4G / 5G): the message goes up to the mobile tower",
                                       "… through the operator's network and down to the other truck (~90 ms)",
                                       "Compared with the direct radio: a little later, but buildings do not block it"],
                                 _v2n), VS["v2v_v2n"])
    decks["v2v_dsrc"] = _deck(_dsrc, ["DSRC / 802.11p: the older Wi-Fi based V2V radio, direct between vehicles",
                                      "Listen before talk: a radio waits until the channel is quiet",
                                      "Many vehicles: two start together → both messages are lost"])
    decks["v2v_std"] = _deck(_v2v_std, ["Today: plain data in our app", "Standard: encoded into compact bytes (ASN.1)",
                                        "Security: signed with a certificate, verified by the receiver"])
    decks["v2v_rsu"] = _deck(_rsu, ["Around a corner a building blocks the direct radio",
                                    "A roadside unit sees both streets and relays the message"])
    decks["yolo"] = _deck(_yolo, ["The camera picture is the input", "A neural network looks at the whole picture",
                                  "It outputs boxes with a class and a confidence",
                                  "The distance is estimated from the box (not measured)",
                                  "A tracker keeps an id per object over the pictures"])
    decks["depth"] = _deck(_depth, ["Two cameras side by side, a known distance apart",
                                    "The same point is shifted between the two pictures (disparity)",
                                    "Distance = focal length × baseline ÷ disparity"])
    decks["lane"] = _deck(_lane, ["The picture with the lane markings", "The lines are found (edges → straight lines)",
                                  "The lane between them decides which objects are ahead"])
    decks["pointpillars"] = _deck(_pointpillars, ["The point cloud: points without labels",
                                                  "A bird's-eye grid: the points of each cell form a pillar",
                                                  "A neural network outputs 3D boxes with a class"])
    decks["dbscan"] = _deck(_dbscan, ["The points (ground removed)", "Neighbours closer than ~0.5 m form one group",
                                      "Each group gets a box; the nearest point gives the distance"])
    decks["radar_fft"] = _deck(_radar_fft, ["The radar sends a 'chirp': a quickly rising frequency",
                                            "The echo comes back later: the frequency gap gives the distance",
                                            "An FFT makes a range-Doppler map: targets are bright spots",
                                            "CFAR keeps the clearly bright spots → detections"])
    decks["radar_4d"] = _deck(_radar_4d, ["Hundreds of points per scan, each with its height",
                                          "Height tells a bridge above the road from a vehicle on it"])
    decks["kalman"] = _deck(_kalman, ["Each object is a track: position + speed + how sure",
                                      "Predict: where it will be next (less sure)",
                                      "Measure + update: weighted by each sensor's accuracy"])
    decks["early_fusion"] = _deck(_early_fusion, ["LiDAR points projected into the camera picture",
                                                  "One network detects on colour + depth together"])
    decks["mpc"] = _deck(_mpc, ["Every 0.1 s it plans the speed for the next ~5 s",
                                "Within limits: comfort, gap, braking, grip",
                                "It applies only the first step, then plans again"])
    decks["fcw"] = _deck(_fcw, ["A warning for the driver (no automatic braking)",
                                "The driver needs ~1.2 s to react", "So the stopping distance is longer"])
