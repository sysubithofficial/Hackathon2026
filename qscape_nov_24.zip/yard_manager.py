"""Sites: delete a site -- the menu beside the site drop-down (top left). New sites are made from the map
(yard_from_map.py).

A site is a folder sites/<site id>/ with its map parameter file in cc_config/. A deleted site goes to
backup/deleted_sites/<site>_<date_time>/ (nothing is lost).
"""
import os
import re
import shutil
import time

from PyQt5.QtWidgets import QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel

import site_config as cfg

DELETED_DIR = os.path.join(cfg.ROOT_DIR, "backup", "deleted_sites")


def valid_site_id(text):
    return bool(re.match(r"^[A-Za-z0-9][A-Za-z0-9_\-]*$", str(text or "")))


def delete_site(site_id):
    """Moves the site's folder to backup/deleted_sites/ (returns where)."""
    os.makedirs(DELETED_DIR, exist_ok=True)
    dest = os.path.join(DELETED_DIR, f"{site_id}_{time.strftime('%Y%m%d_%H%M%S')}")
    shutil.move(cfg.site_dir(site_id), dest)
    return dest


class DeleteYardDialog(QDialog):
    def __init__(self, sites, parent=None):
        super().__init__(parent)
        self.setObjectName("themedDialog")
        self.setWindowTitle("Delete site")
        self.setMinimumWidth(420)
        lay = QFormLayout(self)
        self.combo = QComboBox()
        for s in sites:
            self.combo.addItem(s, s)
        lay.addRow("Site:", self.combo)
        note = QLabel("The site's folder (map file, AVs, obstacles, routes, reports, logs) is moved to "
                      "backup/deleted_sites/. The site that is loaded now cannot be deleted.")
        note.setWordWrap(True)
        note.setStyleSheet("color:#9CA3AF; font-weight:400;")
        lay.addRow(note)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Delete")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addRow(bb)

    def site_id(self):
        return self.combo.currentData()
