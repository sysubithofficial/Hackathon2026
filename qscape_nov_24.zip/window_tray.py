"""Minimized windows go to the bottom bar (next to the version): a small button per window, a click brings it back.

make_minimizable(window, tray, title): a separate window (Follow test, comparison, Vehicles ...) gets the minimize
button in its title bar; minimizing it hides it and puts its button in the tray. A panel inside the map area
(cameras, LiDAR ...) calls tray.add(panel, title) from its own "–" button.
"""
from PyQt5.QtCore import QEvent, QObject, Qt, QTimer
from PyQt5.QtWidgets import QHBoxLayout, QToolButton, QWidget

CHIP_STYLE = """
QToolButton#trayChip { color: #E5E7EB; background: #1E293B; border: 1px solid #334155; border-radius: 9px;
                       padding: 1px 10px; font-size: 11px; }
QToolButton#trayChip:hover { background: #2563EB; border-color: #3B82F6; }
"""


class WindowTray(QWidget):
    """The buttons of the minimized windows (in the bottom bar)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(CHIP_STYLE)
        self.lay = QHBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(6)
        self._chips = {}                                   # id(window) -> (window, button)
        self.setVisible(False)

    def add(self, w, title, icon=None):
        """Hides `w` and puts its button in the tray."""
        key = id(w)
        if key not in self._chips:
            b = QToolButton()
            b.setObjectName("trayChip")
            b.setText(f"▣  {title}")
            if icon is not None:
                b.setIcon(icon)
                b.setText(f" {title}")
                b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setToolTip(f"{title} (minimized) -- click to show it again")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, win=w: self.restore(win))
            self._chips[key] = (w, b)
            self.lay.addWidget(b)
            try:
                w.destroyed.connect(lambda *_a, k=key: self._drop(k))
            except (RuntimeError, TypeError):
                pass
            _watch(w, self, title)
        w.hide()
        self.setVisible(True)

    def restore(self, w):
        self.remove(w)
        if w.isWindow():
            w.showNormal()
            w.activateWindow()
        else:
            w.show()
        w.raise_()

    def remove(self, w):
        self._drop(id(w))

    def _drop(self, key):
        _w, b = self._chips.pop(key, (None, None))
        if b is not None:
            b.deleteLater()
        self.setVisible(bool(self._chips))

    def has(self, w):
        return id(w) in self._chips


class _Watcher(QObject):
    """A window minimized -> into the tray; shown / closed by other means -> its button goes."""

    def __init__(self, w, tray, title):
        super().__init__(w)
        self.tray, self.title = tray, title

    def eventFilter(self, obj, ev):
        t = ev.type()
        if t == QEvent.WindowStateChange and obj.isWindow() and (obj.windowState() & Qt.WindowMinimized):
            QTimer.singleShot(0, lambda o=obj: self._minimized(o))
        elif t in (QEvent.Show, QEvent.Close) and self.tray.has(obj):
            self.tray.remove(obj)
        return False

    def _minimized(self, obj):
        try:
            if not (obj.windowState() & Qt.WindowMinimized):
                return
            obj.hide()
            obj.setWindowState(obj.windowState() & ~Qt.WindowMinimized)
            self.tray.add(obj, self.title)
        except RuntimeError:                               # (deleted meanwhile)
            pass


def _watch(w, tray, title):
    if getattr(w, "_tray_watcher", None) is None:
        w._tray_watcher = _Watcher(w, tray, title)
        w.installEventFilter(w._tray_watcher)
    else:
        w._tray_watcher.title = title


def make_minimizable(w, tray, title):
    """A separate window: a minimize (and maximize) button in its title bar; minimized it goes to the tray."""
    if tray is None or w is None:
        return w
    if w.isWindow():
        flags = w.windowFlags() | Qt.WindowSystemMenuHint | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint \
            | Qt.WindowCloseButtonHint
        if flags != w.windowFlags():
            shown = w.isVisible()
            w.setWindowFlags(flags)
            if shown:
                w.show()
    _watch(w, tray, title)
    return w
