"""Real-world sensor processing for collision testing (sensor mode "real") -- LiDAR, radar, tracking.

The simulated mode (follow_test) gives each sensor the scene's objects and decides per object "seen / not seen".
Here each sensor works like on a real truck, from its MEASUREMENTS only, without knowing what is in the scene:

  LiDAR  the 3D page's ray-traced point cloud (no labels) -> ground removal (height) -> clustering (points closer
         than CELL_M join) -> clusters with >= LIDAR_MIN_PTS points -> distance = the nearest point to the body.
  radar  a beam scan: every 1 deg beam is traced to the first surface (the objects' outlines), its echo power from
         the radar equation (cross-section share, distance^4, weather loss) with random fluctuation, CFAR threshold
         -> detection points (range, angle, Doppler = radial speed) + random false alarms (rain clutter) ->
         clustering by position and Doppler -> objects; standing echoes need a stronger signal (clutter).
  camera real_camera.detect on the camera picture (free space / ground contact).
  tracker per sensor: measurements -> tracks (association by position, alpha-beta filter, confirmed after M of N
         updates, coasted a short while): a track id (C3, L5, R2), never a name.

Names for the reports: a confirmed track is MATCHED to the scene object at its position (as a test bench scores
a perception system against the truth); it carries that name, its own track id and matched=True. Unmatched
tracks (phantoms: rain clutter, a building's corner, two vehicles merged) keep their track id -- and the truck
brakes on them like on anything else in its lane.
"""
import math
import random

import follow_test as ft

LIDAR_MIN_PTS = 5
CELL_M = 0.6
TRUCK_HALF_W = 1.25
LANE_MARGIN_M = 0.3
RADAR_BEAM_DEG = 1.0
RADAR_CFAR_DB = 13.0          # detection threshold over noise (CFAR, ~1e-6 false alarms per cell)
RADAR_STATIC_DB = 4.0         # + for an echo that does not move (ground clutter map)


# ------------------------------------------------------------------ frames
def to_latlng(me, fwd, left):
    """A point fwd / left (m) of the AV's centre -> (lat, lng). me = (lat, lon, heading deg)."""
    h = math.radians(me[2])
    e = fwd * math.sin(h) - left * math.cos(h)
    n = fwd * math.cos(h) + left * math.sin(h)
    lat = me[0] + n / 111320.0
    return lat, me[1] + e / (111320.0 * math.cos(math.radians(me[0])))


def scene_local(me, objs):
    """The scene's objects in the AV's frame: [(id, label, fwd, left, L, W, rel heading rad, kind, moving,
    speed, heading deg)] (evaluation / radar outlines)."""
    out = []
    for o in objs:
        f, l = ft._local(me, o[2], o[3])
        hd = o[8] if len(o) > 8 and o[8] is not None else me[2]
        out.append((str(o[0]), o[1], f, l, float(o[4] or 4.5), float(o[5] or 2.5), math.radians(hd - me[2]),
                    (o[6] if len(o) > 6 else None) or "vehicle", bool(o[7]) if len(o) > 7 else True,
                    float(o[9] or 0.0) if len(o) > 9 else 0.0, hd))
    return out


def match_truth(f, l, local, margin=None):
    """The scene object whose outline (+ margin: 2 m + 15 % of the distance -- a camera's distance is less exact
    far away) holds the point (f, l)."""
    if margin is None:
        margin = 2.0 + 0.15 * max(0.0, f)
    best = None
    for (oid, lab, of, ol, L, W, rh, *_r) in local:
        c, s = math.cos(rh), math.sin(rh)
        dx, dy = f - of, l - ol
        u, v = dx * c - dy * s, dx * s + dy * c            # (in the object's frame)
        out = max(0.0, abs(u) - L / 2) + max(0.0, abs(v) - W / 2)
        if out <= margin and (best is None or out < best[0]):
            best = (out, oid, lab)
    return (best[1], best[2]) if best else (None, None)


# ------------------------------------------------------------------ LiDAR
def lidar_points(me, js_pos, cloud):
    """The page's points (east, north from its AV position js_pos, height) -> [(fwd, left, h)] in OUR AV
    frame (me: the route pose)."""
    if not cloud or not js_pos:
        return []
    f0, l0 = ft._local(me, js_pos[0], js_pos[1])          # (the page's AV position vs the route pose)
    h = math.radians(me[2])
    sh, chh = math.sin(h), math.cos(h)
    pts = []
    for i in range(0, len(cloud) - 2, 3):
        e, n, z = cloud[i], cloud[i + 1], cloud[i + 2]
        pts.append((f0 + e * sh + n * chh, l0 - e * chh + n * sh, z))
    return pts


def weather_filter(pts, voxel=0.2, near_m=12.0):
    """Fog / rain / snow returns close to the sensor are sparse and scattered; surfaces are dense: within near_m a
    point is kept only when its small 3D cell (voxel) holds others too (2, or 3 within 4 m) -- a density
    (outlier) filter as real LiDAR drivers have."""
    cnt = {}
    keys = []
    for p in pts:
        k = (int(math.floor(p[0] / voxel)), int(math.floor(p[1] / voxel)), int(math.floor(p[2] / voxel)))
        keys.append(k)
        cnt[k] = cnt.get(k, 0) + 1
    out = []
    for p, k in zip(pts, keys):
        r = math.hypot(p[0], p[1])
        if r >= near_m or cnt[k] >= (6 if r < 3.5 else 4 if r < 6.0 else 2):
            out.append(p)
    return out


def lidar_clusters(pts, L, W=2.5):
    """Clustering on a grid (cells of CELL_M; touching cells = one object) -> [{gap, f, l, points, size}]."""
    cells = {}
    hl, hw = L / 2.0, W / 2.0
    pts = weather_filter(pts)
    for p in pts:
        if p[0] < hl - 0.3 and abs(p[1]) < hw + 0.3:      # (its own body)
            continue
        cells.setdefault((int(math.floor(p[0] / CELL_M)), int(math.floor(p[1] / CELL_M))), []).append(p)
    seen, out = set(), []
    for c0 in cells:
        if c0 in seen:
            continue
        stack, members = [c0], []
        seen.add(c0)
        while stack:
            c = stack.pop()
            members.extend(cells[c])
            for di in (-1, 0, 1):
                for dj in (-1, 0, 1):
                    nb = (c[0] + di, c[1] + dj)
                    if nb in cells and nb not in seen:
                        seen.add(nb)
                        stack.append(nb)
        if len(members) < LIDAR_MIN_PTS:
            continue
        # the point that matters: the nearest one INSIDE the driving corridor ahead (our width + margin); none
        # there -> the nearest one at all (an object beside the lane: the lane test leaves it out)
        corr = hw + LANE_MARGIN_M
        ahead = [p for p in members if p[0] > hl - 0.3]
        if not ahead:
            continue
        inside = [p for p in ahead if abs(p[1]) <= corr]
        if inside:
            near = min(inside, key=lambda p: p[0])
            gap = max(0.0, near[0] - hl)
        else:
            near = min(ahead, key=lambda p: math.hypot(max(0.0, abs(p[1]) - hw), max(0.0, p[0] - hl)))
            gap = math.hypot(max(0.0, abs(near[1]) - hw), max(0.0, near[0] - hl))
        fs = [p[0] for p in members]; ls = [p[1] for p in members]
        out.append({"gap": round(gap, 2), "f": near[0], "l": near[1], "f_c": sum(fs) / len(fs),
                    "l_c": sum(ls) / len(ls), "points": len(members), "half_w": 0.0, "in_corridor": bool(inside),
                    "size": (round(max(fs) - min(fs), 1), round(max(ls) - min(ls), 1))})
    return out


# ------------------------------------------------------------------ radar
def _ray_box(ox, oy, dx, dy, cf, cl, L, W, rh):
    """Distance along the ray (ox, oy) + t (dx, dy) to the oriented box (centre cf / cl, size L x W, rotation rh);
    None: missed."""
    c, s = math.cos(rh), math.sin(rh)
    px, py = ox - cf, oy - cl
    u0, v0 = px * c - py * s, px * s + py * c
    du, dv = dx * c - dy * s, dx * s + dy * c
    t0, t1 = -1e9, 1e9
    for o, d, h in ((u0, du, L / 2), (v0, dv, W / 2)):
        if abs(d) < 1e-9:
            if abs(o) > h:
                return None
            continue
        a, b = (-h - o) / d, (h - o) / d
        if a > b:
            a, b = b, a
        t0, t1 = max(t0, a), min(t1, b)
        if t0 > t1:
            return None
    return t0 if t0 > 0.2 else None


def radar_scan(me, L, local, climate, ego_v, rnd, radar=ft.FRONT_RADAR):
    """One radar scan -> detection points [{r, az (deg, + left), f, l, doppler (m/s, + opening), power_db, static,
    clutter}] (no names)."""
    ox = L / 2.0
    half = radar["hfov_deg"] / 2.0
    pts = []
    rain = (climate or {}).get("precip") or {}
    # each object's share of the beams (its echo is spread over them)
    for k in range(int(round(2 * half / RADAR_BEAM_DEG)) + 1):
        az = -half + k * RADAR_BEAM_DEG
        dx, dy = math.cos(math.radians(az)), math.sin(math.radians(az))
        hits = []
        for ob in local:
            oid, lab, of, ol, Lo, Wo, rh, kind, moving, speed, hd = ob
            if of < -Lo or of > 160:
                continue
            t = _ray_box(ox, 0.0, dx, dy, of, ol, Lo, Wo, rh)
            if t is not None:
                hits.append((t, ob))
        hits.sort(key=lambda h: h[0])
        for n_, (t, ob) in enumerate(hits[:2]):
            oid, lab, of, ol, Lo, Wo, rh, kind, moving, speed, hd = ob
            if n_ == 1 and str(hits[0][1][7]).lower() not in ("truck", "trailer", "tractor", "outer_truck"):
                break                                         # (only under a high AV does a 2nd echo come back)
            ang_w = max(RADAR_BEAM_DEG, math.degrees(2 * math.atan2(Wo / 2, max(1.0, of))))
            rcs = ft.radar_rcs_db(kind, Wo, radar) - 10 * math.log10(ang_w / RADAR_BEAM_DEG) + 3.0
            margin = ft.radar_margin_db(t, rcs, climate, radar, static=False) - (10.0 if n_ == 1 else 0.0)
            snr_mean = 10 ** ((RADAR_CFAR_DB + margin) / 10.0)
            snr = snr_mean * rnd.expovariate(1.0)             # (Swerling: the echo fluctuates scan to scan)
            # Doppler: the radial relative speed (its velocity minus ours along the beam)
            vh = math.radians(hd - me[2])                     # (its heading against ours: clockwise +)
            vx, vy = speed * math.cos(vh), -speed * math.sin(vh)
            dop = (vx - ego_v) * dx + vy * dy
            static = abs(vx * dx + vy * dy) < 0.5 and abs(speed) < 0.5
            thr = RADAR_CFAR_DB + (RADAR_STATIC_DB if static else 0.0)
            if 10 * math.log10(max(snr, 1e-9)) < thr:
                continue
            sig = min(1.5, radar["range_noise_m"] * (1.0 + 10 ** (-max(-20, margin) / 10.0)))
            r = max(0.3, t + rnd.gauss(0.0, sig))
            a = az + rnd.gauss(0.0, 0.6)
            pts.append({"r": r, "az": a, "f": ox + r * math.cos(math.radians(a)), "l": r * math.sin(math.radians(a)),
                        "doppler": dop + rnd.gauss(0.0, 0.1), "power_db": round(10 * math.log10(snr), 1),
                        "static": static, "clutter": False})
    # false alarms: rain clutter close by (and a few random ones), standing
    lam = 0.15 + (1.5 * float(rain.get("rate") or 0) if rain.get("type") in ("rain", "snow") else 0.0)
    for _ in range(_poisson(rnd, lam)):
        r = rnd.uniform(3.0, 35.0)
        a = rnd.uniform(-half, half)
        pts.append({"r": r, "az": a, "f": ox + r * math.cos(math.radians(a)), "l": r * math.sin(math.radians(a)),
                    "doppler": -ego_v * math.cos(math.radians(a)) + rnd.gauss(0, 0.3), "power_db": RADAR_CFAR_DB + 1,
                    "static": True, "clutter": True})
    return pts


def _poisson(rnd, lam):
    k, p, L_ = 0, 1.0, math.exp(-lam)
    while True:
        p *= rnd.random()
        if p <= L_:
            return k
        k += 1


def radar_clusters(pts, L):
    """Radar points -> objects: points within 2 m of each other with about the same Doppler."""
    pts = sorted(pts, key=lambda p: p["r"])
    groups = []
    for p in pts:
        for g in groups:
            if any(math.hypot(p["f"] - q["f"], p["l"] - q["l"]) < 2.0 and abs(p["doppler"] - q["doppler"]) < 1.5
                   for q in g):
                g.append(p)
                break
        else:
            groups.append([p])
    out = []
    for g in groups:
        if len(g) == 1 and g[0]["static"] and g[0]["power_db"] < RADAR_CFAR_DB + 4.0:
            continue                       # (a single weak standing echo: rain / ground clutter, suppressed)
        near = min(g, key=lambda q: q["f"])
        mid = min(g, key=lambda q: abs(q["l"]))              # (its point nearest our centre line: the lane test)
        out.append({"gap": round(max(0.0, near["f"] - L / 2.0), 2), "f": near["f"], "l": mid["l"],
                    "f_c": sum(q["f"] for q in g) / len(g), "l_c": sum(q["l"] for q in g) / len(g),
                    "doppler": sum(q["doppler"] for q in g) / len(g), "points": len(g),
                    "half_w": 0.3,
                    "power_db": max(q["power_db"] for q in g), "static": all(q["static"] for q in g),
                    "clutter": all(q["clutter"] for q in g)})
    return out


# ------------------------------------------------------------------ tracking
class Tracker:
    """Measurements (gap from the front, y left; optional v_rel) -> tracks: nearest-neighbour association, an
    alpha-beta filter, confirmed after `confirm` of the last `window` updates, kept `coast_s` when missed."""

    def __init__(self, prefix, confirm=2, window=3, coast_s=0.6, gate_m=2.5, static_age=0):
        self.prefix, self.confirm, self.window, self.coast_s, self.gate = prefix, confirm, window, coast_s, gate_m
        self.static_age = static_age       # (radar: a standing echo needs this many updates -- clutter suppression)
        self.tracks, self.n, self.t = [], 0, None

    def update(self, t, meas):
        dt = 0.0 if self.t is None else max(0.0, t - self.t)
        self.t = t
        for tr in self.tracks:                                 # predict
            tr["gap"] += tr["v"] * dt
        free = list(range(len(meas)))
        for tr in sorted(self.tracks, key=lambda x: x["gap"]):
            best, bc = None, None
            for i in free:
                m = meas[i]
                gate = self.gate + 0.05 * m["gap"] + 0.3 * abs(tr["v"]) * dt
                c = abs(m["gap"] - tr["gap"]) + 1.5 * abs(m["y"] - tr["y"])
                if c <= gate and (bc is None or c < bc):
                    best, bc = i, c
            tr["hits"] = (tr["hits"] + [best is not None])[-self.window:]
            if best is None:
                continue
            free.remove(best)
            m = meas[best]
            pg = tr["gap"]
            tr["gap"] = 0.6 * m["gap"] + 0.4 * pg
            tr["y"] = 0.6 * m["y"] + 0.4 * tr["y"]
            if m.get("v_rel") is not None:
                tr["v"] = 0.6 * float(m["v_rel"]) + 0.4 * tr["v"]
            elif dt > 0.02 and tr.get("seen") is not None:
                tr["v"] = 0.7 * tr["v"] + 0.3 * max(-40.0, min(40.0, (m["gap"] - tr["last_gap"]) / max(0.05, t - tr["seen"])))
            tr["last_gap"], tr["seen"], tr["m"] = m["gap"], t, m
            tr["age"] += 1
        for i in free:                                         # new tracks
            m = meas[i]
            self.n += 1
            self.tracks.append({"id": f"{self.prefix}{self.n}", "gap": m["gap"], "y": m["y"],
                                "v": float(m.get("v_rel") or 0.0), "hits": [True], "seen": t, "last_gap": m["gap"],
                                "m": m, "age": 1})
        self.tracks = [tr for tr in self.tracks if t - tr["seen"] <= (self.coast_s if self._conf(tr) else 0.35)]

    def _conf(self, tr):
        return sum(tr["hits"]) >= self.confirm or tr.get("was_conf")

    def confirmed(self, t):
        out = []
        for tr in self.tracks:
            if self._conf(tr) and not (self.static_age and tr["m"].get("static") and tr["age"] < self.static_age):
                tr["was_conf"] = True
                g = tr["gap"] + tr["v"] * max(0.0, t - self.t) if self.t is not None else tr["gap"]
                out.append(dict(tr["m"], track=tr["id"], gap=round(max(0.0, g), 2), y=round(tr["y"], 2),
                                v_rel=round(tr["v"], 2), coasting=tr["seen"] < (self.t or 0) - 1e-6))
        return out


def lane_offset(d):
    """A measured object's offset for the lane test (follow_test: |y| <= CORRIDOR_HALF_M): its NEAR EDGE against our
    width + a margin -- a post 2 m beside the centre line is outside, a AV partly in our lane is inside."""
    y = float(d.get("y", 0.0))
    edge = max(0.0, abs(y) - float(d.get("half_w") or 0.0))
    eff = edge + (ft.CORRIDOR_HALF_M - TRUCK_HALF_W - LANE_MARGIN_M)
    return math.copysign(eff, y) if y else eff


def to_dets(tracks, me, L, local, sensor, extra=None):
    """Confirmed tracks -> detections for the lane filter / fusion: lat / lng of the measured point, the matched
    scene name (reports) or the track id."""
    out = []
    for tr in tracks:
        f = L / 2.0 + tr["gap"]
        lat, lng = to_latlng(me, f, tr["y"])
        oid, lab = match_truth(f, tr["y"], local)
        d = {"id": oid or tr["track"], "label": lab or f"unknown object {tr['track']}", "track": tr["track"],
             "matched": oid is not None, "gap": tr["gap"], "lat": lat, "lng": lng, "sensor": sensor,
             "v_rel": tr["v_rel"] if sensor in ("radar",) else None, "trk_v": tr["v_rel"],
             "coasting": tr["coasting"], "real": True}
        for k in ("points", "cls", "conf", "width_m", "power_db", "static", "half_w"):
            if k in tr:
                d[k] = tr[k]
        if "half_w" not in d and tr.get("width_m"):
            d["half_w"] = float(tr["width_m"]) / 2.0
        if extra:
            d.update(extra)
        out.append(d)
    return out
