"""Step-by-step pictures (slides) of how each sensor / step works -- the info window's ◀ Prev / Next ▶.

DECKS[name] = (height, [caption per step], draw(p, step)): the picture builds up step by step (step 1 .. n), the
current step's part highlighted. Sensor topics have a SIMULATED deck ("camera") and a REAL-WORLD deck
("camera_real") -- the info window shows the one of the chosen set-up. Drawn on an 800-wide logical canvas
(sensor_graphics helpers); schematic, not to scale.
"""
import math
import time

from PyQt5.QtCore import QPointF, QRectF, Qt, QTimer
from PyQt5.QtGui import QColor, QPainter, QPainterPath, QPen, QPolygonF
from PyQt5.QtWidgets import QSizePolicy, QWidget

from sensor_graphics import (AMBER, COL, GREEN, MUTED, OTHER, OURS, RED, TXT, _arrow, _c, _chip, _d_climate, _dim,
                             _fog, _mark, _road, _text, _vehicle, draw_icon)

HL = "#FDE68A"            # the current step's highlight
T = 0.0                   # the animation clock (s since the step was shown) -- set by Slide before drawing
DATA = None               # the deck's data (an option's method dict: the "what adding it takes" step)


def ph(period=2.0, off=0.0):
    """The animation's phase 0..1 (repeating every period s)."""
    return ((T + off) % period) / period


def _hl_box(p, r, col=HL):
    p.save(); p.setPen(QPen(_c(col), 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 8, 8); p.restore()


def _pulse(p, r, col=HL):
    """A dashed frame that pulses (the current step's part)."""
    a = 0.3 + 0.7 * abs(math.sin(T * 3.0))
    p.save(); p.setPen(QPen(_c(col, a), 2.4, Qt.DashLine)); p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(r.adjusted(-4, -4, 4, 4), 10, 10); p.restore()


def _packet(p, a, b, f, col, text=""):
    """A message (envelope) on its way from a to b (f: 0..1)."""
    f = max(0.0, min(1.0, f))
    x, y = a.x() + (b.x() - a.x()) * f, a.y() + (b.y() - a.y()) * f
    r = QRectF(x - 13, y - 9, 26, 18)
    p.save(); p.setPen(QPen(_c(col), 1.6)); p.setBrush(_c("#0B1220")); p.drawRoundedRect(r, 3, 3)
    p.drawLine(QPointF(r.left() + 2, r.top() + 2), QPointF(x, y + 2))
    p.drawLine(QPointF(x, y + 2), QPointF(r.right() - 2, r.top() + 2))
    p.restore()
    if text:
        _text(p, x, y - 14, text, col, 10, True, Qt.AlignCenter, 140)


def _rings(p, c, col, maxr, n=3, period=1.8, a0=None, span=None, sy=1.0, width=2.0):
    """Waves spreading out from c (animated): full rings, or arcs from a0 over span degrees."""
    p.save(); p.setBrush(Qt.NoBrush)
    for k in range(n):
        f = ph(period, period * k / n)
        r = 6 + f * maxr
        p.setPen(QPen(_c(col, 0.95 * (1 - f)), width))
        rect = QRectF(c.x() - r, c.y() - r * sy, 2 * r, 2 * r * sy)
        if span is None:
            p.drawEllipse(rect)
        else:
            p.drawArc(rect, int(a0 * 16), int(span * 16))
    p.restore()


def _appear(i, every=0.45):
    """0..1: the i-th part fades in one after the other."""
    return max(0.0, min(1.0, T * 2.0 - i * every * 2.0))


def _vs(p, rows, title="IN REAL LIFE  ↔  IN OUR APP"):
    """A comparison step: how the real thing works (left) and what our simulation does instead (right)."""
    _text(p, 400, 18, title, HL, 14, True, Qt.AlignCenter, 760)
    _text(p, 200, 42, "IN REAL LIFE", "#7DD3FC", 12, True, Qt.AlignCenter, 360)
    _text(p, 600, 42, "IN OUR APP (the simulation)", GREEN, 12, True, Qt.AlignCenter, 360)
    h = min(40.0, (250 - 60) / max(1, len(rows)) - 6)
    y = 60
    for i, (a, b) in enumerate(rows):
        al = _appear(i)
        for x, t, col in ((14, a, "#7DD3FC"), (414, b, GREEN)):
            r = QRectF(x, y, 372, h)
            p.setPen(QPen(_c(col, 0.6 * al), 1.2)); p.setBrush(_c(col, 0.08 * al)); p.drawRoundedRect(r, 7, 7)
            _text(p, x + 10, y + 13 + (0 if len(t) > 58 else 6), t, _c(TXT, al).name(QColor.HexArgb), 11, False,
                  w=356)
        _arrow(p, QPointF(392, y + h / 2), QPointF(408, y + h / 2), _c(MUTED, al).name(QColor.HexArgb), 1.6, 6,
               both=True)
        y += h + 6


CPLX_COL = {"Low": GREEN, "Medium": AMBER, "High": "#FB923C", "Very high": RED}


def _integrate(p, _s=None):
    """The last step of a not-integrated option: what adding it to our app would take (from its method data)."""
    m = DATA or {}
    _text(p, 400, 18, "NOT IN OUR APP YET — WHAT ADDING IT WOULD TAKE", AMBER, 14, True, Qt.AlignCenter, 760)
    levels = ["Low", "Medium", "High", "Very high"]
    idx = levels.index(m["cplx"]) if m.get("cplx") in levels else 1
    _text(p, 20, 50, "Complexity", MUTED, 11, True, w=120)
    for i, lv in enumerate(levels):
        on = i <= idx
        col = CPLX_COL[lv] if on else "#334155"
        r = QRectF(110 + i * 92, 38, 86, 22)
        grow = _appear(i, 0.25)
        p.setPen(Qt.NoPen); p.setBrush(_c("#1F2937")); p.drawRoundedRect(r, 5, 5)
        if on:
            p.setBrush(_c(col, 0.85)); p.drawRoundedRect(QRectF(r.x(), r.y(), r.width() * grow, r.height()), 5, 5)
        _text(p, r.center().x(), r.y() + 15, lv, "#0B1220" if on and grow > 0.6 else MUTED, 11, True,
              Qt.AlignCenter, 86)
    _text(p, 490, 54, (m.get("effort") or "").split(";")[0], TXT, 11, True, w=300)
    y = 80
    for i, n in enumerate((m.get("needs") or [])[:4]):
        al = _appear(i + 2)
        p.setPen(Qt.NoPen); p.setBrush(_c("#60A5FA", al)); p.drawEllipse(QPointF(26, y + 7), 4, 4)
        _text(p, 38, y + 12, n, _c(TXT, al).name(QColor.HexArgb), 11, False, w=740)
        y += 36 if len(n) > 120 else 26
    _text(p, 400, max(y + 10, 214), "Choosing it in the drop-down changes nothing in the tests: they keep using the "
                                    "option marked 'in use'.", MUTED, 11, False, Qt.AlignCenter, 760)


# ------------------------------------------------------------------ the test flow
def _flow(p, s):
    steps = [("1", "The scene moves", "trucks, vehicles ahead,\nobstacles, stop & go", "#E9D5FF"),
             ("2", "Sensors look", "camera · LiDAR · radar\n+ V2V messages", COL["camera"]),
             ("3", "Pick the target", "nearest vehicle in its\nlane (fusion)", "#F472B6"),
             ("4", "Truck decides", "follow · brake ·\nFULL BRAKE (AEB)", RED),
             ("5", "Check the truth", "real bodies touch?\n→ COLLISION + reason", "#FCA5A5")]
    x = 10
    from PyQt5.QtGui import QFont
    for i, (n, t, sub, col) in enumerate(steps):
        on = i < s
        a = 1.0 if on else 0.18
        r = QRectF(x, 40, 140, 130)
        p.setPen(QPen(_c(col, a), 3 if i == s - 1 else 2)); p.setBrush(_c(col, 0.10 * a)); p.drawRoundedRect(r, 12, 12)
        p.setPen(Qt.NoPen); p.setBrush(_c(col, a)); p.drawEllipse(QPointF(x + 24, 66), 14, 14)
        f = QFont(); f.setPixelSize(14); f.setBold(True); p.setFont(f); p.setPen(_c("#0B1220"))
        p.drawText(QRectF(x + 10, 52, 28, 28), Qt.AlignCenter, n)
        _text(p, x + 44, 61, t, _c(col, a).name(QColor.HexArgb) if not on else col, 13, True, w=96)
        if on:
            _text(p, x + 10, 104, sub, TXT, 11, w=124)
        if i == s - 1:
            _pulse(p, r, col)
        if i < len(steps) - 1 and i < s - 1:
            _arrow(p, QPointF(x + 142, 105), QPointF(x + 158, 105), MUTED, 2, 8)
        x += 158
    _text(p, 400, 196, "Repeated every 100 ms for every truck — the truck only knows what its sensors tell it.",
          MUTED, 12, False, Qt.AlignCenter, 780)


# ------------------------------------------------------------------ camera: simulated
def _camera_sim(p, s):
    _road(p, 60, 200)
    ox, oy = 110, 165
    if s >= 2:
        _fog(p, QRectF(450, 62, 350, 136), 60)
    p.save(); p.setClipRect(QRectF(0, 60, 800, 140))
    path = QPainterPath(QPointF(ox, oy))
    path.lineTo(ox + 700, oy - 700); path.lineTo(ox + 700, oy + 700); path.closeSubpath()
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["camera"], 0.13)); p.drawPath(path)
    p.setPen(QPen(_c(COL["camera"], 0.6), 1.2)); p.drawLine(QPointF(ox, oy), QPointF(ox + 160, oy - 160))
    p.drawLine(QPointF(ox, oy), QPointF(ox + 160, oy + 160))
    a = math.radians(-45 + 90 * (0.5 - 0.5 * math.cos(T * 1.6)))        # (the view sweeping: what it looks at)
    p.setPen(QPen(_c(COL["camera"], 0.9), 2)); p.drawLine(QPointF(ox, oy), QPointF(ox + 700 * math.cos(a),
                                                                                 oy + 700 * math.sin(a)))
    if s >= 2:
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(_c(COL["camera"], 0.45), 1.5, Qt.DashLine))
        p.drawArc(QRectF(ox - 620, oy - 620, 1240, 1240), -45 * 16, 90 * 16)
        p.setPen(QPen(_c(HL if s == 2 else COL["camera"]), 2.5))
        p.drawArc(QRectF(ox - 330, oy - 330, 660, 660), -45 * 16, 90 * 16)
    p.restore()
    _vehicle(p, QRectF(20, 148, 90, 34), OURS, "our truck")
    draw_icon(p, "camera", QRectF(100, 130, 18, 18), COL["camera"])
    if s == 1:
        _text(p, 300, 100, "90° wide view from the front of the truck", HL, 13, True, Qt.AlignCenter, 360)
    if s >= 2:
        _text(p, 448, 46, "fog range 60 m", HL if s == 2 else COL["camera"], 12, True, Qt.AlignCenter, 160)
        _text(p, 700, 46, "clear day 80 m", MUTED, 11, False, Qt.AlignCenter, 160)
    if s >= 3:
        _vehicle(p, QRectF(250, 150, 140, 30), OTHER, "Truck_auto_1")
        _mark(p, 320, 138, True)
        _text(p, 320, 112, "SEEN" + (" · 'truck' 65 %" if s >= 4 else ""), GREEN, 12, True, Qt.AlignCenter, 200)
        _vehicle(p, QRectF(400, 150, 50, 30), OTHER, "", dashed=True, cab=False)
        _mark(p, 425, 138, False)
        _text(p, 380, 205, "hidden behind it", RED, 11, w=150)
        _vehicle(p, QRectF(560, 80, 70, 28), OTHER, "", cab=False)
        _mark(p, 595, 70, False)
        _text(p, 640, 92, "beyond the fog\nrange → NOT seen", RED, 11, True, w=160)
    if s >= 4:
        _dim(p, 110, 250, 226, "gap 28 m")
        _text(p, 470, 228, "40 − 3.5 − 8.25 = 28 m · conf = 1 − 0.75 × 28 ÷ 60 = 65 %", HL, 12, True, w=330)


# ------------------------------------------------------------------ camera: real-world (the picture itself)
def _camera_real(p, s):
    X0, Y0, W, H = 30, 18, 470, 236
    hz = Y0 + 96                                            # the horizon row
    p.save(); p.setClipRect(QRectF(X0, Y0, W, H))
    p.setPen(Qt.NoPen); p.setBrush(_c("#BFD3E6")); p.drawRect(QRectF(X0, Y0, W, hz - Y0))          # sky
    p.setBrush(_c("#9C8A86")); p.drawRect(QRectF(X0, hz, W, Y0 + H - hz))                          # ground
    road = QPolygonF([QPointF(X0 + 205, hz), QPointF(X0 + 265, hz), QPointF(X0 + W, Y0 + H), QPointF(X0 + 20, Y0 + H)])
    p.setBrush(_c("#4B5563")); p.drawPolygon(road)
    p.setBrush(_c("#7B8794")); p.drawRect(QRectF(X0, hz - 70, 120, 70))                          # building
    p.setPen(QPen(_c("#E5E7EB"), 2, Qt.DashLine)); p.drawLine(QPointF(X0 + 235, hz + 4), QPointF(X0 + 235, Y0 + H))
    # the truck ahead (rear view): box, cab, wheels
    tx0, tx1, tb = X0 + 190, X0 + 280, Y0 + 165
    p.setPen(Qt.NoPen); p.setBrush(_c("#F59E0B")); p.drawRect(QRectF(tx0 + 12, tb - 78, tx1 - tx0 - 24, 44))
    p.setBrush(_c("#1E3A8A")); p.drawRect(QRectF(tx0, tb - 36, tx1 - tx0, 26))
    p.setBrush(_c("#0B0F17")); p.drawRect(QRectF(tx0 + 4, tb - 12, 18, 12)); p.drawRect(QRectF(tx1 - 22, tb - 12, 18, 12))
    p.restore()
    p.setPen(QPen(_c("#334155"), 1.5)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(X0, Y0, W, H))
    _text(p, X0 + 6, Y0 + 14, "camera picture (this climate)", "#0F172A", 11, True, w=260)
    rx = 520                                                # (the explanation on the right)
    if s >= 2:                                              # road colours from the bottom strip
        band = QRectF(X0, Y0 + H - 46, W, 46)
        p.setPen(QPen(_c(HL if s == 2 else "#64748B"), 2, Qt.DashLine)); p.setBrush(_c(HL, 0.08 if s == 2 else 0))
        p.drawRect(band)
        _text(p, rx, 40, "Road colours", HL if s == 2 else MUTED, 13, True, w=260)
        for i, c in enumerate(("#4B5563", "#9C8A86", "#E5E7EB")):
            p.setPen(QPen(_c("#0B1220"), 1)); p.setBrush(_c(c)); p.drawRect(QRectF(rx + i * 34, 52, 28, 18))
        _text(p, rx, 86, "learned from the strip in front of the truck;\nfar road fades to the haze colour",
              MUTED, 11, w=270)
    if s >= 3:                                              # column scans (step 3: climbing up, animated)
        f = min(1.0, ph(3.0) * 1.4) if s == 3 else 1.0
        for u in range(X0 + 40, X0 + W - 20, 34):
            on_truck = tx0 <= u <= tx1
            stop = tb if on_truck else (hz + 20 if u < X0 + 120 else hz + 3)
            col = GREEN if on_truck else "#94A3B8"
            top = max(stop + 4, Y0 + H - 6 - (Y0 + H - stop) * f)
            _arrow(p, QPointF(u, Y0 + H - 6), QPointF(u, top), _c(col, 0.95 if s == 3 else 0.5).name(), 1.6, 6)
            if top <= stop + 4.5:
                p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawEllipse(QPointF(u, stop), 3.5, 3.5)
        _text(p, rx, 130, "Each column, bottom → up:", HL if s == 3 else MUTED, 13, True, w=270)
        _text(p, rx, 148, "road … road … STOP where the road ends\nfor good (≥ 0.8 m high) = ground contact",
              MUTED, 11, w=270)
    if s >= 4:                                              # distance from the ground contact row
        p.setPen(QPen(_c("#38BDF8"), 1.2, Qt.DashLine)); p.drawLine(QPointF(X0, hz), QPointF(X0 + W, hz))
        _text(p, X0 + W - 70, hz - 4, "horizon", "#38BDF8", 10, True, w=70)
        p.setPen(QPen(_c(HL), 2)); p.drawLine(QPointF(tx0 - 30, tb), QPointF(tx1 + 30, tb))
        _arrow(p, QPointF(tx1 + 40, hz), QPointF(tx1 + 40, tb), HL, 1.6, 7, both=True)
        _text(p, tx1 + 46, (hz + tb) / 2 + 4, "9.2°", HL, 12, True, w=60)
        _text(p, rx, 186, "Distance (flat road):", HL if s == 4 else MUTED, 13, True, w=270)
        _text(p, rx, 204, "d = h_cam ÷ tan(angle below horizon)\n= 2.4 m ÷ tan(9.2°) = 14.8 m", TXT, 12, True, w=280)
    if s >= 5:
        _hl_box(p, QRectF(tx0 - 6, tb - 84, tx1 - tx0 + 12, 90), GREEN)
        _text(p, (tx0 + tx1) / 2, tb - 96, "truck 93 % · 14.8 m · C3", GREEN, 12, True, Qt.AlignCenter, 220)
        _text(p, rx, 244, "grouped columns (2.5 m wide → 'truck'),\ntracked as C3 over the pictures", GREEN, 11,
              True, w=280)


# ------------------------------------------------------------------ LiDAR: simulated
def _lidar_sim(p, s):
    rows = [(80, "Clear weather", False)] + ([(205, "Whiteout fog", True)] if s >= 3 else [])
    for row, (cy, title, fog) in enumerate(rows):
        _road(p, cy - 45, cy + 45, lanes=1)
        _text(p, 8, cy - 58, title, AMBER if not fog else RED, 12, True, w=200)
        if fog:
            _fog(p, QRectF(118, cy - 44, 430, 88), 55, seed=8, a=0.2)
        _vehicle(p, QRectF(20, cy - 16, 90, 32), OURS, "our truck")
        lx, ly = 104, cy - 12
        p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"])); p.drawEllipse(QPointF(lx, ly), 5, 5)
        _vehicle(p, QRectF(330, cy - 18, 200, 36), OTHER, "Truck_auto_1" + ("" if fog or s >= 2 else " (?)"))
        for k in range(11):
            ty = cy - 30 + k * 6
            if fog:
                end = lx + 40 + (k * 37) % 120
                p.setPen(QPen(_c(COL["LiDAR"], 0.5), 1.2, Qt.DotLine))
                p.drawLine(QPointF(lx, ly), QPointF(end, ly + (ty - ly) * (end - lx) / (330 - lx)))
                p.setPen(Qt.NoPen); p.setBrush(_c("#CBD5E1", 0.7))
                p.drawEllipse(QPointF(lx + 18 + (k * 13) % 40, ly + (k % 5 - 2) * 4), 2.2, 2.2)
            else:                                       # (the scan sweeping over the rays, animated)
                near = 1.0 - min(1.0, abs(k / 10.0 - ph(1.6)) * 4.0)
                p.setPen(QPen(_c(COL["LiDAR"], 0.35 + 0.6 * near), 1.2 + 1.4 * near))
                p.drawLine(QPointF(lx, ly), QPointF(330, ty))
                if cy - 18 <= ty <= cy + 18:
                    p.setPen(Qt.NoPen); p.setBrush(_c(HL)); p.drawEllipse(QPointF(330, ty), 3.2 + 2.0 * near,
                                                                          3.2 + 2.0 * near)
        if not fog:
            if s == 1:
                _text(p, 560, cy - 8, "rays hit its back → points", HL, 12, True, w=230)
            if s >= 2:
                _dim(p, 110, 330, cy + 30, "gap 12.3 m (nearest point)")
                _mark(p, 560, cy, True)
                _text(p, 578, cy - 8, "≥ 4 points → DETECTED", GREEN, 12, True, w=220)
        else:
            _mark(p, 560, cy, False)
            _text(p, 578, cy - 14, "0 points (need 4)\n→ NOT detected", RED, 12, True, w=220)
            _text(p, 130, cy + 30, "fog: rays die out · grey dots = false points near the sensor", MUTED, 11, w=420)


# ------------------------------------------------------------------ LiDAR: real-world (unlabelled points)
def _lidar_real(p, s):
    _road(p, 60, 200, x1=800)
    cy = 130
    _vehicle(p, QRectF(20, cy - 16, 90, 32), OURS, "our truck")
    p.setPen(Qt.NoPen); p.setBrush(_c(COL["LiDAR"])); p.drawEllipse(QPointF(100, cy - 10), 5, 5)
    import random
    rnd = random.Random(4)
    truck = [(330 + rnd.uniform(0, 3), cy - 17 + k * 2.4) for k in range(15)]
    wall = [(150 + k * 14 + rnd.uniform(-2, 2), 66 + rnd.uniform(0, 3)) for k in range(40)]
    pole = [(250 + rnd.uniform(-1, 1), 190 + rnd.uniform(-2, 2)) for _k in range(5)]
    fogp = [(110 + rnd.uniform(0, 50), cy + rnd.uniform(-30, 30)) for _k in range(26)]
    grey = _c("#CBD5E1")
    if s >= 2:                                              # the map's structure: buildings, poles (known)
        p.setPen(QPen(_c("#64748B"), 1, Qt.DashLine)); p.setBrush(_c("#334155", 0.5))
        p.drawRect(QRectF(140, 46, 600, 20)); p.drawEllipse(QPointF(250, 190), 6, 6)
        _text(p, 600, 40, "map: building", MUTED, 10, w=120)
    def dots(pts, col, r=2.4):
        p.setPen(Qt.NoPen); p.setBrush(col)
        for x, y in pts:
            p.drawEllipse(QPointF(x, y), r, r)
    dots(truck, _c(COL["LiDAR"]) if s >= 3 else grey, 2.6)
    dots(wall + pole, _c("#64748B", 0.35) if s >= 2 else grey)
    dots(fogp, _c("#64748B", 0.3) if s >= 2 else grey, 1.8)
    if s >= 2:
        for x, y in fogp[::5]:
            p.setPen(QPen(_c(RED, 0.8), 1.2)); p.drawLine(QPointF(x - 3, y - 3), QPointF(x + 3, y + 3))
    if s == 1:
        _text(p, 400, 240, "Raw points only — the LiDAR does not know what it hit", HL, 13, True, Qt.AlignCenter, 600)
    if s == 2:
        _text(p, 400, 240, "Ground + map structure (buildings, poles) removed · sparse fog points filtered (✕)", HL,
              12, True, Qt.AlignCenter, 760)
    if s >= 3:                                              # grid cells of the cluster
        p.setPen(QPen(_c(COL["LiDAR"], 0.8), 1)); p.setBrush(_c(COL["LiDAR"], 0.12))
        for k in range(6):
            p.drawRect(QRectF(326, cy - 20 + k * 7, 8, 7))
        if s == 3:
            _text(p, 400, 240, "Clustering: touching 0.6 m cells → one object (15 points ≥ 5)", HL, 12, True,
                  Qt.AlignCenter, 700)
    if s >= 4:                                              # the driving corridor + nearest point
        p.setPen(QPen(_c(GREEN, 0.7), 1.4, Qt.DashLine)); p.setBrush(_c(GREEN, 0.06))
        p.drawRect(QRectF(110, cy - 26, 680, 52))
        _text(p, 600, cy - 30, "our corridor: width + 0.3 m", GREEN, 10, True, w=200)
        _dim(p, 110, 330, cy + 40, "12.3 m (nearest point inside)")
        if s == 4:
            _text(p, 400, 240, "Distance = nearest point INSIDE our corridor (the pole beside it does not count)", HL,
                  12, True, Qt.AlignCenter, 760)
    if s >= 5:
        _text(p, 345, cy - 30, "L4 → 'Truck_auto_1'", GREEN, 12, True, w=200)
        _text(p, 400, 240, "Tracked as L4 (2 of 3 scans); its name only from matching to the real object (report)",
              GREEN, 12, True, Qt.AlignCenter, 760)


# ------------------------------------------------------------------ radar: simulated
def _radar_sim(p, s):
    _road(p, 50, 200, x1=590)
    cy = 125
    _fog(p, QRectF(150, 52, 260, 146), 50, seed=11, a=0.14)
    _vehicle(p, QRectF(20, cy - 17, 90, 34), OURS, "our truck")
    p.save(); p.setClipRect(QRectF(0, 52, 588, 146))         # (the waves going out, animated)
    _rings(p, QPointF(112, cy), COL["radar"], 300, n=5, period=2.2, a0=-28, span=56, width=2.4)
    p.restore()
    _vehicle(p, QRectF(420, cy - 17, 150, 34), OTHER, "Truck_auto_1")
    _text(p, 250, 34, "radio waves pass through the fog", HL if s == 1 else COL["radar"], 12, True, Qt.AlignCenter, 300)
    if s >= 2:                                                # (the echo coming back)
        p.save(); p.setClipRect(QRectF(112, 52, 310, 146))
        _rings(p, QPointF(420, cy), "#F0ABFC", 300, n=3, period=2.2, a0=150, span=60, width=1.8)
        p.restore()
        _text(p, 345, 172, "echo comes back", "#F0ABFC", 11, False, Qt.AlignCenter, 160)
        _arrow(p, QPointF(30, 92), QPointF(100, 92), TXT, 2.2); _text(p, 30, 78, "40 km/h", TXT, 12, True, w=120)
        _arrow(p, QPointF(440, 92), QPointF(490, 92), TXT, 2.2); _text(p, 440, 78, "20 km/h", TXT, 12, True, w=120)
        _text(p, 290, 222, "Doppler: closing at 20 km/h — known at once", HL if s == 2 else "#FDE68A", 12, True,
              Qt.AlignCenter, 420)
    if s >= 3:
        x0, y0 = 610, 70
        _text(p, x0, y0 - 14, "Echo strength", HL if s == 3 else MUTED, 11, True, w=180)
        for i, (n, v, col) in enumerate((("truck", 1.0, GREEN), ("car", 0.6, GREEN), ("parked car", 0.35, AMBER),
                                         ("pedestrian", 0.18, RED))):
            y = y0 + 8 + i * 30
            _text(p, x0, y + 2, n, TXT, 11, w=90)
            p.setPen(Qt.NoPen); p.setBrush(_c("#1F2937")); p.drawRoundedRect(QRectF(x0 + 80, y - 6, 100, 12), 4, 4)
            p.setBrush(_c(col)); p.drawRoundedRect(QRectF(x0 + 80, y - 6, 100 * v, 12), 4, 4)
        _text(p, x0, y0 + 132, "per object: a formula → detection chance", MUTED, 10, w=190)


# ------------------------------------------------------------------ radar: real-world (beams, echoes, CFAR)
def _radar_real(p, s):
    _road(p, 40, 210, x1=520)
    cy = 125
    _vehicle(p, QRectF(20, cy - 17, 90, 34), OURS, "our truck")
    _vehicle(p, QRectF(330, cy - 16, 150, 32), OTHER, "")
    ox = 112
    # beams
    p.save(); p.setClipRect(QRectF(0, 40, 520, 170))
    for k in range(-15, 16, 2):
        a = math.radians(k * 2)
        hit = abs(math.tan(a) * (330 - ox)) < 16
        end = (330 if hit else 520)
        p.setPen(QPen(_c(COL["radar"], 0.65 if s == 1 else 0.28), 1))
        p.drawLine(QPointF(ox, cy), QPointF(end, cy + math.tan(a) * (end - ox)))
    p.restore()
    if s == 1:
        _text(p, 300, 30, "1° beams across 60°: each beam → its first hit", HL, 12, True, Qt.AlignCenter, 420)
    # echo power per beam vs CFAR threshold (inset)
    if s >= 2:
        bx, by, bw, bh = 540, 50, 240, 110
        p.setPen(QPen(_c("#334155"), 1)); p.setBrush(_c("#0F172A")); p.drawRect(QRectF(bx, by, bw, bh))
        _text(p, bx, by - 6, "echo power per beam", HL if s == 2 else MUTED, 11, True, w=200)
        import random
        rnd = random.Random(3)
        thr = by + bh * 0.45
        for i in range(24):
            on_t = 9 <= i <= 14
            v = (0.75 + rnd.uniform(0, 0.2)) if on_t else (0.62 if i == 4 else rnd.uniform(0.05, 0.3))
            h = bh * v
            p.setPen(Qt.NoPen); p.setBrush(_c(COL["radar"] if on_t else ("#94A3B8" if i == 4 else "#475569")))
            p.drawRect(QRectF(bx + 4 + i * 9.8, by + bh - h, 7, h))
        p.setPen(QPen(_c(RED), 1.6, Qt.DashLine)); p.drawLine(QPointF(bx, thr), QPointF(bx + bw, thr))
        _text(p, bx + bw - 90, thr - 4, "CFAR threshold", RED, 10, True, w=90)
        _text(p, bx, by + bh + 16, "above it = a detection; one rain-clutter spike too", MUTED, 10, w=250)
    if s >= 3:                                              # detection points with Doppler arrows
        for k in range(5):
            y = cy - 12 + k * 6
            p.setPen(Qt.NoPen); p.setBrush(_c(HL)); p.drawEllipse(QPointF(330, y), 3.2, 3.2)
            _arrow(p, QPointF(330, y), QPointF(318, y), "#F0ABFC", 1.2, 5)
        p.setPen(Qt.NoPen); p.setBrush(_c("#94A3B8")); p.drawEllipse(QPointF(230, 78), 3, 3)
        _text(p, 200, 66, "clutter", MUTED, 10, w=60)
        if s == 3:
            _text(p, 260, 200, "points: range · angle · Doppler (−5.6 m/s)", HL, 12, True, Qt.AlignCenter, 420)
    if s >= 4:
        p.setPen(QPen(_c(GREEN), 1.8, Qt.DashLine)); p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(330, cy), 14, 24)
        _mark(p, 230, 78, False, 7)
        if s == 4:
            _text(p, 260, 200, "same speed, within 2 m → one object · single weak standing echo dropped", HL, 11,
                  True, Qt.AlignCenter, 500)
    if s >= 5:
        _text(p, 400, 92, "R2: 28.8 m, −20 km/h", GREEN, 12, True, Qt.AlignCenter, 200)
        _text(p, 260, 200, "tracked as R2 after 3 of 4 scans (standing echoes: 0.8 s)", GREEN, 12, True,
              Qt.AlignCenter, 500)


# ------------------------------------------------------------------ V2V
def _v2v(p, s):
    _road(p, 110, 210)
    cy = 160
    _fog(p, QRectF(200, 112, 330, 96), 80, seed=5, a=0.26)
    _vehicle(p, QRectF(20, cy - 17, 90, 34), OURS, "our truck")
    _vehicle(p, QRectF(580, cy - 17, 150, 34), OTHER, "Truck_auto_1")
    p.setPen(Qt.NoPen); p.setBrush(_c(RED)); p.drawRect(QRectF(576, cy - 15, 5, 8)); p.drawRect(QRectF(576, cy + 7, 5, 8))
    p.setPen(QPen(_c(COL["camera"], 0.7), 2, Qt.DashLine)); p.drawLine(QPointF(112, cy), QPointF(230, cy))
    _mark(p, 240, cy, False, 9)
    _text(p, 120, cy + 34, "sensors: blocked by fog", HL if s == 1 else RED, 11, True, w=200)
    if s >= 2:                                         # (its radio sending, animated)
        _rings(p, QPointF(655, cy - 20), COL["V2V"], 110, n=3, period=1.5, a0=40, span=100)
        bub = QRectF(240, 24, 320, 58)
        p.setPen(QPen(_c(HL if s == 2 else COL["V2V"]), 1.6)); p.setBrush(_c(COL["V2V"], 0.14))
        p.drawRoundedRect(bub, 10, 10)
        _text(p, 400, 36, "BRAKE ALERT · Truck_auto_1", "#F1F5F9", 13, True, Qt.AlignCenter, 310)
        _text(p, 400, 56, "GPS position · 0 km/h · −5 m/s² · length 16.5 m", COL["V2V"], 11, False, Qt.AlignCenter, 310)
        _text(p, 400, 72, "sent at once + state 10× a second", MUTED, 10, False, Qt.AlignCenter, 310)
    if s >= 3:
        p.setPen(QPen(_c(MUTED), 1.5)); p.setBrush(_c("#334155")); p.drawRect(QRectF(735, 18, 22, 12))
        p.drawLine(QPointF(728, 24), QPointF(764, 24))
        p.setPen(QPen(_c(MUTED), 1, Qt.DotLine)); p.drawLine(QPointF(746, 30), QPointF(670, cy - 18))
        p.setPen(QPen(_c(HL if s == 3 else AMBER), 1.4, Qt.DashLine)); p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(655, cy), 40, 26)
        _text(p, 690, 50, "GPS ± 2.5 m\n→ in our lane?", AMBER, 11, True, w=110)
    if s >= 4:
        _arrow(p, QPointF(600, 96), QPointF(130, 118), _c(COL["V2V"], 0.5).name(QColor.HexArgb), 2.0, 11)
        _packet(p, QPointF(600, 96), QPointF(130, 118), ph(1.6) * 1.25, COL["V2V"])
        _text(p, 300, 104, "delivered after ~20 ms", COL["V2V"], 11, True, w=200)
        if ph(1.6) * 1.25 >= 1.0:
            _mark(p, 140, cy - 34, True, 10)
        _text(p, 10, 236, "Our truck knows it and brakes — no sensor could see through the fog.", HL, 12, True, w=780)


def _v2v_more(p, s):
    """V2V slides 5..8: one message's contents, broadcast to everyone in range, the receiver's checks, heavy traffic."""
    G = COL["V2V"]
    if s == 5:                                         # one message, field by field
        fields = [("Sender id", "Truck_auto_1"), ("Time", "12:04:31.250"), ("Latitude", "8.558421"),
                  ("Longitude", "76.882541"), ("Heading", "169°"), ("Speed", "5.6 m/s"), ("Accel.", "−4.8 m/s²"),
                  ("Brake", "YES"), ("Length", "16.5 m"), ("Type", "BRAKE ALERT"), ("Signature", "security")]
        _text(p, 400, 22, "ONE V2V MESSAGE (~300 bytes)", G, 14, True, Qt.AlignCenter, 600)
        x, y = 12, 48
        for i, (k, v) in enumerate(fields):
            r = QRectF(x, y, 122, 62)
            col = MUTED if k == "Signature" else (RED if k in ("Type", "Brake", "Accel.") else G)
            p.setPen(QPen(_c(col), 1.4)); p.setBrush(_c(col, 0.12)); p.drawRoundedRect(r, 8, 8)
            _text(p, x + 61, y + 16, k, MUTED, 11, False, Qt.AlignCenter, 118)
            _text(p, x + 61, y + 38, v, TXT, 12, True, Qt.AlignCenter, 118)
            x += 131
            if i == 5:
                x, y = 12 + 65, y + 76
        _text(p, 400, 214, "Not in it: the distance to me, my lane, a picture — the RECEIVER works those out.",
              HL, 12, True, Qt.AlignCenter, 760)
        return
    if s == 6:                                         # broadcast: everyone in range gets it
        _road(p, 96, 186)
        cy = 141
        src = QPointF(430, cy - 22)
        p.save(); p.setClipRect(QRectF(0, 30, 800, 170))
        _rings(p, src, G, 360, n=4, period=2.4, sy=0.4)       # (heard by everyone around, animated)
        p.restore()
        _vehicle(p, QRectF(360, cy - 40, 140, 34), OTHER, "sender: Truck_auto_1")
        for r, lab, ok in ((QRectF(160, cy - 40, 90, 34), "behind: gets it", True),
                           (QRectF(40, cy - 40, 90, 34), "behind: gets it", True),
                           (QRectF(600, cy + 6, 90, 34), "other way: gets it", True)):
            _vehicle(p, r, OURS, "")
            _text(p, r.center().x(), r.bottom() + 6 if r.top() > cy else r.top() - 22, lab, G, 11, True,
                  Qt.AlignCenter, 140)
        _text(p, 400, 18, "BROADCAST: nobody is addressed — every vehicle in range (~450 m) receives it",
              TXT, 13, True, Qt.AlignCenter, 760)
        _text(p, 400, 214, "Each receiver keeps the latest message of every sender and decides itself what matters.",
              HL, 12, True, Qt.AlignCenter, 760)
        return
    if s == 7:                                         # the receiver's checks
        steps = [("Fresh?", "age ≤ delay + 0.3 s", True), ("Ahead?", "on my route, in front", True),
                 ("My lane?", "beside ≤ lane + GNSS error", True), ("My way?", "heading within 35°", True),
                 ("USE IT", "gap = 18.3 m · 20 km/h · BRAKE", None)]
        x = 14
        for i, (t, sub, ok) in enumerate(steps):
            last = ok is None
            col = G if not last else HL
            r = QRectF(x, 60, 140, 96)
            p.setPen(QPen(_c(col), 2 if last else 1.5)); p.setBrush(_c(col, 0.12)); p.drawRoundedRect(r, 10, 10)
            _text(p, x + 70, 82, t, col, 14, True, Qt.AlignCenter, 136)
            _text(p, x + 70, 110, sub, TXT, 11, False, Qt.AlignCenter, 132)
            if not last:
                _mark(p, x + 126, 72, True, 9)
                _arrow(p, QPointF(x + 142, 108), QPointF(x + 156, 108), MUTED, 2, 8)
            x += 158
        _text(p, 400, 20, "THE RECEIVER CHECKS EVERY MESSAGE", G, 14, True, Qt.AlignCenter, 600)
        _text(p, 400, 186, "Any ✕ → 'not used' with the reason (behind it · other direction · beside its lane · "
                           "too old) — see Detection details → V2V messages.", MUTED, 12, False, Qt.AlignCenter, 760)
        return
    # s == 8: heavy traffic
    import v2v
    _text(p, 400, 18, "HEAVY TRAFFIC: ONE SHARED RADIO CHANNEL", G, 14, True, Qt.AlignCenter, 600)
    bars = [(10, "light"), (100, ""), (300, ""), (600, "jam")]
    x = 60
    for n, tag in bars:
        ld = v2v.load_of(n)
        h = 120 * ld["cbr"]
        hd = 120 * min(1.2, ld["cbr_demand"])
        col = GREEN if ld["cbr"] < 0.3 else AMBER if ld["cbr"] < 0.55 else RED
        p.setPen(QPen(_c(MUTED), 1, Qt.DashLine)); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(x, 190 - hd, 60, hd))
        p.setPen(Qt.NoPen); p.setBrush(_c(col)); p.drawRect(QRectF(x, 190 - h, 60, h))
        _text(p, x + 30, 196 + 12, f"{n} vehicles", TXT, 11, True, Qt.AlignCenter, 110)
        _text(p, x + 30, 190 - max(h, hd) - 8, f"{ld['cbr'] * 100:.0f} % busy" + (
            f" (wants {ld['cbr_demand'] * 100:.0f} %)" if ld["cbr_demand"] > ld["cbr"] + 1e-6 else ""),
            col, 11, True, Qt.AlignCenter, 170)
        _text(p, x + 30, 232, f"{ld['rate_hz']:.0f}/s · +{ld['extra_loss'] * 100:.0f} % loss", MUTED, 10, False,
              Qt.AlignCenter, 120)
        x += 120
    p.setPen(QPen(_c(RED), 1.4, Qt.DashLine))
    p.drawLine(QPointF(50, 190 - 120 * v2v.DCC_TARGET), QPointF(530, 190 - 120 * v2v.DCC_TARGET))
    for k, line in enumerate(["Busy % = vehicles × messages/s × 0.2 ms",
                              "Above ~30 % busy: messages collide → more loss",
                              "Dashed box: what they want to send — congestion control slows everyone to stay at "
                              "≤ 60 % (positions a bit older)",
                              "The receiver checks every signature: a unit manages ~2000 / s"]):
        _text(p, 545, 44 + 46 * k, "• " + line, TXT if k != 2 else HL, 11, False, Qt.AlignLeft, 245)


# ------------------------------------------------------------------ fusion
def _fusion(p, s, real=False):
    rows = ([("LiDAR", "L4 · 12.4 m", True), ("camera", "C3 · truck 93 % · 13.1 m", True),
             ("radar", "R2 · 12.6 m · −3 m/s", True), ("V2V", "Truck_auto_1 · 13.5 m", True)] if real else
            [("LiDAR", "12.4 m", True), ("camera", "nothing (fog)", None), ("radar", "12.6 m · −3 m/s", True),
             ("V2V", "13.5 m", True)])
    for i, (k, t, ok) in enumerate(rows):
        y = 30 + i * 46
        r = QRectF(10, y, 250, 36)
        p.setPen(QPen(_c(COL[k]), 1.5)); p.setBrush(_c(COL[k], 0.10)); p.drawRoundedRect(r, 8, 8)
        draw_icon(p, k, QRectF(18, y + 7, 22, 22), COL[k])
        _text(p, 48, y + 12, f"{k}: {t}", TXT if ok else MUTED, 12, True, w=210)
        if s >= 3:
            _arrow(p, QPointF(262, y + 18), QPointF(330, 120), _c(COL[k], 0.8 if ok else 0.25).name(), 1.6, 7)
    if s == 1:
        _text(p, 520, 110, ("each sensor's own TRACKS (ids, no names)" if real else
                            "what each sensor gives — by the scene's object id"), HL, 13, True, Qt.AlignCenter, 420)
    y = 30 + 4 * 46
    if s >= 2:
        _text(p, 14, y + 12, "camera C7: standing, only the camera sees it" if real else
              "radar: parked car 4 m to the left", MUTED, 11, w=260)
        _mark(p, 268, y + 16, False, 8)
        _text(p, 14, y + 30, "→ not confirmed by LiDAR / radar: ignored" if real else "→ outside our lane, ignored",
              RED, 11, w=270)
        if s == 2:
            _text(p, 560, 110, ("tracks near each other = one object\n(matched by position)" if real else
                                "only objects in our lane count"), HL, 13, True, Qt.AlignCenter, 380)
    if s >= 3:
        box = QRectF(332, 70, 200, 100)
        p.setPen(QPen(_c("#F472B6"), 2)); p.setBrush(_c("#F472B6", 0.12)); p.drawRoundedRect(box, 12, 12)
        _text(p, 432, 86, "FUSION", "#F472B6", 14, True, Qt.AlignCenter, 190)
        _text(p, 432, 110, "1. in our lane?\n2. take the NEAREST", TXT, 12, False, Qt.AlignCenter, 190)
        _arrow(p, QPointF(534, 120), QPointF(586, 120), "#F472B6", 2.4, 10)
        t = QRectF(588, 62, 204, 116)
        p.setPen(QPen(_c(GREEN), 2)); p.setBrush(_c(GREEN, 0.12)); p.drawRoundedRect(t, 12, 12)
        _text(p, 690, 78, "TARGET", GREEN, 14, True, Qt.AlignCenter, 200)
        _text(p, 690, 102, ("Truck_auto_1 (matched)\n12.4 m ahead\nspeed from R2 / V2V" if real else
                            "Truck_auto_1\n12.4 m ahead\nspeed 8.1 m/s (radar)"), TXT, 12, False, Qt.AlignCenter, 200)


# ------------------------------------------------------------------ braking
def _brake(p, s, ttc_warn=3.0, ttc_crit=1.5):
    _road(p, 30, 90, lanes=1)
    _vehicle(p, QRectF(30, 44, 90, 32), OURS, "our truck")
    _arrow(p, QPointF(40, 28), QPointF(110, 28), TXT, 2); _text(p, 40, 14, "40 km/h = 11.1 m/s", TXT, 11, True, w=200)
    _vehicle(p, QRectF(470, 44, 150, 32), OTHER, "stopped truck")
    _dim(p, 120, 470, 104, "25 m")
    if s >= 2:
        _text(p, 640, 50, "TTC = 25 ÷ 11.1\n= 2.2 s", HL if s == 2 else "#FDE68A", 14, True, w=160)
    if s >= 3:
        x0, x1, y = 40, 760, 170
        span = 6.0
        X = lambda t: x0 + (x1 - x0) * min(span, t) / span       # noqa: E731
        for a, b, col, lab in ((0, ttc_crit, RED, "FULL BRAKE (AEB)"), (ttc_crit, ttc_warn, AMBER, "warning · brake"),
                               (ttc_warn, span, GREEN, "follow / drive on")):
            p.setPen(Qt.NoPen); p.setBrush(_c(col, 0.8)); p.drawRect(QRectF(X(a), y, X(b) - X(a), 22))
            _text(p, (X(a) + X(b)) / 2, y + 16, lab, "#0B1220", 12, True, Qt.AlignCenter, X(b) - X(a))
        for t in (0, ttc_crit, ttc_warn, span):
            _text(p, X(t), y + 36, f"{t:g} s" if t < span else "6 s +", MUTED, 11, False, Qt.AlignCenter, 60)
        m = X(2.2)
        p.setBrush(_c("#FFFFFF")); p.setPen(Qt.NoPen)
        p.drawPolygon(QPolygonF([QPointF(m, y - 2), QPointF(m - 8, y - 14), QPointF(m + 8, y - 14)]))
        _text(p, m, y - 34, "2.2 s → brake", "#FFFFFF", 12, True, Qt.AlignCenter, 140)
    if s == 1:
        _text(p, 400, 180, "it sees a stopped truck 25 m ahead at 40 km/h …", HL, 13, True, Qt.AlignCenter, 600)


def _collision(p, s):
    _road(p, 40, 120, lanes=1)
    _vehicle(p, QRectF(150, 62, 110, 36), OURS, "our truck")
    _vehicle(p, QRectF(262, 62, 160, 36), OTHER, "Truck_auto_1")
    star = QPolygonF()
    for k in range(16):
        r = 22 if k % 2 == 0 else 10
        a = k * math.pi / 8
        star.append(QPointF(261 + r * math.cos(a), 80 + r * math.sin(a)))
    p.setPen(QPen(_c(HL), 1.5)); p.setBrush(_c(RED)); p.drawPolygon(star)
    _text(p, 470, 74, "the real bodies touch\n→ COLLISION (recorded with every\nsensor's view, camera, 3D scene)",
          "#FCA5A5", 12, True, w=320)
    if s >= 2:
        _text(p, 10, 150, "The reason is worked out from the facts:", MUTED, 12, True, w=500)
        x = 10
        for t, col in (("climate (fog / rain cut the range)", "#7DD3FC"), ("hidden / small obstacle", AMBER),
                       ("seen too late for its speed", "#FB923C"), ("test setup", MUTED)):
            x += _chip(p, x, 168, t, col) + 8
        _text(p, 10, 222, "Sensors switched off on purpose are not blamed — they are suggested as a way to avoid it.",
              MUTED, 11, w=780)


DECKS = {
    "flow": (210, ["The scene moves: trucks on the route, vehicles ahead, obstacles, stop & go",
                   "Each truck's sensors look (only those switched on) + V2V messages arrive",
                   "Fusion: the nearest object in its lane is the target",
                   "The truck follows, brakes, or full-brakes (AEB) on what it perceives",
                   "The real positions are checked: bodies touch = a collision, with its reason"], _flow),
    "camera": (245, ["Its view: 90° wide, from the front of the truck",
                     "Its range: ½ the visibility (max 80 m) — fog 120 m → 60 m",
                     "Inside view and range → seen; hidden behind another / beyond the range → not seen",
                     "Distance from the scene's positions: 40 − 3.5 − 8.25 = 28 m; type with a confidence"],
               _camera_sim),
    "camera_real": (262, ["The camera picture of this climate — no positions are given to the camera",
                          "The road's colours are learned from the strip just in front of the truck",
                          "Each pixel column is scanned upward until the road ends for good: an obstacle's ground "
                          "contact",
                          "Distance from that row: d = camera height ÷ tan(angle below the horizon)",
                          "Neighbouring columns form one object (type from its width), tracked as C3"], _camera_real),
    "lidar": (265, ["The laser rays hit the back of the truck ahead → points",
                    "Enough points on it (≥ 4) → detected; distance = its nearest point",
                    "In whiteout fog the rays die out: 0 points → not detected"], _lidar_sim),
    "lidar_real": (250, ["Raw points only — the LiDAR does not know what each point hit",
                         "Ground and the map's structure (buildings, poles) removed; sparse fog points filtered",
                         "Clustering: touching 0.6 m cells form one object",
                         "Distance = its nearest point inside our driving corridor",
                         "Tracked as L4; named only by matching to the real object (reports)"], _lidar_real),
    "radar": (240, ["Radio waves pass through fog",
                    "The echo comes back: distance + speed at once (Doppler)",
                    "Echo strength: big trucks far, pedestrians / parked cars weaker — a formula per object"],
              _radar_sim),
    "radar_real": (250, ["1° beams across its 60° view; each beam's first hit",
                         "Echo power per beam against the CFAR threshold (+ rain clutter)",
                         "Detections: range, angle and Doppler per point",
                         "Points with the same speed within 2 m → one object; a single weak standing echo dropped",
                         "Tracked as R2 after 3 of 4 scans"], _radar_real),
    "v2v": (250, ["Fog: the truck's sensors cannot see the truck ahead",
                  "The truck ahead brakes hard: it sends a BRAKE ALERT at once (+ its state 10× a second)",
                  "Its GPS position (± 2.5 m): is it in our lane, going our way?",
                  "Delivered after ~20 ms → our truck brakes on it",
                  "What is inside one message: 10 fields + the security signature",
                  "Broadcast: every vehicle in range receives it — behind, beside, the other way",
                  "The receiver checks each message: fresh, ahead, my lane, my way → used or not (and why)",
                  "Heavy traffic: the shared channel gets busy → more loss, everyone sends slower"],
            lambda p, s: _v2v(p, s) if s <= 4 else _v2v_more(p, s)),
    "fusion": (250, ["What each sensor gives (by the scene's object id)", "Only objects in our lane count",
                     "The nearest one is the target"], lambda p, s: _fusion(p, s, False)),
    "fusion_real": (250, ["Each sensor's own tracks (ids, no names)",
                          "Tracks near each other = one object; a standing camera-only one needs LiDAR / radar",
                          "The nearest one in our lane is the target"], lambda p, s: _fusion(p, s, True)),
    "brake": (250, ["A stopped truck 25 m ahead at 40 km/h", "Time to collision = distance ÷ closing speed = 2.2 s",
                    "Below 3 s: brake; below 1.5 s: FULL BRAKE (AEB)"], _brake),
    "collision": (240, ["The real bodies touch → a collision record", "The reason, from the facts"], _collision),
}


import sensor_slides_more  # noqa: E402  (more decks: the other options of each sensor, V2V's radio, real life ↔ app)
sensor_slides_more.register(DECKS)
import sensor_slides_tech  # noqa: E402  (the Technical overview's decks: code + picture + calculation per step)
sensor_slides_tech.register(DECKS)
import sensor_slides_simple  # noqa: E402  (the Technical overview's EASY decks: real world · our app · detection ·
sensor_slides_simple.register(DECKS)  # real ↔ app · limits, in pictures)


def deck_for(topic, mode):
    """The deck name of a topic for the set-up (mode 'sim' / 'real')."""
    if mode == "real" and f"{topic}_real" in DECKS:
        return f"{topic}_real"
    return topic if topic in DECKS else None


class Slide(QWidget):
    """One deck at one step (◀ / ▶ in the info window), animated: the parts move (waves spread, messages travel,
    scans sweep) -- the clock restarts at every step; it runs only while the picture is on screen."""
    FPS_MS = 40

    def __init__(self, deck, data=None):
        super().__init__()
        self.deck, self.data, self.step = deck, data, 1
        if deck == "climate":
            self.H = 70 + 36 * len(data or [])
            self.n = 1
        else:
            self.H, caps, _fn = DECKS[deck]
            self.n = len(caps)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setFixedHeight(self.H)
        self.t0 = time.monotonic()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)

    def caption(self):
        return "" if self.deck == "climate" else DECKS[self.deck][1][self.step - 1]

    def go(self, step):
        self.step = max(1, min(self.n, step))
        self.t0 = time.monotonic()
        self.update()

    def showEvent(self, e):
        if self.deck != "climate":
            self.timer.start(self.FPS_MS)
        super().showEvent(e)

    def hideEvent(self, e):
        self.timer.stop()
        super().hideEvent(e)

    def resizeEvent(self, e):
        self.setFixedHeight(int(self.H * min(1.0, max(0.55, self.width() / 800.0))))
        super().resizeEvent(e)

    def paintEvent(self, _e):
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), _c("#0A0F1C"))
            sc = min(self.width() / 800.0, self.height() / float(self.H))
            p.translate((self.width() - 800 * sc) / 2, (self.height() - self.H * sc) / 2)
            p.scale(sc, sc)
            global T, DATA
            T, DATA = time.monotonic() - self.t0, self.data
            if self.deck == "climate":
                _d_climate(p, self.data or [])
            else:
                DECKS[self.deck][2](p, self.step)
        except Exception:
            import sys
            sys.excepthook(*sys.exc_info())
        finally:
            p.end()
