#!/usr/bin/env python3
"""MQTT hardware simulator -- sends the same AV (autonomous vehicle) messages as the app's collision test ("Publish data to
hardware"), without the app. Use it to check the broker, the topic prefix and the ESP32 car on their own.
Not part of the simulation app: copy this one file to any PC (Windows or Ubuntu).

Needs:  Python 3.8+  and  paho-mqtt        (Ubuntu: see "Ubuntu" below)
Run:    python3 mqtt_hw_simulator.py --host test.mosquitto.org --prefix yardsim/k3x9qa/hw --check
            connection check only: sends 20 "paused" messages (the car stays stopped), reads them back, exits
        python3 mqtt_hw_simulator.py --host test.mosquitto.org --prefix yardsim/k3x9qa/hw
            drive scenario in a loop: accelerate, cruise, turn right, turn left, full speed, brake, AEB stop, hold
        python3 mqtt_hw_simulator.py --host test.mosquitto.org --prefix yardsim/k3x9qa/hw --manual
            type commands: go 60 | left | right | straight | brake 50 | aeb | stop | pause | end | quit
        options: --port 1883  --avs 1,2  --rate 10  --user u --password p  --tls --ca file.crt
Ctrl+C ends: an "ended" message is sent, so the car stops.

Ubuntu (everything in a venv, nothing installed into the system Python):
        python3 -m venv ~/mqttsim && ~/mqttsim/bin/pip install paho-mqtt
        ~/mqttsim/bin/python mqtt_hw_simulator.py --host test.mosquitto.org --prefix yardsim/k3x9qa/hw --check
"""
import argparse
import json
import math
import socket
import sys
import threading
import time

try:
    import paho.mqtt.client as mqtt
except ImportError:
    print("paho-mqtt is missing.  Install it:  pip install paho-mqtt   "
          "(Ubuntu: python3 -m venv ~/mqttsim && ~/mqttsim/bin/pip install paho-mqtt)")
    sys.exit(1)

TOP_KMH = 30.0
BASE_LAT, BASE_LON = 8.55312, 76.88101
#            seconds, phase,          speed % from -> to, yaw °/s, brake %, brake_mode, status
SCENARIO = [(3.0, "accelerate",       0,   60,   0,   0, "none",    "running"),
            (3.0, "cruise 60 %",      60,  60,   0,   0, "none",    "running"),
            (3.0, "turn right",       60,  60,  25,   0, "none",    "running"),
            (3.0, "turn left",        60,  60, -25,   0, "none",    "running"),
            (3.0, "full speed",       60, 100,   0,   0, "none",    "running"),
            (2.0, "braking",          100, 30,   0,  50, "braking", "running"),
            (2.0, "AEB stop",         30,   0,   0, 100, "aeb",     "running"),
            (3.0, "held (paused)",    0,    0,   0, 100, "hold",    "paused")]
CYCLE = sum(p[0] for p in SCENARIO)
MANUAL_HELP = ("commands:  go <0-100>   left [deg/s]   right [deg/s]   straight   brake [pct]   aeb   stop   "
               "pause   resume   end   status   help   quit")
RC_TEXT = {1: "wrong protocol version", 2: "client id rejected", 3: "broker unavailable",
           4: "wrong user name / password", 5: "not authorised (login needed)"}


def make_client(cid):
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid)
    except AttributeError:                        # paho-mqtt 1.x
        return mqtt.Client(client_id=cid)


def rc_value(rc):
    try:
        return int(rc.value) if hasattr(rc, "value") else int(rc)
    except Exception:
        return 0 if not getattr(rc, "is_failure", False) else 99


class Sim:
    def __init__(self, a):
        self.a = a
        self.prefix = a.prefix.strip().strip("/")
        self.trucks = [int(x) for x in str(a.trucks).split(",") if x.strip()]
        self.test_id = "sim:%d" % int(time.time() * 1000)
        self.status_topic = self.prefix + "/status"
        self.connected = threading.Event()
        self.conn_rc = None
        self.sent = 0
        self.echo = 0
        self.echo_lat = []
        self.seq = {n: 0 for n in self.trucks}
        self.pos = {n: [0.0, -12.0 * (n - 1), 90.0] for n in self.trucks}   # x, y m, heading (convoy: behind)
        self.manual = {"status": "paused", "speed_pct": 0, "yaw": 0.0, "brake_pct": 100, "mode": "hold"}
        self.lock = threading.Lock()
        self.stop = False
        c = self.client = make_client("yardsim-hw-sim-%d" % (int(time.time()) % 100000))
        if a.user:
            c.username_pw_set(a.user, a.password or None)
        if a.tls:
            c.tls_set(ca_certs=a.ca or None)
        c.will_set(self.status_topic, json.dumps({"online": False, "test": self.test_id}), qos=1, retain=True)
        c.on_connect = self._on_connect
        c.on_disconnect = self._on_disconnect
        c.on_message = self._on_message

    def topic(self, n):
        return "%s/av%d" % (self.prefix, n)

    # ---------------------------------------------------------------- MQTT callbacks
    def _on_connect(self, c, u, flags, rc, *rest):
        self.conn_rc = rc_value(rc)
        if self.conn_rc == 0:
            c.subscribe(self.prefix + "/#", 0)       # read our own messages back: proves the broker round trip
            self.connected.set()

    def _on_disconnect(self, c, u, *rest):
        if self.connected.is_set() and not self.stop:
            print("!! disconnected from the broker -- paho reconnects by itself", flush=True)
        self.connected.clear()

    def _on_message(self, c, u, msg):
        if not msg.topic.startswith(self.prefix + "/av"):
            return
        try:
            d = json.loads(msg.payload.decode("utf-8", "replace"))
        except Exception:
            return
        if d.get("test") == self.test_id:
            self.echo += 1
            if d.get("ts"):
                self.echo_lat.append(time.time() * 1000 - d["ts"])
                del self.echo_lat[:-50]

    # ---------------------------------------------------------------- connect
    def connect(self):
        a = self.a
        print("Broker      : %s:%d%s" % (a.host, a.port, "  (TLS)" if a.tls else ""))
        print("Topics      : " + ", ".join(self.topic(n) for n in self.trucks) + "   status: " + self.status_topic)
        try:
            ip = socket.gethostbyname(a.host)
            print("DNS         : %s -> %s" % (a.host, ip))
        except socket.gaierror as e:
            print("FAILED DNS  : cannot resolve %s (%s). No internet / DNS on this machine?" % (a.host, e))
            return False
        try:
            s = socket.create_connection((a.host, a.port), timeout=6)
            s.close()
            print("TCP port    : %d open" % a.port)
        except OSError as e:
            print("FAILED TCP  : port %d not reachable (%s).\n"
                  "              The network (office Wi-Fi / firewall / proxy) blocks it -- try a phone hotspot." % (a.port, e))
            return False
        try:
            self.client.connect(a.host, a.port, keepalive=10)
        except Exception as e:
            print("FAILED MQTT : %s" % e)
            return False
        self.client.loop_start()
        if not self.connected.wait(8):
            rc = self.conn_rc
            print("FAILED MQTT : broker did not accept the connection%s" %
                  (" (%s)" % RC_TEXT.get(rc, "code %s" % rc) if rc else " within 8 s"))
            return False
        print("MQTT        : connected")
        self._status(True)
        return True

    def _status(self, online):
        m = {"online": online, "test": self.test_id, "route": "simulator", "rate_hz": self.a.rate,
             "ts": int(time.time() * 1000),
             "avs": [{"av": n, "topic": self.topic(n), "name": "Sim AV %d" % n} for n in self.trucks]}
        return self.client.publish(self.status_topic, json.dumps(m), qos=1, retain=True)

    # ---------------------------------------------------------------- messages
    def scenario_state(self, t):
        t = t % CYCLE
        for dur, name, s0, s1, yaw, bp, mode, status in SCENARIO:
            if t < dur:
                f = t / dur
                return {"phase": name, "speed_pct": int(round(s0 + (s1 - s0) * f)), "yaw": float(yaw),
                        "brake_pct": bp, "mode": mode, "status": status, "accel": (s1 - s0) / 100.0 * TOP_KMH / 3.6 / dur}
            t -= dur
        return {"phase": "idle", "speed_pct": 0, "yaw": 0.0, "brake_pct": 0, "mode": "none", "status": "paused", "accel": 0.0}

    def payload(self, n, st, dt):
        sp = max(0, min(100, int(st["speed_pct"])))
        v = TOP_KMH / 3.6 * sp / 100.0
        p = self.pos[n]
        if st["status"] == "running":
            p[2] = (p[2] + st["yaw"] * dt) % 360.0
            p[0] += v * dt * math.sin(math.radians(p[2]))
            p[1] += v * dt * math.cos(math.radians(p[2]))
        self.seq[n] += 1
        bp = int(st["brake_pct"])
        return {"v": 1, "seq": self.seq[n], "ts": int(time.time() * 1000), "test": self.test_id, "av": n, "truck": n,
                "id": "sim-%d" % n, "name": "Sim AV %d" % n, "status": st["status"],
                "lat": round(BASE_LAT + p[1] / 111320.0, 7),
                "lon": round(BASE_LON + p[0] / (111320.0 * math.cos(math.radians(BASE_LAT))), 7),
                "heading": round(p[2], 1), "x": round(p[0], 2), "y": round(p[1], 2),
                "speed": round(v, 2), "kmh": round(v * 3.6, 1), "top_kmh": TOP_KMH, "speed_pct": sp,
                "accel": round(st.get("accel", 0.0), 2), "yaw_rate": round(st["yaw"], 1),
                "brake": 1 if bp > 0 else 0, "brake_pct": bp, "brake_mode": st["mode"],
                "throttle_pct": 0, "state": "simulator: " + st.get("phase", "manual"), "ahead": None}

    def publish(self, n, st, dt):
        m = self.payload(n, st, dt)
        r = self.client.publish(self.topic(n), json.dumps(m, separators=(",", ":")), qos=self.a.qos)
        if r.rc == 0:
            self.sent += 1
        return m

    def end(self):
        self.stop = True
        if not self.connected.is_set():
            return
        for n in self.trucks:
            st = {"status": "ended", "speed_pct": 0, "yaw": 0.0, "brake_pct": 100, "mode": "full", "phase": "ended"}
            self.publish(n, st, 0.0)
        try:
            self._status(False).wait_for_publish(3)
        except Exception:
            time.sleep(0.5)
        time.sleep(0.3)
        self.client.disconnect()
        self.client.loop_stop()
        print("Sent 'ended' -- the car stops. Bye.")

    # ---------------------------------------------------------------- modes
    def run_check(self):
        """20 safe messages (paused, speed 0, brake held), read back from the broker."""
        print("\nCheck: sending 20 'paused' messages (the car stays stopped) and reading them back ...")
        st = {"status": "paused", "speed_pct": 0, "yaw": 0.0, "brake_pct": 100, "mode": "hold", "phase": "check"}
        for _ in range(20):
            for n in self.trucks:
                self.publish(n, st, 0.1)
            time.sleep(0.1)
        want = 20 * len(self.trucks)
        t0 = time.time()
        while self.echo < want and time.time() - t0 < 4:
            time.sleep(0.1)
        lat = sorted(self.echo_lat)
        print("Sent %d, read back %d%s" % (self.sent, self.echo,
                                            ", round trip ~%.0f ms" % lat[len(lat) // 2] if lat else ""))
        ok = self.echo >= want * 0.8
        if ok:
            print("RESULT: OK -- this machine can publish to the broker and read from it.\n"
                  "        An ESP32 listening on %s now shows status=paused." % self.topic(self.trucks[0]))
        else:
            print("RESULT: PROBLEM -- connected, but messages did not come back (broker filtering / very slow link).")
        return ok

    def run_scenario(self):
        print("\nDriving scenario (%d s loop): %s" % (CYCLE, " -> ".join(p[1] for p in SCENARIO)))
        print("AV 2+ follow 1 s behind each other. Ctrl+C to end (the car stops).\n")
        period = 1.0 / self.a.rate
        t0 = last = time.time()
        last_phase, last_print = None, 0.0
        while True:
            now = time.time()
            dt, last = now - last, now
            for n in self.trucks:
                st = self.scenario_state(max(0.0, now - t0 - (n - 1) * 1.0))
                self.publish(n, st, dt)
                if n == self.trucks[0] and st["phase"] != last_phase:
                    last_phase = st["phase"]
                    print("%6.1f s  AV %d: %-14s speed %3d %%  yaw %+4.0f °/s  brake %-7s status %s" %
                          (now - t0, n, st["phase"], st["speed_pct"], st["yaw"], st["mode"], st["status"]), flush=True)
            if now - last_print > 5:
                last_print = now
                print("          (sent %d, read back from the broker %d%s)" % (
                    self.sent, self.echo, "" if self.connected.is_set() else "  -- NOT CONNECTED"), flush=True)
            time.sleep(max(0.0, period - (time.time() - now)))

    def run_manual(self):
        print("\nManual mode. The car starts stopped (paused).\n" + MANUAL_HELP + "\n")
        threading.Thread(target=self._manual_sender, daemon=True).start()
        while True:
            try:
                line = input("> ").strip().lower()
            except EOFError:
                return
            if not line:
                continue
            w = line.split()
            cmd, arg = w[0], (w[1] if len(w) > 1 else None)
            num = None
            try:
                num = float(arg) if arg is not None else None
            except ValueError:
                print("not a number: " + arg)
                continue
            m = self.manual
            with self.lock:
                if cmd == "go":
                    m.update(status="running", speed_pct=int(num if num is not None else 50), brake_pct=0, mode="none")
                elif cmd in ("left", "right"):
                    deg = abs(num) if num is not None else 25.0
                    m["yaw"] = -deg if cmd == "left" else deg
                elif cmd == "straight":
                    m["yaw"] = 0.0
                elif cmd == "brake":
                    m.update(brake_pct=int(num if num is not None else 50), mode="braking")
                elif cmd == "aeb":
                    m.update(speed_pct=0, brake_pct=100, mode="aeb")
                elif cmd == "stop":
                    m.update(speed_pct=0, brake_pct=100, mode="full")
                elif cmd == "pause":
                    m.update(status="paused", speed_pct=0, brake_pct=100, mode="hold")
                elif cmd == "resume":
                    m.update(status="running", brake_pct=0, mode="none")
                elif cmd == "end":
                    m.update(status="ended", speed_pct=0, brake_pct=100, mode="full")
                elif cmd in ("quit", "exit", "q"):
                    return
                elif cmd == "status":
                    pass
                else:
                    print(MANUAL_HELP)
                    continue
            print("  sending: status %s  speed %d %%  yaw %+.0f °/s  brake %s %d %%   (sent %d, read back %d)" %
                  (m["status"], m["speed_pct"], m["yaw"], m["mode"], m["brake_pct"], self.sent, self.echo))

    def _manual_sender(self):
        period = 1.0 / self.a.rate
        last = time.time()
        while not self.stop:
            now = time.time()
            with self.lock:
                st = dict(self.manual, phase="manual", accel=0.0)
            for n in self.trucks:
                self.publish(n, st, now - last)
            last = now
            time.sleep(period)


def main():
    p = argparse.ArgumentParser(description="Send collision-test AV messages over MQTT without the app "
                                            "(checks the broker, the topic prefix and the ESP32 car).")
    p.add_argument("--host", default="test.mosquitto.org", help="broker (default test.mosquitto.org)")
    p.add_argument("--port", type=int, default=1883)
    p.add_argument("--prefix", default="yardsim/hw", help="topic prefix: the same as the app / the ESP32 sketch")
    p.add_argument("--avs", "--trucks", dest="trucks", default="1",
                   help="AV numbers, e.g. 1 or 1,2 (topic <prefix>/av<N>)")
    p.add_argument("--rate", type=int, default=10, help="messages per second per AV (default 10)")
    p.add_argument("--qos", type=int, default=0, choices=(0, 1))
    p.add_argument("--user", default="")
    p.add_argument("--password", default="")
    p.add_argument("--tls", action="store_true")
    p.add_argument("--ca", default="", help="CA certificate file (TLS)")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--check", action="store_true", help="connection check only (the car stays stopped)")
    g.add_argument("--manual", action="store_true", help="drive by typed commands")
    a = p.parse_args()
    if a.host in ("test.mosquitto.org", "broker.hivemq.com", "broker.emqx.io"):
        print("Note: public broker -- anyone can read these topics. Test data only.")
    sim = Sim(a)
    if not sim.connect():
        print("\nRESULT: NOT CONNECTED -- fix the line marked FAILED above.")
        sys.exit(1)
    ok = True
    try:
        if a.check:
            ok = sim.run_check()
        elif a.manual:
            sim.run_manual()
        else:
            sim.run_scenario()
    except KeyboardInterrupt:
        print()
    finally:
        sim.end()
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
