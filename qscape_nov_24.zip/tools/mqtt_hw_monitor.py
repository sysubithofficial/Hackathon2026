"""MQTT hardware monitor -- a stand-alone test app for "Publish data to hardware" of the collision test.

It subscribes to <prefix>/# and shows, per AV topic (<prefix>/av<N>), what a hardware vehicle (ESP32 ...) would
receive: status, speed, brake, heading, position, the object ahead, message rate, age and lost messages, plus a small
track of every AV's x / y. Not part of the simulation app: copy this one file to any PC.

Needs:  Python 3.8+  and  pip install paho-mqtt     (tkinter comes with Python on Windows; Ubuntu: python3-tk)
Run:    python mqtt_hw_monitor.py                                   (window; enter the broker there)
        python mqtt_hw_monitor.py --host 192.168.1.20 --prefix yardsim/hw
        python mqtt_hw_monitor.py --host 192.168.1.20 --cli         (no window: one line per message)
        python mqtt_hw_monitor.py --host test.mosquitto.org --prefix yardsim/ab12cd/hw   (a free public broker:
                                                                    the prefix the app's Publish dialog shows)
        options: --port 1883 --tls --ca file.crt --user u --password p --topic "<any topic filter>"
"""
import argparse
import json
import math
import queue
import sys
import threading
import time

try:
    import paho.mqtt.client as mqtt
except ImportError:
    print("paho-mqtt is missing:  pip install paho-mqtt")
    sys.exit(1)

STALE_S = 1.0                                     # a vehicle should stop after this long without a message
# free public test brokers (port 1883, no login; anyone can read them -- use the app's unique topic prefix)
PUBLIC_BROKERS = [("test.mosquitto.org", 1883), ("broker.hivemq.com", 1883), ("broker.emqx.io", 1883)]
DISCOVER = "yardsim/+/hw/status"                  # the app's status topic under a unique prefix (public brokers)


def found_prefix(a, topic, msg, have_trucks):
    """A status message of the app under another prefix while nothing came yet -> that prefix (else None)."""
    if have_trucks or a.topic or not topic.endswith("/status") or not isinstance(msg, dict) or not msg.get("online"):
        return None
    p = topic[:-len("/status")]
    return p if p != a.prefix.rstrip("/") else None
COLS = [("topic", "Topic", 170), ("status", "Status", 74), ("name", "AV", 110), ("kmh", "km/h", 56),
        ("speed_pct", "Speed %", 60), ("brake", "Brake", 120), ("accel", "Accel m/s²", 74),
        ("heading", "Heading °", 66), ("yaw_rate", "Yaw °/s", 58), ("pos", "Lat, Lon", 170), ("xy", "x, y m", 100),
        ("ahead", "Ahead", 190), ("rate", "msg/s", 50), ("age", "Age s", 56), ("lost", "Lost", 46)]


def make_client(cid):
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid)
    except AttributeError:                        # paho-mqtt 1.x
        return mqtt.Client(client_id=cid)


def rc_ok(rc):
    return (rc == 0) if isinstance(rc, int) else not getattr(rc, "is_failure", False)


class Receiver:
    """paho in its own thread -> (topic, payload, time) into a queue."""

    def __init__(self, a, q):
        self.a, self.q = a, q
        self.client = make_client(f"hw-monitor-{int(time.time() * 1000) % 10 ** 9}")
        self.client.on_connect = self._on_connect
        self.client.on_message = lambda _c, _u, m: q.put(("msg", m.topic, m.payload, time.time()))
        self.client.on_disconnect = lambda *_x: q.put(("conn", False, "disconnected"))
        if a.user:
            self.client.username_pw_set(a.user, a.password or None)
        if a.tls:
            self.client.tls_set(ca_certs=a.ca or None)
        self.client.reconnect_delay_set(1, 5)

    def _on_connect(self, _c, _u, _f, rc, *_x):
        ok = rc_ok(rc)
        self.q.put(("conn", ok, "connected" if ok else f"refused: {rc}"))
        if ok:
            self.client.subscribe(self.topic_filter(), qos=1)
            if not self.a.topic:                          # (also finds the app's status under another prefix)
                self.client.subscribe(DISCOVER, qos=1)

    def use_prefix(self, prefix):
        """Listen on another prefix (found by its status topic)."""
        try:
            self.client.unsubscribe(self.topic_filter())
        except Exception:
            pass
        self.a.prefix = prefix
        self.client.subscribe(self.topic_filter(), qos=1)

    def topic_filter(self):
        return self.a.topic or f"{self.a.prefix.rstrip('/')}/#"

    def start(self):
        self.client.connect_async(self.a.host, int(self.a.port), keepalive=15)
        self.client.loop_start()

    def stop(self):
        try:
            self.client.disconnect(); self.client.loop_stop()
        except Exception:
            pass


class Truck:
    def __init__(self, topic):
        self.topic, self.msg, self.t, self.lost, self.last_seq = topic, {}, 0.0, 0, None
        self.times, self.trail = [], []

    def add(self, msg, t):
        seq = msg.get("seq")
        if isinstance(seq, int) and self.last_seq is not None and seq > self.last_seq + 1:
            self.lost += seq - self.last_seq - 1
        if isinstance(seq, int):
            if self.last_seq is not None and seq < self.last_seq:       # (a new test: counting again)
                self.lost, self.trail = 0, []
            self.last_seq = seq
        self.msg, self.t = msg, t
        self.times = [x for x in self.times if t - x < 2.0] + [t]
        if "x" in msg and "y" in msg:
            if not self.trail or math.hypot(msg["x"] - self.trail[-1][0], msg["y"] - self.trail[-1][1]) > 0.5:
                self.trail.append((msg["x"], msg["y"]))
                del self.trail[:-600]

    def rate(self, now):
        ts = [x for x in self.times if now - x < 2.0]
        return len(ts) / 2.0


def row_values(tr, now):
    m = tr.msg
    age = now - tr.t
    br = (f"{'ON' if m.get('brake') else 'off'} {m.get('brake_pct', 0)}% {m.get('brake_mode', '')}"
          if "brake" in m else "")
    ah = m.get("ahead")
    ahead = (f"{ah.get('name')} {ah.get('gap')} m" + (f", TTC {ah['ttc']} s" if ah.get("ttc") is not None else "")
             if isinstance(ah, dict) else "—")
    return {"topic": tr.topic, "status": m.get("status", "?") if age <= STALE_S else "STALE",
            "name": m.get("name", ""), "kmh": m.get("kmh", ""), "speed_pct": m.get("speed_pct", ""), "brake": br,
            "accel": m.get("accel", ""), "heading": m.get("heading", ""), "yaw_rate": m.get("yaw_rate", ""),
            "pos": f"{m.get('lat', '')}, {m.get('lon', '')}", "xy": f"{m.get('x', '')}, {m.get('y', '')}",
            "ahead": ahead, "rate": f"{tr.rate(now):.0f}", "age": f"{age:.1f}", "lost": tr.lost}


# ------------------------------------------------------------------------------------------------------------ CLI
def run_cli(a):
    try:
        sys.stdout.reconfigure(line_buffering=True)          # (each line at once, also into a file / pipe)
    except Exception:
        pass
    q = queue.Queue()
    r = Receiver(a, q)
    r.start()
    print(f"connecting to {a.host}:{a.port}, topic {r.topic_filter()} ... (Ctrl+C to stop)")
    trucks = {}
    try:
        while True:
            try:
                ev = q.get(timeout=0.5)
            except queue.Empty:
                now = time.time()
                for tr in trucks.values():
                    if tr.t and now - tr.t > STALE_S and not getattr(tr, "warned", False):
                        tr.warned = True
                        print(f"!! {tr.topic}: no message for {now - tr.t:.1f} s -- the vehicle should stop")
                continue
            if ev[0] == "conn":
                print("--", ev[2])
                continue
            _k, topic, payload, t = ev
            try:
                msg = json.loads(payload.decode("utf-8"))
            except Exception:
                print(f"{topic}: (not JSON) {payload[:120]!r}")
                continue
            if "av" not in msg and "truck" not in msg:               # (the status topic)
                fp = found_prefix(a, topic, msg, bool(trucks))
                if fp:
                    print(f"-- the app publishes under prefix '{fp}' (not '{a.prefix}'): listening there now")
                    r.use_prefix(fp)
                print(f"{topic}: {json.dumps(msg)}")
                continue
            if not topic.startswith(a.prefix.rstrip("/") + "/") and not a.topic:
                continue
            tr = trucks.setdefault(topic, Truck(topic))
            tr.add(msg, t)
            tr.warned = False
            v = row_values(tr, time.time())
            print(f"{time.strftime('%H:%M:%S')} {topic:<22} {v['status']:<8} {v['name']:<10} {v['kmh']:>5} km/h "
                  f"brake {v['brake']:<18} hdg {v['heading']:>5}  yaw {v['yaw_rate']:>5}  ({v['pos']})  "
                  f"ahead {v['ahead']}  lost {v['lost']}")
    except KeyboardInterrupt:
        pass
    finally:
        r.stop()


# ------------------------------------------------------------------------------------------------------------ GUI
def run_gui(a):
    import tkinter as tk
    from tkinter import ttk

    root = tk.Tk()
    root.title("MQTT hardware monitor -- collision test")
    root.geometry("1500x760")
    BG, FG, MUTED = "#0B1220", "#E5E7EB", "#94A3B8"
    root.configure(bg=BG)
    st = ttk.Style()
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass
    st.configure("Treeview", background="#0F172A", fieldbackground="#0F172A", foreground=FG, rowheight=24)
    st.configure("Treeview.Heading", background="#1F2937", foreground=FG)
    st.configure("TLabel", background=BG, foreground=FG)
    st.configure("TCheckbutton", background=BG, foreground=FG)
    st.configure("TFrame", background=BG)

    top = ttk.Frame(root); top.pack(fill="x", padx=10, pady=8)
    fields = {}
    for lab, key, w, val in (("Broker", "host", 18, a.host), ("Port", "port", 6, a.port), ("Prefix", "prefix", 16,
                             a.prefix), ("User", "user", 10, a.user or ""), ("Password", "password", 10,
                                                                             a.password or "")):
        ttk.Label(top, text=lab).pack(side="left", padx=(8, 3))
        if key == "host":                                  # (free public test brokers in the list)
            e = ttk.Combobox(top, width=w, values=["localhost"] + [b[0] for b in PUBLIC_BROKERS])
        else:
            e = ttk.Entry(top, width=w, show="*" if key == "password" else "")
        e.insert(0, str(val)); e.pack(side="left")
        fields[key] = e
    tls = tk.BooleanVar(value=bool(a.tls))
    ttk.Checkbutton(top, text="TLS", variable=tls).pack(side="left", padx=6)
    ttk.Label(top, text="CA").pack(side="left")
    ca = ttk.Entry(top, width=18); ca.insert(0, a.ca or ""); ca.pack(side="left")
    status = ttk.Label(top, text="not connected", foreground=MUTED); status.pack(side="right", padx=8)
    btn = ttk.Button(top, text="Connect"); btn.pack(side="left", padx=8)

    mid = ttk.Frame(root); mid.pack(fill="both", expand=True, padx=10)
    tree = ttk.Treeview(mid, columns=[c[0] for c in COLS], show="headings", height=8)
    for k, t, w in COLS:
        tree.heading(k, text=t); tree.column(k, width=w, anchor="w")
    tree.tag_configure("stale", foreground="#F87171")
    tree.tag_configure("brake", foreground="#FBBF24")
    tree.tag_configure("ok", foreground="#34D399")
    tree.pack(fill="x")
    low = ttk.Frame(mid); low.pack(fill="both", expand=True, pady=8)
    canvas = tk.Canvas(low, bg="#0F172A", highlightthickness=0, width=620)
    canvas.pack(side="left", fill="both", expand=True)
    right = ttk.Frame(low); right.pack(side="left", fill="both", expand=True, padx=(8, 0))
    ttk.Label(right, text="Selected topic -- last message (raw JSON):").pack(anchor="w")
    raw = tk.Text(right, bg="#0F172A", fg=FG, insertbackground=FG, height=14, font=("Consolas", 10))
    raw.pack(fill="both", expand=True)
    ttk.Label(right, text="Status topic / events:").pack(anchor="w", pady=(6, 0))
    events = tk.Text(right, bg="#0F172A", fg=MUTED, height=8, font=("Consolas", 9))
    events.pack(fill="both", expand=True)

    state = {"rx": None, "q": queue.Queue(), "trucks": {}, "sel": None}
    COLORS = ["#60A5FA", "#34D399", "#FBBF24", "#F472B6", "#A78BFA", "#22D3EE"]

    def log(text):
        events.insert("end", f"{time.strftime('%H:%M:%S')} {text}\n"); events.see("end")
        if int(events.index("end").split(".")[0]) > 400:
            events.delete("1.0", "100.0")

    def connect():
        if state["rx"] is not None:
            state["rx"].stop(); state["rx"] = None
            btn.configure(text="Connect"); status.configure(text="not connected", foreground=MUTED)
            return
        a.host, a.port = fields["host"].get().strip(), int(fields["port"].get() or 1883)
        a.prefix, a.user, a.password = fields["prefix"].get().strip(), fields["user"].get().strip(), fields["password"].get()
        a.tls, a.ca = tls.get(), ca.get().strip()
        try:
            r = Receiver(a, state["q"]); r.start()
        except Exception as e:
            status.configure(text=f"error: {e}", foreground="#F87171")
            return
        state["rx"] = r
        btn.configure(text="Disconnect")
        status.configure(text=f"connecting to {a.host}:{a.port} …", foreground="#FBBF24")
        log(f"subscribing to {r.topic_filter()}")
    btn.configure(command=connect)

    def on_select(_e=None):
        s = tree.selection()
        state["sel"] = s[0] if s else None
    tree.bind("<<TreeviewSelect>>", on_select)

    def draw():
        canvas.delete("all")
        W, H = canvas.winfo_width(), canvas.winfo_height()
        trs = list(state["trucks"].values())
        pts = [p for tr in trs for p in tr.trail]
        canvas.create_text(10, 10, anchor="nw", fill=MUTED, text="Track: x / y metres from the route start (north up)")
        if not pts:
            return
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
        span = max(20.0, max(xs) - min(xs), max(ys) - min(ys)) * 1.1
        k = min(W, H - 30) / span

        def sc(x, y):
            return W / 2 + (x - cx) * k, (H + 20) / 2 - (y - cy) * k
        for i, tr in enumerate(trs):
            col = COLORS[i % len(COLORS)]
            if len(tr.trail) > 1:
                canvas.create_line(*[c for p in tr.trail for c in sc(*p)], fill=col, width=1, dash=(2, 3))
            m = tr.msg
            if "x" not in m:
                continue
            px, py = sc(m["x"], m["y"])
            h = math.radians(m.get("heading", 0.0))
            stale = time.time() - tr.t > STALE_S
            fill = "#F87171" if stale else ("#FBBF24" if m.get("brake") else col)
            canvas.create_oval(px - 7, py - 7, px + 7, py + 7, fill=fill, outline="white")
            canvas.create_line(px, py, px + 18 * math.sin(h), py - 18 * math.cos(h), fill="white", width=2,
                               arrow="last")
            canvas.create_text(px + 10, py - 14, anchor="w", fill=col,
                               text=f"{m.get('name', tr.topic)}  {m.get('kmh', 0)} km/h"
                                    + ("  BRAKE" if m.get("brake") else "") + ("  STALE" if stale else ""))

    def poll():
        q = state["q"]
        n = 0
        while not q.empty() and n < 2000:
            ev = q.get_nowait(); n += 1
            if ev[0] == "conn":
                status.configure(text=ev[2], foreground="#34D399" if ev[1] else "#F87171")
                log(ev[2])
                continue
            _k, topic, payload, t = ev
            try:
                msg = json.loads(payload.decode("utf-8"))
            except Exception:
                log(f"{topic}: not JSON ({len(payload)} bytes)")
                continue
            if "av" not in msg and "truck" not in msg:               # (the status topic)
                fp = found_prefix(a, topic, msg, bool(state["trucks"]))
                if fp and state["rx"] is not None:
                    log(f"the app publishes under prefix '{fp}' (not '{a.prefix}') -- listening there now")
                    state["rx"].use_prefix(fp)
                    fields["prefix"].delete(0, "end"); fields["prefix"].insert(0, fp)
                log(f"{topic}: {json.dumps(msg)[:300]}")
                continue
            if not topic.startswith(a.prefix.rstrip("/") + "/") and not a.topic:
                continue
            tr = state["trucks"].get(topic)
            if tr is None:
                tr = state["trucks"][topic] = Truck(topic)
                tree.insert("", "end", iid=topic, values=[""] * len(COLS))
                log(f"new AV topic: {topic}")
            prev = tr.msg.get("status")
            tr.add(msg, t)
            if prev != msg.get("status"):
                log(f"{topic}: status {prev} -> {msg.get('status')}")
        now = time.time()
        for topic in sorted(state["trucks"]):
            tr = state["trucks"][topic]
            v = row_values(tr, now)
            tag = "stale" if v["status"] in ("STALE", "ended") else "brake" if tr.msg.get("brake") else "ok"
            tree.item(topic, values=[v[c[0]] for c in COLS], tags=(tag,))
        sel = state["sel"] or (sorted(state["trucks"])[0] if state["trucks"] else None)
        if sel in state["trucks"]:
            raw.delete("1.0", "end"); raw.insert("1.0", f"{sel}\n" + json.dumps(state["trucks"][sel].msg, indent=1))
        draw()
        root.after(150, poll)

    root.after(150, poll)
    if a.autoconnect:
        root.after(200, connect)
    root.protocol("WM_DELETE_WINDOW", lambda: (state["rx"] and state["rx"].stop(), root.destroy()))
    root.mainloop()


def main():
    p = argparse.ArgumentParser(description="Shows the collision test's MQTT messages for hardware vehicles")
    p.add_argument("--host", default="localhost")
    p.add_argument("--port", type=int, default=1883)
    p.add_argument("--prefix", default="yardsim/hw", help="the topic prefix set in the app (subscribes <prefix>/#)")
    p.add_argument("--topic", default="", help="any topic filter instead of <prefix>/#")
    p.add_argument("--user", default="")
    p.add_argument("--password", default="")
    p.add_argument("--tls", action="store_true")
    p.add_argument("--ca", default="", help="CA certificate file (TLS)")
    p.add_argument("--cli", action="store_true", help="no window: print one line per message")
    a = p.parse_args()
    a.autoconnect = any(x.startswith("--host") for x in sys.argv[1:])
    run_cli(a) if a.cli else run_gui(a)


if __name__ == "__main__":
    main()
