"""Ubuntu 22.04 runs Python 3.10: find f-strings that Python 3.12 (Windows) accepts but 3.10 / 3.11 reject
(PEP 701) -- inside a replacement field {...}: the same quote as the f-string, a backslash, a line break (one-line
f-string), a '#' comment. Such a line stops the app on Ubuntu with "SyntaxError: f-string: ...".
Run by tools/pack_for_ubuntu.ps1 before packing (exit code 1: problems found). Needs Python 3.12+ to run.
Usage: python tools/check_py310.py [project folder]"""
import io, os, sys, tokenize

if not hasattr(tokenize, "FSTRING_START"):
    print("check_py310: needs Python 3.12+ to run -- skipped")
    sys.exit(0)
root = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
bad = []
for dp, dn, fn in os.walk(root):
    dn[:] = [d for d in dn if d not in (".venv", "__pycache__", ".git", "node_modules")]
    for f in fn:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        try:
            src = open(p, encoding="utf-8").read()
            toks = list(tokenize.generate_tokens(io.StringIO(src).readline))
        except Exception as e:
            bad.append((p, 0, f"could not tokenize: {e}"))
            continue
        stack = []                     # [quote, triple, brace depth]
        for t in toks:
            if t.type == tokenize.FSTRING_START:
                if stack and stack[-1][2] > 0:
                    q = t.string.lstrip("rRfFbBuU")[:1]
                    if q == stack[-1][0] and (not stack[-1][1] or t.string.lstrip("rRfFbBuU")[:3] == q * 3):
                        bad.append((p, t.start[0], "nested f-string with the same quote"))
                    if t.string.lstrip("rRfFbBuU")[:3] in ('"""', "'''") and not stack[-1][1]:
                        pass
                body = t.string.lstrip("rRfFbBuU")
                stack.append([body[:1], body[:3] in ('"""', "'''"), 0])
                continue
            if not stack:
                continue
            top = stack[-1]
            if t.type == tokenize.FSTRING_END:
                stack.pop()
                continue
            if t.type == tokenize.OP and t.string == "{":
                top[2] += 1
            elif t.type == tokenize.OP and t.string == "}":
                top[2] = max(0, top[2] - 1)
            elif top[2] > 0:
                if t.type == tokenize.STRING:
                    body = t.string.lstrip("rRbBuU")
                    if body[:1] == top[0] and (not top[1] or body[:3] == top[0] * 3):
                        bad.append((p, t.start[0], "string with the same quote inside {}"))
                    if "\\" in t.string:
                        bad.append((p, t.start[0], "backslash inside {}"))
                elif t.type in (tokenize.NL, tokenize.NEWLINE) and not top[1]:
                    bad.append((p, t.start[0], "line break inside {} of a one-line f-string"))
                elif t.type == tokenize.COMMENT:
                    bad.append((p, t.start[0], "comment inside {}"))
            if t.type == tokenize.FSTRING_MIDDLE and top[2] > 0 and "\\" in t.string:
                bad.append((p, t.start[0], "backslash inside a nested format spec"))
seen = set()
for p, ln, why in bad:
    if (p, ln) in seen:
        continue
    seen.add((p, ln))
    print(f"{os.path.relpath(p, root)}:{ln}: {why}")
print(f"Python 3.10 check: {len(seen)} problem line(s)")
sys.exit(1 if seen else 0)
